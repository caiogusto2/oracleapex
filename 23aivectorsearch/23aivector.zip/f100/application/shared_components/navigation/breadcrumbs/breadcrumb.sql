prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>7713964287076301
,p_default_application_id=>100
,p_default_id_offset=>7717210277088665
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(25817092042785221)
,p_name=>'Breadcrumb'
);
wwv_flow_imp.component_end;
end;
/
