prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>7713964287076301
,p_default_application_id=>100
,p_default_id_offset=>7717210277088665
,p_default_owner=>'DEMO'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Home'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.background-red {',
'    background-color: lightgrey;',
'    /*color: white; /* Optional: text color */',
'}',
'',
'/* Class for green background */',
'.background-green {',
'    background-color: lightgreen;',
'    /*color: white; /* Optional: text color */',
'}',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(26219558347861942)
,p_plug_name=>unistr('Distribui\00E7\00E3o Geospacial')
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_location=>null
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(26219595316861943)
,p_region_id=>wwv_flow_imp.id(26219558347861942)
,p_height=>400
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(26219674309861944)
,p_map_region_id=>wwv_flow_imp.id(26219595316861943)
,p_name=>'Bases2023'
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>'select distinct id, local, latitude, longitude from embarcacoes where ano = 2023 order by 1;'
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_stroke_color=>'#000000'
,p_fill_color=>'#ff3b30'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_info_window_adv_formatting=>false
,p_info_window_title_column=>'LOCAL'
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(26220308111861950)
,p_map_region_id=>wwv_flow_imp.id(26219595316861943)
,p_name=>'Bases2022'
,p_layer_type=>'POINT'
,p_display_sequence=>20
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>'select distinct id, local, latitude, longitude from embarcacoes where ano = 2022 order by 1;'
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_stroke_color=>'#000000'
,p_fill_color=>'#4cd964'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_info_window_adv_formatting=>false
,p_info_window_title_column=>'LOCAL'
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(26220421088861951)
,p_map_region_id=>wwv_flow_imp.id(26219595316861943)
,p_name=>'Bases2021'
,p_layer_type=>'POINT'
,p_display_sequence=>30
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>'select distinct id, local, latitude, longitude from embarcacoes where ano = 2021 order by 1;'
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_stroke_color=>'#000000'
,p_fill_color=>'#5856d6'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_info_window_adv_formatting=>false
,p_info_window_title_column=>'LOCAL'
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(26220481281861952)
,p_map_region_id=>wwv_flow_imp.id(26219595316861943)
,p_name=>'Bases2020'
,p_layer_type=>'POINT'
,p_display_sequence=>40
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>'select distinct id, local, latitude, longitude from embarcacoes where ano = 2020 order by 1;'
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_stroke_color=>'#000000'
,p_fill_color=>'#8e8e93'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_info_window_adv_formatting=>false
,p_info_window_title_column=>'LOCAL'
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(26220617094861953)
,p_map_region_id=>wwv_flow_imp.id(26219595316861943)
,p_name=>'Bases2019'
,p_layer_type=>'POINT'
,p_display_sequence=>50
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>'select distinct id, local, latitude, longitude from embarcacoes where ano = 2019 order by 1;'
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_stroke_color=>'#000000'
,p_fill_color=>'#ffcc00'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_info_window_adv_formatting=>false
,p_info_window_title_column=>'LOCAL'
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(26219851617861945)
,p_plug_name=>'Dashboard em Tempo Real'
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(26219924673861946)
,p_region_id=>wwv_flow_imp.id(26219851617861945)
,p_chart_type=>'pie'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(26219995747861947)
,p_chart_id=>wwv_flow_imp.id(26219924673861946)
,p_seq=>10
,p_name=>'New'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    EMBARCACAO,',
'    SUM(QTDE) AS SOMATORIO',
'FROM',
'EMBARCACOES',
'WHERE ANO = 2023',
'GROUP BY EMBARCACAO',
'ORDER BY 2 DESC;'))
,p_items_value_column_name=>'SOMATORIO'
,p_items_label_column_name=>'EMBARCACAO'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(26838728095455928)
,p_plug_name=>unistr('Ano a Ano e Predi\00E7\00E3o Usando OML')
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(26838836587455929)
,p_region_id=>wwv_flow_imp.id(26838728095455928)
,p_chart_type=>'line'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(26838899358455930)
,p_chart_id=>wwv_flow_imp.id(26838836587455929)
,p_seq=>10
,p_name=>'Valor'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    EXTRACT(YEAR FROM CASE_ID) AS CASE_YEAR,  -- Extract the year from CASE_ID',
'    VALUE AS QTDE,',
'    PREDICTION',
'FROM DM$P0ESM_HOUSEHOLD_MDL_YEAR',
'ORDER BY CASE_ID;',
''))
,p_items_value_column_name=>'QTDE'
,p_items_label_column_name=>'CASE_YEAR'
,p_color=>'#000000'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'on'
,p_marker_shape=>'circle'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(26840528046455946)
,p_chart_id=>wwv_flow_imp.id(26838836587455929)
,p_seq=>20
,p_name=>unistr('Predi\00E7\00E3o')
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    EXTRACT(YEAR FROM CASE_ID) AS CASE_YEAR,  -- Extract the year from CASE_ID',
'    VALUE AS QTDE,',
'    PREDICTION',
'FROM DM$P0ESM_HOUSEHOLD_MDL_YEAR',
'ORDER BY CASE_ID;',
''))
,p_items_value_column_name=>'PREDICTION'
,p_items_label_column_name=>'CASE_YEAR'
,p_color=>'#4cd964'
,p_line_style=>'dashed'
,p_line_type=>'auto'
,p_marker_rendered=>'on'
,p_marker_shape=>'circle'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(26838970862455931)
,p_chart_id=>wwv_flow_imp.id(26838836587455929)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(26839097300455932)
,p_chart_id=>wwv_flow_imp.id(26838836587455929)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(26839253430455933)
,p_plug_name=>'Qtde Ano a Ano'
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(26839319772455934)
,p_region_id=>wwv_flow_imp.id(26839253430455933)
,p_chart_type=>'bar'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'value-desc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(26839447146455935)
,p_chart_id=>wwv_flow_imp.id(26839319772455934)
,p_seq=>10
,p_name=>'New'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    ESTADO, ',
'    ANO, ',
'    SUM(QTDE) AS SOMATORIO ',
'FROM EMBARCACOES ',
'WHERE ANO IN (''2023'',''2022'',''2021'',''2020'',''2019'')',
'GROUP BY ANO, ESTADO ',
'ORDER BY SOMATORIO DESC, ANO;'))
,p_series_name_column_name=>'ANO'
,p_items_value_column_name=>'SOMATORIO'
,p_items_label_column_name=>'ESTADO'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(26839467148455936)
,p_chart_id=>wwv_flow_imp.id(26839319772455934)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(26839583246455937)
,p_chart_id=>wwv_flow_imp.id(26839319772455934)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(26839788903455939)
,p_plug_name=>'Home'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--featured'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>60
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(25817092042785221)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
,p_region_image=>'#APP_FILES#icons/app-icon-512.png	'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(26840454025455945)
,p_plug_name=>'Fonte de Dados'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>60
,p_plug_display_point=>'REGION_POSITION_05'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h5>',
'    <spawn>Fonte de dados:</spawn>',
'    <a href="https://dados.gov.br/dados/organizacoes/visualizar/marinha-do-brasil" target="_blank">https://dados.gov.br/dados/organizacoes/visualizar/marinha-do-brasil</a>',
'</h5>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(44132668842097035)
,p_plug_name=>'Busca In/Out'
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>70
,p_location=>null
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(44132861279097036)
,p_region_id=>wwv_flow_imp.id(44132668842097035)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_layer_messages_position=>'BELOW'
,p_show_legend=>false
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(44132907309097037)
,p_map_region_id=>wwv_flow_imp.id(44132861279097036)
,p_name=>'Polygon'
,p_layer_type=>'POLYGON'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_table_name=>'GEOPOLYGON'
,p_include_rowid_column=>false
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOPOLYGON'
,p_stroke_color=>'#101010'
,p_fill_color_is_spectrum=>false
,p_fill_opacity=>.4
,p_tooltip_adv_formatting=>false
,p_info_window_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(44133042321097038)
,p_map_region_id=>wwv_flow_imp.id(44132861279097036)
,p_name=>'Endereco'
,p_layer_type=>'POINT'
,p_display_sequence=>20
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_table_name=>'LOCTEMP'
,p_include_rowid_column=>false
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOPOLYGON'
,p_stroke_color=>'#000000'
,p_fill_color=>'#ff3b30'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_point_svg_shape_scale=>'2'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_info_window_adv_formatting=>false
,p_display_in_legend=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47099206769251331)
,p_plug_name=>'Grafos'
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>80
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT origem,transferencia,destino',
'FROM GRAPH_TABLE (',
'    grafotransferencia',
'    MATCH (uOrigem) -[e]-> (uDestino)',
'    WHERE uOrigem."ID_UNIDADE" IS NOT NULL AND uDestino."ID_UNIDADE" IS NOT NULL',
'    COLUMNS (',
'        vertex_id(uOrigem) AS origem,',
'        edge_id(e) AS transferencia,',
'        vertex_id(uDestino) AS destino',
'    )',
')',
''))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_02', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '    "evolution": {',
    '        "chart": "line",',
    '        "unit": "month",',
    '        "edge": "properties.DATA_TRANSFERENCIA",',
    '        "preservePositions":"true"',
    '    }',
    '}')),
  'attribute_03', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '   "vertex":{',
    '    "size":12,',
    '    "label":"${properties.NOME} - ${properties.LOCALIZACAO}",',
    '    "icon":{',
    '        "class":"oj-ux-ico-location-pin-s",',
    '        "color":"red"',
    '    },',
    '    "color":"white",',
    '    "border":{',
    '               "width":1,',
    '               "color":"black"',
    '            }',
    '   }',
    '}')),
  'attribute_04', 'force',
  'attribute_05', 'N',
  'attribute_14', 'N',
  'attribute_16', '640',
  'custom_theme', 'N',
  'darktheme', 'N',
  'edgemarker', 'none',
  'enable_evolution', 'N',
  'escapehtml', 'N',
  'force_clusterenabled', 'N',
  'livesearch', 'N',
  'show_legend', 'N',
  'showtitle', 'N',
  'size_mode', 'compact',
  'spacing', '10')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(47100070248251340)
,p_name=>'ORIGEM'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(47100209444251341)
,p_name=>'TRANSFERENCIA'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(47100350377251342)
,p_name=>'DESTINO'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47101251600251351)
,p_plug_name=>'Grafos + Geospacial'
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>90
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT origem,transferencia,destino',
'FROM GRAPH_TABLE (',
'    grafotransferencia',
'    MATCH (uOrigem) -[e]-> (uDestino)',
'    WHERE uOrigem."ID_UNIDADE" IS NOT NULL AND uDestino."ID_UNIDADE" IS NOT NULL',
'    COLUMNS (',
'        vertex_id(uOrigem) AS origem,',
'        edge_id(e) AS transferencia,',
'        vertex_id(uDestino) AS destino',
'    )',
')',
''))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_02', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '    "evolution": {',
    '        "chart": "line",',
    '        "unit": "month",',
    '        "edge": "properties.DATA_TRANSFERENCIA"',
    '    }',
    '}')),
  'attribute_03', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '   "vertex":{',
    '    "size":12,',
    '    "label":"${properties.NOME} - ${properties.LOCALIZACAO}",',
    '    "icon":{',
    '        "class":"oj-ux-ico-location-pin-s",',
    '        "color":"red"',
    '    },',
    '    "color":"white",',
    '    "border":{',
    '               "width":1,',
    '               "color":"black"',
    '            }',
    '   },',
    '    "edge": {',
    '    "color": "red",',
    '    "legend": "edge",',
    '    "width": 2',
    '  }',
    '}')),
  'attribute_04', 'geographical',
  'attribute_05', 'N',
  'attribute_14', 'N',
  'attribute_16', '640',
  'custom_theme', 'N',
  'darktheme', 'N',
  'edgemarker', 'none',
  'enable_evolution', 'N',
  'escapehtml', 'N',
  'geo_maptype', 'osm_positron',
  'geo_showinfo', 'N',
  'geo_shownavigation', 'N',
  'livesearch', 'N',
  'show_legend', 'N',
  'showtitle', 'N',
  'size_mode', 'compact')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(47101325122251352)
,p_name=>'ORIGEM'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(47101433087251353)
,p_name=>'TRANSFERENCIA'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(47101468358251354)
,p_name=>'DESTINO'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(44133395731097042)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(44132668842097035)
,p_button_name=>'Submit'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Buscar'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44133118494097039)
,p_name=>'P1_INPUT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(44132668842097035)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Endere\00E7o')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'text_case', 'UPPER',
  'trim_spaces', 'BOTH')).to_clob
,p_show_quick_picks=>'Y'
,p_quick_pick_label_01=>'Oracle Brasil'
,p_quick_pick_value_01=>unistr('Rua Dr. Jos\00E9 \00C1ureo Bustamante, 455 - Ch\00E1cara Santo Ant\00F4nio, S\00E3o Paulo - SP')
,p_quick_pick_label_02=>unistr('Itaquer\00E3o')
,p_quick_pick_value_02=>unistr('ITAQUER\00C3O SAO PAULO SP')
,p_quick_pick_label_03=>unistr('Pra\00E7a da S\00E9')
,p_quick_pick_value_03=>unistr('CATEDRAL PRA\00C7A DA S\00C9 S\00C3O PAULO')
,p_quick_pick_label_04=>'Allianz Parque'
,p_quick_pick_value_04=>'ALLIANZ PARQUE SAO PAULO SP'
,p_quick_pick_label_05=>'Pref Sorocaba'
,p_quick_pick_value_05=>'Av. Eng. Carlos Reinaldo Mendes, 3041 - Alto da Boa Vista, Sorocaba'
,p_quick_pick_label_06=>'Aeroporto Guarulhos'
,p_quick_pick_value_06=>unistr('Rod. H\00E9lio Smidt, s/n\00BA - Aeroporto, Guarulhos - SP')
,p_quick_pick_label_07=>'Vila Belmiro'
,p_quick_pick_value_07=>'Rua Princesa Isabel, S/N, Vila Belmiro, Santos - SP'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44133262201097040)
,p_name=>'P1_OUTPUT'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(44132668842097035)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Output'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44133295768097041)
,p_name=>'P1_TEMP'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(44132668842097035)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44134197406097050)
,p_name=>'P1_CODE01'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(44132668842097035)
,p_prompt=>'Geocoding'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_address_line    VARCHAR2(4000) := :P1_INPUT;',
'    v_geocode_result  SDO_GEOMETRY; -- Assuming that the geocode result is a geometry object',
'BEGIN',
'    -- Fetch the geocode result and store it into a variable',
'    SELECT SDO_GCDR.ELOC_GEOCODE(v_address_line)',
'    INTO :P1_TEMP',
'    FROM dual;',
'',
'    -- Further processing can be done here if needed (e.g., store the result in a table)',
'END;'))
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_required_patch=>wwv_flow_imp.id(25816561808785208)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44134361155097051)
,p_name=>'P1_CODE02'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(44132668842097035)
,p_prompt=>'Geocoding'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_json      VARCHAR2(32767) := :P1_TEMP;',
'    l_text      VARCHAR2(4000);',
'    v_containment_status VARCHAR2(4000);',
'    v_latitude  NUMBER;',
'    v_longitude NUMBER;',
'    v_id        VARCHAR2(10);',
'    v_matchCount NUMBER;',
'BEGIN',
'',
'SELECT jt.id, ',
'       jt.matchCount, ',
'       jt.x AS longitude, ',
'       jt.y AS latitude',
'  INTO v_id, ',
'       v_matchCount, ',
'       v_longitude, ',
'       v_latitude',
'FROM dual, ',
'     JSON_TABLE(l_json, ''$[*]''',
'       COLUMNS (',
'         id VARCHAR2(10) PATH ''$.id'',',
'         matchCount NUMBER PATH ''$.matchCount'',',
'         NESTED PATH ''$.matches[*]'' ',
'         COLUMNS (',
'           x NUMBER PATH ''$.x'',',
'           y NUMBER PATH ''$.y''',
'         )',
'       )',
'     ) jt;',
'',
'    -- Truncate the loctemp table',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE loctemp'';',
'',
'    -- Insert the new data into loctemp',
'    INSERT INTO loctemp (endereco, geopolygon)',
'    VALUES (',
'        :P1_INPUT,',
'        SDO_GEOMETRY(',
'        2001, -- Point type',
'        8307, -- SRS ID (null for default)',
'        SDO_POINT_TYPE(v_longitude, v_latitude, NULL), -- Longitude, Latitude',
'        NULL, -- No ordinates for point',
'        NULL  -- No point array',
'    ));',
'',
'    COMMIT;',
'',
'    -- Get the containment status',
'    SELECT ',
'        CASE ',
unistr('            WHEN COUNT(*) > 0 THEN ''O ENDERE\00C7O FORNECIDO ENCONTRA-SE DENTRO DA CIDADE DE SP'''),
unistr('            ELSE ''O ENDERE\00C7O FORNECIDO N\00C3O SE ENCONTRA DENTRO DA CIDADE DE SP'''),
'        END AS containment_status',
'    INTO v_containment_status',
'    FROM ',
'        geopolygon g',
'    WHERE ',
'        SDO_INSIDE(SDO_GEOMETRY(',
'            2001, -- Point type',
'            8307, -- SRS ID (null for default)',
'            SDO_POINT_TYPE(v_longitude, v_latitude, NULL), -- Longitude, Latitude',
'            NULL, -- No ordinates for point',
'            NULL  -- No point array',
'        ), g.geopolygon) = ''TRUE'';',
'',
'    -- Assign the containment status to P2_OUTPUT2',
'    :P1_OUTPUT := v_containment_status;',
'',
'END;'))
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_required_patch=>wwv_flow_imp.id(25816561808785208)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(44133491229097043)
,p_name=>'CSS'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_OUTPUT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44133619353097044)
,p_event_id=>wwv_flow_imp.id(44133491229097043)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ADD_CLASS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_OUTPUT'
,p_attribute_01=>'background-green'
,p_server_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_server_condition_expr1=>'P1_OUTPUT'
,p_server_condition_expr2=>unistr('O ENDERE\00C7O FORNECIDO ENCONTRA-SE DENTRO DA CIDADE DE SP')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44133686779097045)
,p_event_id=>wwv_flow_imp.id(44133491229097043)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ADD_CLASS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_OUTPUT'
,p_attribute_01=>'background-red'
,p_server_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_server_condition_expr1=>'P1_OUTPUT'
,p_server_condition_expr2=>unistr('O ENDERE\00C7O FORNECIDO N\00C3O SE ENCONTRA DENTRO DA CIDADE DE SP')
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(47101685895251356)
,p_name=>'GeoCoding'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(44133395731097042)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47101886837251358)
,p_event_id=>wwv_flow_imp.id(47101685895251356)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'GeoCoding'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_address_line    VARCHAR2(4000) := :P1_INPUT;',
'    v_geocode_result  SDO_GEOMETRY; -- Assuming that the geocode result is a geometry object',
'BEGIN',
'    -- Fetch the geocode result and store it into a variable',
'    SELECT SDO_GCDR.ELOC_GEOCODE(v_address_line)',
'    INTO :P1_TEMP',
'    FROM dual;',
'',
'    -- Further processing can be done here if needed (e.g., store the result in a table)',
'END;',
''))
,p_attribute_02=>'P1_INPUT'
,p_attribute_03=>'P1_TEMP'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47101992420251359)
,p_event_id=>wwv_flow_imp.id(47101685895251356)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'GeoParse'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_json      VARCHAR2(32767) := :P1_TEMP;',
'    l_text      VARCHAR2(4000);',
'    v_containment_status VARCHAR2(4000);',
'    v_latitude  NUMBER;',
'    v_longitude NUMBER;',
'    v_id        VARCHAR2(10);',
'    v_matchCount NUMBER;',
'BEGIN',
'',
'SELECT jt.id, ',
'       jt.matchCount, ',
'       jt.x AS longitude, ',
'       jt.y AS latitude',
'  INTO v_id, ',
'       v_matchCount, ',
'       v_longitude, ',
'       v_latitude',
'FROM dual, ',
'     JSON_TABLE(l_json, ''$[*]''',
'       COLUMNS (',
'         id VARCHAR2(10) PATH ''$.id'',',
'         matchCount NUMBER PATH ''$.matchCount'',',
'         NESTED PATH ''$.matches[*]'' ',
'         COLUMNS (',
'           x NUMBER PATH ''$.x'',',
'           y NUMBER PATH ''$.y''',
'         )',
'       )',
'     ) jt;',
'',
'    -- Truncate the loctemp table',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE loctemp'';',
'',
'    -- Insert the new data into loctemp',
'    INSERT INTO loctemp (endereco, geopolygon)',
'    VALUES (',
'        :P1_INPUT,',
'        SDO_GEOMETRY(',
'        2001, -- Point type',
'        8307, -- SRS ID (null for default)',
'        SDO_POINT_TYPE(v_longitude, v_latitude, NULL), -- Longitude, Latitude',
'        NULL, -- No ordinates for point',
'        NULL  -- No point array',
'    ));',
'',
'    COMMIT;',
'',
'    -- Get the containment status',
'    SELECT ',
'        CASE ',
unistr('            WHEN COUNT(*) > 0 THEN ''O ENDERE\00C7O FORNECIDO ENCONTRA-SE DENTRO DA CIDADE DE SP'''),
unistr('            ELSE ''O ENDERE\00C7O FORNECIDO N\00C3O SE ENCONTRA DENTRO DA CIDADE DE SP'''),
'        END AS containment_status',
'    INTO v_containment_status',
'    FROM ',
'        geopolygon g',
'    WHERE ',
'        SDO_INSIDE(SDO_GEOMETRY(',
'            2001, -- Point type',
'            8307, -- SRS ID (null for default)',
'            SDO_POINT_TYPE(v_longitude, v_latitude, NULL), -- Longitude, Latitude',
'            NULL, -- No ordinates for point',
'            NULL  -- No point array',
'        ), g.geopolygon) = ''TRUE'';',
'',
'    -- Assign the containment status to P2_OUTPUT2',
'    :P1_OUTPUT := v_containment_status;',
'',
'END;',
''))
,p_attribute_02=>'P1_TEMP'
,p_attribute_03=>'P1_OUTPUT'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47102544794251364)
,p_event_id=>wwv_flow_imp.id(47101685895251356)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ADD_CLASS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_OUTPUT'
,p_attribute_01=>'background-green'
,p_server_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_server_condition_expr1=>'P1_OUTPUT'
,p_server_condition_expr2=>unistr('O ENDERE\00C7O FORNECIDO ENCONTRA-SE DENTRO DA CIDADE DE SP')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47102578280251365)
,p_event_id=>wwv_flow_imp.id(47101685895251356)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ADD_CLASS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_OUTPUT'
,p_attribute_01=>'background-red'
,p_server_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_server_condition_expr1=>'P1_OUTPUT'
,p_server_condition_expr2=>unistr('O ENDERE\00C7O FORNECIDO N\00C3O SE ENCONTRA DENTRO DA CIDADE DE SP')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47102175667251361)
,p_event_id=>wwv_flow_imp.id(47101685895251356)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(44132668842097035)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(44132329568097031)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Execution Chain'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>28791462805574016
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(44132371608097032)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(44132329568097031)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Geocode'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_address_line    VARCHAR2(4000) := :P1_INPUT;',
'    v_geocode_result  SDO_GEOMETRY; -- Assuming that the geocode result is a geometry object',
'BEGIN',
'    -- Fetch the geocode result and store it into a variable',
'    SELECT SDO_GCDR.ELOC_GEOCODE(v_address_line)',
'    INTO :P1_TEMP',
'    FROM dual;',
'',
'    -- Further processing can be done here if needed (e.g., store the result in a table)',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>28791504845574017
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(44132557856097033)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(44132329568097031)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Geoparse'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_json      VARCHAR2(32767) := :P1_TEMP;',
'    l_text      VARCHAR2(4000);',
'    v_containment_status VARCHAR2(4000);',
'    v_latitude  NUMBER;',
'    v_longitude NUMBER;',
'    v_id        VARCHAR2(10);',
'    v_matchCount NUMBER;',
'BEGIN',
'',
'SELECT jt.id, ',
'       jt.matchCount, ',
'       jt.x AS longitude, ',
'       jt.y AS latitude',
'  INTO v_id, ',
'       v_matchCount, ',
'       v_longitude, ',
'       v_latitude',
'FROM dual, ',
'     JSON_TABLE(l_json, ''$[*]''',
'       COLUMNS (',
'         id VARCHAR2(10) PATH ''$.id'',',
'         matchCount NUMBER PATH ''$.matchCount'',',
'         NESTED PATH ''$.matches[*]'' ',
'         COLUMNS (',
'           x NUMBER PATH ''$.x'',',
'           y NUMBER PATH ''$.y''',
'         )',
'       )',
'     ) jt;',
'',
'    -- Truncate the loctemp table',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE loctemp'';',
'',
'    -- Insert the new data into loctemp',
'    INSERT INTO loctemp (endereco, geopolygon)',
'    VALUES (',
'        :P1_INPUT,',
'        SDO_GEOMETRY(',
'        2001, -- Point type',
'        8307, -- SRS ID (null for default)',
'        SDO_POINT_TYPE(v_longitude, v_latitude, NULL), -- Longitude, Latitude',
'        NULL, -- No ordinates for point',
'        NULL  -- No point array',
'    ));',
'',
'    COMMIT;',
'',
'    -- Get the containment status',
'    SELECT ',
'        CASE ',
unistr('            WHEN COUNT(*) > 0 THEN ''O ENDERE\00C7O FORNECIDO ENCONTRA-SE DENTRO DA CIDADE DE SP'''),
unistr('            ELSE ''O ENDERE\00C7O FORNECIDO N\00C3O SE ENCONTRA DENTRO DA CIDADE DE SP'''),
'        END AS containment_status',
'    INTO v_containment_status',
'    FROM ',
'        geopolygon g',
'    WHERE ',
'        SDO_INSIDE(SDO_GEOMETRY(',
'            2001, -- Point type',
'            8307, -- SRS ID (null for default)',
'            SDO_POINT_TYPE(v_longitude, v_latitude, NULL), -- Longitude, Latitude',
'            NULL, -- No ordinates for point',
'            NULL  -- No point array',
'        ), g.geopolygon) = ''TRUE'';',
'',
'    -- Assign the containment status to P2_OUTPUT2',
'    :P1_OUTPUT := v_containment_status;',
'',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>28791691093574018
);
wwv_flow_imp.component_end;
end;
/
