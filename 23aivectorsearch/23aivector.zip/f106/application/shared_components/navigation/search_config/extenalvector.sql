prompt --application/shared_components/navigation/search_config/extenalvector
begin
--   Manifest
--     SEARCH CONFIG: Extenalvector
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>34366086255793542
,p_default_application_id=>106
,p_default_id_offset=>9519496963955951
,p_default_owner=>'DEMOS'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(13706080997808678)
,p_label=>'Extenalvector'
,p_static_id=>'extenalvector'
,p_search_type=>'VECTOR'
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_query_table=>'DOC_CHUNKS'
,p_searchable_columns=>'EMBED_DATA'
,p_oratext_index_column_name=>'EMBED_VECTOR_EXT'
,p_vector_provider_id =>wwv_flow_imp.id(13704241367724021)
,p_vector_search_type=>'EXACT'
,p_vector_distance_metric=>'COSINE'
,p_return_max_results=>100
,p_pk_column_name=>'EMBED_ID'
,p_title_column_name=>'DOC_ID'
,p_description_column_name=>'EMBED_DATA'
,p_icon_source_type=>'INITIALS'
,p_version_scn=>4675262
);
wwv_flow_imp.component_end;
end;
/
