prompt --application/shared_components/navigation/search_config/infloatvector
begin
--   Manifest
--     SEARCH CONFIG: InfloatVector
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>34366086255793542
,p_default_application_id=>106
,p_default_id_offset=>9519496963955951
,p_default_owner=>'DEMOS'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(11045213260506963)
,p_label=>'InfloatVector'
,p_static_id=>'InfloatVector'
,p_search_type=>'VECTOR'
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_query_table=>'DOC_CHUNKS'
,p_oratext_index_column_name=>'EMBED_VECTOR'
,p_vector_provider_id =>wwv_flow_imp.id(10995215507218208)
,p_vector_search_type=>'EXACT'
,p_vector_distance_metric=>'COSINE'
,p_return_max_results=>10
,p_pk_column_name=>'EMBED_ID'
,p_title_column_name=>'EMBED_DATA'
,p_description_column_name=>'DOC_ID'
,p_icon_source_type=>'INITIALS'
,p_version_scn=>4675057
);
wwv_flow_imp.component_end;
end;
/
