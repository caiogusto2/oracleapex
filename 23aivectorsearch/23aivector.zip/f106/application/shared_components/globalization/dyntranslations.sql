prompt --application/shared_components/globalization/dyntranslations
begin
--   Manifest
--     DYNAMIC TRANSLATIONS: 106
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>34366086255793542
,p_default_application_id=>106
,p_default_id_offset=>9519496963955951
,p_default_owner=>'DEMOS'
);
null;
wwv_flow_imp.component_end;
end;
/
