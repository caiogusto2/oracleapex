prompt --application/shared_components/web_sources/cohere_chat
begin
--   Manifest
--     WEB SOURCE: Cohere-Chat
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>34366086255793542
,p_default_application_id=>106
,p_default_id_offset=>9519496963955951
,p_default_owner=>'DEMOS'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(48570407182867844)
,p_name=>'Cohere-Chat'
,p_static_id=>'cohere_chat'
,p_web_source_type=>'NATIVE_OCI'
,p_data_profile_id=>wwv_flow_imp.id(48569581923867837)
,p_remote_server_id=>wwv_flow_imp.id(61819691584803473)
,p_url_path_prefix=>'chat'
,p_credential_id=>wwv_flow_imp.id(58794761201499574)
,p_version_scn=>39555469930221
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(48570761951867847)
,p_web_src_module_id=>wwv_flow_imp.id(48570407182867844)
,p_operation=>'POST'
,p_url_pattern=>'.'
,p_request_body_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'	"chatRequest":{',
'		"apiFormat":"COHERE",',
'		"message":"#MESSAGE#",',
'                "maxTokens":"1800",',
'                "temperature":"0"',
'	},',
'	"compartmentId":"ocid1.compartment.oc1..aaaaaaaacqt2kvaoyjexiops224rzriooevivs63hxhpzjxzwbvadqcgsfha",',
'	"servingMode":{',
'		"servingType":"ON_DEMAND",',
'		"modelId":"cohere.command-r-plus-08-2024"',
'	}',
'}'))
,p_force_error_for_http_404=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(48571150576867851)
,p_web_src_module_id=>wwv_flow_imp.id(48570407182867844)
,p_web_src_operation_id=>wwv_flow_imp.id(48570761951867847)
,p_name=>'Content-Type'
,p_param_type=>'HEADER'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value=>'application/json'
,p_is_static=>true
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(48571586961867854)
,p_web_src_module_id=>wwv_flow_imp.id(48570407182867844)
,p_web_src_operation_id=>wwv_flow_imp.id(48570761951867847)
,p_name=>'MESSAGE'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(48572088319867855)
,p_web_src_module_id=>wwv_flow_imp.id(48570407182867844)
,p_web_src_operation_id=>wwv_flow_imp.id(48570761951867847)
,p_name=>'RESPONSE'
,p_param_type=>'BODY'
,p_is_required=>false
,p_direction=>'OUT'
);
wwv_flow_imp.component_end;
end;
/
