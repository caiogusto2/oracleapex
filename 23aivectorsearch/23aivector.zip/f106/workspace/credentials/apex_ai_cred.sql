prompt --workspace/credentials/apex_ai_cred
begin
--   Manifest
--     CREDENTIAL: apex_ai_cred
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>34366086255793542
,p_default_application_id=>106
,p_default_id_offset=>9519496963955951
,p_default_owner=>'DEMOS'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(58794761201499574)
,p_name=>'apex_ai_cred'
,p_static_id=>'apex_ai_cred'
,p_authentication_type=>'OCI'
,p_namespace=>'ocid1.tenancy.oc1..aaaaaaaaoi6b5sxlv4z773boczybqz3h2vspvvru42jysvizl77lky22ijaq'
,p_prompt_on_install=>true
);
wwv_flow_imp.component_end;
end;
/
