prompt --application/shared_components/user_interface/theme_style
begin
--   Manifest
--     THEME STYLE: 113
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>13326374212697670
,p_default_application_id=>113
,p_default_id_offset=>13327528092704458
,p_default_owner=>'DEMOANA'
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(30229542782419471)
,p_theme_id=>42
,p_name=>'DATAPREV'
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/oracle-fonts/oraclesans-apex#MIN#.css?v=#APEX_VERSION#',
'#THEME_FILES#css/Redwood#MIN#.css?v=#APEX_VERSION#'))
,p_css_classes=>' rw-mode-header--pillar rw-mode-nav--pillar rw-mode-body-header--dark rw-mode-body--dark rw-pillar--neutral rw-layout--fixed t-PageBody--scrollTitle'
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Redwood-Theme.less'
,p_theme_roller_config=>'{"classes":["rw-mode-header--pillar","rw-mode-nav--pillar","rw-mode-body-header--dark","rw-mode-body--dark","rw-pillar--neutral","rw-layout--fixed t-PageBody--scrollTitle"],"vars":{},"customCSS":"","useCustomLess":"N"}'
,p_theme_roller_output_file_url=>'#THEME_DB_FILES#16902014689715013.css'
,p_theme_roller_read_only=>false
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(49395793111080156)
,p_theme_id=>42
,p_name=>'Marinha'
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/oracle-fonts/oraclesans-apex#MIN#.css?v=#APEX_VERSION#',
'#THEME_FILES#css/Redwood#MIN#.css?v=#APEX_VERSION#'))
,p_css_classes=>' rw-layout--fixed t-PageBody--scrollTitle rw-mode-nav--dark rw-mode-body-header--dark rw-mode-body--dark rw-mode-header--dark rw-pillar--sky'
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Redwood-Theme.less'
,p_theme_roller_config=>'{"classes":["rw-layout--fixed t-PageBody--scrollTitle","rw-mode-nav--dark","rw-mode-body-header--dark","rw-mode-body--dark","rw-mode-header--dark","rw-pillar--sky"],"vars":{},"customCSS":"","useCustomLess":"N"}'
,p_theme_roller_output_file_url=>'#THEME_DB_FILES#11554180142277263.css'
,p_theme_roller_read_only=>false
);
wwv_flow_imp.component_end;
end;
/
