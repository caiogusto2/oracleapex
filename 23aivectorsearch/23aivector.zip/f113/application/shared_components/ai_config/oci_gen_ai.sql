prompt --application/shared_components/ai_config/oci_gen_ai
begin
--   Manifest
--     AI CONFIG: oci_gen_ai
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>13326374212697670
,p_default_application_id=>113
,p_default_id_offset=>13327528092704458
,p_default_owner=>'DEMOANA'
);
wwv_flow_imp_shared.create_ai_config(
 p_id=>wwv_flow_imp.id(17440150733166204)
,p_name=>'oci_gen_ai'
,p_static_id=>'oci_gen_ai'
,p_remote_server_id=>wwv_flow_imp.id(15247019222347581)
,p_system_prompt=>'always responde in portuguese'
,p_welcome_message=>'Bem Vindo a GenAI'
,p_temperature=>1
,p_version_scn=>9458157
);
wwv_flow_imp.component_end;
end;
/
