prompt --application/shared_components/duality_views/customersjson
begin
--   Manifest
--     DOCUMENT SOURCE: CustomersJSON
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>13326374212697670
,p_default_application_id=>113
,p_default_id_offset=>13327528092704458
,p_default_owner=>'DEMOANA'
);
wwv_flow_imp_shared.create_document_source(
 p_id=>wwv_flow_imp.id(17455501458055263)
,p_name=>'CustomersJSON'
,p_static_id=>'customersjson'
,p_document_source_type=>'DUALITY_VIEW'
,p_location=>'LOCAL'
,p_object_name=>'CUSTOMERS_DV'
,p_data_profile_id=>wwv_flow_imp.id(17455535884055263)
,p_version_scn=>4637634
);
wwv_flow_imp.component_end;
end;
/
