prompt --application/shared_components/navigation/search_config/infloatvector
begin
--   Manifest
--     SEARCH CONFIG: InfloatVector
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>13326374212697670
,p_default_application_id=>113
,p_default_id_offset=>13327528092704458
,p_default_owner=>'DEMOANA'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(14853244389255470)
,p_label=>'InfloatVector'
,p_static_id=>'InfloatVector'
,p_search_type=>'VECTOR'
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_query_table=>'DOC_CHUNKS'
,p_oratext_index_column_name=>'EMBED_VECTOR'
,p_vector_provider_id =>wwv_flow_imp.id(14803246635966715)
,p_vector_search_type=>'EXACT'
,p_vector_distance_metric=>'COSINE'
,p_return_max_results=>10
,p_pk_column_name=>'EMBED_ID'
,p_title_column_name=>'EMBED_DATA'
,p_description_column_name=>'DOC_ID'
,p_icon_source_type=>'INITIALS'
,p_version_scn=>4675057
);
wwv_flow_imp.component_end;
end;
/
