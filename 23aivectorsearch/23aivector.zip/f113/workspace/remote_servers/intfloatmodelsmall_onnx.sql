prompt --workspace/remote_servers/intfloatmodelsmall_onnx
begin
--   Manifest
--     REMOTE SERVER: intfloatmodelsmall.onnx
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>13326374212697670
,p_default_application_id=>113
,p_default_id_offset=>13327528092704458
,p_default_owner=>'DEMOANA'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(14803246635966715)
,p_name=>'intfloatmodelsmall.onnx'
,p_static_id=>'intfloatmodelsmall_onnx'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('intfloatmodelsmall_onnx'),'https://localhost')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('intfloatmodelsmall_onnx'),'')
,p_server_type=>'VECTOR'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('intfloatmodelsmall_onnx'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('intfloatmodelsmall_onnx'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('intfloatmodelsmall_onnx'),'')
,p_prompt_on_install=>false
,p_ai_is_builder_service=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('intfloatmodelsmall_onnx'),'')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('intfloatmodelsmall_onnx'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('intfloatmodelsmall_onnx'),'')
,p_embedding_type=>'ONNX'
,p_emb_local_model_owner=>'DEMOANA'
,p_emb_local_model_name=>'DOC_MODEL'
);
wwv_flow_imp.component_end;
end;
/
