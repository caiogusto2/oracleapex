prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>1466972381197169
,p_default_application_id=>102
,p_default_id_offset=>1522250818480155
,p_default_owner=>'DEMO'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Assistente AI'
,p_alias=>'ASSISTENTE-AI'
,p_step_title=>'Assistente AI'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(36013195164031361)
,p_plug_name=>'Assistente AI'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--featured'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(34990310156360641)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
,p_region_image=>'#APP_FILES#icons/app-icon-512.png	'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56650787980196642)
,p_plug_name=>'Pesquisar Documentos'
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(97433696451785023)
,p_plug_name=>'Fonte de Dados'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_05'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h5>',
'    <spawn>Fonte de dados:</spawn><br>',
'    <a href="https://www.dataprev.gov.br/governanca/normativos/normasinternas" target="_blank">https://www.dataprev.gov.br/governanca/normativos/normasinternas</a>',
'</h5>',
''))
,p_required_patch=>wwv_flow_imp.id(34989779922360628)
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39043996284911807)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(56650787980196642)
,p_button_name=>'Submit'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Pesquisar'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(36013455573031363)
,p_name=>'P3_ARQUIVO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(56650787980196642)
,p_prompt=>'Selecione a Fonte de sua Consulta'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct doc_name request, doc_name display from doc_upload order by 1;',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(63053918685820660)
,p_name=>'P3_INPUT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(56650787980196642)
,p_prompt=>'Qual a sua pergunta?'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'text_case', 'UPPER',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(63063337291608261)
,p_name=>'P3_VECTOROUTPUT'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(56650787980196642)
,p_prompt=>'Output Consulta Vector DB'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(34989779922360628)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML',
  'send_on_page_submit', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(63065924017608287)
,p_name=>'P3_GENAIOUTPUT'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(56650787980196642)
,p_prompt=>'Output Ajuste Resposta GenAI'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(34989779922360628)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(66506530813816565)
,p_name=>'P3_OUTPUT'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(56650787980196642)
,p_prompt=>unistr('Output Final ap\00F3s Parse GenAI')
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'Y',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39046178670911847)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Busca Documentos'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>14532093794813412
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39045714337911843)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(39046178670911847)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'VectorSearch'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    V_INPUT VARCHAR2(400) := :P3_INPUT;',
'    V_INPUT01 VARCHAR2(400) := :P3_ARQUIVO;',
'    V_OUTPUT CLOB;',
'BEGIN',
'    V_OUTPUT := rag_with_genai_function (V_INPUT,V_INPUT01);',
'    :P3_VECTOROUTPUT := V_OUTPUT;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>14531629461813408
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39046510334911849)
,p_process_sequence=>40
,p_parent_process_id=>wwv_flow_imp.id(39046178670911847)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'ApiCall'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(39050910218911893)
,p_web_src_operation_id=>wwv_flow_imp.id(39051264987911896)
,p_attribute_01=>'WEB_SOURCE'
,p_internal_uid=>14532425458813414
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(39047026454911851)
,p_page_id=>3
,p_web_src_param_id=>wwv_flow_imp.id(39052591355911904)
,p_page_process_id=>wwv_flow_imp.id(39046510334911849)
,p_value_type=>'ITEM'
,p_value=>'P3_GENAIOUTPUT'
,p_ignore_output=>false
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(39047529786911854)
,p_page_id=>3
,p_web_src_param_id=>wwv_flow_imp.id(39052089997911903)
,p_page_process_id=>wwv_flow_imp.id(39046510334911849)
,p_value_type=>'SQL_QUERY'
,p_value=>'SELECT ''SEGUNDO O DOCUMENTO '' || :P3_ARQUIVO || '' '' || :P3_INPUT || '' SEGUNDO O TEXTO '' || :P3_VECTOROUTPUT FROM DUAL;'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39047940529911856)
,p_process_sequence=>50
,p_parent_process_id=>wwv_flow_imp.id(39046178670911847)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'EditOutput'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_json      VARCHAR2(32767) := :P3_GENAIOUTPUT;',
'    l_text      VARCHAR2(4000);',
'BEGIN',
'    -- Extract the text from the JSON',
'    SELECT jt.text',
'    INTO l_text',
'    FROM dual,',
'         JSON_TABLE(',
'             l_json,',
'             ''$.chatResponse'' COLUMNS (',
'                 text VARCHAR2(4000) PATH ''$.text''',
'             )',
'         ) jt;',
'',
'    -- Set the extracted text to P3_OUTPUT',
'    :P3_OUTPUT := l_text;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>14533855653813421
);
wwv_flow_imp.component_end;
end;
/
