prompt --application/shared_components/ai_config/oci_gen_ai
begin
--   Manifest
--     AI CONFIG: oci_gen_ai
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>1466972381197169
,p_default_application_id=>102
,p_default_id_offset=>1522250818480155
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_ai_config(
 p_id=>wwv_flow_imp.id(4112622640461746)
,p_name=>'oci_gen_ai'
,p_static_id=>'oci_gen_ai'
,p_remote_server_id=>wwv_flow_imp.id(1919491129643123)
,p_system_prompt=>'always responde in portuguese'
,p_welcome_message=>'Bem Vindo a GenAI'
,p_temperature=>1
,p_version_scn=>9458157
);
wwv_flow_imp.component_end;
end;
/
