prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>1466972381197169
,p_default_application_id=>102
,p_default_id_offset=>1522250818480155
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(34990790690360648)
,p_name=>'Navigation Menu'
,p_list_status=>'PUBLIC'
,p_version_scn=>9463627
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39043287853911786)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Assitente AI'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:3:::'
,p_list_item_icon=>'fa-head-microchip'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'3'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39184075524922252)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Arquivos e Normas'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-text-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'4'
);
wwv_flow_imp.component_end;
end;
/
