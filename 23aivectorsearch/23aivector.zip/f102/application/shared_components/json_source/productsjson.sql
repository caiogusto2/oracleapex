prompt --application/shared_components/json_source/productsjson
begin
--   Manifest
--     DOCUMENT SOURCE: ProductsJSON
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>1466972381197169
,p_default_application_id=>102
,p_default_id_offset=>1522250818480155
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_document_source(
 p_id=>wwv_flow_imp.id(4145515568411763)
,p_name=>'ProductsJSON'
,p_static_id=>'productsjson'
,p_document_source_type=>'JSON_TABLE'
,p_location=>'LOCAL'
,p_object_name=>'PRODUCTS'
,p_data_profile_id=>wwv_flow_imp.id(4145657142411763)
,p_version_scn=>4638765
);
wwv_flow_imp.component_end;
end;
/
