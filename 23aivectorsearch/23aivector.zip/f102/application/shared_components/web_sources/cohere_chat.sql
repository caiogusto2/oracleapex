prompt --application/shared_components/web_sources/cohere_chat
begin
--   Manifest
--     WEB SOURCE: Cohere-Chat
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>1466972381197169
,p_default_application_id=>102
,p_default_id_offset=>1522250818480155
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(39050910218911893)
,p_name=>'Cohere-Chat'
,p_static_id=>'cohere_chat'
,p_web_source_type=>'NATIVE_OCI'
,p_data_profile_id=>wwv_flow_imp.id(39050084959911886)
,p_remote_server_id=>wwv_flow_imp.id(36534750622805257)
,p_url_path_prefix=>'chat'
,p_credential_id=>wwv_flow_imp.id(36504457535263593)
,p_version_scn=>9411719
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(39051264987911896)
,p_web_src_module_id=>wwv_flow_imp.id(39050910218911893)
,p_operation=>'POST'
,p_url_pattern=>'.'
,p_request_body_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'	"chatRequest":{',
'		"apiFormat":"COHERE",',
'		"message":"#MESSAGE#",',
'                "maxTokens":"1800",',
'                "temperature":"0"',
'	},',
'	"compartmentId":"ocid1.compartment.oc1..aaaaaaaacqt2kvaoyjexiops224rzriooevivs63hxhpzjxzwbvadqcgsfha",',
'	"servingMode":{',
'		"servingType":"ON_DEMAND",',
'		"modelId":"cohere.command-r-plus-08-2024"',
'	}',
'}'))
,p_force_error_for_http_404=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(39051653612911900)
,p_web_src_module_id=>wwv_flow_imp.id(39050910218911893)
,p_web_src_operation_id=>wwv_flow_imp.id(39051264987911896)
,p_name=>'Content-Type'
,p_param_type=>'HEADER'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value=>'application/json'
,p_is_static=>true
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(39052089997911903)
,p_web_src_module_id=>wwv_flow_imp.id(39050910218911893)
,p_web_src_operation_id=>wwv_flow_imp.id(39051264987911896)
,p_name=>'MESSAGE'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(39052591355911904)
,p_web_src_module_id=>wwv_flow_imp.id(39050910218911893)
,p_web_src_operation_id=>wwv_flow_imp.id(39051264987911896)
,p_name=>'RESPONSE'
,p_param_type=>'BODY'
,p_is_required=>false
,p_direction=>'OUT'
);
wwv_flow_imp.component_end;
end;
/
