prompt --workspace/remote_servers/cohere_embedmultilingualv30
begin
--   Manifest
--     REMOTE SERVER: cohere_embedmultilingualv30
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>1466972381197169
,p_default_application_id=>102
,p_default_id_offset=>1522250818480155
,p_default_owner=>'DEMO'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(4184744403768070)
,p_name=>'cohere_embedmultilingualv30'
,p_static_id=>'cohere_embedmultilingualv30'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('cohere_embedmultilingualv30'),'https://inference.generativeai.sa-saopaulo-1.oci.oraclecloud.com')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('cohere_embedmultilingualv30'),'')
,p_server_type=>'VECTOR'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('cohere_embedmultilingualv30'),'')
,p_credential_id=>wwv_flow_imp.id(36504457535263593)
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('cohere_embedmultilingualv30'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('cohere_embedmultilingualv30'),'')
,p_prompt_on_install=>true
,p_ai_provider_type=>'OCI_GENAI'
,p_ai_is_builder_service=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('cohere_embedmultilingualv30'),'')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('cohere_embedmultilingualv30'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('cohere_embedmultilingualv30'),'{"compartmentId":"ocid1.compartment.oc1..aaaaaaaacqt2kvaoyjexiops224rzriooevivs63hxhpzjxzwbvadqcgsfha","servingMode":{"modelId":"cohere.embed-multilingual-v3.0","servingType":"ON_DEMAND"}}')
,p_embedding_type=>'GENAI_PROVIDER'
);
wwv_flow_imp.component_end;
end;
/
