prompt --workspace/credentials/apex_ai_cred
begin
--   Manifest
--     CREDENTIAL: apex_ai_cred
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7622520596424973
,p_default_application_id=>100
,p_default_id_offset=>7623656485434350
,p_default_owner=>'MARINHA'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(35033950463055084)
,p_name=>'apex_ai_cred'
,p_static_id=>'apex_ai_cred'
,p_authentication_type=>'OCI'
,p_namespace=>'ocid1.tenancy.oc1..aaaaaaaaoi6b5sxlv4z773boczybqz3h2vspvvru42jysvizl77lky22ijaq'
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
