prompt --workspace/remote_servers/inference_generativeai_sa_saopaulo_1_oci_oraclecloud_com
begin
--   Manifest
--     REMOTE SERVER: inference.generativeai.sa-saopaulo-1.oci.oraclecloud.com
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7622520596424973
,p_default_application_id=>100
,p_default_id_offset=>7623656485434350
,p_default_owner=>'MARINHA'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(35064243550596748)
,p_name=>'inference.generativeai.sa-saopaulo-1.oci.oraclecloud.com'
,p_static_id=>'inference_generativeai_sa_saopaulo_1_oci_oraclecloud_com'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('inference_generativeai_sa_saopaulo_1_oci_oraclecloud_com'),'https://inference.generativeai.sa-saopaulo-1.oci.oraclecloud.com/20231130/actions/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('inference_generativeai_sa_saopaulo_1_oci_oraclecloud_com'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('inference_generativeai_sa_saopaulo_1_oci_oraclecloud_com'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('inference_generativeai_sa_saopaulo_1_oci_oraclecloud_com'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('inference_generativeai_sa_saopaulo_1_oci_oraclecloud_com'),'')
,p_prompt_on_install=>false
,p_ai_is_builder_service=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('inference_generativeai_sa_saopaulo_1_oci_oraclecloud_com'),'')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('inference_generativeai_sa_saopaulo_1_oci_oraclecloud_com'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('inference_generativeai_sa_saopaulo_1_oci_oraclecloud_com'),'')
);
wwv_flow_imp.component_end;
end;
/
