prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7622520596424973
,p_default_application_id=>100
,p_default_id_offset=>7623656485434350
,p_default_owner=>'MARINHA'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Assistente AI'
,p_alias=>'ASSISTENTE-AI'
,p_step_title=>'Assistente AI'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19122766773367276)
,p_plug_name=>'Assistente AI'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--featured'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(18169866501696810)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(18099881765696556)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(18278388923697147)
,p_region_image=>'#APP_FILES#icons/app-icon-512.png	'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39760359589532557)
,p_plug_name=>'Pesquisar Documentos'
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(18203234955696901)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(39762155857532574)
,p_name=>'Output Select AI'
,p_parent_plug_id=>wwv_flow_imp.id(39760359589532557)
,p_template=>wwv_flow_imp.id(18203234955696901)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    RETURN DBMS_CLOUD_AI.GENERATE(:P3_INPUT, profile_name => ''OCI_GENAI'');',
'END;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(18241627941697015)
,p_plug_query_max_columns=>20
,p_query_headings_type=>'QUERY_COLUMNS'
,p_query_num_rows=>15
,p_query_options=>'GENERIC_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_required_patch=>wwv_flow_imp.id(18099351531696543)
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39762221850532575)
,p_query_column_id=>1
,p_column_alias=>'COL01'
,p_column_display_sequence=>10
,p_column_heading=>'Col01'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39762288236532576)
,p_query_column_id=>2
,p_column_alias=>'COL02'
,p_column_display_sequence=>20
,p_column_heading=>'Col02'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39762454776532577)
,p_query_column_id=>3
,p_column_alias=>'COL03'
,p_column_display_sequence=>30
,p_column_heading=>'Col03'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39762539143532578)
,p_query_column_id=>4
,p_column_alias=>'COL04'
,p_column_display_sequence=>40
,p_column_heading=>'Col04'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39762637743532579)
,p_query_column_id=>5
,p_column_alias=>'COL05'
,p_column_display_sequence=>50
,p_column_heading=>'Col05'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39762662227532580)
,p_query_column_id=>6
,p_column_alias=>'COL06'
,p_column_display_sequence=>60
,p_column_heading=>'Col06'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39762783223532581)
,p_query_column_id=>7
,p_column_alias=>'COL07'
,p_column_display_sequence=>70
,p_column_heading=>'Col07'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39762910686532582)
,p_query_column_id=>8
,p_column_alias=>'COL08'
,p_column_display_sequence=>80
,p_column_heading=>'Col08'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39762999744532583)
,p_query_column_id=>9
,p_column_alias=>'COL09'
,p_column_display_sequence=>90
,p_column_heading=>'Col09'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39763083852532584)
,p_query_column_id=>10
,p_column_alias=>'COL10'
,p_column_display_sequence=>100
,p_column_heading=>'Col10'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39763188666532585)
,p_query_column_id=>11
,p_column_alias=>'COL11'
,p_column_display_sequence=>110
,p_column_heading=>'Col11'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39763346821532586)
,p_query_column_id=>12
,p_column_alias=>'COL12'
,p_column_display_sequence=>120
,p_column_heading=>'Col12'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39763369417532587)
,p_query_column_id=>13
,p_column_alias=>'COL13'
,p_column_display_sequence=>130
,p_column_heading=>'Col13'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39763479435532588)
,p_query_column_id=>14
,p_column_alias=>'COL14'
,p_column_display_sequence=>140
,p_column_heading=>'Col14'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39763603512532589)
,p_query_column_id=>15
,p_column_alias=>'COL15'
,p_column_display_sequence=>150
,p_column_heading=>'Col15'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39763739761532590)
,p_query_column_id=>16
,p_column_alias=>'COL16'
,p_column_display_sequence=>160
,p_column_heading=>'Col16'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39763818575532591)
,p_query_column_id=>17
,p_column_alias=>'COL17'
,p_column_display_sequence=>170
,p_column_heading=>'Col17'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39763888181532592)
,p_query_column_id=>18
,p_column_alias=>'COL18'
,p_column_display_sequence=>180
,p_column_heading=>'Col18'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39763958007532593)
,p_query_column_id=>19
,p_column_alias=>'COL19'
,p_column_display_sequence=>190
,p_column_heading=>'Col19'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39764098411532594)
,p_query_column_id=>20
,p_column_alias=>'COL20'
,p_column_display_sequence=>200
,p_column_heading=>'Col20'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(80543268061120938)
,p_plug_name=>'Fonte de Dados'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(18136583346696715)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_05'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h5>',
'    <spawn>Fonte de dados:</spawn><br>',
'    <a href="https://dados.gov.br/dados/organizacoes/visualizar/marinha-do-brasil" target="_blank">https://dados.gov.br/dados/organizacoes/visualizar/marinha-do-brasil</a><br>',
'    <a href="https://www.marinha.mil.br/dpc/normas-autoridade-maritima-brasileira" target="_blank">https://www.marinha.mil.br/dpc/normas-autoridade-maritima-brasileira</a>',
'</h5>',
''))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(22153567894247722)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(39760359589532557)
,p_button_name=>'Submit'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(18276928505697142)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Pesquisar'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19123027182367278)
,p_name=>'P3_ARQUIVO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(39760359589532557)
,p_prompt=>'Selecione a Fonte de sua Consulta'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct doc_name request, doc_name display from doc_upload order by 1;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Base de Dados'
,p_lov_null_value=>'Base de Dados'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(18274352624697126)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46163490295156575)
,p_name=>'P3_INPUT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(39760359589532557)
,p_prompt=>'Qual a sua pergunta?'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(18274352624697126)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_attribute_06=>'UPPER'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46172908900944176)
,p_name=>'P3_VECTOROUTPUT'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(39760359589532557)
,p_prompt=>'Output Consulta Vector DB'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(18274352624697126)
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(18099351531696543)
,p_attribute_01=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'HTML'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46175495626944202)
,p_name=>'P3_GENAIOUTPUT'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(39760359589532557)
,p_prompt=>'Output Ajuste Resposta GenAI'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(18274352624697126)
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(18099351531696543)
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(49616102423152480)
,p_name=>'P3_OUTPUT'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(39760359589532557)
,p_prompt=>unistr('Output Final ap\00F3s Parse GenAI')
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(18274352624697126)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(22155750280247762)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Busca Documentos'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>14532093794813412
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(22155285947247758)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(22155750280247762)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'VectorSearch'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    V_INPUT VARCHAR2(400) := :P3_INPUT;',
'    V_OUTPUT CLOB;',
'BEGIN',
'    V_OUTPUT := rag_with_genai_function (V_INPUT);',
'    :P3_VECTOROUTPUT := V_OUTPUT;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>14531629461813408
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(22156081944247764)
,p_process_sequence=>40
,p_parent_process_id=>wwv_flow_imp.id(22155750280247762)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'ApiCall'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(22160481828247808)
,p_web_src_operation_id=>wwv_flow_imp.id(22160836597247811)
,p_attribute_01=>'WEB_SOURCE'
,p_process_when=>'P3_VECTOROUTPUT'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_process_when2=>unistr('Falha na busca de conteudo, fa\00E7a outra pergunta')
,p_internal_uid=>14532425458813414
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(22156598064247766)
,p_page_id=>3
,p_web_src_param_id=>wwv_flow_imp.id(22162162965247819)
,p_page_process_id=>wwv_flow_imp.id(22156081944247764)
,p_value_type=>'ITEM'
,p_value=>'P3_GENAIOUTPUT'
,p_ignore_output=>false
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(22157101396247769)
,p_page_id=>3
,p_web_src_param_id=>wwv_flow_imp.id(22161661607247818)
,p_page_process_id=>wwv_flow_imp.id(22156081944247764)
,p_value_type=>'SQL_QUERY'
,p_value=>'SELECT ''SEGUNDO O DOCUMENTO '' || :P3_ARQUIVO || '' '' || :P3_INPUT || '' SEGUNDO O TEXTO '' || :P3_VECTOROUTPUT FROM DUAL;'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(22157512139247771)
,p_process_sequence=>50
,p_parent_process_id=>wwv_flow_imp.id(22155750280247762)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'EditOutput'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_json      VARCHAR2(32767) := :P3_GENAIOUTPUT;',
'    l_text      VARCHAR2(4000);',
'BEGIN',
'    -- Extract the text from the JSON',
'    SELECT jt.text',
'    INTO l_text',
'    FROM dual,',
'         JSON_TABLE(',
'             l_json,',
'             ''$.chatResponse'' COLUMNS (',
'                 text VARCHAR2(4000) PATH ''$.text''',
'             )',
'         ) jt;',
'',
'    -- Set the extracted text to P3_OUTPUT',
'    :P3_OUTPUT := l_text;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'P3_VECTOROUTPUT'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_process_when2=>unistr('Falha na busca de conteudo, fa\00E7a outra pergunta')
,p_internal_uid=>14533855653813421
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(22157879404247772)
,p_process_sequence=>60
,p_parent_process_id=>wwv_flow_imp.id(22155750280247762)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'EditOutput_Error'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_text      VARCHAR2(4000);',
'BEGIN',
unistr('    l_text := ''Falha na busca de conteudo, fa\00E7a outra pergunta.'';'),
'    -- Set the extracted text to P3_OUTPUT',
'    :P3_OUTPUT := l_text;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'P3_VECTOROUTPUT'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>unistr('Falha na busca de conteudo, fa\00E7a outra pergunta')
,p_internal_uid=>14534222918813422
);
wwv_flow_imp.component_end;
end;
/
