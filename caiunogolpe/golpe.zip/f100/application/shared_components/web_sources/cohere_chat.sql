prompt --application/shared_components/web_sources/cohere_chat
begin
--   Manifest
--     WEB SOURCE: Cohere-Chat
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>7752372273860007
,p_default_application_id=>100
,p_default_id_offset=>7753530837857734
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(49017886965101115)
,p_name=>'Cohere-Chat'
,p_static_id=>'cohere_chat'
,p_web_source_type=>'NATIVE_OCI'
,p_data_profile_id=>wwv_flow_imp.id(49017029622101104)
,p_remote_server_id=>wwv_flow_imp.id(83645214197641406)
,p_url_path_prefix=>'chat'
,p_credential_id=>wwv_flow_imp.id(83614921110099742)
,p_version_scn=>44542304051806
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(49018103622101121)
,p_web_src_module_id=>wwv_flow_imp.id(49017886965101115)
,p_operation=>'POST'
,p_url_pattern=>'.'
,p_request_body_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'	"chatRequest":{',
'		"apiFormat":"COHERE",',
'		"message":"#MESSAGE#",',
'                "maxTokens":"1800",',
'                "temperature":"0"',
'	},',
'	"compartmentId":"ocid1.compartment.oc1..aaaaaaaacqt2kvaoyjexiops224rzriooevivs63hxhpzjxzwbvadqcgsfha",',
'	"servingMode":{',
'		"servingType":"ON_DEMAND",',
'		"modelId":"cohere.command-r-plus-08-2024"',
'	}',
'}'))
,p_force_error_for_http_404=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(49018501648101125)
,p_web_src_module_id=>wwv_flow_imp.id(49017886965101115)
,p_web_src_operation_id=>wwv_flow_imp.id(49018103622101121)
,p_name=>'Content-Type'
,p_param_type=>'HEADER'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value=>'application/json'
,p_is_static=>true
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(49018922920101128)
,p_web_src_module_id=>wwv_flow_imp.id(49017886965101115)
,p_web_src_operation_id=>wwv_flow_imp.id(49018103622101121)
,p_name=>'MESSAGE'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(49019433174101129)
,p_web_src_module_id=>wwv_flow_imp.id(49017886965101115)
,p_web_src_operation_id=>wwv_flow_imp.id(49018103622101121)
,p_name=>'RESPONSE'
,p_param_type=>'BODY'
,p_is_required=>false
,p_direction=>'OUT'
);
wwv_flow_imp.component_end;
end;
/
