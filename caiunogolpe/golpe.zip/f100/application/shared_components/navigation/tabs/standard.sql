prompt --application/shared_components/navigation/tabs/standard
begin
--   Manifest
--     TABS: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>7776783556484581
,p_default_application_id=>100
,p_default_id_offset=>7777918819480520
,p_default_owner=>'DEMO'
);
null;
wwv_flow_imp.component_end;
end;
/
