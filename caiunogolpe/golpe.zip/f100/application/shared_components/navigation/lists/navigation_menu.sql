prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>7752372273860007
,p_default_application_id=>100
,p_default_id_offset=>7753530837857734
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(48563474756000223)
,p_name=>'Navigation Menu'
,p_list_status=>'PUBLIC'
,p_version_scn=>44561982683451
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(49488991510008973)
,p_list_item_display_sequence=>5
,p_list_item_link_text=>'Monitoramento de Bases'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-users-alt'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'10'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(48575080368000442)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>unistr('Avalia\00E7\00E3o Usu\00E1rio')
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-clipboard-search'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(50213835581601780)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Cruzamento Bases'
,p_list_item_link_target=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-database-search'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'20'
);
wwv_flow_imp.component_end;
end;
/
