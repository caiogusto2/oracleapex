prompt --application/shared_components/data_profiles/cohere_chat
begin
--   Manifest
--     DATA PROFILE: Cohere-Chat
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>7767125124665576
,p_default_application_id=>100
,p_default_id_offset=>7773462875522703
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_data_profile(
 p_id=>wwv_flow_imp.id(56790492497623807)
,p_name=>'Cohere-Chat'
,p_format=>'JSON'
,p_use_raw_json_selectors=>false
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(56790649022623813)
,p_data_profile_id=>wwv_flow_imp.id(56790492497623807)
,p_name=>'CODE'
,p_sequence=>1
,p_column_type=>'DATA'
,p_data_type=>'NUMBER'
,p_has_time_zone=>false
,p_selector=>'code'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(56790893869623816)
,p_data_profile_id=>wwv_flow_imp.id(56790492497623807)
,p_name=>'MESSAGE'
,p_sequence=>2
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>4000
,p_has_time_zone=>false
,p_selector=>'message'
);
wwv_flow_imp.component_end;
end;
/
