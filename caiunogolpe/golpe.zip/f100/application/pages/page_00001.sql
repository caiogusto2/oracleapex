prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>7767125124665576
,p_default_application_id=>100
,p_default_id_offset=>7773462875522703
,p_default_owner=>'DEMO'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Desafio MPs'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.float{',
'  z-index:100;',
'  position:fixed;',
'  width:60px;',
'  height:60px;',
'  bottom:40px;',
'  right:40px;',
'  background-color: black;',
'  color:#FFF;',
'  border-radius:50px;',
'  text-align:center;',
'  box-shadow: 2px 2px 3px #999;',
'}',
'.my-float{',
'  margin-top:22px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56349465095523158)
,p_plug_name=>unistr('Avalia\00E7\00E3o Usu\00E1rio')
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--featured'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(56336448088522916)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56823373368659526)
,p_plug_name=>'Filtro'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>1569994581593435632
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(57081238066700695)
,p_plug_name=>'Valida Cadastro'
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56823741415659529)
,p_plug_name=>'Valida Cadastro'
,p_parent_plug_id=>wwv_flow_imp.id(57081238066700695)
,p_region_template_options=>'#DEFAULT#:t-IRR-region--noBorders:t-IRR-region--removeHeader js-removeLandmark'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    VARIAVEL, ',
'    VALOR_OGB_USERS, ',
'    VALOR_BANK_ACCOUNTS, ',
'    STATUS ',
'FROM (',
'    -- Nome Completo (First + Last)',
'    SELECT ',
'        ''Nome'' AS VARIAVEL, ',
'        COALESCE(u.FIRST || '' '' || u.LAST, ''N/A'') AS VALOR_OGB_USERS, ',
'        COALESCE(b.FIRST || '' '' || b.LAST, ''N/A'') AS VALOR_BANK_ACCOUNTS, ',
'        CASE ',
'            WHEN u.FIRST = b.FIRST AND u.LAST = b.LAST THEN ''fa-check-circle u-success-text''',
'            ELSE ''fa-minus-circle u-danger-text''',
'        END AS STATUS',
'    FROM OGB_USERS u',
'    FULL OUTER JOIN BANK_ACCOUNTS b ON u.CPF = b.CPF',
'    WHERE (u.CPF = :P1_CPFSEMFORM OR b.CPF = :P1_CPFSEMFORM)',
'',
'    UNION ALL',
'',
'    -- Email',
'    SELECT ',
'        ''Email'' AS VARIAVEL, ',
'        COALESCE(u.EMAIL, ''N/A'') AS VALOR_OGB_USERS, ',
'        COALESCE(b.EMAIL, ''N/A'') AS VALOR_BANK_ACCOUNTS, ',
'        CASE ',
'            WHEN u.EMAIL = b.EMAIL THEN ''fa-check-circle u-success-text''',
'            ELSE ''fa-minus-circle u-danger-text''',
'        END AS STATUS',
'    FROM OGB_USERS u',
'    FULL OUTER JOIN BANK_ACCOUNTS b ON u.CPF = b.CPF',
'    WHERE (u.CPF = :P1_CPFSEMFORM OR b.CPF = :P1_CPFSEMFORM)',
'',
'    UNION ALL',
'',
'    -- Telefone',
'    SELECT ',
'        ''Telefone'' AS VARIAVEL, ',
'        COALESCE(TO_CHAR(u.TELEFONE), ''N/A'') AS VALOR_OGB_USERS, ',
'        COALESCE(TO_CHAR(b.TELEFONE), ''N/A'') AS VALOR_BANK_ACCOUNTS, ',
'        CASE ',
'            WHEN u.TELEFONE = b.TELEFONE THEN ''fa-check-circle u-success-text''',
'            ELSE ''fa-minus-circle u-danger-text''',
'        END AS STATUS',
'    FROM OGB_USERS u',
'    FULL OUTER JOIN BANK_ACCOUNTS b ON u.CPF = b.CPF',
'    WHERE (u.CPF = :P1_CPFSEMFORM OR b.CPF = :P1_CPFSEMFORM)',
'',
'    UNION ALL',
'',
'    -- CPF (to identify missing records)',
'    SELECT ',
'        ''CPF'' AS VARIAVEL, ',
'        COALESCE(TO_CHAR(u.CPF), ''N/A'') AS VALOR_OGB_USERS, ',
'        COALESCE(TO_CHAR(b.CPF), ''N/A'') AS VALOR_BANK_ACCOUNTS, ',
'        CASE ',
'            WHEN u.CPF IS NOT NULL AND b.CPF IS NOT NULL THEN ''fa-check-circle u-success-text''',
'            ELSE ''fa-minus-circle u-danger-text''',
'        END AS STATUS',
'    FROM OGB_USERS u',
'    FULL OUTER JOIN BANK_ACCOUNTS b ON u.CPF = b.CPF',
'    WHERE (u.CPF = :P1_CPFSEMFORM OR b.CPF = :P1_CPFSEMFORM)',
');'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(56937115136612497)
,p_max_row_count=>'1000000'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'GRAPHUSER'
,p_internal_uid=>8307544141039203
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(56937236382612498)
,p_db_column_name=>'VARIAVEL'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Variavel'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(56937318420612499)
,p_db_column_name=>'VALOR_OGB_USERS'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Midias Sociais (MS)'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(56937390627612500)
,p_db_column_name=>'VALOR_BANK_ACCOUNTS'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>unistr('Dados Banc\00E1rios (DB)')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(56937488508612501)
,p_db_column_name=>'STATUS'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'MS = DB'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'TMPL_THEME_42$AVATAR'
,p_heading_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'CSS_CLASSES', '&STATUS.',
  'ICON', 'fa-assistive-listening-systems',
  'SHAPE', 't-Avatar--noShape',
  'SIZE', 't-Avatar--md',
  'TYPE', 'ICON')).to_clob
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(56950252468640042)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'83207'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'VARIAVEL:VALOR_OGB_USERS:VALOR_BANK_ACCOUNTS:STATUS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(57081289127700696)
,p_plug_name=>unistr('\00DAltimas Transa\00E7\00F5es')
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P1_ACCOUNT_ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56940242499612528)
,p_plug_name=>unistr('\00DAltimas Transa\00E7\00F5es')
,p_parent_plug_id=>wwv_flow_imp.id(57081289127700696)
,p_icon_css_classes=>'fa-thumbs-down'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--noBorders:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--SELECT ',
'--    TO_CHAR(txn.TXN_DATE, ''DD/MM/YYYY'') AS TXN_DATE,',
'--    txn.AMOUNT,',
'--    txn.SRC_NAME AS SRC_ACCOUNT_NAME,',
'--    REGEXP_REPLACE(REGEXP_REPLACE(txn.SRC_CPF_RAW, ''\D'', ''''), ''(\d{3})(\d{3})(\d{3})(\d{2})'', ''\1.\2.\3-\4'') AS SRC_CPF,',
'--    txn.DST_NAME AS DST_ACCOUNT_NAME,',
'--    REGEXP_REPLACE(REGEXP_REPLACE(txn.DST_CPF_RAW, ''\D'', ''''), ''(\d{3})(\d{3})(\d{3})(\d{2})'', ''\1.\2.\3-\4'') AS DST_CPF,',
'--    CASE ',
'--        WHEN REGEXP_REPLACE(txn.SRC_CPF_RAW, ''\D'', '''') = REGEXP_REPLACE(:P1_CPF, ''\D'', '''') THEN ',
'--            ''fa-thumbs-down u-danger-text''',
'--        ELSE ',
'--            ''fa-thumbs-up u-success-text''',
'--    END AS TRANSACTION_TYPE',
'--FROM (',
'--    SELECT ',
'--        bt.TXN_DATE,',
'--        bt.AMOUNT,',
'--        src.CPF AS SRC_CPF_RAW,',
'--        dst.CPF AS DST_CPF_RAW,',
'--        src.NAME AS SRC_NAME,',
'--        dst.NAME AS DST_NAME',
'--    FROM BANK_TRANSFERS bt',
'--    JOIN BANK_ACCOUNTS src ON bt.SRC_ACCT_ID = src.ID',
'--    JOIN BANK_ACCOUNTS dst ON bt.DST_ACCT_ID = dst.ID',
'--    WHERE REGEXP_REPLACE(src.CPF, ''\D'', '''') = REGEXP_REPLACE(:P1_CPF, ''\D'', '''')',
'--       OR REGEXP_REPLACE(dst.CPF, ''\D'', '''') = REGEXP_REPLACE(:P1_CPF, ''\D'', '''')',
'--    ORDER BY bt.TXN_DATE DESC',
'--) txn',
'--WHERE ROWNUM <= 10;',
'--',
'',
'SELECT ',
'    txn.TXN_DATE AS TXN_DATE,',
'    txn.AMOUNT,',
'    txn.SRC_NAME AS SRC_ACCOUNT_NAME,',
'    REGEXP_REPLACE(REGEXP_REPLACE(txn.SRC_CPF_RAW, ''\D'', ''''), ''(\d{3})(\d{3})(\d{3})(\d{2})'', ''\1.\2.\3-\4'') AS SRC_CPF,',
'    txn.DST_NAME AS DST_ACCOUNT_NAME,',
'    REGEXP_REPLACE(REGEXP_REPLACE(txn.DST_CPF_RAW, ''\D'', ''''), ''(\d{3})(\d{3})(\d{3})(\d{2})'', ''\1.\2.\3-\4'') AS DST_CPF,',
'    CASE ',
'        WHEN txn.ANOMALY = 1 THEN ''fa-thumbs-down u-danger-text''',
'        ELSE ''fa-thumbs-up u-success-text''',
'    END AS TRANSACTION_TYPE',
'FROM (',
'    SELECT ',
'        bt.TXN_ID,',
'        bt.TXN_DATE,',
'        bt.AMOUNT,',
'        src.CPF AS SRC_CPF_RAW,',
'        dst.CPF AS DST_CPF_RAW,',
'        src.NAME AS SRC_NAME,',
'        dst.NAME AS DST_NAME,',
'        fp.ANOMALY',
'    FROM BANK_TRANSFERS bt',
'    JOIN BANK_ACCOUNTS src ON bt.SRC_ACCT_ID = src.ID',
'    JOIN BANK_ACCOUNTS dst ON bt.DST_ACCT_ID = dst.ID',
'    LEFT JOIN FRAUD_PREDICTIONS fp ON fp.TXN_ID = bt.TXN_ID',
'    WHERE REGEXP_REPLACE(src.CPF, ''\D'', '''') = REGEXP_REPLACE(:P1_CPF, ''\D'', '''')',
'       OR REGEXP_REPLACE(dst.CPF, ''\D'', '''') = REGEXP_REPLACE(:P1_CPF, ''\D'', '''')',
'    ORDER BY bt.TXN_DATE DESC',
') txn',
'--WHERE ROWNUM <= 10',
';',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(56940299798612529)
,p_max_row_count=>'1000000'
,p_show_actions_menu=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'GRAPHUSER'
,p_internal_uid=>8310728803039235
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(56940497362612531)
,p_db_column_name=>'AMOUNT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Valor'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(56940587144612532)
,p_db_column_name=>'SRC_ACCOUNT_NAME'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Origem - Nome'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(56940831421612534)
,p_db_column_name=>'DST_ACCOUNT_NAME'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Destino - Nome'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(56941022357612536)
,p_db_column_name=>'TRANSACTION_TYPE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>unistr('Avalia\00E7\00E3o Transa\00E7\00E3o')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'TMPL_THEME_42$AVATAR'
,p_heading_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'CSS_CLASSES', '&TRANSACTION_TYPE.',
  'ICON', 'fa-assistive-listening-systems',
  'SHAPE', 't-Avatar--noShape',
  'SIZE', 't-Avatar--sm',
  'TYPE', 'ICON')).to_clob
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(56941092252612537)
,p_db_column_name=>'SRC_CPF'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Origem - CPF'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(56941226047612538)
,p_db_column_name=>'DST_CPF'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Destino - CPF'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(58050696471510710)
,p_db_column_name=>'TXN_DATE'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Data Transferencia'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MON-RR'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(57053786292267057)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'84243'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_view_mode=>'REPORT'
,p_report_columns=>'TXN_DATE:AMOUNT:SRC_ACCOUNT_NAME:DST_ACCOUNT_NAME:TRANSACTION_TYPE:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(57081581640700699)
,p_plug_name=>unistr('Transa\00E7\00F5es Financeiras')
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>70
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT origem, transferencia, destino',
'FROM GRAPH_TABLE (',
'    BANK_GRAPH',
'    MATCH (v1 IS BANK_ACCOUNTS) -[e IS BANK_TRANSFERS]-> (v2 IS BANK_ACCOUNTS)',
'    WHERE v1.cpf = :P1_CPFSEMFORM or v2.cpf = :P1_CPFSEMFORM ',
'    COLUMNS (',
'        vertex_id(v1) AS origem,',
'        edge_id(e) AS transferencia,',
'        vertex_id(v2) AS destino',
'    )',
')'))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P1_ACCOUNT_ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_04', 'force',
  'attribute_05', 'N',
  'attribute_14', 'N',
  'attribute_16', '640',
  'basestyles', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '  "vertex": {',
    '    "size": 12,',
    '    "label": "${properties.NAME}",',
    '    "icon": {',
    '      "class": "fa-money",',
    '      "color": "black"',
    '    }',
    '  },',
    '  "edge": {',
    '    "label": "${properties.AMOUNT}",',
    '    "width": 2',
    '  }',
    '}',
    '')),
  'custom_theme', 'N',
  'darktheme', 'N',
  'edgemarker', 'arrow',
  'enable_evolution', 'N',
  'escapehtml', 'N',
  'force_clusterenabled', 'N',
  'livesearch', 'N',
  'rulebasedstyles', wwv_flow_string.join(wwv_flow_t_varchar2(
    '[{',
    '  "_id": 1,',
    '  "component": "edge",',
    '  "stylingEnabled": true,',
    '  "target": "edge",',
    '  "visibilityEnabled": true,',
    '  "conditions": {',
    '    "operator": "and",',
    '    "conditions": [',
    '      {',
    '        "property": "SRC_ACCT_ID",',
    '        "operator": "!=",',
    '        "value": "&P1_ACCOUNT_ID."',
    '      }',
    '    ]',
    '  },',
    '  "legendTitle": "Edge Style",',
    '  "style": {',
    '    "color": "green",',
    '    "width": 2,',
    '    "label": {',
    '      "color": "gray",',
    '      "font": {',
    '        "size": 12',
    '      }',
    '    }',
    '  }',
    '},',
    '',
    '{',
    '  "_id": 2,',
    '  "component": "vertex",',
    '  "stylingEnabled": true,',
    '  "target": "vertex",',
    '  "visibilityEnabled": true,',
    '  "conditions": {',
    '    "operator": "and",',
    '    "conditions": [',
    '      {',
    '        "property": "NAME",',
    '        "operator": "*",',
    '        "value": ""',
    '      }',
    '    ]',
    '  },',
    '  "legendTitle": "Vertex Style",',
    '  "style": {',
    '    "color": "white",',
    '    "width": 2,',
    '    "label": {',
    '      "color": "gray",',
    '      "font": {',
    '        "size": 12',
    '      }',
    '    }',
    '  }',
    '},',
    '{',
    '  "_id": 3,',
    '  "component": "edge",',
    '  "stylingEnabled": true,',
    '  "target": "edge",',
    '  "visibilityEnabled": true,',
    '  "conditions": {',
    '    "operator": "and",',
    '    "conditions": [',
    '      {',
    '        "property": "SRC_ACCT_ID",',
    '        "operator": "=",',
    '        "value": "&P1_ACCOUNT_ID."',
    '      }',
    '    ]',
    '  },',
    '  "legendTitle": "Edge Style",',
    '  "style": {',
    '    "color": "red",',
    '    "width": 2,',
    '    "label": {',
    '      "color": "gray",',
    '      "font": {',
    '        "size": 12',
    '      }',
    '    }',
    '  }',
    '},',
    '{',
    '  "_id": 4,',
    '  "component": "vertex",',
    '  "stylingEnabled": true,',
    '  "target": "vertex",',
    '  "visibilityEnabled": true,',
    '  "conditions": {',
    '    "operator": "and",',
    '    "conditions": [',
    '      {',
    '        "property": "CPF",',
    '        "operator": "~",',
    '        "value": "&P1_CPFSEMFORM."',
    '      }',
    '    ]',
    '  },',
    '  "legendTitle": "My Accounts",',
    '  "style": {',
    '    "color": "black",',
    '    "width": 2,',
    '    "label": {',
    '      "color": "black",',
    '      "font": {',
    '        "size": 12',
    '      }',
    '    },',
    '    "icon": {',
    '      "class": "fa-user",',
    '      "color": "white"',
    '    }',
    '  }',
    '}',
    ']')),
  'show_legend', 'N',
  'showtitle', 'N',
  'size_mode', 'compact',
  'spacing', '10')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(57081884640700702)
,p_name=>'ORIGEM'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(57082005718700703)
,p_name=>'DESTINO'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(57082151019700704)
,p_name=>'TRANSFERENCIA'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(57082414138700707)
,p_plug_name=>unistr('Relacionamentos M\00EDdias Sociais')
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>90
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT origem, transferencia, destino',
'FROM GRAPH_TABLE (',
'    ogb_social_graph',
'    MATCH (p1) -[e1 is FOLLOWS]-> (p2) ',
'    WHERE p1.id = :P1_ACCOUNT_ID_MIDIAS OR p2.id = :P1_ACCOUNT_ID_MIDIAS',
'    COLUMNS (',
'        vertex_id(p1) AS origem,',
'        edge_id(e1) AS transferencia,',
'        vertex_id(p2) AS destino        ',
'    )',
');'))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P1_ACCOUNT_ID_MIDIAS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_02', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '    "evolution": {',
    '        "chart": "line",',
    '        "unit": "day",',
    '        "edge": "properties.FOLLOWED_DATE",',
    '        "preservePositions":"true"',
    '    }',
    '}')),
  'attribute_04', 'force',
  'attribute_05', 'N',
  'attribute_14', 'N',
  'attribute_16', '640',
  'basestyles', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '  "vertex": {',
    '    "size": 12,',
    '    "label": "${properties.FIRST} ${properties.LAST}",',
    '    "icon": {',
    '      "class": "fa-user",',
    '      "color": "black"',
    '    }',
    '  },',
    '  "edge": {',
    '    "width": 2',
    '  }',
    '}',
    '')),
  'custom_theme', 'N',
  'darktheme', 'N',
  'edgemarker', 'arrow',
  'enable_evolution', 'N',
  'escapehtml', 'N',
  'force_clusterenabled', 'N',
  'livesearch', 'N',
  'rulebasedstyles', wwv_flow_string.join(wwv_flow_t_varchar2(
    '[{',
    '  "_id": 1,',
    '  "component": "edge",',
    '  "stylingEnabled": true,',
    '  "target": "edge",',
    '  "visibilityEnabled": true,',
    '  "conditions": {',
    '    "operator": "and",',
    '    "conditions": [',
    '      {',
    '        "property": "ID",',
    '        "operator": ">",',
    '        "value": "0"',
    '      }',
    '    ]',
    '  },',
    '  "legendTitle": "Edge Style",',
    '  "style": {',
    '    "color": "lightblue",',
    '    "width": 2,',
    '    "label": {',
    '      "color": "gray",',
    '      "font": {',
    '        "size": 12',
    '      }',
    '    }',
    '  }',
    '},',
    '{',
    '  "_id": 2,',
    '  "component": "vertex",',
    '  "stylingEnabled": true,',
    '  "target": "vertex",',
    '  "visibilityEnabled": true,',
    '  "conditions": {',
    '    "operator": "and",',
    '    "conditions": [',
    '      {',
    '        "property": "ID",',
    '        "operator": "*",',
    '        "value": ""',
    '      }',
    '    ]',
    '  },',
    '  "legendTitle": "Vertex Style",',
    '  "style": {',
    '    "color": "white",',
    '    "width": 2,',
    '    "label": {',
    '      "color": "gray",',
    '      "font": {',
    '        "size": 12',
    '      }',
    '    }',
    '  }',
    '},',
    '{',
    '  "_id": 4,',
    '  "component": "vertex",',
    '  "stylingEnabled": true,',
    '  "target": "vertex",',
    '  "visibilityEnabled": true,',
    '  "conditions": {',
    '    "operator": "and",',
    '    "conditions": [',
    '      {',
    '        "property": "ID",',
    '        "operator": "=",',
    '        "value": "&P1_ACCOUNT_ID_MIDIAS."',
    '      }',
    '    ]',
    '  },',
    '  "legendTitle": "My Accounts",',
    '  "style": {',
    '    "color": "black",',
    '    "width": 2,',
    '    "label": {',
    '      "color": "black",',
    '      "font": {',
    '        "size": 12',
    '      }',
    '    },',
    '    "icon": {',
    '      "class": "fa-user",',
    '      "color": "white"',
    '    }',
    '  }',
    '}',
    ']')),
  'show_legend', 'N',
  'showtitle', 'Y',
  'size_mode', 'compact',
  'spacing', '10')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(57082540691700708)
,p_name=>'ORIGEM'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(57082665067700709)
,p_name=>'DESTINO'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(57082711078700710)
,p_name=>'TRANSFERENCIA'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(57083027625700713)
,p_plug_name=>'Performance Posts'
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>100
,p_location=>null
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P1_ACCOUNT_ID_MIDIAS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(57083130052700714)
,p_plug_name=>'Performance Post'
,p_parent_plug_id=>wwv_flow_imp.id(57083027625700713)
,p_icon_css_classes=>'fa-thumbs-down'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--noBorders:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    p.ID AS POST_ID,',
'    p.CONTENT,',
'    p.POSTED_DATE AS POSTED_DATE,',
'    COUNT(DISTINCT v.ID) AS TOTAL_VIEWS,',
'    COUNT(DISTINCT co.ID) AS TOTAL_COMMENTS,',
'    COUNT(DISTINCT l.ID) AS TOTAL_LIKES',
'FROM ',
'    OGB_POSTS p',
'JOIN ',
'    OGB_CREATES c ON p.ID = c.POST_ID',
'LEFT JOIN ',
'    OGB_VIEWS v ON p.ID = v.POST_ID',
'LEFT JOIN ',
'    OGB_COMMENTED_ON con ON p.ID = con.POST_ID',
'LEFT JOIN ',
'    OGB_COMMENTS co ON con.COMMENT_ID = co.ID',
'LEFT JOIN ',
'    OGB_REPLIES r ON co.ID = r.REPLY_TO  -- Replies to comments on this post',
'LEFT JOIN ',
'    OGB_LIKES l ON p.ID = l.POST_ID',
'WHERE ',
'    c.POSTER_ID = :P1_ACCOUNT_ID_MIDIAS',
'GROUP BY ',
'    p.ID, p.CONTENT, p.POSTED_DATE',
'ORDER BY ',
'    p.ID desc;',
''))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(57083254983700715)
,p_max_row_count=>'1000000'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'GRAPHUSER'
,p_internal_uid=>8453683988127421
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(57084136523700724)
,p_db_column_name=>'CONTENT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>unistr('Conte\00FAdo')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(57084212434700725)
,p_db_column_name=>'TOTAL_VIEWS'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>unistr('N\00BA Views')
,p_column_link=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.::P100_POST_ID:#POST_ID#'
,p_column_linktext=>'#TOTAL_VIEWS#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(57084276106700726)
,p_db_column_name=>'TOTAL_COMMENTS'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>unistr('N\00BA Coment\00E1rios')
,p_column_link=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.::P102_POST_ID:#POST_ID#'
,p_column_linktext=>'#TOTAL_COMMENTS#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(57084500808700728)
,p_db_column_name=>'TOTAL_LIKES'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>unistr('N\00BA Likes')
,p_column_link=>'f?p=&APP_ID.:103:&SESSION.::&DEBUG.::P103_POST_ID:#POST_ID#'
,p_column_linktext=>'#TOTAL_LIKES#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(57084747686700730)
,p_db_column_name=>'POST_ID'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Post Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(58049307005510696)
,p_db_column_name=>'POSTED_DATE'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Data Postagem'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MON-RR'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(57205759696990332)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'85762'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_view_mode=>'REPORT'
,p_report_columns=>'POST_ID:POSTED_DATE:CONTENT:TOTAL_VIEWS:TOTAL_LIKES:TOTAL_COMMENTS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(58050339967510706)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(57082414138700707)
,p_button_name=>'Copiar02'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Copiar CPFs'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P1_ACCOUNT_ID_MIDIAS'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56820523165659497)
,p_button_sequence=>10
,p_button_name=>'AIAssistant'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'AI Assistant'
,p_button_redirect_url=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
,p_button_css_classes=>'float my-float'
,p_icon_css_classes=>'fa-plus'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56823597269659528)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(56823373368659526)
,p_button_name=>'Pesquisar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Pesquisar'
,p_button_position=>'BUTTON_END'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(58049946525510702)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(57081581640700699)
,p_button_name=>'Copiar01'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Copiar CPFs'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P1_ACCOUNT_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56823552947659527)
,p_name=>'P1_CPF'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(56823373368659526)
,p_prompt=>'DIGITE O CPF'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_show_quick_picks=>'Y'
,p_quick_pick_label_01=>'Caiu no Golpe'
,p_quick_pick_value_01=>'3110789078'
,p_quick_pick_label_02=>'Jocely Green'
,p_quick_pick_value_02=>'26482017052'
,p_quick_pick_label_03=>'Daniele Leon'
,p_quick_pick_value_03=>'12746301916'
,p_quick_pick_label_04=>'Jeffrey Schneider'
,p_quick_pick_value_04=>'59546211569'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56937975235612506)
,p_name=>'P1_CPFSEMFORM'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(56823373368659526)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(57082354299700706)
,p_name=>'P1_ACCOUNT_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(56823373368659526)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(57082791809700711)
,p_name=>'P1_ACCOUNT_ID_MIDIAS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(56823373368659526)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(58049694168510700)
,p_name=>'P1_CPF_MIDIAS'
,p_item_sequence=>80
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT LISTAGG(cpf, ''|'') WITHIN GROUP (ORDER BY cpf) AS cpfs from(',
'select distinct cpf from (',
'SELECT cpf_origem as cpf',
'FROM GRAPH_TABLE (',
'    ogb_social_graph',
'    MATCH (p1) -[e1 is FOLLOWS]-> (p2) ',
'    WHERE p1.id = :P1_ACCOUNT_ID_MIDIAS OR p2.id = :P1_ACCOUNT_ID_MIDIAS',
'    COLUMNS (',
'        p1.cpf AS cpf_origem,',
'        p2.cpf AS cpf_destino',
'    )',
')',
'union all',
'SELECT cpf_destino as cpf',
'FROM GRAPH_TABLE (',
'    ogb_social_graph',
'    MATCH (p1) -[e1 is FOLLOWS]-> (p2) ',
'    WHERE p1.id = :P1_ACCOUNT_ID_MIDIAS OR p2.id = :P1_ACCOUNT_ID_MIDIAS',
'    COLUMNS (',
'        p1.cpf AS cpf_origem,',
'        p2.cpf AS cpf_destino',
'    )',
')) order by 1);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>'P1_ACCOUNT_ID_MIDIAS'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(58049782311510701)
,p_name=>'P1_CPF_FINANCAS'
,p_item_sequence=>50
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT LISTAGG(cpf, ''|'') WITHIN GROUP (ORDER BY cpf) AS cpfs from (',
'select distinct cpf from (',
'SELECT cpf_origem as cpf',
'FROM GRAPH_TABLE (',
'    BANK_GRAPH',
'    MATCH (v1 IS BANK_ACCOUNTS) -[e IS BANK_TRANSFERS]-> (v2 IS BANK_ACCOUNTS)',
'    WHERE v1.cpf = :P1_CPFSEMFORM or v2.cpf = :P1_CPFSEMFORM ',
'    COLUMNS (',
'        v1.cpf AS cpf_origem,',
'        v2.cpf AS cpf_destino',
'    )',
')',
'union all',
'SELECT cpf_destino as cpf',
'FROM GRAPH_TABLE (',
'    BANK_GRAPH',
'    MATCH (v1 IS BANK_ACCOUNTS) -[e IS BANK_TRANSFERS]-> (v2 IS BANK_ACCOUNTS)',
'    WHERE v1.cpf = :P1_CPFSEMFORM or v2.cpf = :P1_CPFSEMFORM ',
'    COLUMNS (',
'        v1.cpf AS cpf_origem,',
'        v2.cpf AS cpf_destino',
'    )',
')));'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>'P1_ACCOUNT_ID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(56937615824612502)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_CPF'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keyup'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56937746302612503)
,p_event_id=>wwv_flow_imp.id(56937615824612502)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function formatCPF(cpf) {',
'    cpf = cpf.replace(/\D/g, ''''); // Remove non-numeric characters',
'    cpf = cpf.replace(/(\d{3})(\d)/, ''$1.$2'');',
'    cpf = cpf.replace(/(\d{3})(\d)/, ''$1.$2'');',
'    cpf = cpf.replace(/(\d{3})(\d{1,2})$/, ''$1-$2'');',
'    return cpf;',
'}',
'',
'// Get CPF field and format while typing',
'var cpfField = document.getElementById("P1_CPF");',
'if (cpfField) {',
'    cpfField.value = formatCPF(cpfField.value);',
'}',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(58050051731510703)
,p_name=>'Click01'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(58049946525510702)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(58050074889510704)
,p_event_id=>wwv_flow_imp.id(58050051731510703)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*to get the value of the hidden item*/',
'let item = $("#P1_CPF_FINANCAS");',
'',
'/*to change the item type to text and select the value inside the item*/ ',
'item.attr("type", "text").select();',
'',
'/*to copy the text inside the item*/',
'document.execCommand("copy");',
'',
'/*to change the item type to hidden*/',
'item.attr("type", "hidden");',
'',
'/*to show success message (Optional)*/',
'apex.message.showPageSuccess(''Copied to Clipboard!'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(58050424094510707)
,p_name=>'Click02'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(58050339967510706)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(58050494086510708)
,p_event_id=>wwv_flow_imp.id(58050424094510707)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*to get the value of the hidden item*/',
'let item = $("#P1_CPF_MIDIAS");',
'',
'/*to change the item type to text and select the value inside the item*/ ',
'item.attr("type", "text").select();',
'',
'/*to copy the text inside the item*/',
'document.execCommand("copy");',
'',
'/*to change the item type to hidden*/',
'item.attr("type", "hidden");',
'',
'/*to show success message (Optional)*/',
'apex.message.showPageSuccess(''Copied to Clipboard!'');'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(56937871625612505)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Arrumar CPF Consulta'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--DECLARE',
'--    CPF_SEMFORM VARCHAR2(11); -- Use VARCHAR2, since CPF may start with zero',
'--    ACCOUNTID NUMBER;',
'--    ACCOUNTID_MIDIAS NUMBER;',
'--BEGIN',
'--    SELECT REGEXP_REPLACE(:P1_CPF, ''[^0-9]'', '''') INTO CPF_SEMFORM FROM DUAL;',
'--    ',
'--    SELECT ID INTO ACCOUNTID from bank_accounts where CPF = CPF_SEMFORM;',
'--',
'--    SELECT ID INTO ACCOUNTID_MIDIAS from ogb_users where CPF = CPF_SEMFORM;',
'--    -- Assign cleaned CPF to an APEX item',
'--    :P1_CPFSEMFORM := CPF_SEMFORM;',
'--    :P1_ACCOUNT_ID := ACCOUNTID;',
'--    :P1_ACCOUNT_ID_MIDIAS := ACCOUNTID_MIDIAS;',
'--END;',
'--',
'DECLARE',
'    CPF_SEMFORM VARCHAR2(11); -- Cleaned CPF',
'    ACCOUNTID NUMBER := NULL;',
'    ACCOUNTID_MIDIAS NUMBER := NULL;',
'BEGIN',
'    -- Clean the CPF input',
'    SELECT REGEXP_REPLACE(:P1_CPF, ''[^0-9]'', '''') INTO CPF_SEMFORM FROM DUAL;',
'',
'    -- Try to get ACCOUNTID from bank_accounts',
'    BEGIN',
'        SELECT ID INTO ACCOUNTID FROM bank_accounts WHERE CPF = CPF_SEMFORM;',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            ACCOUNTID := NULL;',
'    END;',
'',
'    -- Try to get ACCOUNTID_MIDIAS from ogb_users',
'    BEGIN',
'        SELECT ID INTO ACCOUNTID_MIDIAS FROM ogb_users WHERE CPF = CPF_SEMFORM;',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            ACCOUNTID_MIDIAS := NULL;',
'    END;',
'',
'    -- Assign to APEX items',
'    :P1_CPFSEMFORM := CPF_SEMFORM;',
'    :P1_ACCOUNT_ID := NVL(ACCOUNTID, '''');',
'    :P1_ACCOUNT_ID_MIDIAS := NVL(ACCOUNTID_MIDIAS, '''');',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>8308300630039211
);
wwv_flow_imp.component_end;
end;
/
