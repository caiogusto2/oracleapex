prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>7752372273860007
,p_default_application_id=>100
,p_default_id_offset=>7753530837857734
,p_default_owner=>'DEMO'
);
wwv_flow_imp_page.create_page(
 p_id=>10
,p_name=>'Monitoramento'
,p_alias=>unistr('AVALIA\00C7\00C3O-MASSA')
,p_step_title=>'Monitoramento'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.float{',
'  z-index:100;',
'  position:fixed;',
'  width:60px;',
'  height:60px;',
'  bottom:40px;',
'  right:40px;',
'  background-color: black;',
'  color:#FFF;',
'  border-radius:50px;',
'  text-align:center;',
'  box-shadow: 2px 2px 3px #999;',
'}',
'.my-float{',
'  margin-top:22px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49311869260178033)
,p_plug_name=>'Monitoramento de Bases'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--featured'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>90
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(48562985213000213)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49527433933850492)
,p_plug_name=>unistr('Transa\00E7\00F5es Suspeitas')
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:is-collapsed:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>50
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49527625130850494)
,p_plug_name=>unistr('Transa\00E7\00F5es Suspeitas')
,p_parent_plug_id=>wwv_flow_imp.id(49527433933850492)
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    TO_CHAR(txn.TXN_DATE, ''DD/MM/YYYY'') AS TXN_DATE,',
'    txn.AMOUNT,',
'    txn.SRC_NAME AS SRC_ACCOUNT_NAME,',
'    REGEXP_REPLACE(REGEXP_REPLACE(txn.SRC_CPF_RAW, ''\D'', ''''), ''(\d{3})(\d{3})(\d{3})(\d{2})'', ''\1.\2.\3-\4'') AS SRC_CPF,',
'    txn.DST_NAME AS DST_ACCOUNT_NAME,',
'    REGEXP_REPLACE(REGEXP_REPLACE(txn.DST_CPF_RAW, ''\D'', ''''), ''(\d{3})(\d{3})(\d{3})(\d{2})'', ''\1.\2.\3-\4'') AS DST_CPF',
'--    CASE ',
'--        WHEN txn.ANOMALY = 1 THEN ''fa-thumbs-down u-danger-text''',
'--        ELSE ''fa-thumbs-up u-success-text''',
'--    END AS TRANSACTION_TYPE',
'FROM (',
'    SELECT ',
'        bt.TXN_ID,',
'        bt.TXN_DATE,',
'        bt.AMOUNT,',
'        src.CPF AS SRC_CPF_RAW,',
'        dst.CPF AS DST_CPF_RAW,',
'        src.NAME AS SRC_NAME,',
'        dst.NAME AS DST_NAME,',
'        fp.ANOMALY',
'    FROM BANK_TRANSFERS bt',
'    JOIN BANK_ACCOUNTS src ON bt.SRC_ACCT_ID = src.ID',
'    JOIN BANK_ACCOUNTS dst ON bt.DST_ACCT_ID = dst.ID',
'    LEFT JOIN FRAUD_PREDICTIONS fp ON fp.TXN_ID = bt.TXN_ID',
'    where fp.anomaly = 1',
'--    WHERE REGEXP_REPLACE(src.CPF, ''\D'', '''') = REGEXP_REPLACE(:P1_CPF, ''\D'', '''')',
'--       OR REGEXP_REPLACE(dst.CPF, ''\D'', '''') = REGEXP_REPLACE(:P1_CPF, ''\D'', '''')',
'    ORDER BY bt.TXN_DATE DESC',
') txn',
'--WHERE ROWNUM <= 10',
';',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(49527730065850495)
,p_max_row_count=>'100000'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'GRAPHUSER'
,p_internal_uid=>8671621945799904
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(49528168488850499)
,p_db_column_name=>'AMOUNT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Amount'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(49528535457850503)
,p_db_column_name=>'TXN_DATE'
,p_display_order=>50
,p_column_identifier=>'H'
,p_column_label=>unistr('Data Transa\00E7\00E3o')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MON-RR'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(49528644901850504)
,p_db_column_name=>'SRC_ACCOUNT_NAME'
,p_display_order=>60
,p_column_identifier=>'I'
,p_column_label=>'Origem - Nome'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(49528761843850505)
,p_db_column_name=>'SRC_CPF'
,p_display_order=>70
,p_column_identifier=>'J'
,p_column_label=>'Origem - CPF'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(49528855541850506)
,p_db_column_name=>'DST_ACCOUNT_NAME'
,p_display_order=>80
,p_column_identifier=>'K'
,p_column_label=>'Destino - Nome'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(49529005172850507)
,p_db_column_name=>'DST_CPF'
,p_display_order=>90
,p_column_identifier=>'L'
,p_column_label=>'Destino - CPF'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(49540720421501107)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'86847'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_view_mode=>'REPORT'
,p_report_columns=>'TXN_DATE:DST_ACCOUNT_NAME:DST_CPF:SRC_ACCOUNT_NAME:SRC_CPF:AMOUNT:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49527514922850493)
,p_plug_name=>unistr('Avalia\00E7\00E3o Posts')
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:is-collapsed:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>70
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49529694120850514)
,p_plug_name=>unistr('Intera\00E7\00F5es Suspeitas')
,p_parent_plug_id=>wwv_flow_imp.id(49527514922850493)
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from ',
'(SELECT ',
'    p.ID AS CONTENT_ID,',
'    p.CONTENT AS TEXT,',
'    u.CPF AS CPF,',
'    ''POST'' AS CONTENT_TYPE,',
'    p.POSTED_DATE AS DATE_CREATED',
'FROM ',
'    OGB_POSTS p',
'JOIN ',
'    OGB_CREATES c ON p.ID = c.POST_ID',
'JOIN ',
'    OGB_USERS u ON c.POSTER_ID = u.ID',
'',
'UNION ALL',
'',
'SELECT ',
'    c.ID AS CONTENT_ID,',
'    c.COMMENT_TEXT AS TEXT,',
'    u.CPF AS CPF,',
unistr('    ''COMENT\00C1RIO'' AS CONTENT_TYPE,'),
'    umc.COMMENT_DATE AS DATE_CREATED',
'FROM ',
'    OGB_COMMENTS c',
'JOIN ',
'    OGB_USER_MADE_COMMENT umc ON c.ID = umc.COMMENT_ID',
'JOIN ',
'    OGB_USERS u ON umc.USER_ID = u.ID)',
unistr('WHERE REGEXP_LIKE(upper(text), ''ARMA|SEXO|PEDOFILIA|GOSTOSA|NOVINHA|DELICIA|TES\00C3O|REBOLANDO'')'),
'order by DATE_CREATED desc;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(49529730328850515)
,p_max_row_count=>'1000000'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'GRAPHUSER'
,p_internal_uid=>8673622208799924
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(49529847040850516)
,p_db_column_name=>'CONTENT_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(49529988830850517)
,p_db_column_name=>'TEXT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Texto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(49530035135850518)
,p_db_column_name=>'CPF'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'CPF'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(49530179985850519)
,p_db_column_name=>'CONTENT_TYPE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Tipo Conteudo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(49530252456850520)
,p_db_column_name=>'DATE_CREATED'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>unistr('Data Intera\00E7\00E3o')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MON-RR'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(49558262540393537)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'87022'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CONTENT_ID:TEXT:CPF:CONTENT_TYPE:DATE_CREATED'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49531073057850528)
,p_plug_name=>unistr('Estat\00EDsticas Massa de Dados')
,p_icon_css_classes=>'fa-bar-chart'
,p_region_template_options=>'#DEFAULT#:t-Region--showIcon:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49312246876178037)
,p_plug_name=>unistr('Estat\00EDsticas Massa de Dados')
,p_parent_plug_id=>wwv_flow_imp.id(49531073057850528)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
unistr('  (select count(*) from ogb_users) as "Usu\00E1rios m\00EDdias",'),
unistr('  (select count(*) from bank_accounts) as "Usu\00E1rios finan\00E7as",'),
unistr('  (select count(*) from ogb_users o inner join bank_accounts b on o.cpf = b.cpf) as "Usu\00E1rios em comum - CPF";'),
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(49530615337850524)
,p_max_row_count=>'1000000'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'GRAPHUSER'
,p_internal_uid=>8674507217799933
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(49530715510850525)
,p_db_column_name=>unistr('Usu\00E1rios m\00EDdias')
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>unistr('Usu\00E1rios DB M\00EDdias')
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(49530854374850526)
,p_db_column_name=>unistr('Usu\00E1rios finan\00E7as')
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>unistr('Usu\00E1rios DB Finan\00E7as')
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(49530939981850527)
,p_db_column_name=>unistr('Usu\00E1rios em comum - CPF')
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>unistr('Usu\00E1rios Em Comum - CPF')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(50257073761252518)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'94010'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('Usu\00E1rios m\00EDdias:Usu\00E1rios finan\00E7as:Usu\00E1rios em comum - CPF')
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49531193985850529)
,p_plug_name=>'KPI Monitoramento'
,p_icon_css_classes=>'fa-exclamation-triangle-o'
,p_region_template_options=>'#DEFAULT#:t-Region--showIcon:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49531284999850530)
,p_plug_name=>unistr('Estat\00EDsticas Massa de Dados')
,p_parent_plug_id=>wwv_flow_imp.id(49531193985850529)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
unistr('    ''Finan\00E7as'' as basedados,'),
'    count(txn.TXN_ID) as qtde',
'FROM (',
'    SELECT ',
'        bt.TXN_ID,',
'        bt.TXN_DATE,',
'        bt.AMOUNT,',
'        src.CPF AS SRC_CPF_RAW,',
'        dst.CPF AS DST_CPF_RAW,',
'        src.NAME AS SRC_NAME,',
'        dst.NAME AS DST_NAME,',
'        fp.ANOMALY',
'    FROM BANK_TRANSFERS bt',
'    JOIN BANK_ACCOUNTS src ON bt.SRC_ACCT_ID = src.ID',
'    JOIN BANK_ACCOUNTS dst ON bt.DST_ACCT_ID = dst.ID',
'    LEFT JOIN FRAUD_PREDICTIONS fp ON fp.TXN_ID = bt.TXN_ID',
'    WHERE fp.ANOMALY = 1',
') txn',
'',
'union all',
'',
'select ',
unistr('    ''M\00EDdias Sociais'' as basedados,'),
'    count (*) as qtde',
'from (',
'select * from',
'(SELECT ',
'    p.ID AS CONTENT_ID,',
'    p.CONTENT AS TEXT,',
'    u.CPF AS CPF,',
'    ''POST'' AS CONTENT_TYPE,',
'    p.POSTED_DATE AS DATE_CREATED',
'FROM ',
'    OGB_POSTS p',
'JOIN ',
'    OGB_CREATES c ON p.ID = c.POST_ID',
'JOIN ',
'    OGB_USERS u ON c.POSTER_ID = u.ID',
'',
'UNION ALL',
'',
'SELECT ',
'    c.ID AS CONTENT_ID,',
'    c.COMMENT_TEXT AS TEXT,',
'    u.CPF AS CPF,',
unistr('    ''COMENT\00C1RIO'' AS CONTENT_TYPE,'),
'    umc.COMMENT_DATE AS DATE_CREATED',
'FROM ',
'    OGB_COMMENTS c',
'JOIN ',
'    OGB_USER_MADE_COMMENT umc ON c.ID = umc.COMMENT_ID',
'JOIN ',
'    OGB_USERS u ON umc.USER_ID = u.ID)',
unistr('WHERE REGEXP_LIKE(upper(text), ''ARMA|SEXO|PEDOFILIA|GOSTOSA|NOVINHA|DELICIA|TES\00C3O|REBOLANDO''));')))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(49531385600850531)
,p_max_row_count=>'1000000'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'GRAPHUSER'
,p_internal_uid=>8675277480799940
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(49531772744850535)
,p_db_column_name=>'BASEDADOS'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Base de Dados'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(49531889002850536)
,p_db_column_name=>'QTDE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Alertas'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(50266498534180074)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'94104'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BASEDADOS:QTDE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(49489399650008957)
,p_button_sequence=>10
,p_button_name=>'AIAssistant'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'AI Assistant'
,p_button_redirect_url=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
,p_button_css_classes=>'float my-float'
,p_icon_css_classes=>'fa-plus'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(49505552612008809)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P10_CPF'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keyup'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(49506048129008804)
,p_event_id=>wwv_flow_imp.id(49505552612008809)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function formatCPF(cpf) {',
'    cpf = cpf.replace(/\D/g, ''''); // Remove non-numeric characters',
'    cpf = cpf.replace(/(\d{3})(\d)/, ''$1.$2'');',
'    cpf = cpf.replace(/(\d{3})(\d)/, ''$1.$2'');',
'    cpf = cpf.replace(/(\d{3})(\d{1,2})$/, ''$1-$2'');',
'    return cpf;',
'}',
'',
'// Get CPF field and format while typing',
'var cpfField = document.getElementById("P10_CPF");',
'if (cpfField) {',
'    cpfField.value = formatCPF(cpfField.value);',
'}',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(49505219693008811)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Arrumar CPF Consulta'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--DECLARE',
'--    CPF_SEMFORM VARCHAR2(11); -- Use VARCHAR2, since CPF may start with zero',
'--    ACCOUNTID NUMBER;',
'--    ACCOUNTID_MIDIAS NUMBER;',
'--BEGIN',
'--    SELECT REGEXP_REPLACE(:P10_CPF, ''[^0-9]'', '''') INTO CPF_SEMFORM FROM DUAL;',
'--    ',
'--    SELECT ID INTO ACCOUNTID from bank_accounts where CPF = CPF_SEMFORM;',
'--',
'--    SELECT ID INTO ACCOUNTID_MIDIAS from ogb_users where CPF = CPF_SEMFORM;',
'--    -- Assign cleaned CPF to an APEX item',
'--    :P10_CPFSEMFORM := CPF_SEMFORM;',
'--    :P10_ACCOUNT_ID := ACCOUNTID;',
'--    :P10_ACCOUNT_ID_MIDIAS := ACCOUNTID_MIDIAS;',
'--END;',
'--',
'DECLARE',
'    CPF_SEMFORM VARCHAR2(11); -- Cleaned CPF',
'    ACCOUNTID NUMBER := NULL;',
'    ACCOUNTID_MIDIAS NUMBER := NULL;',
'BEGIN',
'    -- Clean the CPF input',
'    SELECT REGEXP_REPLACE(:P10_CPF, ''[^0-9]'', '''') INTO CPF_SEMFORM FROM DUAL;',
'',
'    -- Try to get ACCOUNTID from bank_accounts',
'    BEGIN',
'        SELECT ID INTO ACCOUNTID FROM bank_accounts WHERE CPF = CPF_SEMFORM;',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            ACCOUNTID := NULL;',
'    END;',
'',
'    -- Try to get ACCOUNTID_MIDIAS from ogb_users',
'    BEGIN',
'        SELECT ID INTO ACCOUNTID_MIDIAS FROM ogb_users WHERE CPF = CPF_SEMFORM;',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            ACCOUNTID_MIDIAS := NULL;',
'    END;',
'',
'    -- Assign to APEX items',
'    :P10_CPFSEMFORM := CPF_SEMFORM;',
'    :P10_ACCOUNT_ID := NVL(ACCOUNTID, '''');',
'    :P10_ACCOUNT_ID_MIDIAS := NVL(ACCOUNTID_MIDIAS, '''');',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>8649111572958220
);
wwv_flow_imp.component_end;
end;
/
