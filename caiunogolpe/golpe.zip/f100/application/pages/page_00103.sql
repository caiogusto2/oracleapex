prompt --application/pages/page_00103
begin
--   Manifest
--     PAGE: 00103
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>7752372273860007
,p_default_application_id=>100
,p_default_id_offset=>7753530837857734
,p_default_owner=>'DEMO'
);
wwv_flow_imp_page.create_page(
 p_id=>103
,p_name=>'Likes'
,p_alias=>'LIKES'
,p_page_mode=>'MODAL'
,p_step_title=>'Likes'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>1661186590416509825
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_resizable=>'Y'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(83679373440026309)
,p_plug_name=>'Likes Post'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT origem, transferencia, destino',
'FROM GRAPH_TABLE (',
'  ogb_social_graph',
'  MATCH (u IS USERS) -[v IS LIKES]-> (p IS POSTS)',
'  where p.id = :P103_POST_ID',
'  COLUMNS (',
'    vertex_id(u) AS origem,',
'    edge_id(v) AS transferencia,',
'    vertex_id(p) AS destino',
'  )',
');',
''))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_04', 'radial',
  'attribute_05', 'N',
  'attribute_14', 'N',
  'attribute_16', '640',
  'basestyles', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '  "vertex": {',
    '    "size": 12,',
    '    "label": "${properties.FIRST} ${properties.LAST} ",',
    '    "icon": {',
    '      "class": "fa-user",',
    '      "color": "black"',
    '    }',
    '  },',
    '  "edge": {',
    '    "width": 2',
    '  }',
    '}',
    '')),
  'custom_theme', 'N',
  'darktheme', 'N',
  'edgemarker', 'arrow',
  'enable_evolution', 'N',
  'escapehtml', 'N',
  'livesearch', 'N',
  'rulebasedstyles', wwv_flow_string.join(wwv_flow_t_varchar2(
    '[{',
    '  "_id": 1,',
    '  "component": "edge",',
    '  "stylingEnabled": true,',
    '  "target": "edge",',
    '  "visibilityEnabled": true,',
    '  "conditions": {',
    '    "operator": "and",',
    '    "conditions": [',
    '      {',
    '        "property": "ID",',
    '        "operator": ">",',
    '        "value": "0"',
    '      }',
    '    ]',
    '  },',
    '  "legendTitle": "Edge Style",',
    '  "style": {',
    '    "color": "lightblue",',
    '    "width": 2,',
    '    "label": {',
    '      "color": "gray",',
    '      "font": {',
    '        "size": 12',
    '      }',
    '    }',
    '  }',
    '},',
    '{',
    '  "_id": 2,',
    '  "component": "vertex",',
    '  "stylingEnabled": true,',
    '  "target": "vertex",',
    '  "visibilityEnabled": true,',
    '  "conditions": {',
    '    "operator": "and",',
    '    "conditions": [',
    '      {',
    '        "property": "ID",',
    '        "operator": "*",',
    '        "value": ""',
    '      }',
    '    ]',
    '  },',
    '  "legendTitle": "Vertex Style",',
    '  "style": {',
    '    "color": "white",',
    '    "width": 2,',
    '    "label": {',
    '      "color": "gray",',
    '      "font": {',
    '        "size": 12',
    '      }',
    '    }',
    '  }',
    '},',
    '{',
    '  "_id": 4,',
    '  "component": "vertex",',
    '  "stylingEnabled": true,',
    '  "target": "vertex",',
    '  "visibilityEnabled": true,',
    '  "conditions": {',
    '    "operator": "and",',
    '    "conditions": [',
    '      {',
    '        "property": "ID",',
    '        "operator": "=",',
    '        "value": "&P103_POST_ID."',
    '      }',
    '    ]',
    '  },',
    '  "legendTitle": "My Accounts",',
    '  "style": {',
    '    "color": "black",',
    '    "width": 2,',
    '    "label": {',
    '      "color": "black",',
    '      "font": {',
    '        "size": 12',
    '      }',
    '    },',
    '    "icon": {',
    '      "class": "fa-user",',
    '      "color": "white"',
    '    }',
    '  }',
    '}',
    ']')),
  'show_legend', 'N',
  'showtitle', 'N',
  'size_mode', 'compact',
  'spacing', '2')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(83679499993026310)
,p_name=>'ORIGEM'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(83679624369026311)
,p_name=>'DESTINO'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(83679670380026312)
,p_name=>'TRANSFERENCIA'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(75101920170738445)
,p_name=>'P103_POST_ID'
,p_item_sequence=>20
,p_prompt=>'Post ID'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp.component_end;
end;
/
