prompt --application/pages/page_00020
begin
--   Manifest
--     PAGE: 00020
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>33101331255185790
,p_default_application_id=>106
,p_default_id_offset=>33102577282192857
,p_default_owner=>'GRAPHUSER'
);
wwv_flow_imp_page.create_page(
 p_id=>20
,p_name=>'Cruzamento Bases'
,p_alias=>'CRUZAMENTO-BASES'
,p_step_title=>'Cruzamento Bases'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.float{',
'  z-index:100;',
'  position:fixed;',
'  width:60px;',
'  height:60px;',
'  bottom:40px;',
'  right:40px;',
'  background-color: black;',
'  color:#FFF;',
'  border-radius:50px;',
'  text-align:center;',
'  box-shadow: 2px 2px 3px #999;',
'}',
'.my-float{',
'  margin-top:22px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42522470932130260)
,p_plug_name=>'Cruzamento Bases'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--featured'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>80
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(40809454375142479)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(50653835470830284)
,p_plug_name=>'Filtro'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>1569994581593435632
,p_plug_display_sequence=>20
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(50912043742871457)
,p_plug_name=>unistr('Transa\00E7\00F5es Financeiras')
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>60
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT origem, transferencia, destino',
'FROM GRAPH_TABLE (',
'    BANK_GRAPH',
'    MATCH (v1 IS BANK_ACCOUNTS) -[e IS BANK_TRANSFERS]-> (v2 IS BANK_ACCOUNTS)',
'    WHERE REGEXP_LIKE(v1.cpf, :P20_CPF, ''i'') OR REGEXP_LIKE(v2.cpf, :P20_CPF, ''i'')',
'    COLUMNS (',
'        vertex_id(v1) AS origem,',
'        edge_id(e) AS transferencia,',
'        vertex_id(v2) AS destino',
'    )',
')'))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P20_CPF'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_04', 'radial',
  'attribute_05', 'N',
  'attribute_14', 'N',
  'attribute_16', '640',
  'basestyles', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '  "vertex": {',
    '    "size": 12,',
    '    "label": "${properties.NAME}",',
    '    "icon": {',
    '      "class": "fa-money",',
    '      "color": "black"',
    '    }',
    '  },',
    '  "edge": {',
    '    "label": "${properties.AMOUNT}",',
    '    "width": 2',
    '  }',
    '}',
    '')),
  'custom_theme', 'N',
  'darktheme', 'N',
  'edgemarker', 'arrow',
  'enable_evolution', 'N',
  'escapehtml', 'N',
  'livesearch', 'N',
  'rulebasedstyles', wwv_flow_string.join(wwv_flow_t_varchar2(
    '[',
    '{',
    '  "_id": 2,',
    '  "component": "vertex",',
    '  "stylingEnabled": true,',
    '  "target": "vertex",',
    '  "visibilityEnabled": true,',
    '  "conditions": {',
    '    "operator": "and",',
    '    "conditions": [',
    '      {',
    '        "property": "NAME",',
    '        "operator": "*",',
    '        "value": ""',
    '      }',
    '    ]',
    '  },',
    '  "legendTitle": "Vertex Style",',
    '  "style": {',
    '    "color": "white",',
    '    "width": 2,',
    '    "label": {',
    '      "color": "gray",',
    '      "font": {',
    '        "size": 12',
    '      }',
    '    }',
    '  }',
    '},',
    '{',
    '  "_id": 4,',
    '  "component": "vertex",',
    '  "stylingEnabled": true,',
    '  "target": "vertex",',
    '  "visibilityEnabled": true,',
    '  "conditions": {',
    '    "operator": "and",',
    '    "conditions": [',
    '      {',
    '        "property": "CPF",',
    '        "operator": "~",',
    '        "value": "&P20_CPF."',
    '      }',
    '    ]',
    '  },',
    '  "legendTitle": "My Accounts",',
    '  "style": {',
    '    "color": "black",',
    '    "width": 2,',
    '    "label": {',
    '      "color": "black",',
    '      "font": {',
    '        "size": 12',
    '      }',
    '    },',
    '    "icon": {',
    '      "class": "fa-user",',
    '      "color": "white"',
    '    }',
    '  }',
    '}',
    ']')),
  'show_legend', 'N',
  'showtitle', 'N',
  'size_mode', 'compact',
  'spacing', '2')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(50912346742871460)
,p_name=>'ORIGEM'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(50912467820871461)
,p_name=>'DESTINO'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(50912613121871462)
,p_name=>'TRANSFERENCIA'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(50912876240871465)
,p_plug_name=>unistr('Relacionamentos M\00EDdias Sociais')
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>70
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT origem, transferencia, destino',
'FROM GRAPH_TABLE (',
'    ogb_social_graph',
'    MATCH (p20) -[e1 is FOLLOWS]-> (p2) ',
'    WHERE REGEXP_LIKE(p20.cpf, :P20_CPF, ''i'') OR REGEXP_LIKE(p2.cpf, :P20_CPF, ''i'')',
'    COLUMNS (',
'        vertex_id(p20) AS origem,',
'        edge_id(e1) AS transferencia,',
'        vertex_id(p2) AS destino        ',
'    )',
');'))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P20_CPF'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_04', 'radial',
  'attribute_05', 'N',
  'attribute_14', 'N',
  'attribute_16', '640',
  'basestyles', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '  "vertex": {',
    '    "size": 12,',
    '    "label": "${properties.FIRST} ${properties.LAST}",',
    '    "icon": {',
    '      "class": "fa-user",',
    '      "color": "black"',
    '    }',
    '  },',
    '  "edge": {',
    '    "width": 2',
    '  }',
    '}',
    '')),
  'custom_theme', 'N',
  'darktheme', 'N',
  'edgemarker', 'arrow',
  'enable_evolution', 'N',
  'escapehtml', 'N',
  'livesearch', 'N',
  'rulebasedstyles', wwv_flow_string.join(wwv_flow_t_varchar2(
    '[{',
    '  "_id": 1,',
    '  "component": "edge",',
    '  "stylingEnabled": true,',
    '  "target": "edge",',
    '  "visibilityEnabled": true,',
    '  "conditions": {',
    '    "operator": "and",',
    '    "conditions": [',
    '      {',
    '        "property": "ID",',
    '        "operator": ">",',
    '        "value": "0"',
    '      }',
    '    ]',
    '  },',
    '  "legendTitle": "Edge Style",',
    '  "style": {',
    '    "color": "lightblue",',
    '    "width": 2,',
    '    "label": {',
    '      "color": "gray",',
    '      "font": {',
    '        "size": 12',
    '      }',
    '    }',
    '  }',
    '},',
    '{',
    '  "_id": 2,',
    '  "component": "vertex",',
    '  "stylingEnabled": true,',
    '  "target": "vertex",',
    '  "visibilityEnabled": true,',
    '  "conditions": {',
    '    "operator": "and",',
    '    "conditions": [',
    '      {',
    '        "property": "ID",',
    '        "operator": "*",',
    '        "value": ""',
    '      }',
    '    ]',
    '  },',
    '  "legendTitle": "Vertex Style",',
    '  "style": {',
    '    "color": "white",',
    '    "width": 2,',
    '    "label": {',
    '      "color": "gray",',
    '      "font": {',
    '        "size": 12',
    '      }',
    '    }',
    '  }',
    '},',
    '{',
    '  "_id": 4,',
    '  "component": "vertex",',
    '  "stylingEnabled": true,',
    '  "target": "vertex",',
    '  "visibilityEnabled": true,',
    '  "conditions": {',
    '    "operator": "and",',
    '    "conditions": [',
    '      {',
    '        "property": "CPF",',
    '        "operator": "~",',
    '        "value": "&P20_CPF."',
    '      }',
    '    ]',
    '  },',
    '  "legendTitle": "My Accounts",',
    '  "style": {',
    '    "color": "black",',
    '    "width": 2,',
    '    "label": {',
    '      "color": "black",',
    '      "font": {',
    '        "size": 12',
    '      }',
    '    },',
    '    "icon": {',
    '      "class": "fa-user",',
    '      "color": "white"',
    '    }',
    '  }',
    '}',
    ']')),
  'show_legend', 'N',
  'showtitle', 'N',
  'size_mode', 'compact',
  'spacing', '2')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(50913002793871466)
,p_name=>'ORIGEM'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(50913127169871467)
,p_name=>'DESTINO'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(50913173180871468)
,p_name=>'TRANSFERENCIA'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(42460730395744044)
,p_button_sequence=>10
,p_button_name=>'AIAssistant'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'AI Assistant'
,p_button_redirect_url=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
,p_button_css_classes=>'float my-float'
,p_icon_css_classes=>'fa-plus'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(42471072590743954)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(50653835470830284)
,p_button_name=>'Pesquisar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Pesquisar'
,p_button_position=>'BUTTON_END'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(50665404921830186)
,p_name=>'P20_CPF'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(50653835470830284)
,p_prompt=>'DIGITE OS CPFS'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_show_quick_picks=>'Y'
,p_quick_pick_label_01=>'CPF''s Caiu no Golpe'
,p_quick_pick_value_01=>'3110789078|23205184594|38325904223|35047019583|12317416024|52722617112|23017129509|38845841870|16201511616|33253126535|27103206030'
);
wwv_flow_imp.component_end;
end;
/
