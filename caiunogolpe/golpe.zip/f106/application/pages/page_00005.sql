prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>33101331255185790
,p_default_application_id=>106
,p_default_id_offset=>33102577282192857
,p_default_owner=>'GRAPHUSER'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'Uploader Arquivos'
,p_alias=>'UPLOADER-ARQUIVOS'
,p_page_mode=>'MODAL'
,p_step_title=>'Uploader Arquivos'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(98829537516614390)
,p_plug_name=>'PDF Uploader'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'DOC_UPLOAD'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(99509358511335423)
,p_plug_name=>unistr('Configura\00E7\00F5es Chunks')
,p_parent_plug_id=>wwv_flow_imp.id(98829537516614390)
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>60
,p_location=>null
,p_plug_display_condition_type=>'ITEM_IS_NULL'
,p_plug_display_when_condition=>'P5_DOC_ID'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(98833863289614391)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(41280757793249299)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(98833863289614391)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(41281090011249300)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(98833863289614391)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P5_DOC_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(41281505528249301)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(98833863289614391)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_condition=>'P5_DOC_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(41281958727249302)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(98833863289614391)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_condition=>'P5_DOC_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(94179160331334494)
,p_name=>'P5_JSONCONF'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(99509358511335423)
,p_prompt=>unistr('Par\00E2metros Chunk em JSON')
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>12
,p_display_when=>'P5_DOC_ID'
,p_display_when_type=>'ITEM_IS_NULL'
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<!DOCTYPE html>',
'<html>',
'<body>',
'    <div>',
unistr('        <h3>Colocar em formato JSON as configura\00E7\00F5es dos chunks.</h3>'),
'',
unistr('        <p>Documenta\00E7\00F5es:</p>'),
'        <ul>',
'            <li><a href="https://docs.oracle.com/en/database/oracle/oracle-database/23/arpls/dbms_vector_chain1.html#GUID-4E145629-7098-4C7C-804F-FC85D1F24240" target="_blank">Oracle DBMS_VECTOR_CHAIN Package Documentation</a></li>',
'            <li><a href="https://docs.oracle.com/en/database/oracle/oracle-database/23/sqlrf/vector_chunks.html#SQLRF-GUID-5927E2FA-6419-4744-A7CB-3E62DBB027AD" target="_blank">Oracle Vector Chunks Documentation</a></li>',
'        </ul>',
'',
'        <p>Exemplo:</p>',
'        <pre>',
'{',
'    "by" : "words",',
'    "max" : "50",',
'    "overlap" : "0",',
'    "split": "custom",',
'    "custom_list": [ ";" ],',
'    "language" : "ptb",',
'    "normalize": "none"',
'}',
'        </pre>',
'    </div>',
'</body>',
'</html>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'Y',
  'character_counter', 'N',
  'resizable', 'N',
  'trim_spaces', 'NONE')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98831070431614455)
,p_name=>'P5_DOC_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(98829537516614390)
,p_item_source_plug_id=>wwv_flow_imp.id(98829537516614390)
,p_source=>'DOC_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98831517041614455)
,p_name=>'P5_DOC_NAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(98829537516614390)
,p_item_source_plug_id=>wwv_flow_imp.id(98829537516614390)
,p_prompt=>'Nome Documento'
,p_source=>'DOC_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>200
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98831888901614455)
,p_name=>'P5_DATA'
,p_source_data_type=>'BLOB'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(98829537516614390)
,p_item_source_plug_id=>wwv_flow_imp.id(98829537516614390)
,p_prompt=>'Arquivo'
,p_source=>'DATA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>60
,p_cMaxlength=>255
,p_display_when=>'P5_DOC_ID'
,p_display_when_type=>'ITEM_IS_NULL'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'content_disposition', 'attachment',
  'display_as', 'INLINE',
  'display_download_link', 'Y',
  'storage_type', 'DB_COLUMN')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98832271979614455)
,p_name=>'P5_CREATED_AT'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(98829537516614390)
,p_item_source_plug_id=>wwv_flow_imp.id(98829537516614390)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--SELECT TO_CHAR(SYSTIMESTAMP,''DD-MON-YYYY HH24:MI:SS'') FROM DUAL;',
'SELECT SYSTIMESTAMP FROM DUAL;'))
,p_item_default_type=>'SQL_QUERY'
,p_source=>'CREATED_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98833116584614456)
,p_name=>'P5_MIME_TYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(98829537516614390)
,p_item_source_plug_id=>wwv_flow_imp.id(98829537516614390)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'application/pdf',
''))
,p_source=>'MIME_TYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(41282617927249304)
,p_validation_name=>'P5_CREATED_AT must be timestamp'
,p_validation_sequence=>30
,p_validation=>'P5_CREATED_AT'
,p_validation_type=>'ITEM_IS_TIMESTAMP'
,p_error_message=>'#LABEL# must be a valid timestamp.'
,p_associated_item=>wwv_flow_imp.id(98832271979614455)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(41285151615249314)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(41280757793249299)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(41285622641249316)
,p_event_id=>wwv_flow_imp.id(41285151615249314)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(41283721621249311)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Upload_File_Chain'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>8181144339056454
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(41282953104249309)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>8180375822056452
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(41278397971249288)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(98829537516614390)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form PDF_UPLOADER'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>8175820689056431
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(41283296631249310)
,p_process_sequence=>20
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DeleteChunks'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DELETE FROM DOC_CHUNKS',
'WHERE doc_id = :P5_DOC_ID;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(41281090011249300)
,p_internal_uid=>8180719349056453
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(41278796407249289)
,p_process_sequence=>20
,p_region_id=>wwv_flow_imp.id(98829537516614390)
,p_parent_process_id=>wwv_flow_imp.id(41283721621249311)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form PDF_UPLOADER'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_internal_uid=>8176219125056432
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(41284108650249312)
,p_process_sequence=>40
,p_parent_process_id=>wwv_flow_imp.id(41283721621249311)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create_Chunks'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_chunks_division JSON := JSON(',
'        :P5_JSONCONF',
'    );',
'BEGIN',
'    -- Insert into DOC_CHUNKS',
'    INSERT INTO DOC_CHUNKS (',
'        doc_id,',
'        embed_id,',
'        embed_data,',
'        embed_vector',
'    )',
'    SELECT ',
'        dt.doc_id,',
'        et.embed_id,',
'        et.embed_data,',
'        to_vector(et.embed_vector) AS embed_vector',
'    FROM',
'        doc_upload dt,',
'        dbms_vector_chain.utl_to_embeddings(',
'            dbms_vector_chain.utl_to_chunks(',
'                dbms_vector_chain.utl_to_text(dt.data), ',
'                v_chunks_division',
'            ),',
'            json(',
'                ''{  ',
'                    "provider" : "database", ',
'                    "model" : "doc_model" ',
'                }''',
'            )',
'        ) t,',
'        JSON_TABLE(',
'            t.column_value, ',
'            ''$[*]'' COLUMNS (',
'                embed_id NUMBER PATH ''$.embed_id'', ',
'                embed_data VARCHAR2(4000) PATH ''$.embed_data'', ',
'                embed_vector CLOB PATH ''$.embed_vector''',
'            )',
'        ) et',
'--    WHERE dt.doc_id = (SELECT MAX(doc_id) FROM doc_upload);',
'      WHERE dt.doc_id = :P5_DOC_ID;',
'',
'    -- Update DOC_UPLOAD with CHUNKS_DIVISION',
'    UPDATE doc_upload',
'    SET CHUNKS_DIVISION = v_chunks_division',
'--    WHERE doc_id = (SELECT MAX(doc_id) FROM doc_upload);',
'    WHERE doc_id = :P5_DOC_ID;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>8181531368056455
);
wwv_flow_imp.component_end;
end;
/
