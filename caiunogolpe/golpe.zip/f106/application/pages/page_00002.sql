prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>33101331255185790
,p_default_application_id=>106
,p_default_id_offset=>33102577282192857
,p_default_owner=>'GRAPHUSER'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Assistente AI'
,p_alias=>'ASSISTENTE-AI1'
,p_page_mode=>'MODAL'
,p_step_title=>'Assistente AI'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('var recognition; // Vari\00E1vel global para o reconhecimento de voz'),
unistr('var isRecording = false; // Estado do bot\00E3o'),
unistr('// Fun\00E7\00E3o para alternar a grava\00E7\00E3o ao clicar no bot\00E3o'),
'function toggleRecording() {',
'    if (!isRecording) {',
'        startRecording();',
'    } else {',
'        stopRecording();',
'    }',
'}',
unistr('// Fun\00E7\00E3o para iniciar a grava\00E7\00E3o'),
'function startRecording() {',
'    if (!(''webkitSpeechRecognition'' in window)) {',
unistr('        alert(''Seu navegador n\00E3o suporta reconhecimento de voz. Tente utilizar o Google Chrome.'');'),
'        return;',
'    }',
'    recognition = new webkitSpeechRecognition();',
unistr('    recognition.lang = ''pt-BR''; // Define o idioma para portugu\00EAs'),
unistr('    recognition.continuous = false; // Para ap\00F3s capturar a fala'),
'    recognition.interimResults = false; // Apenas resultados finais',
unistr('    // Quando a grava\00E7\00E3o come\00E7a'),
'    recognition.onstart = function () {',
'        isRecording = true;',
unistr('//        apex.message.showPageSuccess("Grava\00E7\00E3o iniciada... Fale agora!");'),
'',
'',
'$("#BTN_GRAVAR").css("background-color", "rgb(234,153,153)");',
'',
'',
'        setTimeout(function () {',
'            apex.message.hidePageSuccess(); // Remove sucesso',
'        }, 2000);',
'',
'',
unistr('//        $("#BTN_GRAVAR span").text("Parar Grava\00E7\00E3o");'),
unistr('//        $("#BTN_GRAVAR").addClass("recording"); // Adiciona anima\00E7\00E3o ao bot\00E3o'),
'    };',
'    // Quando o reconhecimento de voz captura um resultado',
'    recognition.onresult = function (event) {',
'        var transcript = event.results[0][0].transcript; // Captura o texto reconhecido',
'        console.log("Texto reconhecido: " + transcript);',
unistr('        // **For\00E7a a atualiza\00E7\00E3o do item no APEX**'),
'        apex.item("P2_INPUT").setValue(transcript);',
unistr('        // Alternativa para garantir que o APEX reconhe\00E7a a mudan\00E7a:'),
'        $("input[name=''P2_INPUT'']").val(transcript).trigger("change");',
'    };',
unistr('    // Quando h\00E1 um erro no reconhecimento de voz'),
'    recognition.onerror = function (event) {',
'        console.error("Erro no reconhecimento de voz:", event.error);',
'        apex.message.clearErrors();',
unistr('        apex.message.showErrors([{ type: "error", location: "page", message: "Erro na grava\00E7\00E3o. Tente novamente.", unsafe: false }]);'),
'    };',
unistr('    // Quando a grava\00E7\00E3o termina'),
'    recognition.onend = function () {',
'        isRecording = false;',
unistr(' //       apex.message.showPageSuccess("Grava\00E7\00E3o finalizada.");'),
'',
'        setTimeout(function () {',
'            apex.message.hidePageSuccess(); // Remove sucesso',
'        }, 2000);             ',
'',
'$("#BTN_GRAVAR").css("background-color", "rgb(218, 249, 218)");',
'',
'',
unistr('//        $("#BTN_GRAVAR span").text("Iniciar Grava\00E7\00E3o");'),
unistr('//        $("#BTN_GRAVAR").removeClass("recording"); // Remove anima\00E7\00E3o'),
'    };',
'    recognition.start(); // Inicia o reconhecimento de voz',
'}',
unistr('// Fun\00E7\00E3o para parar a grava\00E7\00E3o'),
'function stopRecording() {',
'    if (recognition) {',
'        recognition.stop();',
'    }',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#BTN_GRAVAR").css("background-color", "rgb(218, 249, 218)");',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'//.a-Button--hot, ',
'//.a-CardView-button--hot, ',
'//.apex-button-group input:checked+label, ',
'//.t-Button--hot, ',
'//.t-Form-fieldContainer--radioButtonGroup .apex-item-group--rc input:checked+label, ',
'//.ui-button--hot {',
'//    --a-button-background-color: rgb(205, 75, 155); /* Pink background */',
'//    --a-button-text-color: rgb(255, 255, 255); /* White text */',
'//    --a-button-hover-background-color: rgb(175, 55, 135); /* Lighter pink hover background */',
'//    --a-button-hover-text-color: rgb(255, 255, 255); /* White text on hover */',
'//    --a-button-hover-border-color: rgb(175, 55, 135); /* Lighter pink hover border */',
'//    --a-button-active-background-color: rgb(145, 35, 115); /* Even darker pink for active state */',
'//    --a-button-active-text-color: rgb(255, 255, 255); /* White text on active */',
'//    --a-button-active-border-color: rgb(145, 35, 115); /* Darker pink active border */',
'//    --a-button-focus-background-color: rgb(175, 55, 135); /* Focus background same as hover */',
'//    --a-button-focus-text-color: rgb(255, 255, 255); /* White text on focus */',
'//    --a-button-focus-border-color: rgb(175, 55, 135); /* Focus border same as hover */',
'//}',
''))
,p_step_template=>1661186590416509825
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_resizable=>'Y'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(41293580711279061)
,p_plug_name=>'Pesquisa'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>1569994581593435632
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(41293892712279064)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(41293580711279061)
,p_button_name=>'Pesquisar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Pesquisar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(41293845898279063)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(41293580711279061)
,p_button_name=>'Falar'
,p_button_static_id=>'BTN_GRAVAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--simple'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Falar'
,p_button_position=>'BUTTON_END'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-microphone'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41293708460279062)
,p_name=>'P2_INPUT'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(41293580711279061)
,p_prompt=>unistr('Fa\00E7a sua pergunta...')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41293989544279065)
,p_name=>'P2_VECTOROUTPUT'
,p_item_sequence=>20
,p_prompt=>'Vectoroutput'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(40808785697142467)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41294154606279066)
,p_name=>'P2_GENAIOUTPUT'
,p_item_sequence=>30
,p_prompt=>'Genaioutput'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(40808785697142467)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41294275395279067)
,p_name=>'P2_OUTPUT'
,p_item_sequence=>40
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P2_GENAIOUTPUT'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>1609121967514267634
,p_item_icon_css_classes=>'fa-robot'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large:margin-top-sm:margin-bottom-sm'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41295201627279077)
,p_name=>'P2_TRADJSON'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(41293580711279061)
,p_prompt=>'Tradjson'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(40808785697142467)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41295685659279082)
,p_name=>'P2_TRADUCAO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(41293580711279061)
,p_prompt=>'Traducao'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(40808785697142467)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(41294312388279068)
,p_name=>'Click'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(41293845898279063)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(41294473163279069)
,p_event_id=>wwv_flow_imp.id(41294312388279068)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'toggleRecording();'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(41294519551279070)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Execution_Chain'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>8191942269086213
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(41295315253279078)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(41294519551279070)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'TRADUZIR'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(41264356127243381)
,p_web_src_operation_id=>wwv_flow_imp.id(41264572784243387)
,p_attribute_01=>'WEB_SOURCE'
,p_internal_uid=>8192737971086221
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(41296241724279087)
,p_page_id=>2
,p_web_src_param_id=>wwv_flow_imp.id(41265392082243394)
,p_page_process_id=>wwv_flow_imp.id(41295315253279078)
,p_value_type=>'SQL_QUERY'
,p_value=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
unistr('    ''CONTEXTO: N\00C3O BUSCAR NADA NA INTERENET, APENAS TRADUZIR O TEXTO DO PORTUGUES PARA INGLES, CONTEUDO: '' '),
'    || :P2_INPUT || '' ;'' AS "OUTPUT"',
'FROM DUAL;',
''))
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(41296353524279088)
,p_page_id=>2
,p_web_src_param_id=>wwv_flow_imp.id(41265902336243395)
,p_page_process_id=>wwv_flow_imp.id(41295315253279078)
,p_value_type=>'ITEM'
,p_value=>'P2_TRADJSON'
,p_ignore_output=>false
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(41295646960279081)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(41294519551279070)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'JSONPARSE-TRADU'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_json      VARCHAR2(32767) := :P2_TRADJSON;',
'    l_text      VARCHAR2(4000);',
'BEGIN',
'    -- Extract the text from the JSON',
'    SELECT jt.text',
'    INTO l_text',
'    FROM dual,',
'         JSON_TABLE(',
'             l_json,',
'             ''$.chatResponse'' COLUMNS (',
'                 text VARCHAR2(4000) PATH ''$.text''',
'             )',
'         ) jt;',
'',
'    -- Set the extracted text to P3_OUTPUT',
'    :P2_TRADUCAO := l_text;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>8193069678086224
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(41294637011279071)
,p_process_sequence=>30
,p_parent_process_id=>wwv_flow_imp.id(41294519551279070)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Vector_Search'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    V_INPUT VARCHAR2(400) := :P2_TRADUCAO;',
'    V_OUTPUT CLOB;',
'BEGIN',
'    V_OUTPUT := rag_with_genai_function (V_INPUT);',
'    :P2_VECTOROUTPUT := V_OUTPUT;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>8192059729086214
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(41294763595279072)
,p_process_sequence=>40
,p_parent_process_id=>wwv_flow_imp.id(41294519551279070)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'API CALL'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(41264356127243381)
,p_web_src_operation_id=>wwv_flow_imp.id(41264572784243387)
,p_attribute_01=>'WEB_SOURCE'
,p_internal_uid=>8192186313086215
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(41294791897279073)
,p_page_id=>2
,p_web_src_param_id=>wwv_flow_imp.id(41265392082243394)
,p_page_process_id=>wwv_flow_imp.id(41294763595279072)
,p_value_type=>'SQL_QUERY'
,p_value=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
unistr('    ''CONTEXTO: SEMPRE RESPONDA EM PORTUGUES; CASO N\00C3O ENCONTRE A INFORMA\00C7\00C3O NO DOCUMENTO, BUSQUE NA INTERNET;'),
unistr('     RESPONDER DE FORMA MAIS RESUMIDA POSS\00CDVEL;'),
'     SEMPRE CITAR AS FONTES DE DADOS INCLUSIVE PARA CONSULTAS NA INTERNET;'' ',
'    || :P2_INPUT',
'    || '' SEGUNDO O TEXTO '' ',
'    || :P2_VECTOROUTPUT',
'    || '' ;'' AS "OUTPUT"',
'FROM DUAL;',
''))
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(41294883577279074)
,p_page_id=>2
,p_web_src_param_id=>wwv_flow_imp.id(41265902336243395)
,p_page_process_id=>wwv_flow_imp.id(41294763595279072)
,p_value_type=>'ITEM'
,p_value=>'P2_GENAIOUTPUT'
,p_ignore_output=>false
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(41295024582279075)
,p_process_sequence=>50
,p_parent_process_id=>wwv_flow_imp.id(41294519551279070)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'JSONPARSE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_json      VARCHAR2(32767) := :P2_GENAIOUTPUT;',
'    l_text      VARCHAR2(4000);',
'BEGIN',
'    -- Extract the text from the JSON',
'    SELECT jt.text',
'    INTO l_text',
'    FROM dual,',
'         JSON_TABLE(',
'             l_json,',
'             ''$.chatResponse'' COLUMNS (',
'                 text VARCHAR2(4000) PATH ''$.text''',
'             )',
'         ) jt;',
'',
'    -- Set the extracted text to P3_OUTPUT',
'    :P2_OUTPUT := l_text;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>8192447300086218
);
wwv_flow_imp.component_end;
end;
/
