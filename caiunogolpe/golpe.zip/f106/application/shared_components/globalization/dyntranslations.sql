prompt --application/shared_components/globalization/dyntranslations
begin
--   Manifest
--     DYNAMIC TRANSLATIONS: 106
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>33101331255185790
,p_default_application_id=>106
,p_default_id_offset=>33102577282192857
,p_default_owner=>'GRAPHUSER'
);
null;
wwv_flow_imp.component_end;
end;
/
