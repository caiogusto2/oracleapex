prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>33101331255185790
,p_default_application_id=>106
,p_default_id_offset=>33102577282192857
,p_default_owner=>'GRAPHUSER'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(40809454375142479)
,p_name=>'Breadcrumb'
);
wwv_flow_imp.component_end;
end;
/
