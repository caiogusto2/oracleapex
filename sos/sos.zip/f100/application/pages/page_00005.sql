prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7517595396827368
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SOS'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>unistr('N\00FAmero Protocolo')
,p_alias=>unistr('N\00DAMERO-PROTOCOLO')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('N\00FAmero Protocolo')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'.maplibregl-popup-content {',
'    height: 10px; ',
'}',
'',
'.a-MapRegion-popup {',
'}',
'',
'',
'.a-MapRegion-popup--info {',
'    height: auto;',
'}',
'    */'))
,p_step_template=>wwv_flow_imp.id(7554605138879677)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'!'||wwv_flow_imp.id(7857661119038654)
,p_dialog_height=>'600'
,p_protection_level=>'C'
,p_page_component_map=>'19'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8002191165070461)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7561302586879713)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(7991965082070400)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(7697359530880157)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8002236515070461)
,p_plug_name=>unistr('N\00FAmero Protocolo')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7561302586879713)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>unistr('<h4>O n\00FAmero do seu protocolo de atendimento \00E9 &PROTOCOLO.</h4>')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8002312458070461)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7564113216879720)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8222518897875904)
,p_plug_name=>unistr('Atendimentos pr\00F3ximos')
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7627989853879914)
,p_plug_display_sequence=>20
,p_location=>null
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(8222619440875905)
,p_region_id=>wwv_flow_imp.id(8222518897875904)
,p_height=>350
,p_tilelayer_type=>'CUSTOM'
,p_tilelayer_name_default=>'bi-world-map'
,p_tilelayer_name_dark=>'osm-bright'
,p_navigation_bar_type=>'SMALL'
,p_navigation_bar_position=>'START'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_legend_position=>'START'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(8222749928875906)
,p_map_region_id=>wwv_flow_imp.id(8222619440875905)
,p_name=>'Localizacao Atual'
,p_label=>unistr('Sua Localiza\00E7\00E3o')
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ROWID,',
'       TO_NUMBER(:LATITUDE) AS LATITUDE,',
'       TO_NUMBER(:LONGITUDE) AS LONGITUDE',
'FROM DUAL;',
''))
,p_has_spatial_index=>false
,p_pk_column=>'ROWID'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_stroke_color=>'#000000'
,p_fill_color=>'#ff3b30'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>unistr('<p>Minha Localiza\00E7\00E3o Aproximada</p>')
,p_info_window_adv_formatting=>false
,p_allow_hide=>false
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(8227004967875949)
,p_map_region_id=>wwv_flow_imp.id(8222619440875905)
,p_name=>'Localizacao Atendimentos'
,p_layer_type=>'POINT'
,p_display_sequence=>20
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'        SELECT centrais_id, ENDERECO, latitude, longitude, telefone, classe, nome,',
'               SDO_GEOM.SDO_DISTANCE(',
'                   SDO_GEOMETRY(2001, 8307, SDO_POINT_TYPE(longitude, latitude, NULL), NULL, NULL),',
'                   SDO_GEOMETRY(2001, 8307, SDO_POINT_TYPE(:LONGITUDE, :LATITUDE, NULL), NULL, NULL),',
'                   0.005',
'               ) AS distance',
'        FROM centrais_atendimento',
'        ORDER BY distance',
'        FETCH FIRST 10 ROWS ONLY'))
,p_has_spatial_index=>false
,p_pk_column=>'CENTRAIS_ID'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_stroke_color=>'#000000'
,p_fill_color=>'#34aadc'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_info_window_adv_formatting=>true
,p_info_window_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<p style="max-height: 50px;">&NOME. | Endere\00E7o: &ENDERECO. <br>'),
'  <a href="tel:&TELEFONE." class="contact-button">Entrar em Contato</a>',
'</p>',
'',
'<style>',
'  .contact-button {',
'    display: inline-block;',
'    padding: 5px 10px;',
'    background-color: #28a745; /* Green color */',
'    color: white;',
'    text-decoration: none;',
'    border-radius: 5px;',
'    font-weight: bold;',
'    text-align: center;',
'  }',
'',
'  .contact-button:hover {',
'    background-color: #218838; /* Darker green on hover */',
'  }'))
,p_allow_hide=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8003856338070466)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(8002312458070461)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(7701569334880184)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
,p_required_patch=>wwv_flow_imp.id(7524097514879520)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8003938061070466)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(8002312458070461)
,p_button_name=>'FINISH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(7701569334880184)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Encerrar'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8004002757070466)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(8002312458070461)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(7700806858880179)
,p_button_image_alt=>'Anterior'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(8005724063070475)
,p_branch_action=>'f?p=&APP_ID.:4:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(8004002757070466)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8004207401070466)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8003856338070466)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8005088278070469)
,p_event_id=>wwv_flow_imp.id(8004207401070466)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8006562185070478)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>8006562185070478
);
wwv_flow_imp.component_end;
end;
/
