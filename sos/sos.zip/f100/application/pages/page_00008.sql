prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7517595396827368
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SOS'
);
wwv_flow_imp_page.create_page(
 p_id=>8
,p_name=>'BKP.Gravar Relato'
,p_alias=>'BKP-GRAVAR-RELATO'
,p_page_mode=>'MODAL'
,p_step_title=>'BKP.Gravar Relato'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let mediaRecorder;',
'',
'const util = {',
'  // builds a js array from long string',
'  // credit: https://apexplained.wordpress.com/2016/09/12/chunked-multi-file-upload-with-ajax/',
'  clob2Array: function (clob, size) {',
'    let array = [];',
'    loopCount = Math.floor(clob.length / size) + 1;',
'    for (let i = 0; i < loopCount; i++) {',
'      array.push(clob.slice(size * i, size * (i + 1)));',
'    }',
'    return array;',
'  },',
'  // converts blob to base64 string',
'  blob2base64: function (blob) {',
'    return new Promise(function(resolve, reject){',
'      const fileReader = new FileReader();',
'      fileReader.onerror = reject;',
'      fileReader.onload = function() {',
'        const dataURI = fileReader.result;',
'        resolve(dataURI.substr(dataURI.indexOf('','') + 1));',
'      }',
'      fileReader.readAsDataURL(blob);',
'    });',
'  }',
'};'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(function() {',
'  let mediaRecorder;',
'  let chunks = [];',
'  let audioBlob;',
'',
'  // Check if getUserMedia is supported',
'  if (navigator.mediaDevices) {',
'    console.debug("getUserMedia supported.");',
'',
'    // Request access to the microphone',
'    navigator.mediaDevices.getUserMedia({ audio: true })',
'      .then((stream) => {',
'        mediaRecorder = new MediaRecorder(stream);',
'',
'        mediaRecorder.ondataavailable = (e) => {',
'          chunks.push(e.data);',
'        };',
'',
'        mediaRecorder.onstop = async () => {',
'          console.debug("Recording stopped.");',
'          audioBlob = new Blob(chunks, { type: ''audio/wav'' });',
'          chunks = [];',
'          const audioURL = URL.createObjectURL(audioBlob);',
'          document.getElementById("player").src = audioURL;  // Assuming an <audio> element with id "player"',
'//          const reader = new FileReader();',
'//          reader.readAsDataURL(audioBlob);',
'',
'          const base64 = await util.blob2base64(blob);',
'',
'',
'//          reader.onloadend = function () {',
'//            const base64data = reader.result;',
'//            $s(''P3_AUDIO'', base64data);',
'//            $s(''P3_MIME_TYPE'', ''audio/wav''); // Replace with the appropriate MIME type',
'//            };',
'',
'          reader.onloadend = function () {',
'            const base64data = reader.result;',
'            $s(''P3_AUDIO'', util.clob2Array(base64, 32000));',
'            $s(''P3_MIME_TYPE'', ''audio/wav''); // Replace with the appropriate MIME type',
'            };',
'',
'',
'',
'          $("#next").prop("disabled", false); // Enable "Next" button after recording',
'        };',
'',
'        // Start recording',
'        $("#startRecord").click(function() {',
'          if (mediaRecorder && mediaRecorder.state === "inactive") {',
'            mediaRecorder.start();',
'            console.debug("Recording started.");',
'            $("#startRecord").prop("disabled", true);',
'            $("#stopRecord").prop("disabled", false);',
'            $("#next").prop("disabled", true); // Disable "Next" button during recording',
'          }',
'        });',
'',
'        // Stop recording',
'        $("#stopRecord").click(async function() {',
'          if (mediaRecorder && mediaRecorder.state === "recording") {',
'            mediaRecorder.stop();',
'            console.debug("Recording stopped.");',
'            $("#startRecord").prop("disabled", false);',
'            $("#stopRecord").prop("disabled", true);',
'            $("#next").prop("disabled", false); // Disable "Next" button during recording',
'          }',
'        });',
'',
'      })',
'      .catch((err) => {',
'        console.error(`Error occurred: ${err}`);',
'      });',
'',
'  } else {',
'    console.error("getUserMedia not supported on this browser.");',
'  }',
'})();',
''))
,p_step_template=>wwv_flow_imp.id(7554605138879677)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'400'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16180823438052372)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7561302586879713)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(7991965082070400)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(7697359530880157)
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16180988533052372)
,p_plug_name=>'Gravar Relato'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7561302586879713)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<button id="startRecord" class="t-Button t-Button--success">Start Recording</button>',
'<button id="stopRecord" class="t-Button t-Button--danger" disabled>Stop Recording</button>',
'<audio id="player" controls style="width: 100%; margin-top: 10px;"></audio>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16181011870052372)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7564113216879720)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8188516709981967)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(16181011870052372)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(7701569334880184)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8188923029981970)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(16181011870052372)
,p_button_name=>'NEXT'
,p_button_static_id=>'next'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(7701684388880185)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(8192289590982009)
,p_branch_name=>'Go To Page 4'
,p_branch_action=>'f?p=&APP_ID.:4:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(8188923029981970)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16029418965922143)
,p_name=>'P8_AUDIO'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16216665760006308)
,p_name=>'P8_MIME_TYPE'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8191256781982004)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8188516709981967)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8191782543982007)
,p_event_id=>wwv_flow_imp.id(8191256781982004)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8190823999981999)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'UPLOAD_AUDIO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'--  l_clob_temp      CLOB;',
'  l_blob_content   BLOB;',
'  l_clob_content   CLOB;',
'  l_filename       VARCHAR2(100) := ''audio_'' || TO_CHAR(SYSTIMESTAMP, ''YYYYMMDDHH24MISS'') || ''.wav'';',
'  l_dest           VARCHAR2(4000);',
'',
'BEGIN',
'--  l_clob_content := REPLACE(:P8_AUDIO, ''data:audio/wav;base64,'', '''');',
'',
'  -- Convert Base64 CLOB to BLOB',
'--  l_blob_content := APEX_WEB_SERVICE.CLOBBASE642BLOB(l_clob_content);',
'    l_blob_content := APEX_WEB_SERVICE.CLOBBASE642BLOB(:P8_AUDIO);',
'',
'',
'  -- Define Object Storage file destination (example URL, modify as needed)',
'  l_dest := ''https://objectstorage.sa-saopaulo-1.oraclecloud.com/n/idi1o0a010nx/b/sosapp/o/'' || l_filename;',
'',
'  -- Upload to OCI Object Storage using DBMS_CLOUD',
'  DBMS_CLOUD.PUT_OBJECT(',
'    credential_name => ''OBJ_STORE_CRED'',   -- Define Object Storage credential name',
'    object_uri      => l_dest,              -- File destination URL',
'    contents        => l_blob_content       -- Content to upload',
'  );',
'',
'  -- Free temporary CLOB',
'--  DBMS_LOB.FREETEMPORARY(l_clob_temp);',
'',
'  -- Return success response as JSON',
'  APEX_JSON.OPEN_OBJECT;',
'  APEX_JSON.WRITE(''success'', true);',
'  APEX_JSON.WRITE(''file_name'', l_filename);',
'  APEX_JSON.WRITE(''file_url'', l_dest);',
'  APEX_JSON.CLOSE_OBJECT;',
'',
'EXCEPTION',
'  WHEN NO_DATA_FOUND THEN',
'    APEX_JSON.OPEN_OBJECT;',
'    APEX_JSON.WRITE(''success'', false);',
'    APEX_JSON.WRITE(''error'', ''No audio file found in P8_AUDIO'');',
'    APEX_JSON.CLOSE_OBJECT;',
'  WHEN OTHERS THEN',
'    APEX_JSON.OPEN_OBJECT;',
'    APEX_JSON.WRITE(''success'', false);',
'    APEX_JSON.WRITE(''error'', SQLERRM);',
'    APEX_JSON.CLOSE_OBJECT;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>8190823999981999
);
wwv_flow_imp.component_end;
end;
/
