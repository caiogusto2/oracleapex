prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7517595396827368
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SOS'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>unistr('Revis\00E3o')
,p_alias=>unistr('REVIS\00C3O')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Revis\00E3o')
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(7554605138879677)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'!'||wwv_flow_imp.id(7857661119038654)
,p_dialog_height=>'400'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7997133012070446)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7561302586879713)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(7991965082070400)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(7697359530880157)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7997204057070446)
,p_plug_name=>unistr('Revis\00E3o')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7561302586879713)
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7997386348070446)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7564113216879720)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8028111030024332)
,p_plug_name=>'Texto'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7561302586879713)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>unistr('<h4>Revise o texto e aproveite para fornecer outras informa\00E7\00F5es/arquivos</h4>')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7998891248070451)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(7997386348070446)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(7701569334880184)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7999168109070451)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(7997386348070446)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(7701684388880185)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Pr\00F3xima')
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7999069917070451)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(7997386348070446)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(7700806858880179)
,p_button_image_alt=>'Anterior'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(8001476239070458)
,p_branch_action=>'f?p=&APP_ID.:5:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(7999168109070451)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(8000713203070456)
,p_branch_action=>'f?p=&APP_ID.:3:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(7999069917070451)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8027790165024328)
,p_name=>'P4_TEXTOREVISADO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(7997204057070446)
,p_prompt=>'Texto Revisado por AI'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(7699044964880169)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8027842306024329)
,p_name=>'P4_ADICIONAIS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(7997204057070446)
,p_prompt=>unistr('Arquivos e Fotos Adicionais (m\00E1x 3 arquivos)')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(7699044964880169)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_10=>'Y'
,p_attribute_12=>'DROPZONE_INLINE'
,p_attribute_22=>'ENVIRONMENT'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(8028719311024338)
,p_computation_sequence=>10
,p_computation_item=>'P4_TEXTOREVISADO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'ITEM_VALUE'
,p_computation=>'AITEXT'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7999200984070452)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(7998891248070451)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8000026052070454)
,p_event_id=>wwv_flow_imp.id(7999200984070452)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8226402326875943)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DBInsert'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--begin',
'--    insert into BOLETIM_OCORRENCIA (',
'--        USUARIO_FK,',
'--        TEXTOAI,',
'--        LATITUDE,',
'--        LONGITUDE,',
'--        CLASSIFICACAO',
'--    )',
'--    values (',
'--        :USUARIO_ID,',
'--        :AITEXT,',
'--        :LATITUDE,',
'--        :LONGITUDE,',
'--        :CLASSIFICACAO',
'--    );',
'--    commit;',
'--end;',
'',
'DECLARE',
'    l_index NUMBER := 1;',
'    l_cursor SYS_REFCURSOR;',
'    l_mimetype VARCHAR2(100);',
'    l_filename VARCHAR2(100);',
'    l_charset VARCHAR2(100);',
'    l_blob BLOB;',
'    l_boid NUMBER;',
'BEGIN',
'    INSERT INTO BOLETIM_OCORRENCIA (',
'        USUARIO_FK,',
'        TEXTOAI,',
'        LATITUDE,',
'        LONGITUDE,',
'        CLASSIFICACAO,',
'        ADIC01, ADIC01_MIMETYPE, ADIC01_FILENAME, ADIC01_CHARSET,',
'        ADIC02, ADIC02_MIMETYPE, ADIC02_FILENAME, ADIC02_CHARSET,',
'        ADIC03, ADIC03_MIMETYPE, ADIC03_FILENAME, ADIC03_CHARSET,',
'        status',
'    )',
'    VALUES (',
'        :USUARIO_ID,',
'        :AITEXT,',
'        :LATITUDE,',
'        :LONGITUDE,',
'        :CLASSIFICACAO,',
'        EMPTY_BLOB(), NULL, NULL, NULL,',
'        EMPTY_BLOB(), NULL, NULL, NULL,',
'        EMPTY_BLOB(), NULL, NULL, NULL,',
'        ''EM ANDAMENTO''',
'    )',
'    RETURNING BO_ID, ADIC01, ADIC02, ADIC03 INTO l_boid, l_blob, l_blob, l_blob;',
'',
'    -- Open cursor for temp files',
'    OPEN l_cursor FOR SELECT MIME_TYPE, FILENAME, BLOB_CONTENT FROM APEX_APPLICATION_TEMP_FILES;',
'    ',
'    LOOP',
'        FETCH l_cursor INTO l_mimetype, l_filename, l_blob;',
'        EXIT WHEN l_cursor%NOTFOUND OR l_index > 3;',
'        ',
'        IF l_index = 1 THEN',
'            UPDATE BOLETIM_OCORRENCIA SET ADIC01 = l_blob, ADIC01_MIMETYPE = l_mimetype, ADIC01_FILENAME = l_filename WHERE BO_ID = (SELECT MAX(BO_ID) FROM BOLETIM_OCORRENCIA);',
'        ELSIF l_index = 2 THEN',
'            UPDATE BOLETIM_OCORRENCIA SET ADIC02 = l_blob, ADIC02_MIMETYPE = l_mimetype, ADIC02_FILENAME = l_filename WHERE BO_ID = (SELECT MAX(BO_ID) FROM BOLETIM_OCORRENCIA);',
'        ELSIF l_index = 3 THEN',
'            UPDATE BOLETIM_OCORRENCIA SET ADIC03 = l_blob, ADIC03_MIMETYPE = l_mimetype, ADIC03_FILENAME = l_filename WHERE BO_ID = (SELECT MAX(BO_ID) FROM BOLETIM_OCORRENCIA);',
'        END IF;',
'        ',
'        l_index := l_index + 1;',
'    END LOOP;',
'    ',
'    CLOSE l_cursor;',
'',
'        :PROTOCOLO := l_boid;',
'',
'    DELETE FROM APEX_APPLICATION_TEMP_FILES;',
'    COMMIT;',
'',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>8226402326875943
);
wwv_flow_imp.component_end;
end;
/
