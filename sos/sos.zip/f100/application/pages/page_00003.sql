prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7517595396827368
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SOS'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Gravar Relato'
,p_alias=>'GRAVAR-RELATO'
,p_page_mode=>'MODAL'
,p_step_title=>'Gravar Relato'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('var recognition; // Vari\00E1vel global para o reconhecimento de voz'),
unistr('var isRecording = false; // Estado do bot\00E3o'),
unistr('// Fun\00E7\00E3o para alternar a grava\00E7\00E3o ao clicar no bot\00E3o'),
'function toggleRecording() {',
'    if (!isRecording) {',
'        startRecording();',
'    } else {',
'        stopRecording();',
'    }',
'}',
unistr('// Fun\00E7\00E3o para iniciar a grava\00E7\00E3o'),
'function startRecording() {',
'    if (!(''webkitSpeechRecognition'' in window)) {',
unistr('        alert(''Seu navegador n\00E3o suporta reconhecimento de voz. Tente utilizar o Google Chrome.'');'),
'        return;',
'    }',
'    recognition = new webkitSpeechRecognition();',
unistr('    recognition.lang = ''pt-BR''; // Define o idioma para portugu\00EAs'),
unistr('    recognition.continuous = false; // Para ap\00F3s capturar a fala'),
'    recognition.interimResults = false; // Apenas resultados finais',
unistr('    // Quando a grava\00E7\00E3o come\00E7a'),
'    recognition.onstart = function () {',
'        isRecording = true;',
unistr('        apex.message.showPageSuccess("Grava\00E7\00E3o iniciada... Fale agora!");'),
unistr('        $("#BTN_GRAVAR span").text("Parar Grava\00E7\00E3o");'),
unistr('//        $("#BTN_GRAVAR").addClass("recording"); // Adiciona anima\00E7\00E3o ao bot\00E3o'),
'    };',
'    // Quando o reconhecimento de voz captura um resultado',
'    recognition.onresult = function (event) {',
'        var transcript = event.results[0][0].transcript; // Captura o texto reconhecido',
'        console.log("Texto reconhecido: " + transcript);',
unistr('        // **For\00E7a a atualiza\00E7\00E3o do item no APEX**'),
'        apex.item("P3_AUDIO").setValue(transcript);',
unistr('        // Alternativa para garantir que o APEX reconhe\00E7a a mudan\00E7a:'),
'        $("input[name=''P3_AUDIO'']").val(transcript).trigger("change");',
'    };',
unistr('    // Quando h\00E1 um erro no reconhecimento de voz'),
'    recognition.onerror = function (event) {',
'        console.error("Erro no reconhecimento de voz:", event.error);',
'        apex.message.clearErrors();',
unistr('        apex.message.showErrors([{ type: "error", location: "page", message: "Erro na grava\00E7\00E3o. Tente novamente.", unsafe: false }]);'),
'    };',
unistr('    // Quando a grava\00E7\00E3o termina'),
'    recognition.onend = function () {',
'        isRecording = false;',
unistr('        apex.message.showPageSuccess("Grava\00E7\00E3o finalizada.");'),
unistr('        $("#BTN_GRAVAR span").text("Iniciar Grava\00E7\00E3o");'),
unistr('//        $("#BTN_GRAVAR").removeClass("recording"); // Remove anima\00E7\00E3o'),
'    };',
'    recognition.start(); // Inicia o reconhecimento de voz',
'}',
unistr('// Fun\00E7\00E3o para parar a grava\00E7\00E3o'),
'function stopRecording() {',
'    if (recognition) {',
'        recognition.stop();',
'    }',
'}'))
,p_step_template=>wwv_flow_imp.id(7554605138879677)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'!'||wwv_flow_imp.id(7857661119038654)
,p_dialog_height=>'600'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7992828881070421)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7561302586879713)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(7991965082070400)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(7697359530880157)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7992993976070421)
,p_plug_name=>'Gravar Relato'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7561302586879713)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7993017313070421)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7564113216879720)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8027195319024322)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(7992993976070421)
,p_button_name=>'Gravar'
,p_button_static_id=>'BTN_GRAVAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(7701569334880184)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Iniciar Grava\00E7\00E3o')
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-microphone'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7994534812070430)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(7993017313070421)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(7701569334880184)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7994899323070431)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(7993017313070421)
,p_button_name=>'NEXT'
,p_button_static_id=>'next'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(7701684388880185)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Pr\00F3xima')
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(7996400208070440)
,p_branch_name=>'Go To Page 4'
,p_branch_action=>'f?p=&APP_ID.:4:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(7994899323070431)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8027603175024327)
,p_name=>'P3_AUDIO'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(7992993976070421)
,p_prompt=>unistr('Transcri\00E7\00E3o de Audio')
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>2000
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(7699044964880169)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'Y'
,p_attribute_04=>'BOTH'
,p_show_quick_picks=>'Y'
,p_quick_pick_label_01=>'Policia - Assalto'
,p_quick_pick_value_01=>unistr('"Estou na Rua das Flores, n\00BA 123. Dois homens armados est\00E3o assaltando um mercado agora. Eles est\00E3o de preto e fugindo em uma moto preta. Preciso de ajuda urgente!"')
,p_quick_pick_label_02=>unistr('Policia - Invas\00E3o Domic\00EDlio')
,p_quick_pick_value_02=>unistr('"Algu\00E9m acabou de entrar na minha casa pela janela! Estou dentro do quarto trancado, na Rua A, n\00BA 45. Ou\00E7o barulhos na sala. Enviem ajuda r\00E1pido!"')
,p_quick_pick_label_03=>unistr('Bombeiro - Inc\00EAndio Florestal')
,p_quick_pick_value_03=>unistr('"Inc\00EAndio na Rua das Palmeiras, n\00BA 200, apartamento 301. Fogo come\00E7ou na cozinha e est\00E1 se espalhando! Pessoas presas na varanda! Enviem ajuda urgente!')
,p_quick_pick_label_04=>unistr('Bombeiro - Acidente de tr\00E2nsito com v\00EDtimas')
,p_quick_pick_value_04=>unistr('"Acidente grave na Avenida Central, perto do posto de gasolina. Carro capotado, duas pessoas presas nas ferragens. Uma est\00E1 inconsciente. Precisamos de resgate urgente!"')
,p_quick_pick_label_05=>unistr('Samu - Parada card\00EDaca')
,p_quick_pick_value_05=>unistr('"Homem de 60 anos teve uma parada card\00EDaca na Rua das Flores, n\00BA 100. Est\00E1 inconsciente e n\00E3o respira! Preciso de ajuda urgente!"')
,p_quick_pick_label_06=>'Samu - Acidente com feridos'
,p_quick_pick_value_06=>unistr('"Acidente grave na Avenida Brasil, perto do shopping. Motoqueiro caiu e est\00E1 desacordado, sangrando na cabe\00E7a. Precisamos de ambul\00E2ncia urgente!"')
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8223978322875918)
,p_name=>'P3_LATITUDE'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8224096190875919)
,p_name=>'P3_LONGITUDE'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7994978473070431)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(7994534812070430)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7995756519070435)
,p_event_id=>wwv_flow_imp.id(7994978473070431)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8027438768024325)
,p_name=>'Iniciar'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8027195319024322)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8027574039024326)
,p_event_id=>wwv_flow_imp.id(8027438768024325)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'toggleRecording();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8223753302875916)
,p_name=>'Localizacao'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8223871655875917)
,p_event_id=>wwv_flow_imp.id(8223753302875916)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_GET_CURRENT_POSITION'
,p_attribute_01=>'lat_long'
,p_attribute_03=>'P3_LATITUDE'
,p_attribute_04=>'P3_LONGITUDE'
,p_attribute_06=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8028229767024333)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Cadeia Execucao'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>8028229767024333
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8028356032024334)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(8028229767024333)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'GenAI API'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(8201356798114970)
,p_web_src_operation_id=>wwv_flow_imp.id(8201982303114978)
,p_attribute_01=>'WEB_SOURCE'
,p_process_error_message=>'Erro ao processar texto junto do GENAI'
,p_internal_uid=>8028356032024334
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(8028560502024336)
,p_page_id=>3
,p_web_src_param_id=>wwv_flow_imp.id(8204307503127032)
,p_page_process_id=>wwv_flow_imp.id(8028356032024334)
,p_value_type=>'SQL_QUERY'
,p_value=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
unistr('    ''CONTEXTO: VOC\00CA \00C9 UM AI COM O OBJETIVO DE CORRIGIR ORTOGRAFIA DO TEXTO ENVIADO, '),
unistr('     FORMAT\00C1-LO, RESUMI-LO, CLASSIFICAR O MESMO DE ACORDO COM A ENTIDADE P\00DABLICA QUE DEVE'),
unistr('     SER ACIONADA: POL\00CDCIA, BOMBEIRO OU SAMU, SEMPRE RESPONDER EM PORTUGU\00CAS E '),
'     NUNCA INVENTAR NADA.',
'     O SEU OUTPUT DEVE VIR NO FORMATO JSON {"MENSAGEM_ORIGINAL":"","CLASSIFICACAO":""}',
unistr('     O TEXTO A SER ANALISADO \00C9: '' || :P3_AUDIO AS TEXTO_ANALISADO'),
'FROM DUAL;',
''))
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(8028638641024337)
,p_page_id=>3
,p_web_src_param_id=>wwv_flow_imp.id(8204719725128266)
,p_page_process_id=>wwv_flow_imp.id(8028356032024334)
,p_value_type=>'ITEM'
,p_value=>'AITEXT'
,p_ignore_output=>false
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8226671618875945)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(8028229767024333)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Parse JSON Classificacao'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--DECLARE',
'--    l_json      VARCHAR2(32767) := :AITEXT;',
'--    l_text      VARCHAR2(4000);',
'--BEGIN',
'--    -- Extract the text from the JSON',
'--    SELECT jt.text',
'--    INTO l_text',
'--    FROM dual,',
'--         JSON_TABLE(',
'--             l_json,',
'--             ''$.chatResponse'' COLUMNS (',
'--                 text VARCHAR2(4000) PATH ''$.text''',
'--             )',
'--         ) jt;',
'--',
'--    :AITEXT := l_text;',
'--END;',
'',
'DECLARE',
'    l_json      CLOB := :AITEXT;',
'    l_text      CLOB;',
'    l_message   CLOB;',
'BEGIN',
'    -- Extrai o campo "text" dentro de "chatResponse"',
'    SELECT jt.text',
'    INTO l_text',
'    FROM dual,',
'         JSON_TABLE(',
'             l_json,',
'             ''$.chatResponse'' COLUMNS (',
'                 text CLOB PATH ''$.text''',
'             )',
'         ) jt;',
'    ',
'    -- Extrai o campo "MENSAGEM_ORIGINAL" de dentro do JSON contido em "text"',
'    SELECT jt.mensagem_original',
'    INTO l_message',
'    FROM dual,',
'         JSON_TABLE(',
'             l_text,',
'             ''$'' COLUMNS (',
'                 mensagem_original CLOB PATH ''$.CLASSIFICACAO''',
'             )',
'         ) jt;',
'    ',
'    :CLASSIFICACAO := l_message;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>8226671618875945
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8028868015024339)
,p_process_sequence=>30
,p_parent_process_id=>wwv_flow_imp.id(8028229767024333)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Parse JSON Mensagem'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--DECLARE',
'--    l_json      VARCHAR2(32767) := :AITEXT;',
'--    l_text      VARCHAR2(4000);',
'--BEGIN',
'--    -- Extract the text from the JSON',
'--    SELECT jt.text',
'--    INTO l_text',
'--    FROM dual,',
'--         JSON_TABLE(',
'--             l_json,',
'--             ''$.chatResponse'' COLUMNS (',
'--                 text VARCHAR2(4000) PATH ''$.text''',
'--             )',
'--         ) jt;',
'--',
'--    :AITEXT := l_text;',
'--END;',
'',
'DECLARE',
'    l_json      CLOB := :AITEXT;',
'    l_text      CLOB;',
'    l_message   CLOB;',
'BEGIN',
'    -- Extrai o campo "text" dentro de "chatResponse"',
'    SELECT jt.text',
'    INTO l_text',
'    FROM dual,',
'         JSON_TABLE(',
'             l_json,',
'             ''$.chatResponse'' COLUMNS (',
'                 text CLOB PATH ''$.text''',
'             )',
'         ) jt;',
'    ',
'    -- Extrai o campo "MENSAGEM_ORIGINAL" de dentro do JSON contido em "text"',
'    SELECT jt.mensagem_original',
'    INTO l_message',
'    FROM dual,',
'         JSON_TABLE(',
'             l_text,',
'             ''$'' COLUMNS (',
'                 mensagem_original CLOB PATH ''$.MENSAGEM_ORIGINAL''',
'             )',
'         ) jt;',
'    ',
'    :AITEXT := l_message;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>8028868015024339
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8224149418875920)
,p_process_sequence=>50
,p_parent_process_id=>wwv_flow_imp.id(8028229767024333)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GEOCODING'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    :LATITUDE := :P3_LATITUDE;',
'    :LONGITUDE:= :P3_LONGITUDE;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>8224149418875920
);
wwv_flow_imp.component_end;
end;
/
