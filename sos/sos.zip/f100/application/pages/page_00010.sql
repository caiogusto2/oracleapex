prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7517595396827368
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SOS'
);
wwv_flow_imp_page.create_page(
 p_id=>10
,p_name=>'Detalhes BO - Policia'
,p_alias=>'DETALHES-BO-POLICIA'
,p_page_mode=>'MODAL'
,p_step_title=>'Detalhes BO - Policia'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.foto {',
'    max-height: 200px;',
'    width: auto;',
'    height: auto; ',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'!'||wwv_flow_imp.id(7857427828037108)
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8586686394376369)
,p_plug_name=>'Detalhes BO - Policia'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7561302586879713)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    b.bo_id,',
'    u.nome,',
'    u.sobrenome,',
'    u.foto,',
'    u.rua,',
'    u.numero,',
'    u.complemento,',
'    u.cidade,',
'    u.estado,',
'    u.pais,',
'    u.telefone,',
'    u.emerg_nome,',
'    u.emerg_sobrenome,',
'    u.emerg_rua,',
'    u.emerg_numero,',
'    u.emerg_complemento,',
'    u.emerg_cidade,',
'    u.emerg_estado,',
'    u.cpf,',
'    u.email,',
'    u.foto_mimetype,',
'    u.foto_filename,',
'    u.foto_date,',
'    b.hora_abertura,',
'    b.textoai,',
'    b.latitude,',
'    b.longitude,',
'    b.adic01,',
'    b.adic01_mimetype,',
'    b.adic01_filename,',
'    b.adic02,',
'    b.adic02_mimetype,',
'    b.adic02_filename,',
'    b.adic03,',
'    b.adic03_mimetype,',
'    b.adic03_filename,',
'    b.classificacao,',
'    b.status,',
'    b.pol_hora_atendimento,',
'    b.pol_conclusao_bo',
'from BOLETIM_OCORRENCIA b, cadastro_usuarios u',
'where b.usuario_fk = u.usuario_id;'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8596952924422015)
,p_plug_name=>unistr('Boletim de Ocorr\00EAncia')
,p_parent_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(7627989853879914)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8597636604422022)
,p_plug_name=>unistr('Informa\00E7\00F5es Solicitante')
,p_parent_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(7627989853879914)
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8597792621422023)
,p_plug_name=>unistr('Contato Emerg\00EAncia Solicitante')
,p_parent_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(7627989853879914)
,p_plug_display_sequence=>30
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8590923862376394)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7564113216879720)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8597055102422016)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(8596952924422015)
,p_button_name=>'DownloadAnexos'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(7701684388880185)
,p_button_image_alt=>'Download Anexos'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    file_content, ',
'    file_name,',
'    mime_type',
'FROM (',
'    SELECT ',
'        adic01 AS file_content, ',
'        ADIC01_FILENAME AS file_name, ',
'        ADIC01_MIMETYPE as mime_type ',
'    FROM boletim_ocorrencia ',
'    where BO_ID = :BO_ID',
'    UNION ALL',
'    SELECT ',
'        adic02 AS file_content, ',
'        ADIC02_FILENAME AS file_name, ',
'        ADIC02_MIMETYPE as mime_type ',
'    FROM boletim_ocorrencia ',
'    where BO_ID = :BO_ID',
'    UNION ALL',
'    SELECT ',
'        adic03 AS file_content, ',
'        ADIC03_FILENAME AS file_name, ',
'        ADIC03_MIMETYPE as mime_type ',
'    FROM boletim_ocorrencia ',
'    where BO_ID = :BO_ID',
') t',
'WHERE file_name is not null;'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-download'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8591235509376397)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(8590923862376394)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(7701569334880184)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8592664074376403)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(8590923862376394)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(7701569334880184)
,p_button_image_alt=>'Deletar'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P10_BO_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8593047582376404)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(8590923862376394)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(7701569334880184)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Salvar'
,p_button_position=>'NEXT'
,p_button_condition=>'P10_BO_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8485987682884730)
,p_name=>'P10_NOME'
,p_source_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(8597636604422022)
,p_item_source_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_prompt=>'Nome'
,p_source=>'NOME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(7699044964880169)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8486090503884731)
,p_name=>'P10_SOBRENOME'
,p_source_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(8597636604422022)
,p_item_source_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_prompt=>'Sobrenome'
,p_source=>'SOBRENOME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(7699044964880169)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8486124029884732)
,p_name=>'P10_FOTO'
,p_source_data_type=>'BLOB'
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(8597636604422022)
,p_item_source_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_prompt=>'Foto'
,p_source=>'FOTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_tag_css_classes=>'foto'
,p_field_template=>wwv_flow_imp.id(7699044964880169)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'DB_COLUMN'
,p_attribute_04=>'FOTO_FILENAME'
,p_attribute_05=>'FOTO_DATE'
,p_attribute_07=>'FOTO_MIMETYPE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8486237208884733)
,p_name=>'P10_RUA'
,p_source_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(8597636604422022)
,p_item_source_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_prompt=>'Rua'
,p_source=>'RUA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(7699044964880169)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8486355335884734)
,p_name=>'P10_NUMERO'
,p_source_data_type=>'NUMBER'
,p_is_query_only=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(8597636604422022)
,p_item_source_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_prompt=>'Numero'
,p_source=>'NUMERO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(7699044964880169)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8486468145884735)
,p_name=>'P10_COMPLEMENTO'
,p_source_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(8597636604422022)
,p_item_source_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_prompt=>'Complemento'
,p_source=>'COMPLEMENTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(7699044964880169)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8486595145884736)
,p_name=>'P10_CIDADE'
,p_source_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(8597636604422022)
,p_item_source_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_prompt=>'Cidade'
,p_source=>'CIDADE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(7699044964880169)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8486680145884737)
,p_name=>'P10_ESTADO'
,p_source_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(8597636604422022)
,p_item_source_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_prompt=>'Estado'
,p_source=>'ESTADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(7699044964880169)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8486704989884738)
,p_name=>'P10_PAIS'
,p_source_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(8597636604422022)
,p_item_source_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_prompt=>'Pais'
,p_source=>'PAIS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(7699044964880169)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8486802203884739)
,p_name=>'P10_TELEFONE'
,p_source_data_type=>'NUMBER'
,p_is_query_only=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(8597636604422022)
,p_item_source_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_prompt=>'Telefone'
,p_source=>'TELEFONE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(7699044964880169)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8486973618884740)
,p_name=>'P10_EMERG_NOME'
,p_source_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(8597792621422023)
,p_item_source_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_prompt=>'Emerg Nome'
,p_source=>'EMERG_NOME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(7699044964880169)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8487088480884741)
,p_name=>'P10_EMERG_SOBRENOME'
,p_source_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(8597792621422023)
,p_item_source_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_prompt=>'Emerg Sobrenome'
,p_source=>'EMERG_SOBRENOME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(7699044964880169)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8487135538884742)
,p_name=>'P10_EMERG_RUA'
,p_source_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(8597792621422023)
,p_item_source_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_prompt=>'Emerg Rua'
,p_source=>'EMERG_RUA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(7699044964880169)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8487269560884743)
,p_name=>'P10_EMERG_NUMERO'
,p_source_data_type=>'NUMBER'
,p_is_query_only=>true
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(8597792621422023)
,p_item_source_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_prompt=>'Emerg Numero'
,p_source=>'EMERG_NUMERO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(7699044964880169)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8487325665884744)
,p_name=>'P10_EMERG_COMPLEMENTO'
,p_source_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(8597792621422023)
,p_item_source_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_prompt=>'Emerg Complemento'
,p_source=>'EMERG_COMPLEMENTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(7699044964880169)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8487449283884745)
,p_name=>'P10_EMERG_CIDADE'
,p_source_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(8597792621422023)
,p_item_source_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_prompt=>'Emerg Cidade'
,p_source=>'EMERG_CIDADE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(7699044964880169)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8487564003884746)
,p_name=>'P10_EMERG_ESTADO'
,p_source_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(8597792621422023)
,p_item_source_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_prompt=>'Emerg Estado'
,p_source=>'EMERG_ESTADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(7699044964880169)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8487771035884748)
,p_name=>'P10_FOTO_MIMETYPE'
,p_source_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(8597636604422022)
,p_item_source_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_source=>'FOTO_MIMETYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8487853241884749)
,p_name=>'P10_FOTO_FILENAME'
,p_source_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(8597636604422022)
,p_item_source_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_source=>'FOTO_FILENAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8487969116884750)
,p_name=>'P10_FOTO_DATE'
,p_source_data_type=>'DATE'
,p_is_query_only=>true
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(8597636604422022)
,p_item_source_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_source=>'FOTO_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8587473805376376)
,p_name=>'P10_CPF'
,p_source_data_type=>'NUMBER'
,p_is_query_only=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(8597636604422022)
,p_item_source_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_prompt=>'Cpf'
,p_source=>'CPF'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(7699044964880169)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8587892714376380)
,p_name=>'P10_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(8596952924422015)
,p_item_source_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_prompt=>'Status'
,p_source=>'STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>unistr('STATIC:CANCELADO;CANCELADO,EM ANDAMENTO;EM ANDAMENTO,CONCLU\00CDDO;CONCLU\00CDDO')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(7700369552880174)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8588204205376381)
,p_name=>'P10_HORA_ABERTURA'
,p_source_data_type=>'TIMESTAMP'
,p_is_query_only=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(8596952924422015)
,p_item_source_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_prompt=>'Hora Abertura'
,p_source=>'HORA_ABERTURA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(7699044964880169)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8589094669376386)
,p_name=>'P10_CLASSIFICACAO'
,p_source_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(8596952924422015)
,p_item_source_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_prompt=>'Classificacao'
,p_source=>'CLASSIFICACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(7699044964880169)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8595555991422001)
,p_name=>'P10_TEXTOAI'
,p_source_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(8596952924422015)
,p_item_source_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_prompt=>'Texto BO'
,p_source=>'TEXTOAI'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(7699044964880169)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8596703047422013)
,p_name=>'P10_BO_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(8596952924422015)
,p_item_source_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_prompt=>'Protocolo'
,p_source=>'BO_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(7699044964880169)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8600121246422047)
,p_name=>'P10_POL_CONCLUSAO_BO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(8596952924422015)
,p_item_source_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_prompt=>unistr('Conclus\00E3o BO')
,p_source=>'POL_CONCLUSAO_BO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(7700369552880174)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8698827395864710)
,p_name=>'P10_POL_HORA_ATENDIMENTO'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(8596952924422015)
,p_item_source_plug_id=>wwv_flow_imp.id(8586686394376369)
,p_source=>'POL_HORA_ATENDIMENTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8591315838376397)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8591235509376397)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8592139393376402)
,p_event_id=>wwv_flow_imp.id(8591315838376397)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8597184082422017)
,p_name=>'Download'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8597055102422016)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8597212705422018)
,p_event_id=>wwv_flow_imp.id(8597184082422017)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DOWNLOAD'
,p_attribute_01=>'Y'
,p_attribute_02=>'procotol_&BO_ID..zip'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    file_content, ',
'    file_name,',
'    mime_type',
'FROM (',
'    SELECT ',
'        adic01 AS file_content, ',
'        ADIC01_FILENAME AS file_name, ',
'        ADIC01_MIMETYPE as mime_type ',
'    FROM boletim_ocorrencia ',
'    where BO_ID = :BO_ID',
'    UNION ALL',
'    SELECT ',
'        adic02 AS file_content, ',
'        ADIC02_FILENAME AS file_name, ',
'        ADIC02_MIMETYPE as mime_type ',
'    FROM boletim_ocorrencia ',
'    where BO_ID = :BO_ID',
'    UNION ALL',
'    SELECT ',
'        adic03 AS file_content, ',
'        ADIC03_FILENAME AS file_name, ',
'        ADIC03_MIMETYPE as mime_type ',
'    FROM boletim_ocorrencia ',
'    where BO_ID = :BO_ID',
') t',
'WHERE file_name is not null;'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8698986972864711)
,p_name=>'TIMESTAMP'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8699019888864712)
,p_event_id=>wwv_flow_imp.id(8698986972864711)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P10_POL_HORA_ATENDIMENTO'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select current_timestamp from dual'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8594234589376409)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(8586686394376369)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Detalhes BO - Policia'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>8594234589376409
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8594666107376410)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>8594666107376410
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8593817278376408)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(8586686394376369)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Detalhes BO - Policia'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>8593817278376408
);
wwv_flow_imp.component_end;
end;
/
