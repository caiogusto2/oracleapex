prompt --application/shared_components/logic/application_items/aitext
begin
--   Manifest
--     APPLICATION ITEM: AITEXT
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7517595396827368
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SOS'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(8211684743527653)
,p_name=>'AITEXT'
,p_protection_level=>'I'
,p_version_scn=>44479705421445
);
wwv_flow_imp.component_end;
end;
/
