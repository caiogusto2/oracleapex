prompt --application/shared_components/logic/application_computations/usuario_id
begin
--   Manifest
--     APPLICATION COMPUTATION: USUARIO_ID
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7517595396827368
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SOS'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(7933224088432332)
,p_computation_sequence=>10
,p_computation_item=>'USUARIO_ID'
,p_computation_point=>'AFTER_LOGIN'
,p_computation_type=>'QUERY'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'SELECT USUARIO_ID FROM CADASTRO_USUARIOS WHERE EMAIL = LOWER(get_apex_app_user);'
,p_version_scn=>44463089558092
);
wwv_flow_imp.component_end;
end;
/
