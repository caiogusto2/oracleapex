prompt --application/shared_components/navigation/lists/abrir_bo
begin
--   Manifest
--     LIST: Abrir BO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7517595396827368
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SOS'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(7991965082070400)
,p_name=>'Abrir BO'
,p_list_status=>'PUBLIC'
,p_version_scn=>44478025294069
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7993377678070422)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Gravar Relato'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7997651627070446)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('Revis\00E3o')
,p_list_item_link_target=>'f?p=&APP_ID.:4:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(8002608937070461)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>unistr('N\00FAmero Protocolo')
,p_list_item_link_target=>'f?p=&APP_ID.:5:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
