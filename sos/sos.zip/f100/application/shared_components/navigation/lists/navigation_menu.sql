prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7517595396827368
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SOS'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(7525182178879544)
,p_name=>'Navigation Menu'
,p_list_status=>'PUBLIC'
,p_version_scn=>44489823517639
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7824844837880989)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_security_scheme=>'!'||wwv_flow_imp.id(7857661119038654)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7859147476055486)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('Informa\00E7\00F5es Pessoais')
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::P2_USUARIO_ID:&USUARIO_ID.:'
,p_list_item_icon=>'fa-user'
,p_security_scheme=>'!'||wwv_flow_imp.id(7857661119038654)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'2'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(8455015546836890)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>unistr('Hist\00F3rico Acionamentos')
,p_list_item_link_target=>'f?p=&APP_ID.:6:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-table-search'
,p_security_scheme=>'!'||wwv_flow_imp.id(7857661119038654)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'6'
);
wwv_flow_imp.component_end;
end;
/
