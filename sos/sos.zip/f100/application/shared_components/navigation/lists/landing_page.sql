prompt --application/shared_components/navigation/lists/landing_page
begin
--   Manifest
--     LIST: Landing Page
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7517595396827368
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SOS'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(7841421075981075)
,p_name=>'Landing Page'
,p_list_status=>'PUBLIC'
,p_version_scn=>44486934732500
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7842019081981083)
,p_list_item_display_sequence=>5
,p_list_item_link_text=>unistr('Informa\00E7\00F5es Pessoais')
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::P2_USUARIO_ID:&USUARIO_ID.:'
,p_list_item_icon=>'fa-user'
,p_security_scheme=>'!'||wwv_flow_imp.id(7857661119038654)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7841607770981081)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>unistr('Hist\00F3rico Acionamentos')
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_security_scheme=>'!'||wwv_flow_imp.id(7857661119038654)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(8196090877019044)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'SOS'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:3:::'
,p_list_item_icon=>'fa-hand-stop-o'
,p_security_scheme=>'!'||wwv_flow_imp.id(7857661119038654)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(8715005980011866)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Consulta BO''s'
,p_list_item_link_target=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-cards'
,p_security_scheme=>'!'||wwv_flow_imp.id(7857427828037108)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
