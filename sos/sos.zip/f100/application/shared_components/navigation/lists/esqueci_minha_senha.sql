prompt --application/shared_components/navigation/lists/esqueci_minha_senha
begin
--   Manifest
--     LIST: Esqueci minha senha
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7517595396827368
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SOS'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(9043079045188051)
,p_name=>'Esqueci minha senha'
,p_list_status=>'PUBLIC'
,p_version_scn=>44489527036234
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(9044411920188077)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>unistr('Envio C\00F3digo')
,p_list_item_link_target=>'f?p=&APP_ID.:1001:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(9048688343188103)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('Valida\00E7\00E3o C\00F3digo')
,p_list_item_link_target=>'f?p=&APP_ID.:1002:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(9053697388188120)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Reset Senha'
,p_list_item_link_target=>'f?p=&APP_ID.:1003:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
