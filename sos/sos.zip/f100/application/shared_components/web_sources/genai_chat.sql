prompt --application/shared_components/web_sources/genai_chat
begin
--   Manifest
--     WEB SOURCE: GenAI-Chat
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7517595396827368
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SOS'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(8201356798114970)
,p_name=>'GenAI-Chat'
,p_static_id=>'genai_chat'
,p_web_source_type=>'NATIVE_OCI'
,p_data_profile_id=>wwv_flow_imp.id(8200267677114957)
,p_remote_server_id=>wwv_flow_imp.id(8200089965114954)
,p_url_path_prefix=>'20231130/actions/chat'
,p_credential_id=>wwv_flow_imp.id(8008690192149957)
,p_version_scn=>44479707637308
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(8201982303114978)
,p_web_src_module_id=>wwv_flow_imp.id(8201356798114970)
,p_operation=>'POST'
,p_url_pattern=>'.'
,p_request_body_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'	"chatRequest":{',
'		"apiFormat":"COHERE",',
'		"message":"#MESSAGE#",',
'                "maxTokens":"1800",',
'                "temperature":"0"',
'	},',
'	"compartmentId":"ocid1.compartment.oc1..aaaaaaaacqt2kvaoyjexiops224rzriooevivs63hxhpzjxzwbvadqcgsfha",',
'	"servingMode":{',
'		"servingType":"ON_DEMAND",',
'		"modelId":"cohere.command-r-plus-08-2024"',
'	}',
'}'))
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(8204307503127032)
,p_web_src_module_id=>wwv_flow_imp.id(8201356798114970)
,p_web_src_operation_id=>wwv_flow_imp.id(8201982303114978)
,p_name=>'MESSAGE'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(8204719725128266)
,p_web_src_module_id=>wwv_flow_imp.id(8201356798114970)
,p_web_src_operation_id=>wwv_flow_imp.id(8201982303114978)
,p_name=>'RESPONSE'
,p_param_type=>'BODY'
,p_is_required=>false
,p_direction=>'OUT'
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(8214042074549821)
,p_web_src_module_id=>wwv_flow_imp.id(8201356798114970)
,p_web_src_operation_id=>wwv_flow_imp.id(8201982303114978)
,p_name=>'Content-Type'
,p_param_type=>'HEADER'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value=>'application/json'
,p_is_static=>true
);
wwv_flow_imp.component_end;
end;
/
