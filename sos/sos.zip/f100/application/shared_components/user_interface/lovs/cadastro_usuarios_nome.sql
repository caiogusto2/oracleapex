prompt --application/shared_components/user_interface/lovs/cadastro_usuarios_nome
begin
--   Manifest
--     CADASTRO_USUARIOS.NOME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7517595396827368
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SOS'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(8445517006827559)
,p_lov_name=>'CADASTRO_USUARIOS.NOME'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'CADASTRO_USUARIOS'
,p_return_column_name=>'USUARIO_ID'
,p_display_column_name=>'NOME'
,p_default_sort_column_name=>'NOME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>44486127743544
);
wwv_flow_imp.component_end;
end;
/
