prompt --workspace/credentials/oci_api_credentials
begin
--   Manifest
--     CREDENTIAL: oci_api_credentials
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7517595396827368
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SOS'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(8008690192149957)
,p_name=>'oci_api_credentials'
,p_static_id=>'oci_api_credentials'
,p_authentication_type=>'OCI'
,p_namespace=>'ocid1.tenancy.oc1..aaaaaaaaoi6b5sxlv4z773boczybqz3h2vspvvru42jysvizl77lky22ijaq'
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
