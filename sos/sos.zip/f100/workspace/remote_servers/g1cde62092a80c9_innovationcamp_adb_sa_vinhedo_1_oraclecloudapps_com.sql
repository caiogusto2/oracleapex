prompt --workspace/remote_servers/g1cde62092a80c9_innovationcamp_adb_sa_vinhedo_1_oraclecloudapps_com
begin
--   Manifest
--     REMOTE SERVER: g1cde62092a80c9-innovationcamp-adb-sa-vinhedo-1-oraclecloudapps-com
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7517595396827368
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SOS'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(8758155203470686)
,p_name=>'g1cde62092a80c9-innovationcamp-adb-sa-vinhedo-1-oraclecloudapps-com'
,p_static_id=>'g1cde62092a80c9_innovationcamp_adb_sa_vinhedo_1_oraclecloudapps_com'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('g1cde62092a80c9_innovationcamp_adb_sa_vinhedo_1_oraclecloudapps_com'),'https://g1cde62092a80c9-innovationcamp.adb.sa-vinhedo-1.oraclecloudapps.com')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('g1cde62092a80c9_innovationcamp_adb_sa_vinhedo_1_oraclecloudapps_com'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('g1cde62092a80c9_innovationcamp_adb_sa_vinhedo_1_oraclecloudapps_com'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('g1cde62092a80c9_innovationcamp_adb_sa_vinhedo_1_oraclecloudapps_com'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('g1cde62092a80c9_innovationcamp_adb_sa_vinhedo_1_oraclecloudapps_com'),'')
,p_prompt_on_install=>false
,p_ai_is_builder_service=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('g1cde62092a80c9_innovationcamp_adb_sa_vinhedo_1_oraclecloudapps_com'),'')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('g1cde62092a80c9_innovationcamp_adb_sa_vinhedo_1_oraclecloudapps_com'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('g1cde62092a80c9_innovationcamp_adb_sa_vinhedo_1_oraclecloudapps_com'),'')
);
wwv_flow_imp.component_end;
end;
/
