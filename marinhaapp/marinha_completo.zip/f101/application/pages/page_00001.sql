prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>10469620858203280
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'MARINHA'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Embarcacoes'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.background-red {',
'    background-color: lightgrey;',
'    /*color: white; /* Optional: text color */',
'}',
'',
'/* Class for green background */',
'.background-green {',
'    background-color: lightgreen;',
'    /*color: white; /* Optional: text color */',
'}',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10878691585338927)
,p_plug_name=>unistr('Distribui\00E7\00E3o Bases')
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(10579578470262551)
,p_plug_display_sequence=>20
,p_location=>null
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(10878728554338928)
,p_region_id=>wwv_flow_imp.id(10878691585338927)
,p_height=>400
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(10878807547338929)
,p_map_region_id=>wwv_flow_imp.id(10878728554338928)
,p_name=>'Bases2023'
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>'select distinct id, local, latitude, longitude from embarcacoes where ano = 2023 order by 1;'
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_stroke_color=>'#000000'
,p_fill_color=>'#ff3b30'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_info_window_adv_formatting=>false
,p_info_window_title_column=>'LOCAL'
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(10879441349338935)
,p_map_region_id=>wwv_flow_imp.id(10878728554338928)
,p_name=>'Bases2022'
,p_layer_type=>'POINT'
,p_display_sequence=>20
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>'select distinct id, local, latitude, longitude from embarcacoes where ano = 2022 order by 1;'
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_stroke_color=>'#000000'
,p_fill_color=>'#4cd964'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_info_window_adv_formatting=>false
,p_info_window_title_column=>'LOCAL'
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(10879554326338936)
,p_map_region_id=>wwv_flow_imp.id(10878728554338928)
,p_name=>'Bases2021'
,p_layer_type=>'POINT'
,p_display_sequence=>30
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>'select distinct id, local, latitude, longitude from embarcacoes where ano = 2021 order by 1;'
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_stroke_color=>'#000000'
,p_fill_color=>'#5856d6'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_info_window_adv_formatting=>false
,p_info_window_title_column=>'LOCAL'
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(10879614519338937)
,p_map_region_id=>wwv_flow_imp.id(10878728554338928)
,p_name=>'Bases2020'
,p_layer_type=>'POINT'
,p_display_sequence=>40
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>'select distinct id, local, latitude, longitude from embarcacoes where ano = 2020 order by 1;'
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_stroke_color=>'#000000'
,p_fill_color=>'#8e8e93'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_info_window_adv_formatting=>false
,p_info_window_title_column=>'LOCAL'
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(10879750332338938)
,p_map_region_id=>wwv_flow_imp.id(10878728554338928)
,p_name=>'Bases2019'
,p_layer_type=>'POINT'
,p_display_sequence=>50
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>'select distinct id, local, latitude, longitude from embarcacoes where ano = 2019 order by 1;'
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_stroke_color=>'#000000'
,p_fill_color=>'#ffcc00'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_info_window_adv_formatting=>false
,p_info_window_title_column=>'LOCAL'
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10878984855338930)
,p_plug_name=>unistr('Embarca\00E7\00F5es 2023')
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(10579578470262551)
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(10879057911338931)
,p_region_id=>wwv_flow_imp.id(10878984855338930)
,p_chart_type=>'pie'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(10879128985338932)
,p_chart_id=>wwv_flow_imp.id(10879057911338931)
,p_seq=>10
,p_name=>'New'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    EMBARCACAO,',
'    SUM(QTDE) AS SOMATORIO',
'FROM',
'EMBARCACOES',
'WHERE ANO = 2023',
'GROUP BY EMBARCACAO',
'ORDER BY 2 DESC;'))
,p_items_value_column_name=>'SOMATORIO'
,p_items_label_column_name=>'EMBARCACAO'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11497861332932913)
,p_plug_name=>unistr('Embarca\00E7\00F5es Ano a Ano e Predi\00E7\00E3o Usando OML')
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(10579578470262551)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(11497969824932914)
,p_region_id=>wwv_flow_imp.id(11497861332932913)
,p_chart_type=>'line'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(11498032595932915)
,p_chart_id=>wwv_flow_imp.id(11497969824932914)
,p_seq=>10
,p_name=>'Valor'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    EXTRACT(YEAR FROM CASE_ID) AS CASE_YEAR,  -- Extract the year from CASE_ID',
'    VALUE AS QTDE,',
'    PREDICTION',
'FROM DM$P0ESM_HOUSEHOLD_MDL_YEAR',
'ORDER BY CASE_ID;',
''))
,p_items_value_column_name=>'QTDE'
,p_items_label_column_name=>'CASE_YEAR'
,p_color=>'#000000'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'on'
,p_marker_shape=>'circle'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(11499661283932931)
,p_chart_id=>wwv_flow_imp.id(11497969824932914)
,p_seq=>20
,p_name=>unistr('Predi\00E7\00E3o')
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    EXTRACT(YEAR FROM CASE_ID) AS CASE_YEAR,  -- Extract the year from CASE_ID',
'    VALUE AS QTDE,',
'    PREDICTION',
'FROM DM$P0ESM_HOUSEHOLD_MDL_YEAR',
'ORDER BY CASE_ID;',
''))
,p_items_value_column_name=>'PREDICTION'
,p_items_label_column_name=>'CASE_YEAR'
,p_color=>'#4cd964'
,p_line_style=>'dashed'
,p_line_type=>'auto'
,p_marker_rendered=>'on'
,p_marker_shape=>'circle'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(11498104099932916)
,p_chart_id=>wwv_flow_imp.id(11497969824932914)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(11498230537932917)
,p_chart_id=>wwv_flow_imp.id(11497969824932914)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11498386667932918)
,p_plug_name=>unistr('Qtde Embarca\00E7\00F5es Ano a Ano')
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(10579578470262551)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(11498453009932919)
,p_region_id=>wwv_flow_imp.id(11498386667932918)
,p_chart_type=>'bar'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'value-desc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(11498580383932920)
,p_chart_id=>wwv_flow_imp.id(11498453009932919)
,p_seq=>10
,p_name=>'New'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    ESTADO, ',
'    ANO, ',
'    SUM(QTDE) AS SOMATORIO ',
'FROM EMBARCACOES ',
'WHERE ANO IN (''2023'',''2022'',''2021'',''2020'',''2019'')',
'GROUP BY ANO, ESTADO ',
'ORDER BY SOMATORIO DESC, ANO;'))
,p_series_name_column_name=>'ANO'
,p_items_value_column_name=>'SOMATORIO'
,p_items_label_column_name=>'ESTADO'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(11498600385932921)
,p_chart_id=>wwv_flow_imp.id(11498453009932919)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(11498716483932922)
,p_chart_id=>wwv_flow_imp.id(11498453009932919)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11498922140932924)
,p_plug_name=>'Home'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--featured'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(10546210016262460)
,p_plug_display_sequence=>60
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(10476225280262206)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(10654732438262797)
,p_region_image=>'#APP_FILES#icons/app-icon-512.png	'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11499587262932930)
,p_plug_name=>'Fonte de Dados'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(10512926861262365)
,p_plug_display_sequence=>60
,p_plug_display_point=>'REGION_POSITION_05'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h5>',
'    <spawn>Fonte de dados:</spawn>',
'    <a href="https://dados.gov.br/dados/organizacoes/visualizar/marinha-do-brasil" target="_blank">https://dados.gov.br/dados/organizacoes/visualizar/marinha-do-brasil</a>',
'</h5>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28791802079574020)
,p_plug_name=>'Busca In/Out'
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(10579578470262551)
,p_plug_display_sequence=>70
,p_location=>null
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(28791994516574021)
,p_region_id=>wwv_flow_imp.id(28791802079574020)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_layer_messages_position=>'BELOW'
,p_show_legend=>false
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(28792040546574022)
,p_map_region_id=>wwv_flow_imp.id(28791994516574021)
,p_name=>'Polygon'
,p_layer_type=>'POLYGON'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_table_name=>'GEOPOLYGON'
,p_include_rowid_column=>false
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOPOLYGON'
,p_stroke_color=>'#101010'
,p_fill_color_is_spectrum=>false
,p_fill_opacity=>.4
,p_tooltip_adv_formatting=>false
,p_info_window_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(28792175558574023)
,p_map_region_id=>wwv_flow_imp.id(28791994516574021)
,p_name=>'Endereco'
,p_layer_type=>'POINT'
,p_display_sequence=>20
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_table_name=>'LOCTEMP'
,p_include_rowid_column=>false
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOPOLYGON'
,p_stroke_color=>'#000000'
,p_fill_color=>'#ff3b30'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_point_svg_shape_scale=>'2'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_info_window_adv_formatting=>false
,p_display_in_legend=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31758340006728316)
,p_plug_name=>unistr('Transfer\00EAncia de Embarca\00E7\00F5es entre Regi\00F5es')
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(10579578470262551)
,p_plug_display_sequence=>80
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT origem,transferencia,destino',
'FROM GRAPH_TABLE (',
'    grafotransferencia',
'    MATCH (uOrigem) -[e]-> (uDestino)',
'    WHERE uOrigem."ID_UNIDADE" IS NOT NULL AND uDestino."ID_UNIDADE" IS NOT NULL',
'    COLUMNS (',
'        vertex_id(uOrigem) AS origem,',
'        edge_id(e) AS transferencia,',
'        vertex_id(uDestino) AS destino',
'    )',
')',
''))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_02', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '    "evolution": {',
    '        "chart": "line",',
    '        "unit": "month",',
    '        "edge": "properties.DATA_TRANSFERENCIA",',
    '        "preservePositions":"true"',
    '    }',
    '}')),
  'attribute_03', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '   "vertex":{',
    '    "size":12,',
    '    "label":"${properties.NOME} - ${properties.LOCALIZACAO}",',
    '    "icon":{',
    '        "class":"oj-ux-ico-location-pin-s",',
    '        "color":"red"',
    '    },',
    '    "color":"white",',
    '    "border":{',
    '               "width":1,',
    '               "color":"black"',
    '            }',
    '   }',
    '}')),
  'attribute_04', 'force',
  'attribute_05', 'N',
  'attribute_14', 'N',
  'attribute_16', '640',
  'custom_theme', 'N',
  'darktheme', 'N',
  'edgemarker', 'none',
  'enable_evolution', 'N',
  'escapehtml', 'N',
  'force_clusterenabled', 'N',
  'livesearch', 'N',
  'show_legend', 'N',
  'showtitle', 'N',
  'size_mode', 'compact',
  'spacing', '10')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(31759203485728325)
,p_name=>'ORIGEM'
,p_data_type=>'CLOB'
,p_is_visible=>true
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(31759342681728326)
,p_name=>'TRANSFERENCIA'
,p_data_type=>'CLOB'
,p_is_visible=>true
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(31759483614728327)
,p_name=>'DESTINO'
,p_data_type=>'CLOB'
,p_is_visible=>true
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31760384837728336)
,p_plug_name=>unistr('Transfer\00EAncia de Embarca\00E7\00F5es entre Regi\00F5es - Mapa')
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(10579578470262551)
,p_plug_display_sequence=>90
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT origem,transferencia,destino',
'FROM GRAPH_TABLE (',
'    grafotransferencia',
'    MATCH (uOrigem) -[e]-> (uDestino)',
'    WHERE uOrigem."ID_UNIDADE" IS NOT NULL AND uDestino."ID_UNIDADE" IS NOT NULL',
'    COLUMNS (',
'        vertex_id(uOrigem) AS origem,',
'        edge_id(e) AS transferencia,',
'        vertex_id(uDestino) AS destino',
'    )',
')',
''))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_02', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '    "evolution": {',
    '        "chart": "line",',
    '        "unit": "month",',
    '        "edge": "properties.DATA_TRANSFERENCIA"',
    '    }',
    '}')),
  'attribute_03', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '   "vertex":{',
    '    "size":12,',
    '    "label":"${properties.NOME} - ${properties.LOCALIZACAO}",',
    '    "icon":{',
    '        "class":"oj-ux-ico-location-pin-s",',
    '        "color":"red"',
    '    },',
    '    "color":"white",',
    '    "border":{',
    '               "width":1,',
    '               "color":"black"',
    '            }',
    '   },',
    '    "edge": {',
    '    "color": "red",',
    '    "legend": "edge",',
    '    "width": 2',
    '  }',
    '}')),
  'attribute_04', 'geographical',
  'attribute_05', 'N',
  'attribute_14', 'N',
  'attribute_16', '640',
  'custom_theme', 'N',
  'darktheme', 'N',
  'edgemarker', 'none',
  'enable_evolution', 'N',
  'escapehtml', 'N',
  'geo_maptype', 'osm_positron',
  'geo_showinfo', 'N',
  'geo_shownavigation', 'N',
  'livesearch', 'N',
  'show_legend', 'N',
  'showtitle', 'N',
  'size_mode', 'compact')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(31760458359728337)
,p_name=>'ORIGEM'
,p_data_type=>'CLOB'
,p_is_visible=>true
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(31760566324728338)
,p_name=>'TRANSFERENCIA'
,p_data_type=>'CLOB'
,p_is_visible=>true
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(31760601595728339)
,p_name=>'DESTINO'
,p_data_type=>'CLOB'
,p_is_visible=>true
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28792528968574027)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(28791802079574020)
,p_button_name=>'Submit'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--gapBottom'
,p_button_template_id=>wwv_flow_imp.id(10653180167262791)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Buscar'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28792251731574024)
,p_name=>'P1_INPUT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(28791802079574020)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Endere\00E7o')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(10650696139262776)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_attribute_06=>'UPPER'
,p_show_quick_picks=>'Y'
,p_quick_pick_label_01=>'Oracle Brasil'
,p_quick_pick_value_01=>unistr('Rua Dr. Jos\00E9 \00C1ureo Bustamante, 455 - Ch\00E1cara Santo Ant\00F4nio, S\00E3o Paulo - SP')
,p_quick_pick_label_02=>unistr('Itaquer\00E3o')
,p_quick_pick_value_02=>unistr('ITAQUER\00C3O SAO PAULO SP')
,p_quick_pick_label_03=>unistr('Pra\00E7a da S\00E9')
,p_quick_pick_value_03=>unistr('CATEDRAL PRA\00C7A DA S\00C9 S\00C3O PAULO')
,p_quick_pick_label_04=>'Allianz Parque'
,p_quick_pick_value_04=>'ALLIANZ PARQUE SAO PAULO SP'
,p_quick_pick_label_05=>'Pref Sorocaba'
,p_quick_pick_value_05=>'Av. Eng. Carlos Reinaldo Mendes, 3041 - Alto da Boa Vista, Sorocaba'
,p_quick_pick_label_06=>'Aeroporto Guarulhos'
,p_quick_pick_value_06=>unistr('Rod. H\00E9lio Smidt, s/n\00BA - Aeroporto, Guarulhos - SP')
,p_quick_pick_label_07=>'Vila Belmiro'
,p_quick_pick_value_07=>'Rua Princesa Isabel, S/N, Vila Belmiro, Santos - SP'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28792395438574025)
,p_name=>'P1_OUTPUT'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(28791802079574020)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Output'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(10650696139262776)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28792429005574026)
,p_name=>'P1_TEMP'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(28791802079574020)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28793330643574035)
,p_name=>'P1_CODE01'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(28791802079574020)
,p_prompt=>'Geocoding'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_address_line    VARCHAR2(4000) := :P1_INPUT;',
'    v_geocode_result  SDO_GEOMETRY; -- Assuming that the geocode result is a geometry object',
'BEGIN',
'    -- Fetch the geocode result and store it into a variable',
'    SELECT SDO_GCDR.ELOC_GEOCODE(v_address_line)',
'    INTO :P1_TEMP',
'    FROM dual;',
'',
'    -- Further processing can be done here if needed (e.g., store the result in a table)',
'END;'))
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(10650696139262776)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_required_patch=>wwv_flow_imp.id(10475695046262193)
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28793494392574036)
,p_name=>'P1_CODE02'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(28791802079574020)
,p_prompt=>'Geocoding'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_json      VARCHAR2(32767) := :P1_TEMP;',
'    l_text      VARCHAR2(4000);',
'    v_containment_status VARCHAR2(4000);',
'    v_latitude  NUMBER;',
'    v_longitude NUMBER;',
'    v_id        VARCHAR2(10);',
'    v_matchCount NUMBER;',
'BEGIN',
'',
'SELECT jt.id, ',
'       jt.matchCount, ',
'       jt.x AS longitude, ',
'       jt.y AS latitude',
'  INTO v_id, ',
'       v_matchCount, ',
'       v_longitude, ',
'       v_latitude',
'FROM dual, ',
'     JSON_TABLE(l_json, ''$[*]''',
'       COLUMNS (',
'         id VARCHAR2(10) PATH ''$.id'',',
'         matchCount NUMBER PATH ''$.matchCount'',',
'         NESTED PATH ''$.matches[*]'' ',
'         COLUMNS (',
'           x NUMBER PATH ''$.x'',',
'           y NUMBER PATH ''$.y''',
'         )',
'       )',
'     ) jt;',
'',
'    -- Truncate the loctemp table',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE loctemp'';',
'',
'    -- Insert the new data into loctemp',
'    INSERT INTO loctemp (endereco, geopolygon)',
'    VALUES (',
'        :P1_INPUT,',
'        SDO_GEOMETRY(',
'        2001, -- Point type',
'        8307, -- SRS ID (null for default)',
'        SDO_POINT_TYPE(v_longitude, v_latitude, NULL), -- Longitude, Latitude',
'        NULL, -- No ordinates for point',
'        NULL  -- No point array',
'    ));',
'',
'    COMMIT;',
'',
'    -- Get the containment status',
'    SELECT ',
'        CASE ',
unistr('            WHEN COUNT(*) > 0 THEN ''O ENDERE\00C7O FORNECIDO ENCONTRA-SE DENTRO DA CIDADE DE SP'''),
unistr('            ELSE ''O ENDERE\00C7O FORNECIDO N\00C3O SE ENCONTRA DENTRO DA CIDADE DE SP'''),
'        END AS containment_status',
'    INTO v_containment_status',
'    FROM ',
'        geopolygon g',
'    WHERE ',
'        SDO_INSIDE(SDO_GEOMETRY(',
'            2001, -- Point type',
'            8307, -- SRS ID (null for default)',
'            SDO_POINT_TYPE(v_longitude, v_latitude, NULL), -- Longitude, Latitude',
'            NULL, -- No ordinates for point',
'            NULL  -- No point array',
'        ), g.geopolygon) = ''TRUE'';',
'',
'    -- Assign the containment status to P2_OUTPUT2',
'    :P1_OUTPUT := v_containment_status;',
'',
'END;'))
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(10650696139262776)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_required_patch=>wwv_flow_imp.id(10475695046262193)
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(28792624466574028)
,p_name=>'CSS'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_OUTPUT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(28792752590574029)
,p_event_id=>wwv_flow_imp.id(28792624466574028)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ADD_CLASS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_OUTPUT'
,p_attribute_01=>'background-green'
,p_server_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_server_condition_expr1=>'P1_OUTPUT'
,p_server_condition_expr2=>unistr('O ENDERE\00C7O FORNECIDO ENCONTRA-SE DENTRO DA CIDADE DE SP')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(28792820016574030)
,p_event_id=>wwv_flow_imp.id(28792624466574028)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ADD_CLASS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_OUTPUT'
,p_attribute_01=>'background-red'
,p_server_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_server_condition_expr1=>'P1_OUTPUT'
,p_server_condition_expr2=>unistr('O ENDERE\00C7O FORNECIDO N\00C3O SE ENCONTRA DENTRO DA CIDADE DE SP')
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(31760819132728341)
,p_name=>'GeoCoding'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(28792528968574027)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31761020074728343)
,p_event_id=>wwv_flow_imp.id(31760819132728341)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'GeoCoding'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_address_line    VARCHAR2(4000) := :P1_INPUT;',
'    v_geocode_result  SDO_GEOMETRY; -- Assuming that the geocode result is a geometry object',
'BEGIN',
'    -- Fetch the geocode result and store it into a variable',
'    SELECT SDO_GCDR.ELOC_GEOCODE(v_address_line)',
'    INTO :P1_TEMP',
'    FROM dual;',
'',
'    -- Further processing can be done here if needed (e.g., store the result in a table)',
'END;',
''))
,p_attribute_02=>'P1_INPUT'
,p_attribute_03=>'P1_TEMP'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31761125657728344)
,p_event_id=>wwv_flow_imp.id(31760819132728341)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'GeoParse'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_json      VARCHAR2(32767) := :P1_TEMP;',
'    l_text      VARCHAR2(4000);',
'    v_containment_status VARCHAR2(4000);',
'    v_latitude  NUMBER;',
'    v_longitude NUMBER;',
'    v_id        VARCHAR2(10);',
'    v_matchCount NUMBER;',
'BEGIN',
'',
'SELECT jt.id, ',
'       jt.matchCount, ',
'       jt.x AS longitude, ',
'       jt.y AS latitude',
'  INTO v_id, ',
'       v_matchCount, ',
'       v_longitude, ',
'       v_latitude',
'FROM dual, ',
'     JSON_TABLE(l_json, ''$[*]''',
'       COLUMNS (',
'         id VARCHAR2(10) PATH ''$.id'',',
'         matchCount NUMBER PATH ''$.matchCount'',',
'         NESTED PATH ''$.matches[*]'' ',
'         COLUMNS (',
'           x NUMBER PATH ''$.x'',',
'           y NUMBER PATH ''$.y''',
'         )',
'       )',
'     ) jt;',
'',
'    -- Truncate the loctemp table',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE loctemp'';',
'',
'    -- Insert the new data into loctemp',
'    INSERT INTO loctemp (endereco, geopolygon)',
'    VALUES (',
'        :P1_INPUT,',
'        SDO_GEOMETRY(',
'        2001, -- Point type',
'        8307, -- SRS ID (null for default)',
'        SDO_POINT_TYPE(v_longitude, v_latitude, NULL), -- Longitude, Latitude',
'        NULL, -- No ordinates for point',
'        NULL  -- No point array',
'    ));',
'',
'    COMMIT;',
'',
'    -- Get the containment status',
'    SELECT ',
'        CASE ',
unistr('            WHEN COUNT(*) > 0 THEN ''O ENDERE\00C7O FORNECIDO ENCONTRA-SE DENTRO DA CIDADE DE SP'''),
unistr('            ELSE ''O ENDERE\00C7O FORNECIDO N\00C3O SE ENCONTRA DENTRO DA CIDADE DE SP'''),
'        END AS containment_status',
'    INTO v_containment_status',
'    FROM ',
'        geopolygon g',
'    WHERE ',
'        SDO_INSIDE(SDO_GEOMETRY(',
'            2001, -- Point type',
'            8307, -- SRS ID (null for default)',
'            SDO_POINT_TYPE(v_longitude, v_latitude, NULL), -- Longitude, Latitude',
'            NULL, -- No ordinates for point',
'            NULL  -- No point array',
'        ), g.geopolygon) = ''TRUE'';',
'',
'    -- Assign the containment status to P2_OUTPUT2',
'    :P1_OUTPUT := v_containment_status;',
'',
'END;',
''))
,p_attribute_02=>'P1_TEMP'
,p_attribute_03=>'P1_OUTPUT'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31761678031728349)
,p_event_id=>wwv_flow_imp.id(31760819132728341)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ADD_CLASS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_OUTPUT'
,p_attribute_01=>'background-green'
,p_server_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_server_condition_expr1=>'P1_OUTPUT'
,p_server_condition_expr2=>unistr('O ENDERE\00C7O FORNECIDO ENCONTRA-SE DENTRO DA CIDADE DE SP')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31761711517728350)
,p_event_id=>wwv_flow_imp.id(31760819132728341)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ADD_CLASS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_OUTPUT'
,p_attribute_01=>'background-red'
,p_server_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_server_condition_expr1=>'P1_OUTPUT'
,p_server_condition_expr2=>unistr('O ENDERE\00C7O FORNECIDO N\00C3O SE ENCONTRA DENTRO DA CIDADE DE SP')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31761308904728346)
,p_event_id=>wwv_flow_imp.id(31760819132728341)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(28791802079574020)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28791462805574016)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Execution Chain'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>28791462805574016
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28791504845574017)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(28791462805574016)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Geocode'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_address_line    VARCHAR2(4000) := :P1_INPUT;',
'    v_geocode_result  SDO_GEOMETRY; -- Assuming that the geocode result is a geometry object',
'BEGIN',
'    -- Fetch the geocode result and store it into a variable',
'    SELECT SDO_GCDR.ELOC_GEOCODE(v_address_line)',
'    INTO :P1_TEMP',
'    FROM dual;',
'',
'    -- Further processing can be done here if needed (e.g., store the result in a table)',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>28791504845574017
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28791691093574018)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(28791462805574016)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Geoparse'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_json      VARCHAR2(32767) := :P1_TEMP;',
'    l_text      VARCHAR2(4000);',
'    v_containment_status VARCHAR2(4000);',
'    v_latitude  NUMBER;',
'    v_longitude NUMBER;',
'    v_id        VARCHAR2(10);',
'    v_matchCount NUMBER;',
'BEGIN',
'',
'SELECT jt.id, ',
'       jt.matchCount, ',
'       jt.x AS longitude, ',
'       jt.y AS latitude',
'  INTO v_id, ',
'       v_matchCount, ',
'       v_longitude, ',
'       v_latitude',
'FROM dual, ',
'     JSON_TABLE(l_json, ''$[*]''',
'       COLUMNS (',
'         id VARCHAR2(10) PATH ''$.id'',',
'         matchCount NUMBER PATH ''$.matchCount'',',
'         NESTED PATH ''$.matches[*]'' ',
'         COLUMNS (',
'           x NUMBER PATH ''$.x'',',
'           y NUMBER PATH ''$.y''',
'         )',
'       )',
'     ) jt;',
'',
'    -- Truncate the loctemp table',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE loctemp'';',
'',
'    -- Insert the new data into loctemp',
'    INSERT INTO loctemp (endereco, geopolygon)',
'    VALUES (',
'        :P1_INPUT,',
'        SDO_GEOMETRY(',
'        2001, -- Point type',
'        8307, -- SRS ID (null for default)',
'        SDO_POINT_TYPE(v_longitude, v_latitude, NULL), -- Longitude, Latitude',
'        NULL, -- No ordinates for point',
'        NULL  -- No point array',
'    ));',
'',
'    COMMIT;',
'',
'    -- Get the containment status',
'    SELECT ',
'        CASE ',
unistr('            WHEN COUNT(*) > 0 THEN ''O ENDERE\00C7O FORNECIDO ENCONTRA-SE DENTRO DA CIDADE DE SP'''),
unistr('            ELSE ''O ENDERE\00C7O FORNECIDO N\00C3O SE ENCONTRA DENTRO DA CIDADE DE SP'''),
'        END AS containment_status',
'    INTO v_containment_status',
'    FROM ',
'        geopolygon g',
'    WHERE ',
'        SDO_INSIDE(SDO_GEOMETRY(',
'            2001, -- Point type',
'            8307, -- SRS ID (null for default)',
'            SDO_POINT_TYPE(v_longitude, v_latitude, NULL), -- Longitude, Latitude',
'            NULL, -- No ordinates for point',
'            NULL  -- No point array',
'        ), g.geopolygon) = ''TRUE'';',
'',
'    -- Assign the containment status to P2_OUTPUT2',
'    :P1_OUTPUT := v_containment_status;',
'',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>28791691093574018
);
wwv_flow_imp.component_end;
end;
/
