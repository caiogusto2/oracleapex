prompt --application/shared_components/data_profiles/cohere_chat
begin
--   Manifest
--     DATA PROFILE: Cohere-Chat
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>10469620858203280
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'MARINHA'
);
wwv_flow_imp_shared.create_data_profile(
 p_id=>wwv_flow_imp.id(14536000083813451)
,p_name=>'Cohere-Chat'
,p_format=>'JSON'
,p_use_raw_json_selectors=>false
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(14536178251813454)
,p_data_profile_id=>wwv_flow_imp.id(14536000083813451)
,p_name=>'CODE'
,p_sequence=>1
,p_column_type=>'DATA'
,p_data_type=>'NUMBER'
,p_has_time_zone=>false
,p_selector=>'code'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(14536430010813456)
,p_data_profile_id=>wwv_flow_imp.id(14536000083813451)
,p_name=>'MESSAGE'
,p_sequence=>2
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>4000
,p_has_time_zone=>false
,p_selector=>'message'
);
wwv_flow_imp.component_end;
end;
/
