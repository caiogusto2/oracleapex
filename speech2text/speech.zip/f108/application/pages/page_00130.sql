prompt --application/pages/page_00130
begin
--   Manifest
--     PAGE: 00130
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>8276771796044321
,p_default_application_id=>108
,p_default_id_offset=>8277989379040266
,p_default_owner=>'DEMO'
);
wwv_flow_imp_page.create_page(
 p_id=>130
,p_name=>'Detalhes Video'
,p_alias=>'DETALHES-VIDEO'
,p_step_title=>'Detalhes Video'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'@media only screen and (-webkit-min-device-pixel-ratio: 1.25), only screen and (-webkit-min-device-pixel-ratio: 1.3), only screen and (min-resolution: 120dpi) {',
'    .rw-pillar--rose .t-Body-title:after, .rw-pillar--rose.rw-layout--fixed .t-Body-mainContent:before',
'Specificity: (0,3,1)',
' {',
'        background-image: none;',
'    }',
'}',
'',
'.rw-pillar--rose .t-Body-title:after, .rw-pillar--rose.rw-layout--fixed .t-Body-mainContent:before {',
'    background-image: none;',
'}',
'.t-Body-title:after {',
'    background-color: rgb(217, 0, 0);',
'//    background-repeat: repeat-x;',
'//    background-size: auto 100%;',
'//    content: "";',
'//    display: block;',
'//    height: var(--ut-body-title-border-width);',
'//    left: 0;',
'//    position: absolute;',
'//    right: 0;',
'//    top: 100%;',
'}',
'',
'@media (min-width: 640px) {',
'    .rw-layout--fixed:not(.rw-layout--edge-to-edge):not(.rw-layout--contained):not(.rw-layout--foldout) .t-Body-mainContent:before {',
'        background-color: rgb(217, 0, 0);',
'//        background-repeat: repeat-x;',
'//        background-size: auto 100%;',
'//        border-top-left-radius: .3125rem;',
'//        border-top-right-radius: .3125rem;',
'//        content: "";',
'//        display: block;',
'//        height: var(--ut-body-title-border-width);',
'//        left: 0;',
'//        overflow: hidden;',
'//        position: absolute;',
'//        right: 0;',
'//        top: 0;',
'    }',
'}',
'',
'',
'.a-Button--hot, .a-CardView-button--hot, .apex-button-group input:checked+label, .t-Button--hot, .t-Form-fieldContainer--radioButtonGroup .apex-item-group--rc input:checked+label, .ui-button--hot {',
'    --a-button-background-color: rgb(217, 0, 0);',
'    --a-button-text-color: white;',
'    --a-button-hover-background-color: rgb(217, 0, 0);',
'    --a-button-hover-text-color: white;',
'    --a-button-hover-border-color: rgb(217, 0, 0);',
'    --a-button-active-background-color: white;',
'    --a-button-active-text-color: rgb(217, 0, 0);',
'    --a-button-active-border-color: white;',
'    --a-button-focus-background-color: rgb(217, 0, 0);',
'    --a-button-focus-text-color: white;',
'    --a-button-focus-border-color: rgb(217, 0, 0);',
'}',
'',
'.floatlogoff {',
'  z-index: 100;',
'  position: absolute;',
'  top: 10px;  /* Position from the top */',
'  right: 10px; /* Position from the right */',
'  width: auto; /* Adjust width as needed */',
'  height: auto; /* Adjust height as needed */',
'  padding: 10px 20px; /* Add padding for better spacing */',
'  color: black;',
'  text-align: center;',
'  border-radius: 5px; /* Optional: Slightly rounded corners */',
'  /* background-color: black;  Removed */',
'  /* box-shadow: 2px 2px 3px #999;  Removed */',
'}',
'',
'.my-floatlogoff {',
'  margin-top: 0; /* Remove unnecessary margin */',
'}',
'',
'.t-HeroRegion-title {',
'    color: black;    ',
'}'))
,p_step_template=>2979075366320325194
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8694670024303141)
,p_plug_name=>'Botoes'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8695351620303148)
,p_plug_name=>'COL1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>40
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8694701756303142)
,p_plug_name=>'Video'
,p_parent_plug_id=>wwv_flow_imp.id(8695351620303148)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ''https://objectstorage.sa-saopaulo-1.oraclecloud.com/p/UNAENag4apaRh18u52veDkRLgqvcRZ96T7UC32fEyVQfvIN6TgIox64pgqTubFFw/n/idi1o0a010nx/b/bucket-MPSP-Video/o/'' || :P130_NOME_ARQUIVO AS video_url,',
'       NULL AS poster_url,  -- You can replace this if you have a poster image BLOB or URL',
'       MIME_TYPE AS mime_type',
'  FROM VIDEOS',
'  where id = :P130_ID;',
''))
,p_plug_source_type=>'PLUGIN_DE.DANIELH.VIDEOPLAYER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', '600',
  'attribute_02', '300',
  'attribute_03', 'true',
  'attribute_04', 'false',
  'attribute_05', 'false',
  'attribute_06', 'auto',
  'attribute_07', 'BIGPLAYBUTTONCENTER',
  'attribute_08', 'To view this video please enable JavaScript, and consider upgrading to a web browser that supports',
  'attribute_09', 'en',
  'attribute_10', 'VIDEO_URL',
  'attribute_11', 'POSTER_URL',
  'attribute_12', 'MIME_TYPE',
  'attribute_15', 'false')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8695488098303149)
,p_plug_name=>'COL2'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8800257672195016)
,p_plug_name=>'Detalhes Video'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       NOME_ARQUIVO,',
'       CREATED_AT,',
'       QUEM_FEZ_UPLOAD',
'  from VIDEOS'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17579702796156717)
,p_plug_name=>'Detalhes Video'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--featured'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>60
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8892605923814871)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(17579702796156717)
,p_button_name=>'Logoff'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Logoff'
,p_button_redirect_url=>'&LOGOUT_URL.'
,p_button_css_classes=>'floatlogoff my-floatlogoff'
,p_icon_css_classes=>'fa-sign-out'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8808483623194955)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(8694670024303141)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--warning'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Deletar Video'
,p_button_position=>'NEXT'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8838609262878214)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(8694670024303141)
,p_button_name=>'DownloadTranscricao'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>unistr('Download Transcri\00E7\00E3o')
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8838720493878215)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(8694670024303141)
,p_button_name=>'DownloadVideo'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Download Video'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8839324454878221)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(8694670024303141)
,p_button_name=>'CopyClipboard'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Copy2clipboard'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8840724942878235)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(8694670024303141)
,p_button_name=>'Voltar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Voltar'
,p_button_position=>'PREVIOUS'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(8809589803194951)
,p_branch_name=>'Go To Page 100'
,p_branch_action=>'f?p=&APP_ID.:100:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(8808483623194955)
,p_branch_sequence=>1
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(8840938350878237)
,p_branch_name=>'Go To Page 100'
,p_branch_action=>'f?p=&APP_ID.:100:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(8840724942878235)
,p_branch_sequence=>11
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8695544690303150)
,p_name=>'P130_TRANSCRICAO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(8695488098303149)
,p_prompt=>unistr('Transcri\00E7\00E3o')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8800550753195009)
,p_name=>'P130_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(8800257672195016)
,p_item_source_plug_id=>wwv_flow_imp.id(8800257672195016)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8800902935195001)
,p_name=>'P130_NOME_ARQUIVO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(8800257672195016)
,p_item_source_plug_id=>wwv_flow_imp.id(8800257672195016)
,p_prompt=>'Nome Arquivo'
,p_source=>'NOME_ARQUIVO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8801784228194997)
,p_name=>'P130_CREATED_AT'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(8800257672195016)
,p_item_source_plug_id=>wwv_flow_imp.id(8800257672195016)
,p_prompt=>'Data Upload'
,p_source=>'CREATED_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8802420523194987)
,p_name=>'P130_QUEM_FEZ_UPLOAD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(8800257672195016)
,p_item_source_plug_id=>wwv_flow_imp.id(8800257672195016)
,p_prompt=>'Quem Fez Upload'
,p_source=>'QUEM_FEZ_UPLOAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8838965729878217)
,p_name=>'Download'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8838720493878215)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8839030360878218)
,p_event_id=>wwv_flow_imp.id(8838965729878217)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DOWNLOAD'
,p_attribute_01=>'N'
,p_attribute_03=>'ATTACHMENT'
,p_attribute_05=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    video as content, ',
'    nome_arquivo as filename, ',
'    mime_type ',
'from videos where id = :P130_ID'))
,p_attribute_06=>'P130_ID'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8839167615878219)
,p_name=>'DownloadJSON'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8838609262878214)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8839225188878220)
,p_event_id=>wwv_flow_imp.id(8839167615878219)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DOWNLOAD'
,p_attribute_01=>'N'
,p_attribute_03=>'ATTACHMENT'
,p_attribute_05=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    transc_json as content, ',
'    ''transcription_'' || nome_arquivo || ''.json'' as filename, ',
'    ''application/json'' as mime_type ',
'from videos ',
'where id = :P130_ID',
''))
,p_attribute_06=>'P130_ID'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8839470146878222)
,p_name=>'Click'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8839324454878221)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8839585678878223)
,p_event_id=>wwv_flow_imp.id(8839470146878222)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COPY.TO.CLIPBOARD.APEX'
,p_attribute_01=>'P130_TRANSCRICAO'
,p_attribute_02=>'Copied to Clipboard!'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8838305071878211)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from videos where id = :P130_ID;',
'    commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(8808483623194955)
,p_internal_uid=>8838305071878211
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8838232420878210)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetTranscricao'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  v_json         CLOB;',
'  v_result       CLOB := '''';',
'  v_current_speaker NUMBER := NULL;',
'  v_text         CLOB := '''';',
'  v_start        NUMBER := NULL;',
'  v_end          NUMBER := NULL;',
'',
unistr('  -- Fun\00E7\00E3o para converter "18.624s" em 18.624 com seguran\00E7a'),
'  FUNCTION safe_to_number(p_text VARCHAR2) RETURN NUMBER IS',
'  BEGIN',
'    RETURN TO_NUMBER(REPLACE(TRIM(p_text), ''s'', ''''));',
'  EXCEPTION',
'    WHEN OTHERS THEN',
'      RETURN 0;',
'  END;',
'',
'  -- Procedure para salvar um bloco no resultado',
'  PROCEDURE flush_block IS',
'  BEGIN',
'    IF v_text IS NOT NULL THEN',
'      v_result := v_result || ',
'        ''Speaker '' || v_current_speaker || '' ['' ||',
'        TO_CHAR(v_start, ''FM9990.000'') || ''s - '' ||',
'        TO_CHAR(v_end, ''FM9990.000'') || ''s]: '' ||',
'        v_text || CHR(10);',
'    END IF;',
'  END;',
'',
'BEGIN',
'EXECUTE IMMEDIATE ''ALTER SESSION SET NLS_NUMERIC_CHARACTERS = ''''. '''''';',
'',
'  -- Buscar o JSON da tabela',
'  SELECT transc_json',
'  INTO v_json',
'  FROM videos',
'  WHERE id = :P130_ID;',
'',
'  -- Loop direto sobre o JSON_TABLE',
'  FOR r IN (',
'    SELECT *',
'    FROM JSON_TABLE(',
'      v_json,',
'      ''$.transcriptions[0].tokens[*]''',
'      COLUMNS (',
'        token         VARCHAR2(100) PATH ''$.token'',',
'        start_time    VARCHAR2(20)  PATH ''$.startTime'',',
'        end_time      VARCHAR2(20)  PATH ''$.endTime'',',
'        speaker_index NUMBER        PATH ''$.speakerIndex''',
'      )',
'    )',
'  ) LOOP',
'    DECLARE',
'      start_num NUMBER := safe_to_number(r.start_time);',
'      end_num   NUMBER := safe_to_number(r.end_time);',
'    BEGIN',
'      IF v_current_speaker IS NULL OR r.speaker_index != v_current_speaker THEN',
'        flush_block;',
'        v_current_speaker := r.speaker_index;',
'        v_text := r.token;',
'        v_start := start_num;',
'        v_end := end_num;',
'      ELSE',
'        v_text := v_text || '' '' || r.token;',
'        v_end := GREATEST(v_end, end_num);',
'      END IF;',
'    END;',
'  END LOOP;',
'',
'  flush_block;',
'',
unistr('  -- Impress\00E3o do resultado em :P130_TRANSCRICAO'),
'  DECLARE',
'    v_offset NUMBER := 1;',
'    v_chunk  VARCHAR2(32767);',
'    v_full_output CLOB := EMPTY_CLOB();',
'  BEGIN',
'    DBMS_LOB.CREATETEMPORARY(v_full_output, TRUE);',
'',
'    WHILE v_offset <= DBMS_LOB.GETLENGTH(v_result) LOOP',
'      v_chunk := DBMS_LOB.SUBSTR(v_result, 32767, v_offset);',
'      DBMS_LOB.WRITEAPPEND(v_full_output, LENGTH(v_chunk), v_chunk);',
'      v_offset := v_offset + 32767;',
'    END LOOP;',
':P130_TRANSCRICAO := v_full_output;',
'--DBMS_OUTPUT.PUT_LINE(v_full_output);',
'  END;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>8838232420878210
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8810033554194948)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(8800257672195016)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Detalhes Video'
,p_internal_uid=>8810033554194948
);
wwv_flow_imp.component_end;
end;
/
