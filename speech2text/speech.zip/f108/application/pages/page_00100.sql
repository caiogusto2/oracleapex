prompt --application/pages/page_00100
begin
--   Manifest
--     PAGE: 00100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>8276771796044321
,p_default_application_id=>108
,p_default_id_offset=>8277989379040266
,p_default_owner=>'DEMO'
);
wwv_flow_imp_page.create_page(
 p_id=>100
,p_name=>'Home'
,p_alias=>'HOME1'
,p_step_title=>'Home'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'@media only screen and (-webkit-min-device-pixel-ratio: 1.25), only screen and (-webkit-min-device-pixel-ratio: 1.3), only screen and (min-resolution: 120dpi) {',
'    .rw-pillar--rose .t-Body-title:after, .rw-pillar--rose.rw-layout--fixed .t-Body-mainContent:before',
'Specificity: (0,3,1)',
' {',
'        background-image: none;',
'    }',
'}',
'',
'.rw-pillar--rose .t-Body-title:after, .rw-pillar--rose.rw-layout--fixed .t-Body-mainContent:before {',
'    background-image: none;',
'}',
'.t-Body-title:after {',
'    background-color: rgb(217, 0, 0);',
'//    background-repeat: repeat-x;',
'//    background-size: auto 100%;',
'//    content: "";',
'//    display: block;',
'//    height: var(--ut-body-title-border-width);',
'//    left: 0;',
'//    position: absolute;',
'//    right: 0;',
'//    top: 100%;',
'}',
'',
'@media (min-width: 640px) {',
'    .rw-layout--fixed:not(.rw-layout--edge-to-edge):not(.rw-layout--contained):not(.rw-layout--foldout) .t-Body-mainContent:before {',
'        background-color: rgb(217, 0, 0);',
'//        background-repeat: repeat-x;',
'//        background-size: auto 100%;',
'//        border-top-left-radius: .3125rem;',
'//        border-top-right-radius: .3125rem;',
'//        content: "";',
'//        display: block;',
'//        height: var(--ut-body-title-border-width);',
'//        left: 0;',
'//        overflow: hidden;',
'//        position: absolute;',
'//        right: 0;',
'//        top: 0;',
'    }',
'}',
'',
'',
'.a-Button--hot, .a-CardView-button--hot, .apex-button-group input:checked+label, .t-Button--hot, .t-Form-fieldContainer--radioButtonGroup .apex-item-group--rc input:checked+label, .ui-button--hot {',
'    --a-button-background-color: rgb(217, 0, 0);',
'    --a-button-text-color: white;',
'    --a-button-hover-background-color: rgb(217, 0, 0);',
'    --a-button-hover-text-color: white;',
'    --a-button-hover-border-color: rgb(217, 0, 0);',
'    --a-button-active-background-color: white;',
'    --a-button-active-text-color: rgb(217, 0, 0);',
'    --a-button-active-border-color: white;',
'    --a-button-focus-background-color: rgb(217, 0, 0);',
'    --a-button-focus-text-color: white;',
'    --a-button-focus-border-color: rgb(217, 0, 0);',
'}',
'',
'.floatlogoff {',
'  z-index: 100;',
'  position: absolute;',
'  top: 10px;  /* Position from the top */',
'  right: 10px; /* Position from the right */',
'  width: auto; /* Adjust width as needed */',
'  height: auto; /* Adjust height as needed */',
'  padding: 10px 20px; /* Add padding for better spacing */',
'  color: black;',
'  text-align: center;',
'  border-radius: 5px; /* Optional: Slightly rounded corners */',
'  /* background-color: black;  Removed */',
'  /* box-shadow: 2px 2px 3px #999;  Removed */',
'}',
'',
'.my-floatlogoff {',
'  margin-top: 0; /* Remove unnecessary margin */',
'}',
'',
'.t-HeroRegion-title {',
'    color: black;    ',
'}'))
,p_step_template=>2979075366320325194
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8694481783303139)
,p_plug_name=>unistr('Consulta Transcri\00E7\00F5es')
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--featured'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8751782004882264)
,p_plug_name=>'Search Results'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       NOME_ARQUIVO,',
'       MIME_TYPE,',
'       CREATED_AT,',
'       QUEM_FEZ_UPLOAD,',
'       TAMANHO_ARQUIVO,',
'       TRANSC_JOBID,',
'       TRANSC_OCIID,',
'       VIDEO,',
'       TRANSC_JSON',
'  from VIDEOS',
'  where quem_fez_upload = GET_APEX_APP_USER();'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(8839646519878224)
,p_max_row_count=>'1000000'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:130:&SESSION.::&DEBUG.::P130_ID:#ID#'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_owner=>'DEMO'
,p_internal_uid=>8839646519878224
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8839721701878225)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8839862203878226)
,p_db_column_name=>'NOME_ARQUIVO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Nome Arquivo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8839905626878227)
,p_db_column_name=>'MIME_TYPE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Mime Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8840054913878228)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Data Upload'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8840198885878229)
,p_db_column_name=>'QUEM_FEZ_UPLOAD'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Quem Fez Upload'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8840220928878230)
,p_db_column_name=>'TAMANHO_ARQUIVO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Tamanho Arquivo'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8840338136878231)
,p_db_column_name=>'TRANSC_JOBID'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Transc Jobid'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8840462461878232)
,p_db_column_name=>'TRANSC_OCIID'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Transc Ociid'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8840598005878233)
,p_db_column_name=>'VIDEO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Video'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_heading_alignment=>'LEFT'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8840633260878234)
,p_db_column_name=>'TRANSC_JSON'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Transc Json'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_heading_alignment=>'LEFT'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(8880919516900675)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'88810'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NOME_ARQUIVO:CREATED_AT:QUEM_FEZ_UPLOAD:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8752697764882243)
,p_plug_name=>'Button Bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>'<div id="active_facets"></div>'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8892093435822519)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(8694481783303139)
,p_button_name=>'Logoff'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Logoff'
,p_button_redirect_url=>'&LOGOUT_URL.'
,p_button_css_classes=>'floatlogoff my-floatlogoff'
,p_icon_css_classes=>'fa-sign-out'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8753130528882237)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(8752697764882243)
,p_button_name=>'RESET'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Reset'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&APP_SESSION.::&DEBUG.:RR,100::'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8691219359303107)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(8752697764882243)
,p_button_name=>'UploadArquivo'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Upload Arquivo'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-cloud-arrow-up'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8694173540303136)
,p_name=>'Refresh'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8691219359303107)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8694210708303137)
,p_event_id=>wwv_flow_imp.id(8694173540303136)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8751782004882264)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
