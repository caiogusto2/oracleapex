prompt --application/shared_components/user_interface/theme_style
begin
--   Manifest
--     THEME STYLE: 108
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>8276771796044321
,p_default_application_id=>108
,p_default_id_offset=>8277989379040266
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(8317777907561110)
,p_theme_id=>42
,p_name=>'MPSP'
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/oracle-fonts/oraclesans-apex#MIN#.css?v=#APEX_VERSION#',
'#THEME_FILES#css/Redwood#MIN#.css?v=#APEX_VERSION#'))
,p_css_classes=>' rw-pillar--rose rw-layout--fixed t-PageBody--scrollTitle rw-mode-nav--dark rw-mode-body--light rw-mode-header--light rw-mode-body-header--light'
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Redwood-Theme.less'
,p_theme_roller_config=>'{"classes":["rw-pillar--rose","rw-layout--fixed t-PageBody--scrollTitle","rw-layout--fixed t-PageBody--scrollTitle","rw-mode-nav--dark","rw-mode-body--light","rw-mode-header--light","rw-mode-body-header--light"],"vars":{},"customCSS":"","useCustomLes'
||'s":"N"}'
,p_theme_roller_output_file_url=>'#THEME_DB_FILES#8317777907561110.css'
,p_theme_roller_read_only=>false
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(34852867728302336)
,p_theme_id=>42
,p_name=>'dataprev'
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/oracle-fonts/oraclesans-apex#MIN#.css?v=#APEX_VERSION#',
'#THEME_FILES#css/Redwood#MIN#.css?v=#APEX_VERSION#'))
,p_css_classes=>' rw-pillar--pebble rw-layout--fixed t-PageBody--scrollTitle rw-mode-header--dark rw-mode-nav--dark rw-mode-body-header--dark rw-mode-body--dark'
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Redwood-Theme.less'
,p_theme_roller_config=>'{"classes":["rw-pillar--pebble","rw-layout--fixed t-PageBody--scrollTitle","rw-mode-header--dark","rw-mode-nav--dark","rw-mode-body-header--dark","rw-mode-body--dark"],"vars":{},"customCSS":"","useCustomLess":"N"}'
,p_theme_roller_output_file_url=>'#THEME_DB_FILES#11500633450724331.css'
,p_theme_roller_read_only=>false
);
wwv_flow_imp.component_end;
end;
/
