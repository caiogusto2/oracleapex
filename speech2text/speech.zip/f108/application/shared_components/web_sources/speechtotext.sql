prompt --application/shared_components/web_sources/speechtotext
begin
--   Manifest
--     WEB SOURCE: SpeechToText
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>8276771796044321
,p_default_application_id=>108
,p_default_id_offset=>8277989379040266
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(8285333784818819)
,p_name=>'SpeechToText'
,p_static_id=>'speechtotext'
,p_web_source_type=>'NATIVE_OCI'
,p_data_profile_id=>wwv_flow_imp.id(8284262480818842)
,p_remote_server_id=>wwv_flow_imp.id(8284086193818846)
,p_url_path_prefix=>'/20220101/transcriptionJobs'
,p_credential_id=>wwv_flow_imp.id(8283562764841269)
,p_version_scn=>44713524702393
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(8285959382818804)
,p_web_src_module_id=>wwv_flow_imp.id(8285333784818819)
,p_operation=>'POST'
,p_url_pattern=>'.'
,p_request_body_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'    "compartmentId": "ocid1.compartment.oc1..aaaaaaaaphu7klxfxmx4rg2oo7yg6sbgbr6qguclbrjqhyxznqqajof4iiyq",',
'    "inputLocation": {',
'      "locationType": "OBJECT_LIST_INLINE_INPUT_LOCATION",',
'      "objectLocations": [{',
'        "namespaceName": "idi1o0a010nx",',
'        "bucketName": "bucket-MPSP-Video",',
'        "objectNames": ["#MESSAGE#"]',
'      }]',
'    },',
'    "outputLocation": {',
'      "namespaceName": "idi1o0a010nx",',
'      "bucketName": "bucket-MPSP-Video-Output"',
'    },',
'    "modelDetails":',
'    {',
'        "domain":"GENERIC",',
'        "languageCode":"pt-BR",',
'        "modelType":"ORACLE",',
'        "transcriptionSettings": {',
'            "diarization":{',
'                "isDiarizationEnabled": true',
'            }',
'        }',
'    }',
'  }'))
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(8287899576788969)
,p_web_src_module_id=>wwv_flow_imp.id(8285333784818819)
,p_web_src_operation_id=>wwv_flow_imp.id(8285959382818804)
,p_name=>'Content-Type'
,p_param_type=>'HEADER'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value=>'application/json'
,p_is_static=>true
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(8288232134786527)
,p_web_src_module_id=>wwv_flow_imp.id(8285333784818819)
,p_web_src_operation_id=>wwv_flow_imp.id(8285959382818804)
,p_name=>'MESSAGE'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(8288644051784797)
,p_web_src_module_id=>wwv_flow_imp.id(8285333784818819)
,p_web_src_operation_id=>wwv_flow_imp.id(8285959382818804)
,p_name=>'RESPONSE'
,p_param_type=>'BODY'
,p_is_required=>false
,p_direction=>'OUT'
);
wwv_flow_imp.component_end;
end;
/
