prompt --application/shared_components/navigation/lists/upload_video
begin
--   Manifest
--     LIST: Upload_Video
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>8276771796044321
,p_default_application_id=>108
,p_default_id_offset=>8277989379040266
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(8755155925863788)
,p_name=>'Upload_Video'
,p_list_status=>'PUBLIC'
,p_version_scn=>44727422047909
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(8756566947863777)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Selecione seu Arquivo'
,p_list_item_link_target=>'f?p=&APP_ID.:110:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(8760810646863737)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('Revis\00E3o Final')
,p_list_item_link_target=>'f?p=&APP_ID.:120:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
