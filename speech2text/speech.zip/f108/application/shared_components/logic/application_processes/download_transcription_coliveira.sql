prompt --application/shared_components/logic/application_processes/download_transcription_coliveira
begin
--   Manifest
--     APPLICATION PROCESS: DOWNLOAD_TRANSCRIPTION_COLIVEIRA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>8276771796044321
,p_default_application_id=>108
,p_default_id_offset=>8277989379040266
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(8708716678171613)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DOWNLOAD_TRANSCRIPTION_COLIVEIRA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  l_url         VARCHAR2(4000) := ''https://speech.aiservice.sa-saopaulo-1.oci.oraclecloud.com'';',
'  l_response    CLOB;',
'  l_json        JSON_OBJECT_T;',
'  l_status      VARCHAR2(100);',
'  l_ocid        VARCHAR2(4000);',
'  l_file        BLOB;',
'  l_mime_type   VARCHAR2(100);',
'  l_clob        CLOB;',
'  l_dest_offset INTEGER := 1;',
'  l_src_offset  INTEGER := 1;',
'  l_lang_ctx    NUMBER := DBMS_LOB.default_lang_ctx;',
'  l_warning     INTEGER;',
'BEGIN',
'  -- Get OCI Job ID from table',
'  SELECT OCI_ID INTO l_ocid FROM CONTROLE_UPLOAD WHERE NOME_ARQUIVO = :APP_OBJECT_NAME;',
'',
'  -- Set headers',
'  apex_web_service.g_request_headers(1).name  := ''Content-Type'';',
'  apex_web_service.g_request_headers(1).value := ''application/json'';',
'',
'  -- Call REST API',
'  l_response := APEX_WEB_SERVICE.MAKE_REST_REQUEST(',
'    p_url                  => l_url || ''/20220101/transcriptionJobs/'' || l_ocid,',
'    p_http_method          => ''GET'',',
'    p_credential_static_id => ''oci''',
'  );',
'',
'  -- Parse response',
'  l_json := JSON_OBJECT_T.parse(l_response);',
'  l_status := l_json.get_string(''lifecycleState'');',
'',
'  -- Mostrar status',
'  :COLIVEIRA := ''Status: '' || l_status;',
'',
'  IF l_status <> ''SUCCEEDED'' THEN',
unistr('    RAISE_APPLICATION_ERROR(-20001, ''Arquivo ainda n\00E3o dispon\00EDvel, aguarde alguns minutos'');'),
'    RETURN;',
'  ELSE',
'    -- Download object',
'    l_file := dbms_cloud.get_object(',
'      credential_name => :CREDENTIAL_NAME,',
'      object_uri      => ''https://objectstorage.sa-saopaulo-1.oraclecloud.com/n/idi1o0a010nx/b/bucket-MPSP-Video-Output/o/'' || :JOB_ID || ''%2Fidi1o0a010nx_bucket-MPSP-Video_'' || :APP_OBJECT_NAME || ''.json'');',
'',
'    -- Convert BLOB to CLOB',
'--    DBMS_LOB.createtemporary(l_clob, TRUE);',
'--    DBMS_LOB.convertToCLOB(',
'--      dest_lob     => l_clob,',
'--      src_blob     => l_file,',
'--      amount       => DBMS_LOB.lobmaxsize,',
'--      dest_offset  => l_dest_offset,',
'--      src_offset   => l_src_offset,',
'--      blob_csid    => DBMS_LOB.default_csid,',
'--      lang_context => l_lang_ctx,',
'--      warning      => l_warning',
'--    );',
'',
'    -- Atualiza a coluna JSON na tabela',
'    UPDATE CONTROLE_UPLOAD',
'       SET JSON_DATA = l_file',
'     WHERE NOME_ARQUIVO = :APP_OBJECT_NAME;',
'',
'    COMMIT;',
'',
'  END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>unistr('Arquivo ainda n\00E3o dispon\00EDvel, aguarde alguns minutos')
,p_process_when_type=>'USER_IS_NOT_PUBLIC_USER'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>44724496939747
);
wwv_flow_imp.component_end;
end;
/
