prompt --application/plugin_settings
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>8276771796044321
,p_default_application_id=>108
,p_default_id_offset=>8277989379040266
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(8279249090039880)
,p_plugin_type=>'WEB SOURCE TYPE'
,p_plugin=>'NATIVE_BOSS'
,p_version_scn=>44709299997886
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(34492233374969136)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'include_slider', 'Y')).to_clob
,p_version_scn=>44322277195323
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(34492530414969141)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_SELECT_MANY'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_values_as', 'separated')).to_clob
,p_version_scn=>44322277195327
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(34492760898969142)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_SINGLE_CHECKBOX'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', 'Y',
  'unchecked_value', 'N')).to_clob
,p_version_scn=>44322277195327
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(34493066679969143)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_MAP_REGION'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_vector_tile_layers', 'Y')).to_clob
,p_version_scn=>44322277195327
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(34493397862969144)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_IR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'actions_menu_structure', 'IG')).to_clob
,p_version_scn=>44322277195327
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(34493686684969145)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_YES_NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_style', 'SWITCH_CB',
  'off_value', 'N',
  'on_value', 'Y')).to_clob
,p_version_scn=>44322277195327
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(34493998998969146)
,p_plugin_type=>'DYNAMIC ACTION'
,p_plugin=>'NATIVE_OPEN_AI_ASSISTANT'
,p_version_scn=>44322277195327
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(34494301420969146)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_STAR_RATING'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'default_icon', 'fa-star',
  'tooltip', '#VALUE#')).to_clob
,p_version_scn=>44322277195327
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(34494594931969147)
,p_plugin_type=>'PROCESS TYPE'
,p_plugin=>'NATIVE_GEOCODING'
,p_attribute_01=>'RELAX_HOUSE_NUMBER'
,p_version_scn=>44322277195327
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(34494875375969148)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_GEOCODED_ADDRESS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'background', 'default',
  'display_as', 'LIST',
  'map_preview', 'POPUP:ITEM',
  'match_mode', 'RELAX_HOUSE_NUMBER',
  'show_coordinates', 'N')).to_clob
,p_version_scn=>44322277195328
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(34495197331969149)
,p_plugin_type=>'WEB SOURCE TYPE'
,p_plugin=>'NATIVE_ADFBC'
,p_version_scn=>44322277195328
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(34495498251969150)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_COLOR_PICKER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'mode', 'FULL')).to_clob
,p_version_scn=>44322277195328
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(34495796177969151)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_DATE_PICKER_APEX'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'appearance_behavior', 'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON',
  'days_outside_month', 'VISIBLE',
  'show_on', 'FOCUS',
  'time_increment', '15')).to_clob
,p_version_scn=>44322277195328
);
wwv_flow_imp.component_end;
end;
/
