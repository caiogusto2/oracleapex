prompt --application/user_interfaces/combined_files
begin
--   Manifest
--     COMBINED FILES: 108
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>8276771796044321
,p_default_application_id=>108
,p_default_id_offset=>8277989379040266
,p_default_owner=>'DEMO'
);
null;
wwv_flow_imp.component_end;
end;
/
