prompt --workspace/remote_servers/speech_aiservice_sa_saopaulo_1_oci_oraclecloud_com
begin
--   Manifest
--     REMOTE SERVER: speech-aiservice-sa-saopaulo-1-oci-oraclecloud-com
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>8276771796044321
,p_default_application_id=>108
,p_default_id_offset=>8277989379040266
,p_default_owner=>'DEMO'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(8284086193818846)
,p_name=>'speech-aiservice-sa-saopaulo-1-oci-oraclecloud-com'
,p_static_id=>'speech_aiservice_sa_saopaulo_1_oci_oraclecloud_com'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('speech_aiservice_sa_saopaulo_1_oci_oraclecloud_com'),'https://speech.aiservice.sa-saopaulo-1.oci.oraclecloud.com')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('speech_aiservice_sa_saopaulo_1_oci_oraclecloud_com'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('speech_aiservice_sa_saopaulo_1_oci_oraclecloud_com'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('speech_aiservice_sa_saopaulo_1_oci_oraclecloud_com'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('speech_aiservice_sa_saopaulo_1_oci_oraclecloud_com'),'')
,p_prompt_on_install=>false
,p_ai_is_builder_service=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('speech_aiservice_sa_saopaulo_1_oci_oraclecloud_com'),'')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('speech_aiservice_sa_saopaulo_1_oci_oraclecloud_com'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('speech_aiservice_sa_saopaulo_1_oci_oraclecloud_com'),'')
);
wwv_flow_imp.component_end;
end;
/
