prompt --application/shared_components/navigation/lists/doc_upload
begin
--   Manifest
--     LIST: Doc Upload
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>7714649592973093
,p_default_application_id=>100
,p_default_id_offset=>7914225024987764
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(43352741416353926)
,p_name=>'Doc Upload'
,p_list_status=>'PUBLIC'
,p_version_scn=>44734768489412
);
wwv_flow_imp.component_end;
end;
/
