prompt --application/pages/page_00120
begin
--   Manifest
--     PAGE: 00120
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>7714649592973093
,p_default_application_id=>100
,p_default_id_offset=>7914225024987764
,p_default_owner=>'DEMO'
);
wwv_flow_imp_page.create_page(
 p_id=>120
,p_name=>unistr('Revis\00E3o Final')
,p_alias=>unistr('REVIS\00C3O-FINAL')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Revis\00E3o Final')
,p_autocomplete_on_off=>'OFF'
,p_step_template=>1661186590416509825
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_height=>'400'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16607006699290886)
,p_plug_name=>'Mensagem'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>50
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<h4>Revis\00E3o e Comunicado antes do Upload</h4>'),
'<br>',
'<ul>',
'    <li>O registro de timestamp foi adicionado ao nome do arquivo.</li>',
unistr('    <li>O arquivo ser\00E1 enviado com o novo nome <strong>&P120_FILENAME.</strong></li>'),
'</ul>',
'<br>',
'<p>',
'    Caso seja feito o upload do arquivo errado, delete o mesmo e realize o procedimento de upload novamente.',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16674540940851502)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(16669380950851552)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>2010149141494510257
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16674683305851502)
,p_plug_name=>unistr('Revis\00E3o Final')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16674741942851502)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16676263459851494)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(16674741942851502)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancelar'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16676378010851494)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(16674741942851502)
,p_button_name=>'FINISH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Fazer Upload'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16676489948851494)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(16674741942851502)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Voltar'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(16678199390851488)
,p_branch_action=>'f?p=&APP_ID.:110:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(16676489948851494)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16606792293290884)
,p_name=>'P120_FILENAME'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16607326633290890)
,p_name=>'P120_FILENAMESEMEDICAO'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16607981776290896)
,p_name=>'P120_OUTPUT_API'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(16606907847290885)
,p_computation_sequence=>10
,p_computation_item=>'P120_FILENAME'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>'SELECT TO_CHAR(CURRENT_TIMESTAMP, ''DDMMYYYYHH24MI'') || ''_'' || REGEXP_SUBSTR(:P120_FILENAMESEMEDICAO, ''[^/]+$'', 1, 1)  FROM DUAL;'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(16676719619851494)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(16676263459851494)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16677481080851491)
,p_event_id=>wwv_flow_imp.id(16676719619851494)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(16607101977290887)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Execution_Chain'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(16676378010851494)
,p_internal_uid=>8692876952303123
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(16679011359851484)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>8764786334863720
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(16607181342290888)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(16607101977290887)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DOC_UPLOAD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for rec in (',
'        select * from apex_application_temp_files',
'        where name = :P120_FILENAMESEMEDICAO',
'  ) ',
'  loop',
'      dbms_cloud.put_object (',
'        credential_name => :CREDENTIAL_NAME,',
'        object_uri      => :LOCATION_URI || :P120_FILENAME,',
'        contents        => rec.blob_content);',
'  end loop;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>8692956317303124
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(16697407760568487)
,p_process_sequence=>30
,p_parent_process_id=>wwv_flow_imp.id(16607101977290887)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'API_SpeechToText'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(16199558809806583)
,p_web_src_operation_id=>wwv_flow_imp.id(16200184407806568)
,p_attribute_01=>'WEB_SOURCE'
,p_internal_uid=>8783182735580723
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(16697768248568482)
,p_page_id=>120
,p_web_src_param_id=>wwv_flow_imp.id(16202457159774291)
,p_page_process_id=>wwv_flow_imp.id(16697407760568487)
,p_value_type=>'ITEM'
,p_value=>'P120_FILENAME'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(16698266135568479)
,p_page_id=>120
,p_web_src_param_id=>wwv_flow_imp.id(16202869076772561)
,p_page_process_id=>wwv_flow_imp.id(16697407760568487)
,p_value_type=>'ITEM'
,p_value=>'P120_OUTPUT_API'
,p_ignore_output=>false
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(16608094168290897)
,p_process_sequence=>40
,p_parent_process_id=>wwv_flow_imp.id(16607101977290887)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Wait Job'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  l_json_id       VARCHAR2(32767) := :P120_OUTPUT_API;',
'  l_text_editado  VARCHAR2(4000);',
'  l_url           VARCHAR2(4000) := ''https://speech.aiservice.sa-saopaulo-1.oci.oraclecloud.com'';',
'  l_response      CLOB;',
'  l_json          JSON_OBJECT_T;',
'  l_status        VARCHAR2(100);',
'BEGIN',
'  -- Extract the text from the JSON ID (assuming :P120_OUTPUT_API is correctly set)',
'  SELECT jt.text',
'    INTO l_text_editado',
'    FROM dual,',
'         JSON_TABLE(',
'             l_json_id,',
'             ''$'' COLUMNS (',
'                 text VARCHAR2(4000) PATH ''$.id''',
'             )',
'         ) jt;',
'',
'  -- Set headers',
'  apex_web_service.g_request_headers(1).name  := ''Content-Type'';',
'  apex_web_service.g_request_headers(1).value := ''application/json'';',
'',
'  -- Call REST API',
'  LOOP',
'    l_response := APEX_WEB_SERVICE.MAKE_REST_REQUEST(',
'      p_url                  => l_url || ''/20220101/transcriptionJobs/'' || l_text_editado,',
'      p_http_method          => ''GET'',',
'      p_credential_static_id => ''oci''',
'    );',
'',
'    -- Parse response',
'    l_json := JSON_OBJECT_T.parse(l_response);',
'    l_status := l_json.get_string(''lifecycleState'');',
'',
'    IF l_status = ''SUCCEEDED'' THEN',
'      -- Handle successful response',
'      -- Optionally, you can break out of the loop here if no further looping is needed',
'      EXIT;',
'    ELSE',
'      -- Optionally handle cases where l_status is not ''SUCCEEDED''',
'      -- You may want to log or handle errors here',
'      -- Add retry logic or appropriate error handling based on API requirements',
'      -- For simplicity, I''m not including detailed error handling here',
'      DBMS_LOCK.SLEEP(30);',
'      NULL;',
'    END IF;',
'  END LOOP;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>8693869143303133
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(16608134870290898)
,p_process_sequence=>50
,p_parent_process_id=>wwv_flow_imp.id(16607101977290887)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DML Process'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_mime_type     varchar2(200);',
'    l_created       date;',
'    l_blob_content  blob;',
'    ',
'    l_quem          varchar2(200);',
'',
'    l_json_id       VARCHAR2(32767) := :P120_OUTPUT_API;',
'    l_ociid         VARCHAR2(4000);',
'    ',
'    l_jobid         varchar2(4000);',
'',
'    l_file          BLOB;    ',
'',
'begin',
unistr('    --trazer informa\00E7\00F5es do temp_files'),
'    select mime_type, created_on, blob_content into l_mime_type, l_created, l_blob_content from apex_application_temp_files where NAME = :P120_FILENAMESEMEDICAO;',
'',
'    -- trazer quem fez o upload',
'    select GET_APEX_APP_USER() into l_quem from dual;',
'',
unistr('    -- trazer informa\00E7\00F5es do json - ocid'),
'  SELECT jt.text',
'    INTO l_ociid',
'    FROM dual,',
'         JSON_TABLE(',
'             l_json_id,',
'             ''$'' COLUMNS (',
'                 text VARCHAR2(4000) PATH ''$.id''',
'             )',
'         ) jt;',
'     ',
unistr('    -- trazer informa\00E7\00F5es do json - pasta output'),
'    SELECT REPLACE(jt.text, ''/'', '''')',
'    INTO l_jobid',
'    FROM dual,',
'         JSON_TABLE(',
'             l_json_id,',
'             ''$.outputLocation'' COLUMNS (',
'                 text VARCHAR2(4000) PATH ''$.prefix''',
'             )',
'         ) jt;',
'',
unistr('    -- download transcri\00E7\00E3o'),
'    l_file := dbms_cloud.get_object(',
'    credential_name => :CREDENTIAL_NAME,',
'    object_uri      => :LOCATION_URI_OUTPUT || l_jobid || ''%2F'' || :NAMESPACE || ''_'' || :NOME_BUCKET_INPUT || ''_'' || :P120_FILENAME || ''.json'');',
'',
'    -- realizar dml',
'    insert into videos (',
'        nome_arquivo, ',
'        mime_type, ',
'        created_at,',
'        video, ',
'        quem_fez_upload, ',
'        tamanho_arquivo, ',
'        transc_jobid, ',
'        transc_ociid,',
'        transc_json',
'        ) values',
'        (',
'            :P120_FILENAME,',
'            l_mime_type,',
'            l_created,',
'            l_blob_content,',
'            l_quem,',
'            DBMS_LOB.GETLENGTH(l_blob_content),',
'            l_jobid,',
'            l_ociid,',
'            l_file',
'        );',
'        commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>8693909845303134
);
wwv_flow_imp.component_end;
end;
/
