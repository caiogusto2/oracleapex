prompt --workspace/credentials/oci
begin
--   Manifest
--     CREDENTIAL: OCI
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>7714649592973093
,p_default_application_id=>100
,p_default_id_offset=>7914225024987764
,p_default_owner=>'DEMO'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(16197787789829033)
,p_name=>'OCI'
,p_static_id=>'oci'
,p_authentication_type=>'OCI'
,p_namespace=>'ocid1.tenancy.oc1..aaaaaaaaoi6b5sxlv4z773boczybqz3h2vspvvru42jysvizl77lky22ijaq'
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
