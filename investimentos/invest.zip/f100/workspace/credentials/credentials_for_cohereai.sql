prompt --workspace/credentials/credentials_for_cohereai
begin
--   Manifest
--     CREDENTIAL: Credentials for cohereai
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>10979034347205586
,p_default_application_id=>100
,p_default_id_offset=>7563027525787247
,p_default_owner=>'PERSONAL'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(9162193275133871)
,p_name=>'Credentials for cohereai'
,p_static_id=>'credentials_for_cohereai'
,p_authentication_type=>'HTTP_HEADER'
,p_valid_for_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://api.cohere.ai/v1',
''))
,p_prompt_on_install=>true
);
wwv_flow_imp.component_end;
end;
/
