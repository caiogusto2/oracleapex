prompt --workspace/credentials/idcs_web_credentials
begin
--   Manifest
--     CREDENTIAL: IDCS Web Credentials
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>10979034347205586
,p_default_application_id=>100
,p_default_id_offset=>7563027525787247
,p_default_owner=>'PERSONAL'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(50162143916261545)
,p_name=>'IDCS Web Credentials'
,p_static_id=>'idcs_web_credentials'
,p_authentication_type=>'BASIC'
,p_prompt_on_install=>true
);
wwv_flow_imp.component_end;
end;
/
