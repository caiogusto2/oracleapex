prompt --workspace/remote_servers/cohereai
begin
--   Manifest
--     REMOTE SERVER: CohereAI
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>10979034347205586
,p_default_application_id=>100
,p_default_id_offset=>7563027525787247
,p_default_owner=>'PERSONAL'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(9162467751133879)
,p_name=>'CohereAI'
,p_static_id=>'Cohere'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('Cohere'),'https://api.cohere.ai/v1')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('Cohere'),'')
,p_server_type=>'GENERATIVE_AI'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('Cohere'),'')
,p_credential_id=>wwv_flow_imp.id(9162193275133871)
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('Cohere'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('Cohere'),'')
,p_prompt_on_install=>true
,p_ai_provider_type=>'COHERE'
,p_ai_is_builder_service=>true
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('Cohere'),'')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('Cohere'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('Cohere'),'')
);
wwv_flow_imp.component_end;
end;
/
