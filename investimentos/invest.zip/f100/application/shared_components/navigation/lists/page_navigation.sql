prompt --application/shared_components/navigation/lists/page_navigation
begin
--   Manifest
--     LIST: Page Navigation
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>10979034347205586
,p_default_application_id=>100
,p_default_id_offset=>7563027525787247
,p_default_owner=>'PERSONAL'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(18909835103121387)
,p_name=>'Page Navigation'
,p_list_status=>'PUBLIC'
,p_version_scn=>39550156164859
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(18910257388121387)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Dashboard CDBs'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-dashboard'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(9051770016919580)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Lista CDBs'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(61671200724695690)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Grupos e Empresas'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-building-o'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(17370301418562258)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>unistr('Simulador CDB Pr\00E9')
,p_list_item_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-lightbulb-o'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(18383070107651235)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Monitoramento Carteira'
,p_list_item_link_target=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-desktop'
,p_security_scheme=>wwv_flow_imp.id(55362192641686762)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(9965128508734067)
,p_list_item_display_sequence=>1000
,p_list_item_link_text=>unistr('Administra\00E7\00E3o')
,p_list_item_link_target=>'f?p=&APP_ID.:10000:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-id-card'
,p_security_scheme=>wwv_flow_imp.id(55368053991614197)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
