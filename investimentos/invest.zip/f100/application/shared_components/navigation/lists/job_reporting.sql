prompt --application/shared_components/navigation/lists/job_reporting
begin
--   Manifest
--     LIST: Job Reporting
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>10979034347205586
,p_default_application_id=>100
,p_default_id_offset=>7563027525787247
,p_default_owner=>'PERSONAL'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(9962390271702765)
,p_name=>'Job Reporting'
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_imp.id(9894894388702693)
,p_version_scn=>39534443659352
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(9962763555702766)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Job Reporting'
,p_list_item_link_target=>'f?p=&APP_ID.:10030:&APP_SESSION.::&DEBUG.:10030::'
,p_list_item_icon=>'fa-user-chart'
,p_list_text_01=>'View status and run details of jobs supporting this application'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
