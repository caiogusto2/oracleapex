prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>10979034347205586
,p_default_application_id=>100
,p_default_id_offset=>7563027525787247
,p_default_owner=>'PERSONAL'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(9762203180663988)
,p_build_option_name=>'Feature: Access Control'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>39534443271699
,p_feature_identifier=>'APPLICATION_ACCESS_CONTROL'
,p_build_option_comment=>'Incorporate role based user authentication within your application and manage username mappings to application roles.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(9807717915692042)
,p_build_option_name=>'Feature: Activity Reporting'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>39534443564398
,p_feature_identifier=>'APPLICATION_ACTIVITY_REPORTING'
,p_build_option_comment=>'Include numerous reports and charts on end user activity.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(9894894388702693)
,p_build_option_name=>'Feature: Job Reporting'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>39534443658523
,p_feature_identifier=>'APPLICATION_JOB_REPORTING'
,p_build_option_comment=>'Includes a report on database jobs, with the ability to drill down on a specific job to see additional details.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(18552896725120762)
,p_build_option_name=>'Commented Out'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>41644280139784
);
wwv_flow_imp.component_end;
end;
/
