prompt --application/shared_components/logic/application_computations/investidor
begin
--   Manifest
--     APPLICATION COMPUTATION: INVESTIDOR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>10979034347205586
,p_default_application_id=>100
,p_default_id_offset=>7563027525787247
,p_default_owner=>'PERSONAL'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(10309100864368743)
,p_computation_sequence=>10
,p_computation_item=>'INVESTIDOR'
,p_computation_point=>'AFTER_LOGIN'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_result VARCHAR2(1) := ''N'';',
'    l_result VARCHAR2(4000); -- Declare l_result to store the concatenated string',
'BEGIN',
'    -- Check if the user belongs to the APPADMIN group',
'    BEGIN',
'        SELECT ''Y''',
'        INTO v_result',
'        FROM apex_workspace_session_groups',
'        WHERE USER_NAME = get_apex_app_user',
'          AND GROUP_NAME = ''APPADMIN''',
'        FETCH FIRST 1 ROW ONLY;',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            v_result := ''N''; -- Explicitly set v_result to ''N'' if no data is found',
'    END;',
'',
'    -- If the user is not an APPADMIN, return the user name',
'    IF v_result = ''N'' THEN',
'        RETURN get_apex_app_user;',
'    END IF;',
'',
'    -- Initialize l_result to avoid NULL concatenation issues',
'    l_result := '''';',
'',
'    -- Loop through the distinct values of ''quem'' in the ''investimentos'' table',
'    FOR r IN (SELECT DISTINCT quem FROM investimentos ORDER BY quem) LOOP',
'        l_result := l_result || r.quem || ''|'';',
'    END LOOP;',
'',
'    -- Trim the trailing ''|''',
'    l_result := RTRIM(l_result, ''|'');',
'',
'    -- Return the concatenated result',
'    RETURN l_result;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        -- Handle any unexpected errors',
'        RETURN ''Error: '' || SQLERRM;',
'END;'))
,p_version_scn=>39555474874457
);
wwv_flow_imp.component_end;
end;
/
