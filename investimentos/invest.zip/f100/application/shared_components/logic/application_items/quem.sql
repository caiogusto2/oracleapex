prompt --application/shared_components/logic/application_items/quem
begin
--   Manifest
--     APPLICATION ITEM: QUEM
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>10979034347205586
,p_default_application_id=>100
,p_default_id_offset=>7563027525787247
,p_default_owner=>'PERSONAL'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(10276102056154666)
,p_name=>'QUEM'
,p_protection_level=>'I'
,p_version_scn=>39555472364041
);
wwv_flow_imp.component_end;
end;
/
