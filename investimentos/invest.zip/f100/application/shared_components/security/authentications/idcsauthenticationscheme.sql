prompt --application/shared_components/security/authentications/idcsauthenticationscheme
begin
--   Manifest
--     AUTHENTICATION: IDCSAuthenticationScheme
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>10979034347205586
,p_default_application_id=>100
,p_default_id_offset=>7563027525787247
,p_default_owner=>'PERSONAL'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(50162351372248295)
,p_name=>'IDCSAuthenticationScheme'
,p_scheme_type=>'NATIVE_SOCIAL'
,p_attribute_01=>wwv_flow_imp.id(50162143916261545)
,p_attribute_02=>'OPENID_CONNECT'
,p_attribute_03=>'https://idcs-4b20ece511e04f5981703a379370c21c.identity.oraclecloud.com:443/.well-known/openid-configuration'
,p_attribute_07=>'email,profile,groups'
,p_attribute_09=>'#sub#'
,p_attribute_10=>'groups,email'
,p_attribute_11=>'Y'
,p_attribute_13=>'N'
,p_attribute_14=>'G_GROUPS,IDCS_EMAIL'
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'procedure load_dynamic_groups as',
'    l_group_names apex_t_varchar2;',
'begin',
'    --',
'    -- add all group names to l_group_names',
'    --',
'    for i in 1 .. apex_json.get_count(''groups'') loop',
'        apex_string.push (',
'            p_table => l_group_names,',
'            p_value => apex_json.get_varchar2 (',
'                        p_path => ''groups[%d].name'',',
'                        p0     => i ));',
'    end loop;',
'    --',
'    -- save group names in session',
'    --',
'    apex_authorization.enable_dynamic_groups (',
'        p_group_names => l_group_names );',
'end;',
'',
'',
'--procedure load_dynamic_groups as',
'--    l_group_names apex_t_varchar2;',
'--begin',
'--    --',
'--    -- add all group names to l_group_names',
'--    --',
'--    for i in 1 .. apex_json.get_count(''groups'') loop',
'--        apex_string.push (',
'--            p_table => l_group_names,',
'--            p_value => apex_json.get_varchar2 (',
'--                        p_path => ''groups[%d].name'',',
'--                        p0     => i ));',
'--    end loop;',
'--    --',
'--    -- save group names in session',
'--    --',
'--    apex_authorization.enable_dynamic_groups (',
'--        p_group_names => l_group_names );',
'--end;',
'--',
'',
'',
'',
'--PROCEDURE load_dynamic_groups AS',
'--    l_cpf VARCHAR2(100); -- Adjust the size based on your data',
'--    v_exists NUMBER;',
'--BEGIN',
'--    -- Assuming l_cpf is retrieved from JSON using apex_json.get_varchar2',
'--    l_cpf := apex_json.get_varchar2(p_path => ''sub'', p0 => 1);',
'--',
'--    -- Checking if l_cpf exists in your table',
'--    SELECT COUNT(*)',
'--    INTO v_exists',
'--    FROM teste',
'--    WHERE coluna1 = l_cpf;',
'--',
'--    -- Redirect logic based on the existence of l_cpf',
'--    IF v_exists = 0 THEN',
'--        apex_util.redirect_url(p_url => ''https://oracle.com'');',
'--    ELSE',
'--        DBMS_OUTPUT.PUT_LINE(''OK''); -- Placeholder for success message or further logic',
'--    END IF;',
'--END load_dynamic_groups;',
'--'))
,p_invalid_session_type=>'LOGIN'
,p_logout_url=>'https://GEAADB7C2063479-ADB02.adb.sa-saopaulo-1.oraclecloudapps.com/ords/f?p=100:1'
,p_post_auth_process=>'load_dynamic_groups'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
,p_switch_in_session_yn=>'Y'
,p_version_scn=>39557633314634
);
wwv_flow_imp.component_end;
end;
/
