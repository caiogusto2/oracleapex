prompt --application/shared_components/security/authorizations/appuser
begin
--   Manifest
--     SECURITY SCHEME: APPUSER
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>10979034347205586
,p_default_application_id=>100
,p_default_id_offset=>7563027525787247
,p_default_owner=>'PERSONAL'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(55362192641686762)
,p_name=>'APPUSER'
,p_scheme_type=>'NATIVE_IS_IN_GROUP'
,p_attribute_01=>'APPUSER'
,p_attribute_02=>'C'
,p_version_scn=>39548644762215
,p_caching=>'BY_USER_BY_SESSION'
);
wwv_flow_imp.component_end;
end;
/
