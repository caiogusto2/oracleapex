prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>10979034347205586
,p_default_application_id=>100
,p_default_id_offset=>7563027525787247
,p_default_owner=>'PERSONAL'
);
wwv_flow_imp_page.create_page(
 p_id=>8
,p_name=>unistr('Simulador CDB Pr\00E9')
,p_alias=>'SIMULADOR'
,p_step_title=>unistr('Simulador CDB Pr\00E9')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16163682276264308)
,p_plug_name=>'Inputs'
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16164435771264316)
,p_plug_name=>'Output'
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17162624485723488)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(18553455804120767)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16164515053264317)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(16163682276264308)
,p_button_name=>'Submit'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Calcular'
,p_button_position=>'CREATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16164001325264312)
,p_name=>'P8_VALORINICIAL'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(16163682276264308)
,p_prompt=>'Valor Inicial'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'min_value', '0',
  'number_alignment', 'left',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16164172478264313)
,p_name=>'P8_TXACONTRATADA'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(16163682276264308)
,p_prompt=>'Taxa Contratada (a.a.)  - Ex. 10%'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16164207157264314)
,p_name=>'P8_DATAVENCIMENTO'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(16163682276264308)
,p_prompt=>'Data Vencimento'
,p_format_mask=>'DD-MON-YYYY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16164398608264315)
,p_name=>'P8_DATACONTRATO'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(16163682276264308)
,p_prompt=>unistr('Data Contrata\00E7\00E3o')
,p_format_mask=>'DD-MON-YYYY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16164625073264318)
,p_name=>'P8_OUTPUT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(16164435771264316)
,p_prompt=>'Valor Final Bruto'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16165082030264322)
,p_name=>'P8_OUTPUT_IR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(16164435771264316)
,p_prompt=>'IR % Sobre Ganho de Capital'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16165185067264323)
,p_name=>'P8_OUTPUT_LIQ'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(16164435771264316)
,p_prompt=>unistr('Valor Final L\00EDquido')
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(16164900006264321)
,p_validation_name=>'New'
,p_validation_sequence=>10
,p_validation=>'TO_DATE(:P8_DATACONTRATO, ''DD-MON-YYYY'') < TO_DATE(:P8_DATAVENCIMENTO, ''DD-MON-YYYY'')'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Data de vencimento deve ser maior que a data de contrata\00E7\00E3o')
,p_associated_item=>wwv_flow_imp.id(16164207157264314)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(16164804870264320)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Calculos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_result NUMBER; -- Assuming the return type of the function is NUMBER',
'    v_days_diff NUMBER;',
'    v_interest_rate NUMBER;',
'    v_taxacalculada NUMBER;',
'BEGIN',
'    -- Calculate the difference in days',
'    v_days_diff := (TRUNC(TO_DATE(:P8_DATAVENCIMENTO, ''DD-MON-YYYY'')) - TRUNC(TO_DATE(:P8_DATACONTRATO, ''DD-MON-YYYY'')));',
'',
'    -- Assign the interest rate based on the days difference',
'    :P8_OUTPUT_IR := CASE ',
'                        WHEN v_days_diff < 180 THEN 22.5',
'                        WHEN v_days_diff < 360 THEN 20',
'                        WHEN v_days_diff < 720 THEN 17.5',
'                        ELSE 15',
'                     END;',
'',
'    -- Calculate interest rate as a fraction',
'    v_interest_rate := :P8_OUTPUT_IR / 100;',
'    v_taxacalculada := :P8_TXACONTRATADA / 100;',
'',
'    -- Call the function and assign its result to v_result',
'    v_result := ROUND(calcular_juros_compostos(:P8_VALORINICIAL,',
'                                             v_taxacalculada,',
'                                             v_days_diff / 365,',
'                                             12), 2);',
'    ',
'    -- Assign the result to the bind variable',
'    :P8_OUTPUT := v_result;',
'',
'    -- Calculate :P8_OUTPUT_LIQ',
'    :P8_OUTPUT_LIQ := round(:P8_OUTPUT - ((:P8_OUTPUT - :P8_VALORINICIAL) * v_interest_rate),2);',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>16164804870264320
);
wwv_flow_imp.component_end;
end;
/
