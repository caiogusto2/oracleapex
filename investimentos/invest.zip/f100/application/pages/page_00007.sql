prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>10979034347205586
,p_default_application_id=>100
,p_default_id_offset=>7563027525787247
,p_default_owner=>'PERSONAL'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'AI Search'
,p_alias=>'AI-SEARCH'
,p_page_mode=>'MODAL'
,p_step_title=>'AI Search'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9043069836732324)
,p_plug_name=>'Chat'
,p_region_name=>'chat'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9043185233732325)
,p_name=>'P7_ID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9043299031732326)
,p_name=>'P7_CONTEXT'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9045565954732349)
,p_name=>'P7_TESTE'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(9042908210732323)
,p_computation_sequence=>10
,p_computation_item=>'P7_CONTEXT'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
unistr('  output_line CLOB := ''Os meus investimentos s\00E3o: '';'),
'BEGIN',
'',
'  -- Loop through each record and concatenate the output',
'  FOR record IN (',
'    SELECT',
'      ''ID : '' || I.ID || '' | '' ||',
'      ''TIPO DE INVESTIMENTO : '' || I.TIPO_DE_INVESTIMENTO || '' | '' ||',
unistr('      ''BANCO : '' || C.DESCRI\00C7\00C3O || '' '' ||'),
'      ''VENCIMENTO : '' || TO_CHAR(I.VENCIMENTO, ''DD/MM/YYYY'') || '' | '' ||',
'      ''TAXA CONTRATADA : '' || I.TAXA_NEGOCIADA || '' | '' ||',
'      ''VALOR APLICADO OU VALOR INICIAL : '' || I.VALOR_APLICADO || '' | '' ||',
'      ''QUEM OU INVESTIDOR : '' || I.QUEM || '' | '' ||',
'      ''DATA INVESTIMENTO : '' || TO_CHAR(I.DATA_INVESTIMENTO, ''DD/MM/YYYY'') || '' | '' ||',
'      ''VALOR ATUAL : '' || I.VALOR_ATUAL || '' | '' ||',
'      ''VALOR PROJETADO : '' || I.VALOR_PROJETADO || '' | '' ||',
'      ''VALOR HOJE : '' || I.VALOR_PROJETADO || '' | '' ||',
'      ''STATUS : '' || I.STATUS || '' | '' ||',
'      ''CONGLOMERADO : '' || C.GRUPO_ACIONARIO',
'      AS prompt_context',
'    FROM INVESTIMENTOS I, CONTROLE_ACIONARIO C ',
'    WHERE REGEXP_LIKE(quem, :INVESTIDOR)',
'    AND I.CONTROLE_ACIONARIO_ID = C.ID',
'  ) LOOP',
'    -- Concatenate the formatted string to the output_line',
'    output_line := output_line || record.prompt_context || CHR(10) || CHR(10);',
'  END LOOP;',
'  ',
'  -- Return the output',
'  RETURN output_line;',
'END;',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(9043443615732328)
,p_name=>'Open AI Assistant - Chat'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9043591333732329)
,p_event_id=>wwv_flow_imp.id(9043443615732328)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_AI_ASSISTANT'
,p_attribute_01=>'INLINE'
,p_attribute_03=>'#chat'
,p_ai_remote_server_id=>wwv_flow_imp.id(9162467751133879)
,p_ai_system_prompt=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Use the below context to answer all questions:',
'',
'''''''',
'',
'&P7_CONTEXT.',
'',
'''''''',
'',
unistr('If the question cannot be answered based on the above context, say "Informa\00E7\00E3o N\00E3o Encontrada".')))
,p_ai_welcome_message=>'Bem Vindo ao AI Assistant, digite sua pergunta...'
);
wwv_flow_imp.component_end;
end;
/
