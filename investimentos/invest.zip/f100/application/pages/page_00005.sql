prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>10979034347205586
,p_default_application_id=>100
,p_default_id_offset=>7563027525787247
,p_default_owner=>'PERSONAL'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'Investimentos'
,p_alias=>'INVESTIMENTOS'
,p_page_mode=>'MODAL'
,p_step_title=>'Investimentos'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>1661186590416509825
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18876670184121305)
,p_plug_name=>'Investimentos'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'INVESTIMENTOS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18881967627121323)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(18882361920121324)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(18881967627121323)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancelar'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(18884559185121327)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(18881967627121323)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Criar'
,p_button_position=>'CREATE'
,p_button_condition=>'P5_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(18883806343121327)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(18881967627121323)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--simple'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Deletar'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P5_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(18884188420121327)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(18881967627121323)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Salvar'
,p_button_position=>'NEXT'
,p_button_condition=>'P5_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16162967122264301)
,p_name=>'P5_ARQUIVO'
,p_source_data_type=>'BLOB'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(18876670184121305)
,p_item_source_plug_id=>wwv_flow_imp.id(18876670184121305)
,p_prompt=>'Comprovante Investimento'
,p_source=>'ARQUIVO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'blob_last_updated_column', 'ARQUIVO_DATA',
  'content_disposition', 'inline',
  'display_as', 'DROPZONE_BLOCK',
  'display_download_link', 'Y',
  'filename_column', 'ARQUIVO_NOME',
  'mime_type_column', 'ARQUIVO_MIMETYPE',
  'storage_type', 'DB_COLUMN')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16163223802264304)
,p_name=>'P5_CORRETORA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(18876670184121305)
,p_item_source_plug_id=>wwv_flow_imp.id(18876670184121305)
,p_prompt=>'Corretora'
,p_source=>'CORRETORA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>300
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'text_case', 'UPPER',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17884914626389795)
,p_name=>'P5_QUEM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(18876670184121305)
,p_item_source_plug_id=>wwv_flow_imp.id(18876670184121305)
,p_prompt=>'Investidor'
,p_source=>'QUEM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT DISTINCT QUEM REQUEST, QUEM DISPLAY FROM INVESTIMENTOS ORDER BY 1'
,p_cHeight=>1
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ''Y''',
'FROM apex_workspace_session_groups',
'WHERE USER_NAME = get_apex_app_user',
'AND GROUP_NAME = ''APPADMIN''',
'FETCH FIRST 1 ROW ONLY;'))
,p_read_only_when_type=>'NOT_EXISTS'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17885095894389797)
,p_name=>'P5_DATA_INVESTIMENTO'
,p_source_data_type=>'DATE'
,p_is_required=>true
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(18876670184121305)
,p_item_source_plug_id=>wwv_flow_imp.id(18876670184121305)
,p_item_default=>'SELECT current_date FROM DUAL;'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Data Investimento'
,p_format_mask=>'DD-MON-YYYY'
,p_source=>'DATA_INVESTIMENTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18877073022121305)
,p_name=>'P5_ID'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(18876670184121305)
,p_item_source_plug_id=>wwv_flow_imp.id(18876670184121305)
,p_use_cache_before_default=>'NO'
,p_prompt=>'ID'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18877466972121318)
,p_name=>'P5_TIPO_DE_INVESTIMENTO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(18876670184121305)
,p_item_source_plug_id=>wwv_flow_imp.id(18876670184121305)
,p_prompt=>'Tipo De Investimento'
,p_source=>'TIPO_DE_INVESTIMENTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'text_case', 'UPPER',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18878285883121319)
,p_name=>'P5_VENCIMENTO'
,p_source_data_type=>'DATE'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(18876670184121305)
,p_item_source_plug_id=>wwv_flow_imp.id(18876670184121305)
,p_prompt=>'Vencimento'
,p_format_mask=>'DD-MON-YYYY'
,p_source=>'VENCIMENTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18878672750121320)
,p_name=>'P5_TAXA_NEGOCIADA'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(18876670184121305)
,p_item_source_plug_id=>wwv_flow_imp.id(18876670184121305)
,p_prompt=>'Txa a.a. (Ex. 0,1055)'
,p_format_mask=>'999G999G999G999G990D0000'
,p_source=>'TAXA_NEGOCIADA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'max_value', '1',
  'min_value', '0',
  'number_alignment', 'left',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18879091168121320)
,p_name=>'P5_QUANTIDADE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(18876670184121305)
,p_item_source_plug_id=>wwv_flow_imp.id(18876670184121305)
,p_prompt=>'Quantidade'
,p_source=>'QUANTIDADE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18879460739121320)
,p_name=>'P5_VALOR_APLICADO'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(18876670184121305)
,p_item_source_plug_id=>wwv_flow_imp.id(18876670184121305)
,p_prompt=>'Valor Aplicado'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_source=>'VALOR_APLICADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'min_value', '0',
  'number_alignment', 'left',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18952393027614165)
,p_name=>'P5_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(18876670184121305)
,p_item_source_plug_id=>wwv_flow_imp.id(18876670184121305)
,p_item_default=>'ATIVO'
,p_prompt=>'STATUS'
,p_source=>'STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:ATIVO;ATIVO,INATIVO;INATIVO'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(55794191034021012)
,p_name=>'P5_EMPRESA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(18876670184121305)
,p_item_source_plug_id=>wwv_flow_imp.id(18876670184121305)
,p_prompt=>'Empresa'
,p_source=>'CONTROLE_ACIONARIO_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>unistr('select distinct descri\00E7\00E3o request,id display from controle_acionario order by 1; ')
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
unistr('  Se a empresa que voc\00EA deseja cadastrar n\00E3o estiver na lista, fa\00E7a antes o cadastro da mesma na guia '),
'  <a href="f?p=&APP_ID.:10:&SESSION.::&DEBUG.::::">Grupos e Empresas</a>.',
'</p>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(16163189727264303)
,p_computation_sequence=>10
,p_computation_item=>'P5_ARQUIVO'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'null'
,p_compute_when=>'P5_ARQUIVO'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(8409925596170816)
,p_computation_sequence=>10
,p_computation_item=>'P5_QUEM'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'SQL'
,p_computation=>'get_apex_app_user'
,p_security_scheme=>wwv_flow_imp.id(55362192641686762)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(18882434058121324)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(18882361920121324)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(18883269980121326)
,p_event_id=>wwv_flow_imp.id(18882434058121324)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(18952221496614163)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Execution_Chain'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>11389193970826916
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(18885827052121328)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>11322799526334081
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(18884994931121328)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(18876670184121305)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Investimentos'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>11321967405334081
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(18885395027121328)
,p_process_sequence=>20
,p_region_id=>wwv_flow_imp.id(18876670184121305)
,p_parent_process_id=>wwv_flow_imp.id(18952221496614163)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Investimentos'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_internal_uid=>11322367501334081
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(18952125223614162)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(18952221496614163)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Refresh_Valores'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'	DBMS_SCHEDULER.run_job(job_name =>''PERSONAL.ATUALIZAR_VALOR_ATUAL'', use_current_session => FALSE);',
'	DBMS_SCHEDULER.run_job(job_name =>''PERSONAL.ATUALIZAR_VALOR_PROJETADO'', use_current_session => FALSE);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>11389097697826915
);
wwv_flow_imp.component_end;
end;
/
