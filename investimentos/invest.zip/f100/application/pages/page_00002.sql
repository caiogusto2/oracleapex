prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>10979034347205586
,p_default_application_id=>100
,p_default_id_offset=>7563027525787247
,p_default_owner=>'PERSONAL'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Dashboard CDBs'
,p_alias=>'DASHBOARD'
,p_step_title=>'Dashboard CDBs'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.kpis {',
'    background: lightyellow;',
'}',
'',
'.imagem {',
'    text-align: center;',
'    width: 25%; /* any size you want */',
'    height: auto;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'04'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7768933819457513)
,p_plug_name=>unistr('Evolu\00E7\00E3o Patrim\00F4nio M\00EAs a M\00EAs')
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>70
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(7769086092457514)
,p_region_id=>wwv_flow_imp.id(7768933819457513)
,p_chart_type=>'bar'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(7769139616457515)
,p_chart_id=>wwv_flow_imp.id(7769086092457514)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH month_data AS (',
'    SELECT LEVEL - 1 AS month_num,',
'           TRUNC(SYSDATE) - ((LEVEL - 1) * 30) AS month_date',
'    FROM DUAL',
'    CONNECT BY LEVEL <= 6',
'),',
'investment_data AS (',
'    SELECT ',
'        VALOR_APLICADO, ',
'        TAXA_NEGOCIADA, ',
'        DATA_INVESTIMENTO, ',
'        quem ',
'    FROM ',
'        investimentos',
'    WHERE ',
'        (REGEXP_LIKE(quem, :QUEM)',
'        OR REGEXP_LIKE(quem, :P2_INVESTIDOR))',
'        AND STATUS = ''ATIVO''',
'--    quem = ''CAIO''',
'),',
'compounded_values AS (',
'    SELECT ',
'        md.month_date,',
'        SUM(ROUND(calcular_juros_compostos(',
'            id.VALOR_APLICADO,',
'            id.TAXA_NEGOCIADA,',
'            (TRUNC(md.month_date) - TRUNC(id.DATA_INVESTIMENTO)) / 365,',
'            12',
'        ), 2)) AS valor_atual',
'    FROM ',
'        month_data md',
'    JOIN ',
'        investment_data id ON 1 = 1',
'    GROUP BY ',
'        md.month_date',
')',
'SELECT ',
'    TO_CHAR(month_date, ''DD/MM/YYYY'') AS "Date", ',
'    valor_atual AS "Value"',
'FROM ',
'    compounded_values',
'ORDER BY ',
'    month_date ASC;',
''))
,p_max_row_count=>200
,p_items_value_column_name=>'Value'
,p_items_label_column_name=>'Date'
,p_color=>'#4cd964'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(7769304467457517)
,p_chart_id=>wwv_flow_imp.id(7769086092457514)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>unistr('Total Patrim\00F4nio')
,p_format_type=>'currency'
,p_decimal_places=>0
,p_currency=>'R$'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(7769273051457516)
,p_chart_id=>wwv_flow_imp.id(7769086092457514)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>'Data'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7769480686457518)
,p_plug_name=>unistr('Ganho de Capital M\00EAs a M\00EAs')
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>80
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(7769535548457519)
,p_region_id=>wwv_flow_imp.id(7769480686457518)
,p_chart_type=>'bar'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(7769668709457520)
,p_chart_id=>wwv_flow_imp.id(7769535548457519)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH month_data AS (',
'    SELECT LEVEL - 1 AS month_num,',
'           TRUNC(SYSDATE) - ((LEVEL - 1) * 30) AS month_date',
'    FROM DUAL',
'    CONNECT BY LEVEL <= 6',
'),',
'investment_data AS (',
'    SELECT ',
'        VALOR_APLICADO, ',
'        TAXA_NEGOCIADA, ',
'        DATA_INVESTIMENTO',
'    FROM ',
'        investimentos',
'    WHERE ',
'        (REGEXP_LIKE(quem, :QUEM)',
'        OR REGEXP_LIKE(quem, :P2_INVESTIDOR))',
'        AND STATUS = ''ATIVO''',
'),',
'compounded_values AS (',
'    SELECT ',
'        md.month_date,',
'        SUM(ROUND(calcular_juros_compostos(',
'            id.VALOR_APLICADO,',
'            id.TAXA_NEGOCIADA,',
'            (TRUNC(md.month_date) - TRUNC(id.DATA_INVESTIMENTO)) / 365,',
'            12',
'        ), 2)) AS valor_atual',
'    FROM ',
'        month_data md',
'    JOIN ',
'        investment_data id ON 1 = 1 -- Adjust join condition as per your data structure',
'    GROUP BY ',
'        md.month_date',
'),',
'final_data AS (',
'    SELECT ',
'        TO_CHAR(cv.month_date, ''DD/MM/YYYY'') AS "Date", ',
'        cv.valor_atual AS "Value",',
'        NVL(cv.valor_atual - LAG(cv.valor_atual, 1) OVER (ORDER BY cv.month_date), 0) AS "Difference",',
'        ROW_NUMBER() OVER (ORDER BY cv.month_date) AS rn',
'    FROM ',
'        compounded_values cv',
')',
'SELECT ',
'    "Date", ',
'    "Value",',
'    "Difference"',
'FROM ',
'    final_data',
'WHERE ',
'    rn > 1',
'ORDER BY ',
'    TO_DATE("Date", ''DD/MM/YYYY'') ASC;',
''))
,p_max_row_count=>200
,p_items_value_column_name=>'Difference'
,p_items_label_column_name=>'Date'
,p_color=>'#ff9500'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(7769857246457522)
,p_chart_id=>wwv_flow_imp.id(7769535548457519)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'Ganho de Capital'
,p_format_type=>'currency'
,p_decimal_places=>0
,p_currency=>'R$'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(7769753352457521)
,p_chart_id=>wwv_flow_imp.id(7769535548457519)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>'Data'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17882829010389775)
,p_plug_name=>'Filtro'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_required_role=>wwv_flow_imp.id(55368053991614197)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17883153752389778)
,p_plug_name=>'KPIs'
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18858679145121233)
,p_plug_name=>'Investimentos por Banco - Valor sem Juros'
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(18859078090121233)
,p_region_id=>wwv_flow_imp.id(18858679145121233)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'horizontal'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(18860761198121235)
,p_chart_id=>wwv_flow_imp.id(18859078090121233)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
unistr('    C.DESCRI\00C7\00C3O AS BANCO, '),
'    SUM(I.VALOR_APLICADO) AS "TOTAL APLICADO"',
'FROM INVESTIMENTOS I, CONTROLE_ACIONARIO C ',
'--WHERE QUEM=:QUEM',
'where ',
'I.CONTROLE_ACIONARIO_ID = C.ID AND',
'(REGEXP_LIKE(quem, :QUEM)',
'OR REGEXP_LIKE(quem, :P2_INVESTIDOR))',
'AND STATUS = ''ATIVO''',
unistr('GROUP BY DESCRI\00C7\00C3O ORDER BY 2 desc;')))
,p_max_row_count=>20
,p_items_value_column_name=>'TOTAL APLICADO'
,p_items_label_column_name=>'BANCO'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(18859556867121234)
,p_chart_id=>wwv_flow_imp.id(18859078090121233)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>'Bancos'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(18860144321121235)
,p_chart_id=>wwv_flow_imp.id(18859078090121233)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'Valores em Reais'
,p_format_type=>'currency'
,p_decimal_places=>0
,p_currency=>'R$'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18861413198121236)
,p_plug_name=>'Fluxo de Caixa - Valor com Juros'
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>60
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(18861738390121236)
,p_region_id=>wwv_flow_imp.id(18861413198121236)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'top'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(18863472478121237)
,p_chart_id=>wwv_flow_imp.id(18861738390121236)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
unistr('    C.descri\00E7\00E3o as "BANCO",'),
'    extract(year from I.vencimento) as "ANO",',
'    sum(I.valor_projetado) as "VALOR_PROJETADO"',
'from investimentos I, CONTROLE_ACIONARIO C ',
'--where quem = :QUEM',
'where ',
'I.CONTROLE_ACIONARIO_ID = C.ID AND',
'(REGEXP_LIKE(quem, :QUEM)',
'OR REGEXP_LIKE(quem, :P2_INVESTIDOR))',
'AND STATUS = ''ATIVO''',
unistr('group by descri\00E7\00E3o, extract(year from vencimento)'),
'order by 2, 3 desc;',
''))
,p_max_row_count=>200
,p_series_name_column_name=>'BANCO'
,p_items_value_column_name=>'VALOR_PROJETADO'
,p_items_label_column_name=>'ANO'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(18862896118121237)
,p_chart_id=>wwv_flow_imp.id(18861738390121236)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'Valores Projetados'
,p_format_type=>'currency'
,p_decimal_places=>0
,p_currency=>'R$'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(18862276245121236)
,p_chart_id=>wwv_flow_imp.id(18861738390121236)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>'Ano de Vencimento'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18866787746121241)
,p_plug_name=>'Dashboards CDBs'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(18553455804120767)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
,p_landmark_type=>'exclude_landmark'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31983142936907603)
,p_plug_name=>unistr('Investimentos por Grupo Acion\00E1rio - Valor sem Juros')
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>50
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(31983231902907604)
,p_region_id=>wwv_flow_imp.id(31983142936907603)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'horizontal'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(31983357182907605)
,p_chart_id=>wwv_flow_imp.id(31983231902907604)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
unistr('    C.GRUPO_ACIONARIO AS "GRUPO ACION\00C1RIO", '),
'    SUM(I.VALOR_APLICADO) AS "TOTAL APLICADO"',
'FROM INVESTIMENTOS I, CONTROLE_ACIONARIO C ',
'--WHERE QUEM=:QUEM',
'where ',
'I.CONTROLE_ACIONARIO_ID = C.ID AND',
'(REGEXP_LIKE(quem, :QUEM)',
'OR REGEXP_LIKE(quem, :P2_INVESTIDOR))',
'AND I.STATUS = ''ATIVO''',
'GROUP BY C.GRUPO_ACIONARIO ORDER BY 2 desc;'))
,p_max_row_count=>20
,p_items_value_column_name=>'TOTAL APLICADO'
,p_items_label_column_name=>unistr('GRUPO ACION\00C1RIO')
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(31983586215907607)
,p_chart_id=>wwv_flow_imp.id(31983231902907604)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'Valores em Reais'
,p_format_type=>'currency'
,p_decimal_places=>0
,p_currency=>'R$'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(31983499924907606)
,p_chart_id=>wwv_flow_imp.id(31983231902907604)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>unistr('Grupo Acion\00E1rio')
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17883061335389777)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(17882829010389775)
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Submit'
,p_button_position=>'CREATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7767805150457502)
,p_name=>'P2_RETORNOCARTEIRA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(17883153752389778)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Retorno Carteira % a.a.'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    (trunc(SUM(ROUND(calcular_juros_compostos(VALOR_APLICADO,TAXA_NEGOCIADA,(TRUNC(SYSDATE) - TRUNC(DATA_INVESTIMENTO)) / 365, 12), 2)) /',
'    SUM(ROUND(calcular_juros_compostos(VALOR_APLICADO,TAXA_NEGOCIADA,(TRUNC(SYSDATE - 365) - TRUNC(DATA_INVESTIMENTO)) / 365, 12), 2)),4) -1 ) *100 AS retorno_carteira',
'FROM ',
'    investimentos',
'where (REGEXP_LIKE(quem, :QUEM)',
'OR REGEXP_LIKE(quem, :P2_INVESTIDOR))',
'AND STATUS = ''ATIVO'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7770605759457530)
,p_name=>'P2_TXADI'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(17883153752389778)
,p_prompt=>'Indicadores - Txa DI a.a.'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_source=>'Get_CDI_Hoje'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_css_classes=>'kpis'
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div>Indicadores Retirados do Site: <a href="https://investidor10.com.br/indices/" target="_blank" rel="noopener noreferrer">investidor10.com.br</a></div>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7770783745457531)
,p_name=>'P2_TXAIPCA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(17883153752389778)
,p_prompt=>'Indicadores - Txa IPCA a.a.'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_source=>'Get_IPCA_Hoje'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_css_classes=>'kpis'
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div>Indicadores Retirados do Site: <a href="https://investidor10.com.br/indices/" target="_blank" rel="noopener noreferrer">investidor10.com.br</a></div>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17883009611389776)
,p_name=>'P2_INVESTIDOR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(17882829010389775)
,p_prompt=>'Escolha o Investidor'
,p_display_as=>'NATIVE_SELECT_MANY'
,p_lov=>'SELECT DISTINCT QUEM AS REQUEST, QUEM AS DISPLAY FROM INVESTIMENTOS;'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'fetch_on_search', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0',
  'use_defaults', 'Y')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>'|'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17883249026389779)
,p_name=>'P2_INVESTIDO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(17883153752389778)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Capital Inicial Investido'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT TO_CHAR(SUM(valor_aplicado), ''L999G999G990D99'') AS request',
'FROM investimentos',
'WHERE (REGEXP_LIKE(quem, :QUEM)',
'OR REGEXP_LIKE(quem, :P2_INVESTIDOR))',
'AND STATUS = ''ATIVO'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18950942550614151)
,p_name=>'P2_PROJETADO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(17883153752389778)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Capital Projetado ap\00F3s Tempo')
,p_format_mask=>'FML999G999G999G999G990D00'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select TO_CHAR(SUM(valor_projetado), ''L999G999G990D99'') as request ',
'from investimentos',
'--where quem=:QUEM;',
'where (REGEXP_LIKE(quem, :QUEM)',
'OR REGEXP_LIKE(quem, :P2_INVESTIDOR))',
'AND STATUS = ''ATIVO'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18951397504614155)
,p_name=>'P2_ATUAL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(17883153752389778)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Capital Atual'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select TO_CHAR(SUM(valor_atual), ''L999G999G990D99'') as request ',
'from investimentos',
'--where quem=:QUEM;',
'where (REGEXP_LIKE(quem, :QUEM)',
'OR REGEXP_LIKE(quem, :P2_INVESTIDOR))',
'AND STATUS = ''ATIVO'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(55794375586021014)
,p_name=>'P2_TXASELIC'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(17883153752389778)
,p_prompt=>'Indicadores - Txa SELIC a.a.'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_source=>'Get_SELIC_Hoje'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_css_classes=>'kpis'
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div>Indicadores Retirados do Site: <a href="https://investidor10.com.br/indices/" target="_blank" rel="noopener noreferrer">investidor10.com.br</a></div>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp.component_end;
end;
/
