prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>10979034347205586
,p_default_application_id=>100
,p_default_id_offset=>7563027525787247
,p_default_owner=>'PERSONAL'
);
wwv_flow_imp_page.create_page(
 p_id=>9
,p_name=>'Monitoramento Carteira'
,p_alias=>'MONITORAMENTO-CARTEIRA'
,p_step_title=>'Monitoramento Carteira'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'!'||wwv_flow_imp.id(18846823496121183)
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16165952033264331)
,p_plug_name=>'Controle de Monitoramento'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17770133879895242)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(18553455804120767)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16167644594264348)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(16165952033264331)
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submeter'
,p_button_position=>'CREATE'
,p_icon_css_classes=>'fa-exchange'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16166018083264332)
,p_name=>'P9_VENCIMENTO6MESES'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(16165952033264331)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    job_exists VARCHAR2(1);',
'    result     VARCHAR2(10);',
'BEGIN',
'    BEGIN',
'        SELECT ''Y''',
'        INTO job_exists',
'        FROM user_scheduler_jobs',
'        WHERE job_name = ''PERSONAL.'' || :P9_USERNAME || ''_VENC6MESES''',
'        AND ROWNUM = 1;',
'',
'        result := ''ENABLE'';',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            result := ''DISABLE'';',
'    END;',
'',
'    RETURN result;',
'END;'))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Receber Email com CDBs a Vencer (Alerta 6 meses, 1 semana e no dia do vencimento)'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'U'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', 'ENABLE',
  'unchecked_value', 'DISABLE',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16166360196264335)
,p_name=>'P9_USERNAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(16165952033264331)
,p_prompt=>unistr('Usu\00E1rio')
,p_source=>'&QUEM.'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16166477171264336)
,p_name=>'P9_EMAIL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(16165952033264331)
,p_prompt=>'Email Cadastrado'
,p_source=>'&IDCS_EMAIL.'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18370292063306302)
,p_name=>'P9_ARQCONTROLE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(16165952033264331)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    job_exists VARCHAR2(1);',
'    result     VARCHAR2(10);',
'BEGIN',
'    BEGIN',
'        SELECT ''Y''',
'        INTO job_exists',
'        FROM user_scheduler_jobs',
'        WHERE job_name = ''PERSONAL.'' || :P9_USERNAME || ''_ARQCONTROLE''',
'        AND ROWNUM = 1;',
'',
'        result := ''ENABLE'';',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            result := ''DISABLE'';',
'    END;',
'',
'    RETURN result;',
'END;'))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Receber Email com CDBs com Arquivos Pendentes'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'U'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', 'ENABLE',
  'unchecked_value', 'DISABLE',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(16167761732264349)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ALTERARVENC6MESES'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    job_exists EXCEPTION;',
'    PRAGMA EXCEPTION_INIT(job_exists, -27475);',
'BEGIN',
'    IF :P9_VENCIMENTO6MESES = ''ENABLE'' THEN',
'        BEGIN',
'            DBMS_SCHEDULER.DROP_JOB(job_name => ''PERSONAL.'' || :P9_USERNAME || ''_VENC6MESES'', force => TRUE);',
'            DBMS_SCHEDULER.DROP_JOB(job_name => ''PERSONAL.'' || :P9_USERNAME || ''_VENCWEEK'', force => TRUE);',
'            DBMS_SCHEDULER.DROP_JOB(job_name => ''PERSONAL.'' || :P9_USERNAME || ''_VENCTODAY'', force => TRUE);',
'        EXCEPTION',
'            WHEN job_exists THEN',
'                NULL; -- Job does not exist, ignore error',
'        END;',
'        ',
'        DBMS_SCHEDULER.CREATE_JOB (',
'            job_name        => ''PERSONAL.'' || :P9_USERNAME || ''_VENC6MESES'',',
'            job_type        => ''PLSQL_BLOCK'',',
'            job_action      => ''BEGIN vencimento6meses('''''' || :P9_USERNAME || '''''', '''''' || :P9_EMAIL || ''''''); END;'',',
'            start_date      => SYSDATE,',
'            repeat_interval => ''FREQ=MONTHLY; BYMONTHDAY=1; BYHOUR=9'',',
'            auto_drop       => FALSE,',
'            enabled         => TRUE,',
'            comments        => ''Job para envio de CDBs a vencer do usuario: '' || :P9_USERNAME || '';''',
'        );',
'',
'        DBMS_SCHEDULER.run_job(job_name =>''PERSONAL.'' || :P9_USERNAME || ''_VENC6MESES'', use_current_session => FALSE);',
'',
'        DBMS_SCHEDULER.CREATE_JOB (',
'            job_name        => ''PERSONAL.'' || :P9_USERNAME || ''_VENCWEEK'',',
'            job_type        => ''PLSQL_BLOCK'',',
'            job_action      => ''BEGIN vencimentoweek('''''' || :P9_USERNAME || '''''', '''''' || :P9_EMAIL || ''''''); END;'',',
'            start_date      => SYSDATE,',
'            repeat_interval => ''FREQ=WEEKLY; BYDAY=MON; BYHOUR=9'',',
'            auto_drop       => FALSE,',
'            enabled         => TRUE,',
'            comments        => ''Job para envio de CDBs a vencer do usuario: '' || :P9_USERNAME || '';''',
'        );',
'',
'        DBMS_SCHEDULER.run_job(job_name =>''PERSONAL.'' || :P9_USERNAME || ''_VENCWEEK'', use_current_session => FALSE);',
'',
'        DBMS_SCHEDULER.CREATE_JOB (',
'            job_name        => ''PERSONAL.'' || :P9_USERNAME || ''_VENCTODAY'',',
'            job_type        => ''PLSQL_BLOCK'',',
'            job_action      => ''BEGIN vencimentohoje('''''' || :P9_USERNAME || '''''', '''''' || :P9_EMAIL || ''''''); END;'',',
'            start_date      => SYSDATE,',
'            repeat_interval => ''FREQ=DAILY; BYHOUR=9'',',
'            auto_drop       => FALSE,',
'            enabled         => TRUE,',
'            comments        => ''Job para envio de CDBs a vencer do usuario: '' || :P9_USERNAME || '';''',
'        );',
'',
'        DBMS_SCHEDULER.run_job(job_name =>''PERSONAL.'' || :P9_USERNAME || ''_VENCTODAY'', use_current_session => FALSE);',
'        ',
'    ELSIF :P9_VENCIMENTO6MESES = ''DISABLE'' THEN',
'        BEGIN',
'            DBMS_SCHEDULER.DROP_JOB(job_name => ''PERSONAL.'' || :P9_USERNAME || ''_VENC6MESES'', force => TRUE);',
'            DBMS_SCHEDULER.DROP_JOB(job_name => ''PERSONAL.'' || :P9_USERNAME || ''_VENCWEEK'', force => TRUE);',
'            DBMS_SCHEDULER.DROP_JOB(job_name => ''PERSONAL.'' || :P9_USERNAME || ''_VENCTODAY'', force => TRUE);',
'        EXCEPTION',
'            WHEN job_exists THEN',
'                NULL; -- Job does not exist, ignore error',
'        END;',
'    ELSE',
'        RAISE_APPLICATION_ERROR(-20001, ''Invalid value for :P9_VENCIMENTO6MESES. Use ENABLE or DISABLE.'');',
'    END IF;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>16167761732264349
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(18370345189306303)
,p_process_sequence=>20
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ALTERARARQCONTROLE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    job_exists EXCEPTION;',
'    PRAGMA EXCEPTION_INIT(job_exists, -27475);',
'BEGIN',
'    IF :P9_ARQCONTROLE = ''ENABLE'' THEN',
'        BEGIN',
'            DBMS_SCHEDULER.DROP_JOB(job_name => ''PERSONAL.'' || :P9_USERNAME || ''_ARQCONTROLE'', force => TRUE);',
'        EXCEPTION',
'            WHEN job_exists THEN',
'                NULL; -- Job does not exist, ignore error',
'        END;',
'        ',
'        DBMS_SCHEDULER.CREATE_JOB (',
'            job_name        => ''PERSONAL.'' || :P9_USERNAME || ''_ARQCONTROLE'',',
'            job_type        => ''PLSQL_BLOCK'',',
'            job_action      => ''BEGIN arquivopendente('''''' || :P9_USERNAME || '''''', '''''' || :P9_EMAIL || ''''''); END;'',',
'            start_date      => SYSDATE,',
'            repeat_interval => ''FREQ=MONTHLY; BYMONTHDAY=1; BYHOUR=9'',',
'            auto_drop       => FALSE,',
'            enabled         => TRUE,',
'            comments        => ''Job para envio de CDBs a vencer do usuario: '' || :P9_USERNAME || '';''',
'        );',
'',
'        DBMS_SCHEDULER.run_job(job_name =>''PERSONAL.'' || :P9_USERNAME || ''_ARQCONTROLE'', use_current_session => FALSE);',
'',
'    ELSIF :P9_ARQCONTROLE = ''DISABLE'' THEN',
'        BEGIN',
'            DBMS_SCHEDULER.DROP_JOB(job_name => ''PERSONAL.'' || :P9_USERNAME || ''_ARQCONTROLE'', force => TRUE);',
'        EXCEPTION',
'            WHEN job_exists THEN',
'                NULL; -- Job does not exist, ignore error',
'        END;',
'    ELSE',
'        RAISE_APPLICATION_ERROR(-20001, ''Invalid value for :P9_ARQCONTROLE. Use ENABLE or DISABLE.'');',
'    END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>18370345189306303
);
wwv_flow_imp.component_end;
end;
/
