prompt --application/shared_components/navigation/breadcrumbentry
begin
--   Manifest
--     BREADCRUMB ENTRY: 
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>11138133706382214
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DATAPREV'
);
null;
wwv_flow_imp.component_end;
end;
/
