prompt --application/shared_components/files/icons_app_icon_32_png
begin
--   Manifest
--     APP STATIC FILES: 101
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>11138133706382214
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DATAPREV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200806000000737A7AF4000000017352474200AECE1CE9000000EA49444154584763CC6B9DF19F610001E3A8034643603404464360D087C0EFEF9F194404F8E165E57F4606860F9FBF3130B2B0';
wwv_flow_imp.g_varchar2_table(2) := '33303232525C86122C09F9D99918B43454512CFAFBF71FC3A90B9719FE33B13130323151E408B21C00B2F1DFBF7F0C8F9E3C63F8F6ED3B4E07BCF9F09181959317AF03C97200C8F29B77EE3168A928E235FCD6BD070C6FBEFEA1CC0122DC2C0C6A4A0A28';
wwv_flow_imp.g_varchar2_table(3) := '86303131325819EB307071B0E3357CD7E1330CC72EDFA1CC0156BA2A0C6EB62664C5F3A80346436078840027D33F06436D35B272C1B96BB7197EFCC55F5C132C88C8B299044DA30E180D81D110180D81010F0100401FA761A3B837730000000049454E44';
wwv_flow_imp.g_varchar2_table(4) := 'AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(11435214885392354)
,p_file_name=>'icons/app-icon-32.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
