prompt --application/shared_components/logic/application_processes/download_object
begin
--   Manifest
--     APPLICATION PROCESS: DOWNLOAD_OBJECT
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>11138133706382214
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DATAPREV'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(11477969494902348)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DOWNLOAD_OBJECT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_file blob;',
'  l_mime_type varchar2(32767);',
'begin',
'',
'  l_file := dbms_cloud.get_object(',
'    credential_name => :CREDENTIAL_NAME,',
'    object_uri      => :LOCATION_URI || :APP_OBJECT_NAME);',
'',
'  l_mime_type := ''application/octet-stream'';',
'',
'  sys.htp.init;',
'  sys.owa_util.mime_header(l_mime_type, false);',
'  sys.htp.p(''content-length: '' || dbms_lob.getlength(l_file));',
'  sys.htp.p(''content-disposition: filename="'' || :app_object_name || ''"'');',
'  sys.owa_util.http_header_close;',
'  sys.wpg_docload.download_file(l_file);',
'',
'  apex_application.stop_apex_engine;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'USER_IS_NOT_PUBLIC_USER'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>44322313387035
);
wwv_flow_imp.component_end;
end;
/
