prompt --application/shared_components/logic/application_items/app_object_name
begin
--   Manifest
--     APPLICATION ITEM: APP_OBJECT_NAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>11138133706382214
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DATAPREV'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(11477406153894096)
,p_name=>'APP_OBJECT_NAME'
,p_protection_level=>'S'
,p_version_scn=>44322312605625
);
wwv_flow_imp.component_end;
end;
/
