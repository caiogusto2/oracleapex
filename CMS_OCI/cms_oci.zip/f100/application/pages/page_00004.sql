prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7553740741214470
,p_default_application_id=>100
,p_default_id_offset=>7554970837234538
,p_default_owner=>'DEMO'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'API Key Form'
,p_alias=>'API-KEY-FORM'
,p_page_mode=>'MODAL'
,p_step_title=>'API Key Form'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31722956392314517)
,p_plug_name=>'API Key Form'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(26255427281929042)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    ID,',
'    NAME,',
'    DESCRIPTION,',
'    ''Read'' AS grant_type,',
'    ''Admin'' AS owner,',
'    ''email@example.com'' AS email,',
'    ''ALL PRIVILEGES'' AS privilegio,',
'    ''User Profile'' AS perfil',
'FROM ',
'    user_ords_clients;',
''))
,p_is_editable=>true
,p_edit_operations=>'i:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31742306744314626)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(26258217261929050)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(31742670553314627)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(31742306744314626)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(26395606577929488)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(31743996210314641)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(31742306744314626)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(26395606577929488)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P4_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(31744793396314644)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(31742306744314626)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(26395606577929488)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_condition=>'P4_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31522962289298943)
,p_name=>'P4_GRANT_TYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(31722956392314517)
,p_item_source_plug_id=>wwv_flow_imp.id(31722956392314517)
,p_source=>'GRANT_TYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31523124780298944)
,p_name=>'P4_OWNER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(31722956392314517)
,p_item_source_plug_id=>wwv_flow_imp.id(31722956392314517)
,p_source=>'OWNER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31523341437298946)
,p_name=>'P4_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(31722956392314517)
,p_item_source_plug_id=>wwv_flow_imp.id(31722956392314517)
,p_source=>'EMAIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31523385980298947)
,p_name=>'P4_PRIVILEGIO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(31722956392314517)
,p_item_source_plug_id=>wwv_flow_imp.id(31722956392314517)
,p_source=>'PRIVILEGIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31523463358298948)
,p_name=>'P4_PERFIL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(31722956392314517)
,p_item_source_plug_id=>wwv_flow_imp.id(31722956392314517)
,p_source=>'PERFIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31524151415298955)
,p_name=>'P4_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(31722956392314517)
,p_item_source_plug_id=>wwv_flow_imp.id(31722956392314517)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31524404115298957)
,p_name=>'P4_NOME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(31722956392314517)
,p_item_source_plug_id=>wwv_flow_imp.id(31722956392314517)
,p_prompt=>'Nome Client'
,p_source=>'NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_read_only_when=>'P4_ID'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(26393110057929474)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31524459862298958)
,p_name=>'P4_DESCRICAO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(31722956392314517)
,p_item_source_plug_id=>wwv_flow_imp.id(31722956392314517)
,p_prompt=>unistr('Descri\00E7\00E3o Client')
,p_source=>'DESCRIPTION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_read_only_when=>'P4_ID'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(26393110057929474)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(31523626628298949)
,p_computation_sequence=>10
,p_computation_item=>'P4_GRANT_TYPE'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'client_credentials'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(31523731859298950)
,p_computation_sequence=>20
,p_computation_item=>'P4_OWNER'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'CAIO OLIVEIRA'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(31523889777298952)
,p_computation_sequence=>30
,p_computation_item=>'P4_EMAIL'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'caio.oliveira@oracle.com'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(31524000484298953)
,p_computation_sequence=>40
,p_computation_item=>'P4_PRIVILEGIO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'customer_api_priv'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(31524088244298954)
,p_computation_sequence=>50
,p_computation_item=>'P4_PERFIL'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'cms_oci'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(31742837496314627)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(31742670553314627)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31743457206314637)
,p_event_id=>wwv_flow_imp.id(31742837496314627)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(31745573633314649)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Criar Client'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	oauth.create_client(',
'	p_name => :P4_NOME,',
'	p_grant_type => :P4_GRANT_TYPE,',
'	p_owner => :P4_OWNER,',
'	p_description => :P4_DESCRICAO,',
'	p_support_email => :P4_EMAIL,',
'	p_privilege_names => :P4_PRIVILEGIO',
');',
'',
'oauth.grant_client_role(',
'p_client_name => :P4_NOME,',
'p_role_name => :P4_PERFIL',
');',
'',
'commit;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(31744793396314644)
,p_internal_uid=>16671328734776910
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(31524254769298956)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Deletar Client'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  OAUTH.delete_client(',
'    p_name => :P4_NOME',
'  );',
'',
'  COMMIT;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(31743996210314641)
,p_internal_uid=>16450009870761217
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(31746020311314650)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>16671775412776911
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(31524900202298962)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(31722956392314517)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Highschoool'
,p_internal_uid=>16450655303761223
);
wwv_flow_imp.component_end;
end;
/
