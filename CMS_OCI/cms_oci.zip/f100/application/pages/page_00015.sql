prompt --application/pages/page_00015
begin
--   Manifest
--     PAGE: 00015
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7553740741214470
,p_default_application_id=>100
,p_default_id_offset=>7554970837234538
,p_default_owner=>'DEMO'
);
wwv_flow_imp_page.create_page(
 p_id=>15
,p_name=>'Selecione seu Arquivo'
,p_alias=>'STEP-1'
,p_page_mode=>'MODAL'
,p_step_title=>'Selecione seu Arquivo'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(26248697020929007)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'600'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27161427166325902)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(26255427281929042)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(27160527012325896)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(26391419793929466)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27161524941325903)
,p_plug_name=>'Selecione seu Arquivo'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(26255427281929042)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27161597197325903)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(26258217261929050)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(27163057181325916)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(27161597197325903)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(26395606577929488)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(27163395083325916)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(27161597197325903)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(26395677015929488)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Pr\00F3ximo')
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(27164967521325923)
,p_branch_name=>'Go To Page 17'
,p_branch_action=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.::P17_FILENAME:&P15_FILE_UPLOAD.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(27163395083325916)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27126497547207744)
,p_name=>'P15_FILE_UPLOAD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(27161524941325903)
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(26393110057929474)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_11=>'.csv'
,p_attribute_12=>'DROPZONE_BLOCK'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(27248806108908356)
,p_validation_name=>'Valida Qtde Colunas'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(SELECT COUNT(*)',
'FROM (',
'    SELECT REPLACE(column_name, '']'', ''_'') AS modified_column_name',
'    FROM TABLE(APEX_DATA_PARSER.GET_COLUMNS((',
'        SELECT APEX_DATA_PARSER.DISCOVER(',
'            p_content   => f.blob_content,',
'            p_file_name => f.name,',
'            p_max_rows  => 10',
'        ) AS profile_json',
'        FROM apex_application_temp_files f',
'        WHERE f.name = :P15_FILE_UPLOAD',
'    )))',
')) = 12'))
,p_validation2=>'SQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Erro no Arquivo: o arquivo n\00E3o cont\00E9m 12 colunas')
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(27248860806908357)
,p_validation_name=>'Valida Linha'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(SELECT',
'    JSON_VALUE(f.profile_json, ''$."parsed-rows"''            RETURNING NUMBER) - 1   AS rows_',
'FROM (',
'    SELECT',
'        f.name,',
'        f.mime_type,',
'        APEX_DATA_PARSER.DISCOVER (',
'            p_content           => f.blob_content,',
'            p_file_name         => f.name,',
'            p_max_rows          => 10',
'        )                       AS profile_json',
'    FROM apex_application_temp_files f',
'    WHERE f.name = :P15_FILE_UPLOAD',
') f) > 0'))
,p_validation2=>'SQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Erro no Arquivo: o arquivo n\00E3o cont\00E9m cabe\00E7alho, esta em branco ou n\00E3o possui registros')
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(27313729848537357)
,p_validation_name=>unistr('Valida Cabe\00E7alho')
,p_validation_sequence=>30
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(SELECT COUNT(*)',
'FROM (',
'    -- Generate the required column list',
'    SELECT column_value AS column_name FROM TABLE(',
'        SYS.ODCIVARCHAR2LIST(',
'            ''CPF'', ''NOME_COMPLETO'', ''RUA'', ''NUMERO'', ''COMPLEMENTO'', ',
'            ''CIDADE'', ''ESTADO'', ''PREPOSICAO'', ''DATA_ATUALIZACAO'', ',
'            ''CEP'', ''TELEFONE'', ''EMAIL''',
'        )',
'    )',
'    MINUS',
'    -- Extract column names from uploaded file',
'    SELECT REPLACE(column_name, '']'', ''_'') AS column_name',
'    FROM TABLE(APEX_DATA_PARSER.GET_COLUMNS((',
'        SELECT APEX_DATA_PARSER.DISCOVER(',
'            p_content   => f.blob_content,',
'            p_file_name => f.name,',
'            p_max_rows  => 10',
'        ) AS profile_json',
'        FROM apex_application_temp_files f',
'        WHERE f.name = :P15_FILE_UPLOAD',
'    )))',
') ) = 0'))
,p_validation2=>'SQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Erro no Arquivo: O arquivo possui alguma coluna fora do padr\00E3o estabelecido')
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(27163531022325916)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(27163057181325916)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(27164293505325920)
,p_event_id=>wwv_flow_imp.id(27163531022325916)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp.component_end;
end;
/
