prompt --application/pages/page_00017
begin
--   Manifest
--     PAGE: 00017
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7553740741214470
,p_default_application_id=>100
,p_default_id_offset=>7554970837234538
,p_default_owner=>'DEMO'
);
wwv_flow_imp_page.create_page(
 p_id=>17
,p_name=>unistr('Revis\00E3o Final')
,p_alias=>'STEP-3'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Revis\00E3o Final')
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(26248697020929007)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'600'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27170736729325943)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(26255427281929042)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(27160527012325896)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(26391419793929466)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27170796112325943)
,p_plug_name=>unistr('Revis\00E3o Final')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(26255427281929042)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27249677490908365)
,p_plug_name=>'Controle Upload'
,p_parent_plug_id=>wwv_flow_imp.id(27170796112325943)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(26321953793929234)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    id,',
'    nome_arquivo,',
'    url_os,',
'    status_processamento,',
'    tamanho_arquivo,',
'    data_upload,',
'    quem_fez_upload',
'from',
'    controle_upload'))
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27314003874537360)
,p_plug_name=>unistr('Informa\00E7\00F5es Gerais')
,p_parent_plug_id=>wwv_flow_imp.id(27170796112325943)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(26321953793929234)
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<h4>Revis\00E3o e Comunicado antes do Upload</h4>'),
'<br>',
'<ul>',
'    <li>O registro de timestamp foi adicionado ao nome do arquivo <strong>&P17_NAME.</strong></li>',
unistr('    <li>O arquivo informado ser\00E1 enviado com o novo nome <strong>&P17_NOME_ARQUIVO.</strong></li>'),
'</ul>',
'<br>',
'<p>',
'    Caso seja feito o upload do arquivo errado, delete o mesmo e realize o procedimento de upload novamente.',
'</p>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27170868996325943)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(26258217261929050)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(27172356667325948)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(27170868996325943)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(26395606577929488)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(27172539562325948)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(27170868996325943)
,p_button_name=>'UPLOAD'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(26395606577929488)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enviar Arquivo'
,p_button_position=>'NEXT'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(27172593503325948)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(27170868996325943)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(26394865684929484)
,p_button_image_alt=>'Voltar'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(27174153107325953)
,p_branch_name=>'Go To Page 15'
,p_branch_action=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(27172593503325948)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27249216552908360)
,p_name=>'P17_FILENAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(27170796112325943)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27249851626908367)
,p_name=>'P17_NOME_ARQUIVO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(27249677490908365)
,p_item_source_plug_id=>wwv_flow_imp.id(27249677490908365)
,p_source=>'NOME_ARQUIVO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27249971538908368)
,p_name=>'P17_URL_OS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(27249677490908365)
,p_item_source_plug_id=>wwv_flow_imp.id(27249677490908365)
,p_source=>'URL_OS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27250062793908369)
,p_name=>'P17_STATUS_PROCESSAMENTO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(27249677490908365)
,p_item_source_plug_id=>wwv_flow_imp.id(27249677490908365)
,p_source=>'STATUS_PROCESSAMENTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27250152125908370)
,p_name=>'P17_TAMANHO_ARQUIVO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(27249677490908365)
,p_item_source_plug_id=>wwv_flow_imp.id(27249677490908365)
,p_source=>'TAMANHO_ARQUIVO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27250343655908371)
,p_name=>'P17_DATA_UPLOAD'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(27249677490908365)
,p_item_source_plug_id=>wwv_flow_imp.id(27249677490908365)
,p_format_mask=>'DD/MM/YY HH24:MI'
,p_source=>'DATA_UPLOAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27250479727908373)
,p_name=>'P17_QUEM_FEZ_UPLOAD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(27249677490908365)
,p_item_source_plug_id=>wwv_flow_imp.id(27249677490908365)
,p_source=>'QUEM_FEZ_UPLOAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27250560449908374)
,p_name=>'P17_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(27249677490908365)
,p_item_source_plug_id=>wwv_flow_imp.id(27249677490908365)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27314107927537361)
,p_name=>'P17_NAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(27170796112325943)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    REGEXP_SUBSTR(:P17_FILENAME, ''[^/]+$'', 1, 1)  ',
'FROM DUAL;',
''))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(27250868594908377)
,p_computation_sequence=>10
,p_computation_item=>'P17_NOME_ARQUIVO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT TO_CHAR(CURRENT_TIMESTAMP, ''DDMMYYYYHH24MI'') || ''_'' || REGEXP_SUBSTR(:P17_FILENAME, ''[^/]+$'', 1, 1)  FROM DUAL;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(27250973698908378)
,p_computation_sequence=>20
,p_computation_item=>'P17_URL_OS'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    :LOCATION_URI || :P17_NOME_ARQUIVO',
'from',
'    dual'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(27251048859908379)
,p_computation_sequence=>30
,p_computation_item=>'P17_DATA_UPLOAD'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT TO_CHAR(CURRENT_TIMESTAMP, ''DD/MM/YY HH24:MI'') AS FORMATTED_TIMESTAMP FROM DUAL;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(27251184043908380)
,p_computation_sequence=>40
,p_computation_item=>'P17_TAMANHO_ARQUIVO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    --ROUND(',
'        DBMS_LOB.GETLENGTH(BLOB_CONTENT) ',
'    --    / (1024 * 1024), 2)',
'FROM apex_application_temp_files',
'where NAME = :P17_FILENAME;'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(27251311735908381)
,p_computation_sequence=>50
,p_computation_item=>'P17_STATUS_PROCESSAMENTO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'Enviado'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(27251522085908383)
,p_computation_sequence=>60
,p_computation_item=>'P17_QUEM_FEZ_UPLOAD'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'CAIO OLIVEIRA'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(27172817022325948)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(27172356667325948)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(27173577858325951)
,p_event_id=>wwv_flow_imp.id(27172817022325948)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(27251737857908385)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Execution Chain'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(27172539562325948)
,p_internal_uid=>12177492959370646
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(27174951036325955)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>12100706137788216
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(27249831086908366)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(27249677490908365)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize form Revis\00E3o Final')
,p_internal_uid=>12175586188370627
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(27251602770908384)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(27251737857908385)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Doc Upload'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for rec in (',
'        select * from apex_application_temp_files',
'        where name = :P17_FILENAME',
'  ) ',
'  loop',
'      dbms_cloud.put_object (',
'        credential_name => :CREDENTIAL_NAME,',
'        object_uri      => :P17_URL_OS,',
'        contents        => rec.blob_content);',
'  end loop;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Falha no upload do arquivo: Entre em contato com o administrador'
,p_internal_uid=>12177357872370645
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(27251787471908386)
,p_process_sequence=>30
,p_region_id=>wwv_flow_imp.id(27249677490908365)
,p_parent_process_id=>wwv_flow_imp.id(27251737857908385)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'DML Process'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_process_error_message=>unistr('Falha na inser\00E7\00E3o do registro em tabela: Entre em contato com o administrador')
,p_internal_uid=>12177542573370647
);
wwv_flow_imp.component_end;
end;
/
