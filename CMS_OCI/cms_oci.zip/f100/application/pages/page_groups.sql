prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7553740741214470
,p_default_application_id=>100
,p_default_id_offset=>7554970837234538
,p_default_owner=>'DEMO'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(26512302953930111)
,p_group_name=>'Administration'
);
wwv_flow_imp.component_end;
end;
/
