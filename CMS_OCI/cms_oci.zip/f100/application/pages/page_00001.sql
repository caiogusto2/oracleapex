prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7553740741214470
,p_default_application_id=>100
,p_default_id_offset=>7554970837234538
,p_default_owner=>'DEMO'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'CMS - OCI'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(26519808062930187)
,p_plug_name=>'CMS - OCI'
,p_title=>'CMS - OCI'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--featured'
,p_plug_template=>wwv_flow_imp.id(26288685812929140)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_plug_source=>unistr('Consulta e edi\00E7\00E3o de workloads')
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(26527072714044142)
,p_plug_name=>'Arquivos'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(26312165032929207)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    c.object_name,',
'    ROUND(c.bytes/1024/1024, 2) as "Tamanho (MB)",',
'    l.status_processamento as "Status Processamento",',
'    l.data_upload as "Data Upload",',
'    l.data_processamento as "Data Processamento",',
'    l.quem_fez_upload as "Quem fez o upload",',
'    ''Download'' as download_object,',
'    ''Delete'' as delete_object',
'FROM ',
'    dbms_cloud.list_objects(:CREDENTIAL_NAME,:LOCATION_URI) c, controle_upload l',
'where c.object_name = l.nome_arquivo',
'order by l.data_upload;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(26527186587044143)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_actions_menu=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DATAPREV'
,p_internal_uid=>11452941688506404
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(26530733709044178)
,p_db_column_name=>'OBJECT_NAME'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Nome Arquivo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(26527737018044148)
,p_db_column_name=>'DOWNLOAD_OBJECT'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Link Download'
,p_column_link=>'f?p=&APP_ID.:0:&SESSION.:APPLICATION_PROCESS=DOWNLOAD_OBJECT:&DEBUG.::APP_OBJECT_NAME:#OBJECT_NAME#'
,p_column_linktext=>'#DOWNLOAD_OBJECT#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(26528960703044161)
,p_db_column_name=>'DELETE_OBJECT'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Link Delete'
,p_column_link=>'javascript:void(null);'
,p_column_linktext=>'#DELETE_OBJECT#'
,p_column_link_attr=>'data-object="#OBJECT_NAME#" class="delete"'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(27312840139537348)
,p_db_column_name=>'Tamanho (MB)'
,p_display_order=>70
,p_column_identifier=>'O'
,p_column_label=>'Tamanho (MB)'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(27312858176537349)
,p_db_column_name=>'Status Processamento'
,p_display_order=>80
,p_column_identifier=>'P'
,p_column_label=>'Status Processamento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(27313029260537350)
,p_db_column_name=>'Data Upload'
,p_display_order=>90
,p_column_identifier=>'Q'
,p_column_label=>'Data Upload'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MON-YYYY HH24:MI'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(27313121228537351)
,p_db_column_name=>'Data Processamento'
,p_display_order=>100
,p_column_identifier=>'R'
,p_column_label=>'Data Processamento'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(27313210753537352)
,p_db_column_name=>'Quem fez o upload'
,p_display_order=>110
,p_column_identifier=>'S'
,p_column_label=>'Quem Fez O Upload'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(26535046121075391)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'114609'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'OBJECT_NAME:Tamanho (MB):Data Upload:Data Processamento:Status Processamento:Quem fez o upload:DOWNLOAD_OBJECT:DELETE_OBJECT:'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(27313252373537353)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(26527072714044142)
,p_button_name=>unistr('Instru\00E7\00F5es')
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--warning'
,p_button_template_id=>wwv_flow_imp.id(26395606577929488)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Instru\00E7\00F5es Template .csv')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(26527873227044150)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(26527072714044142)
,p_button_name=>'Upload'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(26395677015929488)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Upload'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:CR,15::'
,p_icon_css_classes=>'fa-cloud-upload'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(26529809769044169)
,p_name=>'P1_OBJECT_NAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(26527072714044142)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(26529847658044170)
,p_name=>'DELETE'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.delete'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26529986477044171)
,p_event_id=>wwv_flow_imp.id(26529847658044170)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
' $s(''P1_OBJECT_NAME'', $(this.triggeringElement).data(''object''));',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26530084323044172)
,p_event_id=>wwv_flow_imp.id(26529847658044170)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Tem certeza que deseja deletar o documento "&P1_OBJECT_NAME."?',
''))
,p_attribute_03=>'warning'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26530218114044173)
,p_event_id=>wwv_flow_imp.id(26529847658044170)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'Delete File on Cloud'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
' dbms_cloud.delete_object(',
'     credential_name => :CREDENTIAL_NAME,',
'     object_uri      => :LOCATION_URI || :P1_OBJECT_NAME);',
''))
,p_attribute_02=>'P1_OBJECT_NAME'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(27313831736537358)
,p_event_id=>wwv_flow_imp.id(26529847658044170)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'Update Tabela'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update ',
'    CONTROLE_UPLOAD',
'set ',
'    DATA_DELETOUARQUIVO = CURRENT_TIMESTAMP,',
'    QUEM_DELETOUARQUIVO = ''CAIO OLIVEIRA''',
'WHERE',
'    NOME_ARQUIVO = :P1_OBJECT_NAME;'))
,p_attribute_02=>'P1_OBJECT_NAME'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26530258263044174)
,p_event_id=>wwv_flow_imp.id(26529847658044170)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(26527072714044142)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(26594573359424177)
,p_name=>'Refresh'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(26527873227044150)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26594711548424178)
,p_event_id=>wwv_flow_imp.id(26594573359424177)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(26527072714044142)
);
wwv_flow_imp.component_end;
end;
/
