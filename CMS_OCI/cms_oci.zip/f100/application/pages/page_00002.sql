prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7553740741214470
,p_default_application_id=>100
,p_default_id_offset=>7554970837234538
,p_default_owner=>'DEMO'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>unistr('Instru\00E7\00F5es para cria\00E7\00E3o do arquivo .csv')
,p_alias=>unistr('INSTRU\00C7\00D5ES-ARQUIVO')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Instru\00E7\00F5es para cria\00E7\00E3o do arquivo .csv')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'1200px'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27314179742537362)
,p_plug_name=>unistr('Instru\00E7\00F5es Gerais')
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(26321953793929234)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<h4>Siga as instru\00E7\00F5es abaixo para elaborar seu arquivo <code>.csv</code> compat\00EDvel com esta ferramenta:</h4>'),
'',
'<ul>',
'    <li>O arquivo a ser enviado deve estar no formato <strong>.csv (UTF-8)</strong>.</li>',
unistr('    <li>O arquivo deve conter, na primeira linha, as seguintes colunas com cabe\00E7alhos definidos.</li>'),
'    <li>O arquivo deve conter pelo menos um registro para ser aceito pela ferramenta.</li>',
'    <li>',
unistr('        Voc\00EA pode baixar o '),
unistr('        <a href="#APP_FILES#template.csv" download>template.csv</a>, preencher com suas informa\00E7\00F5es, '),
unistr('        renomear o arquivo conforme necess\00E1rio e fazer o upload na ferramenta.'),
'    </li>',
'</ul>',
'',
'<h5>Exemplo de arquivo preenchido:</h5>',
'',
'<img src="#APP_FILES#exemplo01.png" alt="Exemplo de arquivo CSV preenchido" style="width: 100%; height: auto;">',
'<br>',
'',
'<h5>Como salvar o seu arquivo no excel para ter a compatibilidade com a ferramenta:</h5>',
'<img src="#APP_FILES#exemplo02.png" alt="Modo de salvamento no Excel" style="width: 100%; height: auto;">',
'<br>',
'<h4>Caso envie o arquivo errado, exclua-o e realize o upload novamente.</h4>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
