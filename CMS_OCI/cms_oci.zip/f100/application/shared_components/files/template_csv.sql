prompt --application/shared_components/files/template_csv
begin
--   Manifest
--     APP STATIC FILES: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7517532956292161
,p_default_application_id=>100
,p_default_id_offset=>7519274061303201
,p_default_owner=>'DEMO'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '4350463B4E4F4D455F434F4D504C45544F3B5255413B4E554D45524F3B434F4D504C454D454E544F3B4349444144453B45535441444F3B505245504F534943414F3B444154415F415455414C495A4143414F3B4345503B54454C45464F4E453B454D4149';
wwv_flow_imp.g_varchar2_table(2) := '4C0D0A';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(19781036563507375)
,p_file_name=>'template.csv'
,p_mime_type=>'text/csv'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
