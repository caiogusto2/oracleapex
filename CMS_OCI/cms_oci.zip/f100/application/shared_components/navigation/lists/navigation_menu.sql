prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7517532956292161
,p_default_application_id=>100
,p_default_id_offset=>7519274061303201
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(18664222887694360)
,p_name=>'Navigation Menu'
,p_list_status=>'PUBLIC'
,p_version_scn=>44341648759297
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(18963910118695637)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Upload Workloads'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-cloud-arrow-up'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(23769358236058711)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'API Keys'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-key'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'3'
);
wwv_flow_imp.component_end;
end;
/
