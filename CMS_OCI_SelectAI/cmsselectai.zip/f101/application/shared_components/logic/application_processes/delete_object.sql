prompt --application/shared_components/logic/application_processes/delete_object
begin
--   Manifest
--     APPLICATION PROCESS: DELETE_OBJECT
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>8803538852700265
,p_default_application_id=>101
,p_default_id_offset=>8804740466685515
,p_default_owner=>'SANDBOX'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(17551135933325737)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DELETE_OBJECT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    dbms_cloud.delete_object(',
'     credential_name => :CREDENTIAL_NAME,',
'     object_uri      => :LOCATION_URI || :APP_OBJECT_NAME);',
'--     apex_application.stop_apex_engine;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'USER_IS_NOT_PUBLIC_USER'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>45789328553559
);
wwv_flow_imp.component_end;
end;
/
