prompt --application/shared_components/user_interface/theme_style
begin
--   Manifest
--     THEME STYLE: 101
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>8803538852700265
,p_default_application_id=>101
,p_default_id_offset=>8804740466685515
,p_default_owner=>'SANDBOX'
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(17505469687455281)
,p_theme_id=>42
,p_name=>'CMS'
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/oracle-fonts/oraclesans-apex#MIN#.css?v=#APEX_VERSION#',
'#THEME_FILES#css/Redwood#MIN#.css?v=#APEX_VERSION#'))
,p_css_classes=>' rw-layout--fixed t-PageBody--scrollTitle rw-mode-header--dark rw-mode-nav--dark rw-mode-body-header--dark rw-pillar--ocean'
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Redwood-Theme.less'
,p_theme_roller_config=>'{"classes":["rw-layout--fixed t-PageBody--scrollTitle","rw-mode-header--dark","rw-mode-nav--dark","rw-mode-body-header--dark","rw-pillar--ocean"],"vars":{},"customCSS":"","useCustomLess":"N"}'
,p_theme_roller_output_file_url=>'#THEME_DB_FILES#8700729220769766.css'
,p_theme_roller_read_only=>false
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(43707186739762315)
,p_theme_id=>42
,p_name=>'dataprev'
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/oracle-fonts/oraclesans-apex#MIN#.css?v=#APEX_VERSION#',
'#THEME_FILES#css/Redwood#MIN#.css?v=#APEX_VERSION#'))
,p_css_classes=>' rw-pillar--pebble rw-layout--fixed t-PageBody--scrollTitle rw-mode-header--dark rw-mode-nav--dark rw-mode-body-header--dark rw-mode-body--dark'
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Redwood-Theme.less'
,p_theme_roller_config=>'{"classes":["rw-pillar--pebble","rw-layout--fixed t-PageBody--scrollTitle","rw-mode-header--dark","rw-mode-nav--dark","rw-mode-body-header--dark","rw-mode-body--dark"],"vars":{},"customCSS":"","useCustomLess":"N"}'
,p_theme_roller_output_file_url=>'#THEME_DB_FILES#11500633450724331.css'
,p_theme_roller_read_only=>false
);
wwv_flow_imp.component_end;
end;
/
