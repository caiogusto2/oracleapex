prompt --application/shared_components/navigation/lists/doc_upload
begin
--   Manifest
--     LIST: Doc Upload
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>8803538852700265
,p_default_application_id=>101
,p_default_id_offset=>8804740466685515
,p_default_owner=>'SANDBOX'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(44292835402826141)
,p_name=>'Doc Upload'
,p_list_status=>'PUBLIC'
,p_version_scn=>44328440423548
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(44294216068826148)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Upload Arquivos'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(44303527687826188)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>unistr('Revis\00E3o')
,p_list_item_link_target=>'f?p=&APP_ID.:17:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
