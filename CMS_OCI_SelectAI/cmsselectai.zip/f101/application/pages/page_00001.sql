prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>8803538852700265
,p_default_application_id=>101
,p_default_id_offset=>8804740466685515
,p_default_owner=>'SANDBOX'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'CMS - OCI'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.float{',
'  z-index:100;',
'  position:fixed;',
'  width:60px;',
'  height:60px;',
'  bottom:40px;',
'  right:40px;',
'  background-color: black;',
'  color:#FFF;',
'  border-radius:50px;',
'  text-align:center;',
'  box-shadow: 2px 2px 3px #999;',
'}',
'.my-float{',
'  margin-top:22px;',
'}',
'',
'.float-logoff {',
'  z-index: 100;',
'  position: absolute;',
'  top: 10px;  /* Position from the top */',
'  right: 10px; /* Position from the right */',
'  width: auto; /* Adjust width as needed */',
'  height: auto; /* Adjust height as needed */',
'  padding: 10px 20px; /* Add padding for better spacing */',
'  color: #FFF;',
'  text-align: center;',
'  border-radius: 5px; /* Optional: Slightly rounded corners */',
unistr('  background-color: transparent !important; /* \2705 ensures no background color */'),
'  /* background-color: black;  Removed */',
'  /* box-shadow: 2px 2px 3px #999;  Removed */',
'}',
'',
'.my-float-logoff {',
'  margin-top: 0; /* Remove unnecessary margin */',
'}',
'',
'.green {',
'    background-color: #f0fff0 !important; /* very light green */',
'    color: black;',
'}',
'',
'.red {',
'    background-color: #ffecec !important; /* very light red */',
'    color: black;',
'}',
'',
'.a-CardView {',
'  display: flex;',
'  flex-direction: column;',
'  height: 100%; /* ensures full height for consistent layout */',
'}',
'',
'.a-CardView-actions {',
'  margin-top: auto; /* pushes actions to the bottom of the card */',
'  padding-top: 0.5rem;',
'  border-top: 1px solid rgba(0,0,0,0.1); /* optional separator line */',
'}'))
,p_step_template=>2979075366320325194
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16996834286966162)
,p_plug_name=>'Arquivos - Cards'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc:t-CardsRegion--styleB'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2072724515482255512
,p_plug_display_sequence=>60
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    c.object_name,',
'    ROUND(c.bytes / 1024 / 1024, 2) AS "Tamanho (MB)",',
'    TO_CHAR(c.last_modified, ''DD/MM/YYYY'') AS "LAST_MODIFIED",',
'    ',
'    -- Count how many vector chunks are linked to this object',
'    (',
'        SELECT COUNT(*)',
'          FROM support$vectab v',
'         WHERE JSON_VALUE(v.attributes, ''$.object_name'') = c.object_name',
'    ) AS qtd_chunks,',
'    ',
'    -- Assign color dynamically for APEX cards or reports',
'    CASE ',
'        WHEN (',
'            SELECT COUNT(*)',
'              FROM support$vectab v',
'             WHERE JSON_VALUE(v.attributes, ''$.object_name'') = c.object_name',
'        ) > 0 THEN ''green''',
'        ELSE ''red''',
'    END AS card_color,',
'',
'    -- Assign color dynamically for APEX cards or reports',
'    CASE ',
'        WHEN (',
'            SELECT COUNT(*)',
'              FROM support$vectab v',
'             WHERE JSON_VALUE(v.attributes, ''$.object_name'') = c.object_name',
'        ) > 0 THEN ''Vetorizado''',
'        ELSE ''N Vetorizado''',
'    END AS status_vetorizacao,',
'    ',
'    ''Download'' AS download_object,',
'    ''Delete''   AS delete_object',
'    ',
'FROM ',
'    TABLE(dbms_cloud.list_objects(:CREDENTIAL_NAME, :LOCATION_URI)) c',
'ORDER BY ',
'    c.last_modified DESC;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(17536060013926422)
,p_region_id=>wwv_flow_imp.id(16996834286966162)
,p_layout_type=>'GRID'
,p_card_css_classes=>'&CARD_COLOR!ATTR.'
,p_title_adv_formatting=>false
,p_title_column_name=>'OBJECT_NAME'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>unistr('<h4 class="a-CardView-subTitle ">Modifica\00E7\00E3o: &LAST_MODIFIED. <br>Qtd Chunks: &QTD_CHUNKS. <br> Status Vetoriza\00E7\00E3o: &STATUS_VETORIZACAO.</h4>')
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'INITIALS'
,p_icon_class_column_name=>'OBJECT_NAME'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'OBJECT_NAME'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(17536195771926423)
,p_card_id=>wwv_flow_imp.id(17536060013926422)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>10
,p_label=>'Download'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:0:&SESSION.:APPLICATION_PROCESS=DOWNLOAD_OBJECT:&DEBUG.::APP_OBJECT_NAME:&OBJECT_NAME.'
,p_button_display_type=>'TEXT'
,p_is_hot=>true
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(17536280306926424)
,p_card_id=>wwv_flow_imp.id(17536060013926422)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>20
,p_label=>'Delete'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_link_attributes=>'data-action=delete data-value=&OBJECT_NAME.'
,p_button_display_type=>'TEXT'
,p_is_hot=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17538960127926451)
,p_plug_name=>'Como foi feita essa demo'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>50
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<!-- Edited HTML -->',
'<pre><code id="codeBlock" class="language-sql">',
'BEGIN',
'   DBMS_CLOUD.CREATE_CREDENTIAL (',
'       credential_name => ''OCIAI_CRED'',',
'       user_ocid       => ''ocid1.user...'',',
'       tenancy_ocid    => ''ocid1.tenancy...'',',
'       private_key     => ''pem_key'',',
'       fingerprint     => ''fingerprint''',
'   );',
'',
'   DBMS_CLOUD_AI.CREATE_PROFILE(',
'       ''GENAI_VECTOR'',',
'       ''{',
'           "provider": "oci",',
'           "credential_name": "OCIAI_CRED",',
'           "region": "sa-saopaulo-1",',
'           "model": "cohere.embed-multilingual-v3.0"',
'       }''',
'   );',
'',
'   DBMS_CLOUD_AI.CREATE_VECTOR_INDEX(',
'       index_name => ''support'',',
'       attributes => ''{',
'           "vector_db_provider": "oracle",',
'           "location": "https://objectstorage.sa-saopaulo-1.oraclecloud.com/n/your_namespace/b/your_bucket/o/",',
'           "profile_name": "GENAI_VECTOR",',
'           "vector_dimension": 1024,',
'           "vector_distance_metric": "cosine",',
'           "chunk_overlap": 50,',
'           "chunk_size": 450',
'       }''',
'   );',
'END;',
'/',
'</code></pre>',
'',
'<p>',
'  <a href="https://docs.oracle.com/en-us/iaas/Content/generative-ai/cohere-embed-multilingual-3.htm" target="_blank" rel="noopener noreferrer">',
unistr('    Link \2014 Documenta\00E7\00E3o do Modelo (cohere.embed-multilingual-v3.0)'),
'  </a>',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17539154737926453)
,p_plug_name=>'Botoes'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43652116453430432)
,p_plug_name=>'CMS - OCI'
,p_title=>'CMS - OCI'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--featured:t-HeroRegion--iconsCircle'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_plug_source=>unistr('Consulta e edi\00E7\00E3o de workloads')
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16996702876966161)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(43652116453430432)
,p_button_name=>'Logoff'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Logoff'
,p_button_redirect_url=>'&LOGOUT_URL.'
,p_button_css_classes=>'float-logoff my-float-logoff'
,p_icon_css_classes=>'fa-sign-out'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16995805055966152)
,p_button_sequence=>70
,p_button_name=>'AIAssistant'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'AIAssistant'
,p_button_redirect_url=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:CR,2::'
,p_button_css_classes=>'float my-float'
,p_icon_css_classes=>'fa-plus'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17539103274926452)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(17539154737926453)
,p_button_name=>'Refresh'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--gapBottom'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Refresh'
,p_button_position=>'DELETE'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17537486294926436)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(17539154737926453)
,p_button_name=>'Upload_Arquivo'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--gapBottom'
,p_button_template_id=>2082829544945815391
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Upload'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:CR,15::'
,p_icon_css_classes=>'fa-cloud-upload'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17537943636926441)
,p_name=>'P1_OBJECT_NAME'
,p_item_sequence=>80
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(17537541263926437)
,p_name=>'Refresh'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(17537486294926436)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17537810228926439)
,p_event_id=>wwv_flow_imp.id(17537541263926437)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(16996834286966162)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(17538540349926446)
,p_name=>'DELETE'
,p_event_sequence=>50
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'[data-action=''delete'']'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17538562074926447)
,p_event_id=>wwv_flow_imp.id(17538540349926446)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_OBJECT_NAME'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.dataset.value'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17538728257926448)
,p_event_id=>wwv_flow_imp.id(17538540349926446)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Tem certeza que deseja deletar o documento "&P1_OBJECT_NAME."?',
''))
,p_attribute_03=>'warning'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17538791023926449)
,p_event_id=>wwv_flow_imp.id(17538540349926446)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'Delete File on Cloud'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
' dbms_cloud.delete_object(',
'     credential_name => :CREDENTIAL_NAME,',
'     object_uri      => :LOCATION_URI || :P1_OBJECT_NAME);',
''))
,p_attribute_02=>'P1_OBJECT_NAME'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43662566653544419)
,p_event_id=>wwv_flow_imp.id(17538540349926446)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(16996834286966162)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
