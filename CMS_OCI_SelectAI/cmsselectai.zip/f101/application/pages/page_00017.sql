prompt --application/pages/page_00017
begin
--   Manifest
--     PAGE: 00017
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>8803538852700265
,p_default_application_id=>101
,p_default_id_offset=>8804740466685515
,p_default_owner=>'SANDBOX'
);
wwv_flow_imp_page.create_page(
 p_id=>17
,p_name=>unistr('Revis\00E3o Final')
,p_alias=>'STEP-3'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Revis\00E3o Final')
,p_autocomplete_on_off=>'OFF'
,p_step_template=>2121795032473542284
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'600'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(44303045119826188)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-WizardSteps--displayLabels'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(44292835402826141)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>2010149141494510257
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(44303104502826188)
,p_plug_name=>unistr('Revis\00E3o Final')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(44446312265037605)
,p_plug_name=>unistr('Informa\00E7\00F5es Gerais')
,p_parent_plug_id=>wwv_flow_imp.id(44303104502826188)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>60
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<h4>Revis\00E3o e Comunicado antes do Upload</h4>'),
'<br>',
'<ul>',
unistr('    <li>O arquivo de nome <strong>&P17_NOME_ARQUIVO.</strong> ser\00E1 enviado para o OCI Object Storage</li>'),
'</ul>',
'<br>',
'<p>',
'    Caso se arrependa do arquivo enviado, delete o mesmo e realize o procedimento de upload novamente.',
'</p>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(44303177386826188)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(44304665057826193)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(44303177386826188)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancelar'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(44304847952826193)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(44303177386826188)
,p_button_name=>'UPLOAD'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enviar Arquivo'
,p_button_position=>'NEXT'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(44304901893826193)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(44303177386826188)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Voltar'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(44306461497826198)
,p_branch_name=>'Go To Page 15'
,p_branch_action=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(44304901893826193)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44381524943408605)
,p_name=>'P17_FILENAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(44303104502826188)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44382160017408612)
,p_name=>'P17_NOME_ARQUIVO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(44303104502826188)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44382279929408613)
,p_name=>'P17_URL_OS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(44303104502826188)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44446416318037606)
,p_name=>'P17_NAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(44303104502826188)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    REGEXP_SUBSTR(:P17_FILENAME, ''[^/]+$'', 1, 1)  ',
'FROM DUAL;',
''))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(44383176985408622)
,p_computation_sequence=>10
,p_computation_item=>'P17_NOME_ARQUIVO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT REGEXP_SUBSTR(:P17_FILENAME, ''[^/]+$'', 1, 1)  FROM DUAL;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(44383282089408623)
,p_computation_sequence=>20
,p_computation_item=>'P17_URL_OS'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    :LOCATION_URI || :P17_NOME_ARQUIVO',
'from',
'    dual'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(44305125412826193)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(44304665057826193)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44305886248826196)
,p_event_id=>wwv_flow_imp.id(44305125412826193)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(44384046248408630)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Execution Chain'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(44304847952826193)
,p_internal_uid=>12177492959370646
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(44307259426826200)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>12100706137788216
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(44383911161408629)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(44384046248408630)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Doc Upload'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for rec in (',
'        select * from apex_application_temp_files',
'        where name = :P17_FILENAME',
'  ) ',
'  loop',
'      dbms_cloud.put_object (',
'        credential_name => :CREDENTIAL_NAME,',
'        object_uri      => :P17_URL_OS,',
'        contents        => rec.blob_content);',
'  end loop;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Falha no upload do arquivo: Entre em contato com o administrador'
,p_internal_uid=>12177357872370645
);
wwv_flow_imp.component_end;
end;
/
