prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>8803538852700265
,p_default_application_id=>101
,p_default_id_offset=>8804740466685515
,p_default_owner=>'SANDBOX'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Select AI + RAG'
,p_alias=>'AI-ASSISTANT'
,p_page_mode=>'MODAL'
,p_step_title=>'Select AI + RAG'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>1661186590416509825
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16995887107966153)
,p_plug_name=>'Pesquisar Documentos'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16996128707966155)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(16995887107966153)
,p_button_name=>'Submit'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Pesquisar'
,p_icon_css_classes=>'fa-search'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16996024962966154)
,p_name=>'P2_PROMPT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(16995887107966153)
,p_prompt=>'Qual a sua pergunta?'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'text_case', 'UPPER',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16996165034966156)
,p_name=>'P2_OUTPUT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(16995887107966153)
,p_prompt=>unistr('Output Final ap\00F3s GenAI')
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>10
,p_display_when=>'P2_PROMPT'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'Y',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(16996526918966159)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SelectAI'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_json_input    CLOB;',
'    l_json_response CLOB;',
'BEGIN',
'    -- Monta o JSON de entrada com o texto digitado no P2_PROMPT',
'    l_json_input := ''{"search_term": "'' || REPLACE(:P2_PROMPT, ''"'', ''\"'') || ''"}'';',
'',
'    -- Chama o procedimento que faz a busca e gera a resposta',
'    search_documents(',
'        l_json_input   => l_json_input,',
'        l_json_response => l_json_response',
'    );',
'',
'    -- Extrai apenas o campo "search_result" do JSON retornado',
'    :P2_OUTPUT := json_value(l_json_response, ''$.search_result'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>8191786452280644
);
wwv_flow_imp.component_end;
end;
/
