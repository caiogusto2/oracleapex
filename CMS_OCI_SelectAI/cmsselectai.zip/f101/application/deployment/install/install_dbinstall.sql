prompt --application/deployment/install/install_dbinstall
begin
--   Manifest
--     INSTALL: INSTALL-dbinstall
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>8803538852700265
,p_default_application_id=>101
,p_default_id_offset=>8804740466685515
,p_default_owner=>'SANDBOX'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(8814592298497063)
,p_install_id=>wwv_flow_imp.id(8813974475500412)
,p_name=>'dbinstall'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace PROCEDURE search_documents(',
'l_json_input in   CLOB,',
'l_json_response  out CLOB',
')',
'AS',
'l_json_obj      JSON_OBJECT_T;',
'l_json_arr      JSON_ARRAY_T;',
'l_json_arr_outer      JSON_ARRAY_T;',
'l_json_arr_inner      JSON_ARRAY_T;',
'v_arr      JSON_ARRAY_T;',
'l_response_text CLOB;',
'v_menu_str varchar2(200);',
'l_count number;',
'l_values apex_json.t_values;',
'search_term varchar2(4000);',
'search_result clob;',
'BEGIN',
'',
'select json_value(l_json_input,''$.search_term'') into search_term  from dual;',
'',
'apex_json.initialize_clob_output; ',
'search_result := dbms_cloud_ai.generate(',
'                                prompt => ''SELECT AI NARRATE ''||search_term,',
'                                profile_name => ''GENAI_VECTOR''',
'                               );',
'APEX_JSON.OPEN_OBJECT;',
' apex_json.write(''search_term'', search_term);',
' apex_json.write(''search_result'', search_result);',
'APEX_JSON.CLOSE_OBJECT;',
'',
'l_response_text := APEX_JSON.get_clob_output;',
'apex_json.free_output;',
'',
'        ',
'l_json_response := l_response_text;',
'END;',
'/ '))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(8814668922497059)
,p_script_id=>wwv_flow_imp.id(8814592298497063)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PROCEDURE'
,p_object_name=>'SEARCH_DOCUMENTS'
);
wwv_flow_imp.component_end;
end;
/
