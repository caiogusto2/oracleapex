prompt --workspace/remote_servers/jls5sznibkq_sa_vinhedo_1_functions_oci_oraclecloud_com
begin
--   Manifest
--     REMOTE SERVER: jls5sznibkq-sa-vinhedo-1-functions-oci-oraclecloud-com
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7697586261496936
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DEMO'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(18298503059003598)
,p_name=>'jls5sznibkq-sa-vinhedo-1-functions-oci-oraclecloud-com'
,p_static_id=>'jls5sznibkq_sa_vinhedo_1_functions_oci_oraclecloud_com'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('jls5sznibkq_sa_vinhedo_1_functions_oci_oraclecloud_com'),'https://jls5sznibkq.sa-vinhedo-1.functions.oci.oraclecloud.com')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('jls5sznibkq_sa_vinhedo_1_functions_oci_oraclecloud_com'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('jls5sznibkq_sa_vinhedo_1_functions_oci_oraclecloud_com'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('jls5sznibkq_sa_vinhedo_1_functions_oci_oraclecloud_com'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('jls5sznibkq_sa_vinhedo_1_functions_oci_oraclecloud_com'),'')
,p_prompt_on_install=>false
,p_ai_is_builder_service=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('jls5sznibkq_sa_vinhedo_1_functions_oci_oraclecloud_com'),'')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('jls5sznibkq_sa_vinhedo_1_functions_oci_oraclecloud_com'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('jls5sznibkq_sa_vinhedo_1_functions_oci_oraclecloud_com'),'')
);
wwv_flow_imp.component_end;
end;
/
