prompt --workspace/remote_servers/ocigenai
begin
--   Manifest
--     REMOTE SERVER: ocigenai
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7697586261496936
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DEMO'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(12898916381597365)
,p_name=>'ocigenai'
,p_static_id=>'ocigenai'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('ocigenai'),'https://inference.generativeai.sa-saopaulo-1.oci.oraclecloud.com')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('ocigenai'),'')
,p_server_type=>'GENERATIVE_AI'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('ocigenai'),'')
,p_credential_id=>wwv_flow_imp.id(8092296345229224)
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('ocigenai'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('ocigenai'),'')
,p_prompt_on_install=>true
,p_ai_provider_type=>'OCI_GENAI'
,p_ai_is_builder_service=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('ocigenai'),'')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('ocigenai'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('ocigenai'),'{'||wwv_flow.LF||
'  "compartmentId" : "ocid1.compartment.oc1..aaaaaaaacqt2kvaoyjexiops224rzriooevivs63hxhpzjxzwbvadqcgsfha",'||wwv_flow.LF||
'  "servingMode" :'||wwv_flow.LF||
'  {'||wwv_flow.LF||
'    "modelId" : "cohere.command-r-plus-08-2024",'||wwv_flow.LF||
'    "servingType" : "ON_DEMAND"'||wwv_flow.LF||
'  }'||wwv_flow.LF||
'}')
);
wwv_flow_imp.component_end;
end;
/
