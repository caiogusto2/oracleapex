prompt --application/deployment/install/install_dbinstall
begin
--   Manifest
--     INSTALL: INSTALL-DBInstall
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7697586261496936
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(32098572033563048)
,p_install_id=>wwv_flow_imp.id(31698790211552528)
,p_name=>'DBInstall'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  CREATE TABLE "DATASETS" ',
'   (	"DATASET_ID" NUMBER GENERATED ALWAYS AS IDENTITY MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  NOT NULL ENABLE, ',
'	"NOME_DATASET" VARCHAR2(100), ',
'	"REGISTRO_DATASET" DATE DEFAULT current_date, ',
'	"OCI_ENDPOINT" VARCHAR2(4000), ',
'	"PERFIL_ACESSO" VARCHAR2(500), ',
'	"METADATA" JSON, ',
'	"CLASSIFICACAOAI" VARCHAR2(4000), ',
'	 PRIMARY KEY ("DATASET_ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'create or replace FUNCTION get_apex_app_user',
'RETURN VARCHAR2',
'IS',
'    v_app_user VARCHAR2(100);',
'BEGIN',
'    v_app_user := SYS_CONTEXT(''APEX$SESSION'', ''APP_USER'');',
'    RETURN v_app_user;',
'END;',
'/',
' '))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(32098614793563083)
,p_script_id=>wwv_flow_imp.id(32098572033563048)
,p_object_owner=>'#OWNER#'
,p_object_type=>'FUNCTION'
,p_object_name=>'GET_APEX_APP_USER'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(32098877406563089)
,p_script_id=>wwv_flow_imp.id(32098572033563048)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'DATASETS'
);
wwv_flow_imp.component_end;
end;
/
