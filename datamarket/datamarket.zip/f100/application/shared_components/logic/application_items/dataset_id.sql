prompt --application/shared_components/logic/application_items/dataset_id
begin
--   Manifest
--     APPLICATION ITEM: DATASET_ID
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7697586261496936
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(8054412638226194)
,p_name=>'DATASET_ID'
,p_protection_level=>'B'
,p_version_scn=>44791052144101
);
wwv_flow_imp.component_end;
end;
/
