prompt --application/shared_components/logic/application_items/app_object_name
begin
--   Manifest
--     APPLICATION ITEM: APP_OBJECT_NAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7697586261496936
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(7996555144060218)
,p_name=>'APP_OBJECT_NAME'
,p_protection_level=>'S'
,p_version_scn=>44785588447071
);
wwv_flow_imp.component_end;
end;
/
