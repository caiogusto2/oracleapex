prompt --application/shared_components/logic/application_processes/download_file
begin
--   Manifest
--     APPLICATION PROCESS: Download_File
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7697586261496936
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(7998118339115171)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Download_File'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_file blob;',
'  l_mime_type varchar2(32767);',
'  l_endpoint varchar2(4000);',
'  l_nomedataset varchar2(200);',
'begin',
'',
'  select oci_endpoint, nome_dataset into l_endpoint, l_nomedataset from datasets where nome_dataset = :APP_OBJECT_NAME;',
'   ',
'  l_file := dbms_cloud.get_object(',
'    credential_name => ''CREDENCIALOS'',',
'    object_uri      => l_endpoint);',
'',
'  l_mime_type := ''text/csv'';',
'',
'  sys.htp.init;',
'  sys.owa_util.mime_header(l_mime_type, false);',
'  sys.htp.p(''content-length: '' || dbms_lob.getlength(l_file));',
'  sys.htp.p(''content-disposition: attachment; filename="'' || :APP_OBJECT_NAME || ''.csv'');',
'  sys.owa_util.http_header_close;',
'  sys.wpg_docload.download_file(l_file);',
'',
'  apex_application.stop_apex_engine;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'USER_IS_NOT_PUBLIC_USER'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>44828362372497
);
wwv_flow_imp.component_end;
end;
/
