prompt --application/shared_components/web_sources/analisar_csv_function01
begin
--   Manifest
--     WEB SOURCE: analisar-csv-function01
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7697586261496936
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(18299870103003620)
,p_name=>'analisar-csv-function01'
,p_static_id=>'analisar_csv_function01'
,p_web_source_type=>'NATIVE_OCI'
,p_data_profile_id=>wwv_flow_imp.id(18298717426003603)
,p_remote_server_id=>wwv_flow_imp.id(18298503059003598)
,p_url_path_prefix=>'/20181201/functions/ocid1.fnfunc.oc1.sa-vinhedo-1.aaaaaaaaqivulvoskzqlabyjc73isu62yjg4mjmtftm3lmhptvppq4oi5x5q/actions/invoke'
,p_credential_id=>wwv_flow_imp.id(8092296345229224)
,p_version_scn=>44828467590562
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(18300410349003653)
,p_web_src_module_id=>wwv_flow_imp.id(18299870103003620)
,p_operation=>'POST'
,p_url_pattern=>'.'
,p_request_body_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'  "file": "#MESSAGE#"',
'}'))
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(18499103434014829)
,p_web_src_module_id=>wwv_flow_imp.id(18299870103003620)
,p_web_src_operation_id=>wwv_flow_imp.id(18300410349003653)
,p_name=>'MESSAGE'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(18499529813015997)
,p_web_src_module_id=>wwv_flow_imp.id(18299870103003620)
,p_web_src_operation_id=>wwv_flow_imp.id(18300410349003653)
,p_name=>'RESPONSE'
,p_param_type=>'BODY'
,p_is_required=>false
,p_direction=>'OUT'
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(18499962237017732)
,p_web_src_module_id=>wwv_flow_imp.id(18299870103003620)
,p_web_src_operation_id=>wwv_flow_imp.id(18300410349003653)
,p_name=>'Content-Type'
,p_param_type=>'HEADER'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value=>'application/json'
,p_is_static=>true
);
wwv_flow_imp.component_end;
end;
/
