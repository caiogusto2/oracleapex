prompt --application/shared_components/security/app_access_control/ecommerce
begin
--   Manifest
--     ACL ROLE: ECOMMERCE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7697586261496936
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_acl_role(
 p_id=>wwv_flow_imp.id(8228621339989936)
,p_static_id=>'ECOMMERCE'
,p_name=>'ECOMMERCE'
,p_version_scn=>44791370731235
);
wwv_flow_imp.component_end;
end;
/
