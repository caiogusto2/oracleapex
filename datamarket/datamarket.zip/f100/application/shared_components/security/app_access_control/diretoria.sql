prompt --application/shared_components/security/app_access_control/diretoria
begin
--   Manifest
--     ACL ROLE: DIRETORIA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7697586261496936
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_acl_role(
 p_id=>wwv_flow_imp.id(8228811685990756)
,p_static_id=>'DIRETORIA'
,p_name=>'DIRETORIA'
,p_version_scn=>44791370735504
);
wwv_flow_imp.component_end;
end;
/
