SQL> 
SQL> -- Retrieve the user grants and DDLs
SQL> SELECT DBMS_METADATA.GET_DDL('USER', u.username) AS ddl
  2  FROM   dba_users u
  3  WHERE  u.username = :v_username
  4  UNION ALL
  5  SELECT DBMS_METADATA.GET_GRANTED_DDL('TABLESPACE_QUOTA', tq.username) AS ddl
  6  FROM   dba_ts_quotas tq
  7  WHERE  tq.username = :v_username
  8  UNION ALL
  9  SELECT DBMS_METADATA.GET_GRANTED_DDL('ROLE_GRANT', rp.grantee) AS ddl
 10  FROM   dba_role_privs rp
 11  WHERE  rp.grantee = :v_username
 12  UNION ALL
 13  SELECT DBMS_METADATA.GET_GRANTED_DDL('SYSTEM_GRANT', sp.grantee) AS ddl
 14  FROM   dba_sys_privs sp
 15  WHERE  sp.grantee = :v_username
 16  UNION ALL
 17  SELECT DBMS_METADATA.GET_GRANTED_DDL('OBJECT_GRANT', tp.grantee) AS ddl
 18  FROM   dba_tab_privs tp
 19  WHERE  tp.grantee = :v_username
 20  UNION ALL
 21  SELECT DBMS_METADATA.GET_GRANTED_DDL('DEFAULT_ROLE', rp.grantee) AS ddl
 22  FROM   dba_role_privs rp
 23  WHERE  rp.grantee = :v_username
 24    AND  rp.default_role = 'YES'
 25  UNION ALL
 26  SELECT TO_CLOB('/* Start profile creation script in case they are missing */') AS ddl
 27  FROM   dba_users u
 28  WHERE  u.username = :v_username
 29    AND  u.profile <> 'DEFAULT'
 30  UNION ALL
 31  SELECT DBMS_METADATA.GET_DDL('PROFILE', u.profile) AS ddl
 32  FROM   dba_users u
 33  WHERE  u.username = :v_username
 34    AND  u.profile <> 'DEFAULT'
 35  UNION ALL
 36  SELECT TO_CLOB('/* End profile creation script */') AS ddl
 37  FROM   dba_users u
 38  WHERE  u.username = :v_username
 39    AND  u.profile <> 'DEFAULT';

DDL                                                                             
--------------------------------------------------------------------------------
                                                                                
   CREATE USER "MARINHA" DEFAULT COLLATION "USING_NLS_COMP"                     
      DEFAULT TABLESPACE "DATA"                                                 
      TEMPORARY TABLESPACE "TEMP";                                              
                                                                                
                                                                                
   GRANT "GRAPH_DEVELOPER" TO "MARINHA";                                        
   GRANT "DWROLE" TO "MARINHA";                                                 
                                                                                
                                                                                
   GRANT "GRAPH_DEVELOPER" TO "MARINHA";                                        
   GRANT "DWROLE" TO "MARINHA";                                                 
                                                                                
                                                                                
  GRANT UNLIMITED TABLESPACE TO "MARINHA";                                      
                                                                                
                                                                                
  GRANT EXECUTE ON "C##CLOUD$SERVICE"."DBMS_CLOUD" TO "MARINHA";                
  GRANT EXECUTE ON "C##CLOUD$SERVICE"."DBMS_CLOUD_AI" TO "MARINHA";             
  GRANT READ ON DIRECTORY "VEC_DUMP" TO "MARINHA";                              
  GRANT WRITE ON DIRECTORY "VEC_DUMP" TO "MARINHA";                             
                                                                                
                                                                                
  GRANT EXECUTE ON "C##CLOUD$SERVICE"."DBMS_CLOUD" TO "MARINHA";                
  GRANT EXECUTE ON "C##CLOUD$SERVICE"."DBMS_CLOUD_AI" TO "MARINHA";             
  GRANT READ ON DIRECTORY "VEC_DUMP" TO "MARINHA";                              
  GRANT WRITE ON DIRECTORY "VEC_DUMP" TO "MARINHA";                             
                                                                                
                                                                                
  GRANT EXECUTE ON "C##CLOUD$SERVICE"."DBMS_CLOUD" TO "MARINHA";                
  GRANT EXECUTE ON "C##CLOUD$SERVICE"."DBMS_CLOUD_AI" TO "MARINHA";             
  GRANT READ ON DIRECTORY "VEC_DUMP" TO "MARINHA";                              
  GRANT WRITE ON DIRECTORY "VEC_DUMP" TO "MARINHA";                             
                                                                                
                                                                                
  GRANT EXECUTE ON "C##CLOUD$SERVICE"."DBMS_CLOUD" TO "MARINHA";                
  GRANT EXECUTE ON "C##CLOUD$SERVICE"."DBMS_CLOUD_AI" TO "MARINHA";             
  GRANT READ ON DIRECTORY "VEC_DUMP" TO "MARINHA";                              
  GRANT WRITE ON DIRECTORY "VEC_DUMP" TO "MARINHA";                             
                                                                                
                                                                                
   ALTER USER "MARINHA" DEFAULT ROLE "GRAPH_DEVELOPER", "DWROLE";               
                                                                                
                                                                                
   ALTER USER "MARINHA" DEFAULT ROLE "GRAPH_DEVELOPER", "DWROLE";               
                                                                                

10 rows selected.

SQL> 
SQL> SPOOL OFF;
