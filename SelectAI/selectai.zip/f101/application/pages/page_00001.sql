prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>8913349955741052
,p_default_application_id=>101
,p_default_id_offset=>8914865186760203
,p_default_owner=>'MOVIESTREAM'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'ADBChat'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'#APP_FILES#speechRecognition#MIN#.js'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Container Flex */',
'.t-Body-mainContent,',
'.t-Body-contentInner,',
'.t-Body-contentInner > .container,',
'.t-Body-contentInner > .container > .row,',
'.t-Body-contentInner > .container > .row > .col,',
'#PROMPTS,',
'#PROMPTS_TemplateComponent {',
'  display: flex;',
'  flex-grow: 1;',
'  flex-direction: column;',
'}',
'',
'.t-Body-mainContent {',
'  overflow: clip;',
'}',
'',
'.t-Body-contentInner {',
'  padding: 0;',
'}',
'',
'#PROMPTS_TemplateComponent {',
'  flex-shrink: 1;',
'}',
'',
'',
'/* Hide Footer */',
'.t-Footer {',
'  --ut-footer-padding-y: .5rem;',
'}',
'',
'.t-Footer-top,',
'.t-Footer-body {',
'  display: none;',
'}',
'',
'/* Prompt */',
'.a-TMV-altMessage {',
'  justify-content: center;',
'  display: flex;',
'  flex-direction: column;',
'}',
'',
'.a-TMV-altMessage-icon {',
'  display: none;',
'}',
'',
'',
'/* Question */',
'.sticky-Footer {',
'  --ut-field-padding-y: 0rem;',
'  --ut-field-padding-x: 0rem;',
'',
'  position: sticky;',
'  inset-inline: 0;',
'  inset-block-end: 0;',
'  background-color: #eeeae7;',
'  border-block-start: 1px solid #e6e6e6;',
'  flex-shrink: 0;',
'  flex-grow: 0;',
'}',
'',
'.sticky-Footer .t-Button--icon {',
'  --a-button-padding-y: .625rem;',
'  --a-button-icon-size: 1.5rem;',
'}',
'',
'.sticky-Footer .t-Button--icon .t-Icon {',
'  min-inline-size: var(--a-button-line-height, 1rem);',
'}',
'',
'.llm-recording {',
'  pointer-events: auto !important;',
'  cursor: pointer;',
'}',
'',
'.llm-recording:after {',
'  content: '''';',
'  display: block;',
'  position: absolute;',
'  block-size: 2rem;',
'  inline-size: 2rem;',
'  border-radius: .25rem;',
'}',
'',
'.llm-recording:hover:after {',
'  background-color: rgba(0, 0, 0, .1);',
'}'))
,p_step_template=>wwv_flow_imp.id(49875015454959905275)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(125371094513300490)
,p_plug_name=>'Prompts'
,p_region_name=>'PROMPTS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(49875026985506905281)
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       CONV_ID,',
'       PROMPT,',
'       RESPONSE,',
'       ASKED_ON,',
'       SHOWSQL,',
'       (case when RESPONSE is not null then ''CHAT'' ELSE NULL END) RESPONSE_TYPE',
'  from ADB_CHAT_PROMPTS',
' where CONV_ID = :P1_CONV_ID',
' order by ASKED_ON'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_LLM_CONVERSATION'
,p_ajax_items_to_submit=>'P1_CONV_ID'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_plug_query_no_data_found=>'No questions have been asked!'
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'ID', 'ID',
  'PROMPT', 'PROMPT',
  'RESPONSE_TYPE', 'RESPONSE_TYPE')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(118399031953115097)
,p_name=>'RESPONSE_TYPE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'RESPONSE_TYPE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(125371199447300491)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(125371289443300492)
,p_name=>'CONV_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CONV_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(125371409843300493)
,p_name=>'PROMPT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PROMPT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(125371439618300494)
,p_name=>'RESPONSE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'RESPONSE'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(125371542911300495)
,p_name=>'SHOWSQL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SHOWSQL'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(125371701280300496)
,p_name=>'ASKED_ON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ASKED_ON'
,p_data_type=>'TIMESTAMP'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(48323555768100564318)
,p_plug_name=>'Question'
,p_parent_plug_id=>wwv_flow_imp.id(125371094513300490)
,p_region_css_classes=>'sticky-Footer padding-md'
,p_region_template_options=>'#DEFAULT#:t-ItemContainer--alignStart:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(49875484499322905303)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(48323555586482564316)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(48323555768100564318)
,p_button_name=>'RUN'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_imp.id(49875564757827905338)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Run'
,p_button_position=>'BUTTON_END'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-send-o'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(122360008626354478)
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::P1_CONV_ID:&P1_CONV_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(119607574148477572)
,p_branch_action=>'f?p=&APP_ID.:20020:&SESSION.::&DEBUG.:::'
,p_branch_point=>'BEFORE_COMPUTATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'REQUEST_EQUALS_CONDITION'
,p_branch_condition=>'OPEN_AI_SETTINGS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(118399123978115098)
,p_name=>'P1_ASK_ADB'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(48323555768100564318)
,p_item_default=>'Y'
,p_prompt=>'Ask your database'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_field_template=>wwv_flow_imp.id(49875562926188905337)
,p_item_template_options=>'#DEFAULT#:margin-top-sm'
,p_help_text=>'By checking this box, your app will utilize your business data to provide answers to your questions. Uncheck this box to search the internet for general information.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122359252472354471)
,p_name=>'P1_CONV_ID'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48323555421586564315)
,p_name=>'P1_PROMPT'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(48323555768100564318)
,p_prompt=>'Prompt'
,p_placeholder=>'Ask a question'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_field_template=>wwv_flow_imp.id(49875562671583905336)
,p_item_icon_css_classes=>'fa-microphone llm-recording'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'Y',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(119607368764477570)
,p_name=>'Open AI Settings'
,p_event_sequence=>60
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'FUNCTION_BODY'
,p_display_when_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return APEX_UTIL.GET_PREFERENCE(       ',
'         p_preference => ''CLOUD_AI_PROFILE'',',
'            p_user       => :APP_USER) is null;'))
,p_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(119607456500477571)
,p_event_id=>wwv_flow_imp.id(119607368764477570)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'OPEN_AI_SETTINGS'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(122359432179354472)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create a Conversation'
,p_process_sql_clob=>'INSERT INTO ADB_CHAT_CONVERSATIONS (USERNAME, STARTED_ON) VALUES (:APP_USER, SYSTIMESTAMP) returning id into :P1_CONV_ID;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P1_CONV_ID'
,p_process_when_type=>'ITEM_IS_NULL'
,p_internal_uid=>7968697490642105
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(127060317470917972)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'AI Call'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    j_response JSON;',
'    j_profiles JSON;',
'    b_is_chat boolean;',
'    c_response clob;',
'    c_sql clob;',
'    l_has_summary number;',
'    l_prompt varchar2(4000);',
'    v_profile_name varchar2(100);',
'    v_summary_profile_name varchar2(100);',
'    l_profile_names user_cloud_ai_profiles.profile_name%type := lower(APEX_UTIL.GET_PREFERENCE(       ',
'         p_preference => ''CLOUD_AI_PROFILE'',',
'            p_user       => :APP_USER));',
'begin',
'',
'    -- Is this a chat or ask database?',
'    b_is_chat := case when upper(:P1_ASK_ADB) = ''Y'' then false else true end;',
'',
'    -- Get the AI profile for this prompt. It will choose from the list of profiles that were selected by the user',
'    v_profile_name:= ADB_CHAT.get_profile(',
'        profile_names => JSON(l_profile_names),',
'        prompt => :P1_PROMPT,',
'        is_chat => b_is_chat',
'    );',
'',
'    v_profile_name := UPPER(v_profile_name);',
'',
'    -- Generate response using prompt and profiles. If v_proifle_name is NULL, then generate will produce a nice error message.',
'    j_response:= ADB_CHAT.generate(',
'                profile_name => v_profile_name,',
'                prompt => :P1_PROMPT,',
'                is_chat => b_is_chat',
'            );',
'',
'    c_response := JSON_VALUE(j_response, ''$.response'' RETURNING CLOB);',
'    c_sql := JSON_VALUE(j_response, ''$.sql'' RETURNING CLOB);',
'',
'',
'    -- Generate a summary?',
'    select count(*)',
'    into l_has_summary',
'    from ADB_CHAT_CONVERSATIONS',
'    where id = :p1_conv_id ',
'      and summary is not null;',
'    ',
'',
'    if l_has_summary = 0 then',
'        -- Yes! Generate the summary b/c one does not exist.',
'        -- get a profile to generate the response. ',
'        v_summary_profile_name:= ADB_CHAT.get_profile(',
'                profile_names => JSON(l_profile_names),',
'                prompt => :P1_PROMPT,',
'                is_chat => true',
'            );',
'',
'        if v_summary_profile_name is null then',
'            l_prompt := ''Untitiled conversation'';            ',
'        else',
'            l_prompt := dbms_cloud_ai.generate(',
'                        prompt => ''Rewrite as a short title : ''||:P1_PROMPT,',
'                        action => ''chat'',',
'                        profile_name => v_summary_profile_name',
'                    );',
'',
'        end if;',
'        ',
'        update ADB_CHAT_CONVERSATIONS set summary = l_prompt',
'        where id = :p1_conv_id and summary is null;',
'    ',
'    end if;',
'',
'    insert into ADB_CHAT_PROMPTS (conv_id, profile_name, prompt, response, asked_on, showsql) ',
'    values (:p1_conv_id, v_profile_name, :p1_prompt, c_response, systimestamp, c_sql);',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>12669582782205605
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(125372346114300503)
,p_region_id=>wwv_flow_imp.id(125371094513300490)
,p_position_id=>wwv_flow_imp.id(125581181537643352)
,p_display_sequence=>10
,p_label=>'Explore'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:RR,2:P2_CURRENT_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_is_hot=>false
,p_show_as_disabled=>false
,p_condition_type=>'ITEM_IS_NOT_NULL'
,p_condition_expr1=>'SHOWSQL'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(125372534285300504)
,p_region_id=>wwv_flow_imp.id(125371094513300490)
,p_position_id=>wwv_flow_imp.id(125581181537643352)
,p_display_sequence=>20
,p_label=>'Explain'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::P3_CURRENT_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_is_hot=>false
,p_show_as_disabled=>false
,p_condition_type=>'ITEM_IS_NOT_NULL'
,p_condition_expr1=>'SHOWSQL'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp.component_end;
end;
/
