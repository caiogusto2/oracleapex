prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>8913349955741052
,p_default_application_id=>101
,p_default_id_offset=>8914865186760203
,p_default_owner=>'MOVIESTREAM'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Explore'
,p_alias=>'REPORT'
,p_step_title=>'Explore'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(141323423068649425)
,p_plug_name=>'Breadcrumb'
,p_region_sub_css_classes=>'u-textCenter'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(49875504558473905312)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(49874988904297905264)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(49875567090173905339)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(173290389004641646)
,p_plug_name=>'REPORT'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(49875482361924905303)
,p_plug_display_sequence=>10
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P2_SQL IS NULL THEN',
'RETURN Q''[select',
'       C001,',
'       C002,',
'       C003,',
'       C004,',
'       C005,',
'       N001,',
'       N002,',
'       N003,',
'       N004,',
'       N005,',
'       D001,',
'       D002,',
'       D003,',
'       D004,',
'       D005',
'  from APEX_COLLECTIONS]'';',
'  ELSE RETURN :P2_SQL;',
'  END IF;'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P2_VAR_COL_LABEL_1,P2_VAR_COL_LABEL_2,P2_VAR_COL_LABEL_3,P2_VAR_COL_LABEL_4,P2_VAR_COL_LABEL_5,P2_NUM_COL_LABEL_1,P2_NUM_COL_LABEL_2,P2_NUM_COL_LABEL_3,P2_NUM_COL_LABEL_4,P2_NUM_COL_LABEL_5,P2_DATE_COL_LABEL_1,P2_DATE_COL_LABEL_2,P2_DATE_COL_LABEL_3,'
||'P2_DATE_COL_LABEL_4,P2_DATE_COL_LABEL_5,P2_SQL'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'REPORT'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(122091572388409982)
,p_name=>'C001'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C001'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'&P2_VAR_COL_LABEL_1.'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>32767
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_VAR_COL_LABEL_1'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(122091738816409983)
,p_name=>'C002'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C002'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'&P2_VAR_COL_LABEL_2.'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>32767
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_VAR_COL_LABEL_2'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(122091758629409984)
,p_name=>'C003'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C003'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'&P2_VAR_COL_LABEL_3.'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>32767
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_VAR_COL_LABEL_3'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(122091885112409985)
,p_name=>'C004'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C004'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'&P2_VAR_COL_LABEL_4.'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>32767
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_VAR_COL_LABEL_4'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(122091961900409986)
,p_name=>'C005'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C005'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'&P2_VAR_COL_LABEL_5.'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>32767
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_VAR_COL_LABEL_5'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(122169508357521884)
,p_name=>'N001'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N001'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'&P2_NUM_COL_LABEL_1.'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>550
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_NUM_COL_LABEL_1'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(122169588766521885)
,p_name=>'N002'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N002'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'&P2_NUM_COL_LABEL_2.'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>560
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_NUM_COL_LABEL_2'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(122169743487521886)
,p_name=>'N003'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N003'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'&P2_NUM_COL_LABEL_3.'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>570
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_NUM_COL_LABEL_3'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(122169838730521887)
,p_name=>'N004'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N004'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'&P2_NUM_COL_LABEL_4.'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>580
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_NUM_COL_LABEL_4'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(122169938490521888)
,p_name=>'N005'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'N005'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'&P2_NUM_COL_LABEL_5.'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>590
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_NUM_COL_LABEL_5'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(122170041097521889)
,p_name=>'D001'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'D001'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'&P2_DATE_COL_LABEL_1.'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>600
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_DATE_COL_LABEL_1'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(122170109051521890)
,p_name=>'D002'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'D002'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'&P2_DATE_COL_LABEL_2.'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>610
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_DATE_COL_LABEL_2'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(122170234756521891)
,p_name=>'D003'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'D003'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'&P2_DATE_COL_LABEL_3.'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>620
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_DATE_COL_LABEL_3'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(122170323889521892)
,p_name=>'D004'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'D004'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'&P2_DATE_COL_LABEL_4.'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>630
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_DATE_COL_LABEL_4'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(122170394977521893)
,p_name=>'D005'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'D005'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'&P2_DATE_COL_LABEL_5.'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>640
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P2_DATE_COL_LABEL_5'
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(122091266866409979)
,p_internal_uid=>16663213184896630
,p_is_editable=>false
,p_lazy_loading=>true
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SET'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(122171971984524628)
,p_interactive_grid_id=>wwv_flow_imp.id(122091266866409979)
,p_static_id=>'167440'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(122172158209524628)
,p_report_id=>wwv_flow_imp.id(122171971984524628)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(122174485886524640)
,p_view_id=>wwv_flow_imp.id(122172158209524628)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(122091572388409982)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(122175426849524643)
,p_view_id=>wwv_flow_imp.id(122172158209524628)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(122091738816409983)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(122176183484524646)
,p_view_id=>wwv_flow_imp.id(122172158209524628)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(122091758629409984)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(122177070016524649)
,p_view_id=>wwv_flow_imp.id(122172158209524628)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(122091885112409985)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(122178042271524652)
,p_view_id=>wwv_flow_imp.id(122172158209524628)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(122091961900409986)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(122178927122524655)
,p_view_id=>wwv_flow_imp.id(122172158209524628)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(122169508357521884)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(122179771909524658)
,p_view_id=>wwv_flow_imp.id(122172158209524628)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(122169588766521885)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(122180665159524660)
,p_view_id=>wwv_flow_imp.id(122172158209524628)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(122169743487521886)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(122181578767524662)
,p_view_id=>wwv_flow_imp.id(122172158209524628)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(122169838730521887)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(122182498934524665)
,p_view_id=>wwv_flow_imp.id(122172158209524628)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(122169938490521888)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(122183366703524668)
,p_view_id=>wwv_flow_imp.id(122172158209524628)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(122170041097521889)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(122184327741524671)
,p_view_id=>wwv_flow_imp.id(122172158209524628)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(122170109051521890)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(122185180495524673)
,p_view_id=>wwv_flow_imp.id(122172158209524628)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(122170234756521891)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(122186124605524676)
,p_view_id=>wwv_flow_imp.id(122172158209524628)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(122170323889521892)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(122186989147524687)
,p_view_id=>wwv_flow_imp.id(122172158209524628)
,p_display_seq=>17
,p_column_id=>wwv_flow_imp.id(122170394977521893)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(121923178572205828)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(141323423068649425)
,p_button_name=>'CLOSE_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(49875564757827905338)
,p_button_image_alt=>'Close Report'
,p_button_position=>'UP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121893719936183591)
,p_name=>'P2_CURRENT_ID'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(173290389004641646)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122340764476216258)
,p_name=>'P2_SQL'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(173290389004641646)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(154739943295235303)
,p_name=>'P2_NUM_COL_LABEL_1'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(173290389004641646)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(154740029971235304)
,p_name=>'P2_NUM_COL_LABEL_2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(173290389004641646)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(154740131302235305)
,p_name=>'P2_NUM_COL_LABEL_3'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(173290389004641646)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(154740230686235306)
,p_name=>'P2_NUM_COL_LABEL_4'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(173290389004641646)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(154740308612235307)
,p_name=>'P2_NUM_COL_LABEL_5'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(173290389004641646)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(154740418457235308)
,p_name=>'P2_DATE_COL_LABEL_1'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(173290389004641646)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(154740563457235309)
,p_name=>'P2_DATE_COL_LABEL_2'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(173290389004641646)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(154740624798235310)
,p_name=>'P2_DATE_COL_LABEL_3'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(173290389004641646)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(154740708370235311)
,p_name=>'P2_DATE_COL_LABEL_4'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(173290389004641646)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(154740879874235312)
,p_name=>'P2_DATE_COL_LABEL_5'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(173290389004641646)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(176177977483075359)
,p_name=>'P2_COL_COUNT'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(173290389004641646)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(176476855699471477)
,p_name=>'P2_VAR_COL_LABEL_1'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(173290389004641646)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(176476966856471478)
,p_name=>'P2_VAR_COL_LABEL_2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(173290389004641646)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(176477065731471479)
,p_name=>'P2_VAR_COL_LABEL_3'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(173290389004641646)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(176477188136471480)
,p_name=>'P2_VAR_COL_LABEL_4'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(173290389004641646)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(176477209207471481)
,p_name=>'P2_VAR_COL_LABEL_5'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(173290389004641646)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(122091167374409978)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Init Items'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P2_VAR_COL_LABEL_1   := NULL;',
':P2_VAR_COL_LABEL_2   := null;  ',
':P2_VAR_COL_LABEL_3  := null;',
':P2_VAR_COL_LABEL_4  := null;',
':P2_VAR_COL_LABEL_5  := null;',
':P2_NUM_COL_LABEL_1  := null;',
':P2_NUM_COL_LABEL_2  := null;',
':P2_NUM_COL_LABEL_3  := null;',
':P2_NUM_COL_LABEL_4  := null;',
':P2_NUM_COL_LABEL_5  := null;',
':P2_DATE_COL_LABEL_1  := NULL; ',
':P2_DATE_COL_LABEL_2  := NULL; ',
':P2_DATE_COL_LABEL_3  := NULL; ',
':P2_DATE_COL_LABEL_4  := NULL; ',
':P2_DATE_COL_LABEL_5  := NULL;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>16663113692896629
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(121940009283205842)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Fill Collection'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_sql VARCHAR2(4000);',
'    l_cursor_id INTEGER;',
'    l_desc_tab dbms_sql.desc_tab;',
'    l_col_cnt   INTEGER;',
'    l_char_columns varchar2(4000);',
'    l_date_columns varchar2(4000);',
'    l_num_columns varchar2(4000);',
'    l_char_counter number := 0;',
'    l_num_counter number := 0;',
'    l_date_counter number := 0;',
'begin',
'',
' ',
'',
'',
'  SELECT showsql into l_sql from ADB_CHAT_PROMPTS where id = :P2_CURRENT_ID;',
'',
'   APEX_DEBUG.INFO(''INIT l_sql - ''||l_sql || '' id - ''||:P2_CURRENT_ID);',
'   begin',
'      APEX_COLLECTION.DELETE_COLLECTION(',
'            p_collection_name => ''RESPONSE_REPORT_JARVIS'') ;',
'    exception',
'    when others then ',
'        null;',
'    end;',
'',
'  l_cursor_id := DBMS_SQL.OPEN_CURSOR;',
'  dbms_sql.parse(l_cursor_id, l_sql, dbms_sql.native);',
'  dbms_sql.describe_columns(l_cursor_id, l_col_cnt, l_desc_tab);',
'',
'  :P2_COL_COUNT := l_col_cnt;',
'',
'  FOR i IN 1..l_col_cnt LOOP',
'',
'  IF  l_desc_tab(i).col_type = 1 then -- VARCHAR2',
'    l_char_counter := l_char_counter + 1;',
'    if l_char_counter > 5 then',
'        CONTINUE;',
'    end if;',
'    APEX_UTIL.SET_SESSION_STATE(''P2_VAR_COL_LABEL_''||l_char_counter, l_desc_tab(i).col_name, true); ',
'',
'    l_char_columns := l_char_columns || '',"''||l_desc_tab(i).col_name||''" AS C00''||l_char_counter;',
'',
'  ELSif l_desc_tab(i).col_type = 2 then -- NUMBER',
'    l_num_counter := l_num_counter + 1;',
'    if l_num_counter > 5 then',
'        CONTINUE;',
'    end if;',
'    APEX_UTIL.SET_SESSION_STATE(''P2_NUM_COL_LABEL_''||l_num_counter, l_desc_tab(i).col_name, true); ',
'APEX_DEBUG.INFO(''P2_NUM_COL_LABEL_''||l_num_counter ||''- ''||APEX_UTIL.gET_SESSION_STATE(''P2_NUM_COL_LABEL_''||l_num_counter));',
'    l_num_columns := l_num_columns || '',"''||l_desc_tab(i).col_name ||''" AS N00''||l_num_counter;',
'   ELSif l_desc_tab(i).col_type = 12 then -- DATE',
'    l_date_counter := l_date_counter + 1;',
'     if l_date_counter > 5 then',
'        CONTINUE;',
'    end if;',
'    APEX_UTIL.SET_SESSION_STATE(''P2_DATE_COL_LABEL_''||l_date_counter, l_desc_tab(i).col_name, true); ',
'',
'    l_date_columns := l_date_columns || '',"''||l_desc_tab(i).col_name||''" AS D00''||l_date_counter;',
'',
'  END IF;',
'',
'  ',
'',
'  ',
'  end loop;',
'',
'  ',
'',
'  if l_num_counter < 5 then ',
'    for i in l_num_counter +1..5 loop',
'        l_num_columns := l_num_columns ||'',null AS N00''||i;',
'    end loop;',
'  end if;',
'',
' if l_date_counter < 5 then ',
'    for i in l_date_counter+1..5 loop',
'        l_date_columns := l_date_columns ||'',null AS D00''||i;',
'    end loop;',
'  end if;',
'',
'',
'',
'  IF INSTR(l_CHAR_columns, '','') = 1 THEN ',
'    l_CHAR_columns := SUBSTR(l_CHAR_columns, 2);',
'  END IF;',
'',
'  IF INSTR(l_num_columns, '','') = 1 THEN ',
'    l_num_columns := SUBSTR(l_num_columns, 2);',
'  END IF;',
'',
' IF INSTR(l_date_columns, '','') = 1 THEN ',
'    l_date_columns := SUBSTR(l_date_columns, 2);',
'  END IF;',
'',
'',
'  APEX_DEBUG.INFO(''l_date_columns - ''||l_date_columns);',
'  APEX_DEBUG.INFO(''l_num_columns - ''||l_num_columns);',
'  APEX_DEBUG.INFO(''l_CHAR_columns - ''||l_CHAR_columns);',
'',
' ',
'  l_sql := ''SELECT '' || l_num_columns||',
'  (CASE WHEN l_date_columns is not null then '' , ''||l_date_columns',
'    else null end )||(CASE WHEN l_char_columns is not null then '' , ''||l_char_columns',
'    else null end ) ||'' FROM (''||l_sql||'' )'';',
'',
'  APEX_DEBUG.INFO(''l_sql - ''||l_sql);',
'',
'--   APEX_COLLECTION.CREATE_COLLECTION_FROM_QUERY2 (',
'--         p_collection_name => ''RESPONSE_REPORT_JARVIS'', ',
'--         p_query => l_sql,',
'--         p_generate_md5 => ''NO'');',
'',
':P2_SQL := l_sql;',
'',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>16511955601692493
);
wwv_flow_imp.component_end;
end;
/
