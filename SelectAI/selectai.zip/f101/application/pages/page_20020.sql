prompt --application/pages/page_20020
begin
--   Manifest
--     PAGE: 20020
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>8913349955741052
,p_default_application_id=>101
,p_default_id_offset=>8914865186760203
,p_default_owner=>'MOVIESTREAM'
);
wwv_flow_imp_page.create_page(
 p_id=>20020
,p_name=>'AI Settings'
,p_alias=>'AI-SETTINGS'
,p_page_mode=>'MODAL'
,p_step_title=>'AI Settings'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(124952046114045811)
,p_javascript_code_onload=>'apex.pwa.initPushSubscriptionPage();'
,p_step_template=>wwv_flow_imp.id(49874989663593905265)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_required_patch=>wwv_flow_imp.id(124952231786045818)
,p_protection_level=>'C'
,p_help_text=>'This page contains the settings for controlling push notification subscription for the current user.'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(135524107436403251)
,p_plug_name=>'Push Notifications'
,p_region_css_classes=>'a-pwaPush--subscriptionRegion'
,p_icon_css_classes=>'fa-bell-o'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--wizard:t-Alert--customIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark:t-Form--xlarge'
,p_plug_template=>wwv_flow_imp.id(49875020357004905277)
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>'Pick one or more subject areas to use as sources for your questions. Subject areas marked with [1] must selected individually. '
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(124962374652069822)
,p_button_sequence=>10
,p_button_name=>'BACK'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(49875565594478905338)
,p_button_image_alt=>'Settings'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:20000:&APP_SESSION.::&DEBUG.:::'
,p_button_css_classes=>'t-Button--inlineLink'
,p_icon_css_classes=>'fa-chevron-left'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(26035150444901476)
,p_name=>'P20020_SELECTION_ERROR_MESSAGE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(135524107436403251)
,p_item_default=>' '''''
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_column=>1
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(49875562771113905337)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(124964343371072919)
,p_name=>'P20020_SERVICE'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(135524107436403251)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Choose subject areas'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Clean up the user preference if nec. This can happen if a selected AI profile was deleted',
'-- only include valid profiles',
'DECLARE',
'    c_valid_profiles CLOB;',
'BEGIN    ',
'    c_valid_profiles := adb_chat.get_valid_profiles(',
'                            profile_names => APEX_UTIL.GET_PREFERENCE (      ',
'                                p_preference => ''CLOUD_AI_PROFILE'',',
'                                p_user       => :APP_USER)',
'                                );',
'',
'    APEX_UTIL.SET_PREFERENCE(        ',
'        p_preference => ''CLOUD_AI_PROFILE'',',
'        p_value      => c_valid_profiles,      ',
'        p_user       => :APP_USER);',
'',
'',
'    RETURN c_valid_profiles;',
'',
'END;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_SELECT_MANY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'  case when u.description is null then profile_name || '' [1]'' ',
'       else profile_name end as d , ',
'  profile_name r ',
'from user_cloud_ai_profiles u;'))
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(49875562926188905337)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'fetch_on_search', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0',
  'use_defaults', 'Y')).to_clob
,p_multi_value_type=>'JSON_ARRAY'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(124188370552484577)
,p_name=>'Set AI_SERVICE'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P20020_SERVICE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(124188437375484578)
,p_event_id=>wwv_flow_imp.id(124188370552484577)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  declare',
'    b_is_valid boolean;',
'  begin',
'    -- Need to validate the selection. In the case of a multiselect, all of the profiles must have a description',
'    -- associated with them. ',
'',
'    if :P20020_SERVICE is null then ',
'        :P20020_SELECTION_ERROR_MESSAGE := ''Please select a subject area.'';',
'    else',
'',
'        -- Call function that checks for a valid profile list',
'        b_is_valid := adb_chat.is_valid_profile_selection(selected_profile_names => JSON(:P20020_SERVICE));',
'',
'        if b_is_valid then',
'            -- clear the error field',
'            :P20020_SELECTION_ERROR_MESSAGE := '''';',
'            -- save the preference',
'            APEX_UTIL.SET_PREFERENCE(        ',
'                    p_preference => ''CLOUD_AI_PROFILE'',',
'                    p_value      => :P20020_SERVICE,      ',
'                    p_user       => :APP_USER); ',
'        else ',
'            -- failed. Clear out that selection.',
'            :P20020_SELECTION_ERROR_MESSAGE := ''* You tried to add a subject area that has no description associated with it. You can pick that subject area individually, or pick '' ||',
'                ''multiple subject areas that do not have a [1] next to the name. To fix this problem in the future, ask your Select AI admin to add a description to each of your AI profiles.'';',
'            :P20020_SERVICE := null;',
'        end if;',
'    end if;',
'  end;',
'  ',
'  '))
,p_attribute_02=>'P20020_SERVICE'
,p_attribute_03=>'P20020_SELECTION_ERROR_MESSAGE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(124962924656069825)
,p_name=>'Change P20020_ENABLE_PUSH'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P20020_ENABLE_PUSH'
,p_condition_element=>'P20020_ENABLE_PUSH'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Y'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(124963367669069827)
,p_event_id=>wwv_flow_imp.id(124962924656069825)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Subscribe to push notifications'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.pwa.subscribePushNotifications();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(124963892268069829)
,p_event_id=>wwv_flow_imp.id(124962924656069825)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Unsubscribe from push notifications'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.pwa.unsubscribePushNotifications();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(26035233634901477)
,p_name=>'ClearErrorMessage'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26035276092901478)
,p_event_id=>wwv_flow_imp.id(26035233634901477)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P20020_SELECTION_ERROR_MESSAGE'
);
wwv_flow_imp.component_end;
end;
/
