prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>8913349955741052
,p_default_application_id=>101
,p_default_id_offset=>8914865186760203
,p_default_owner=>'MOVIESTREAM'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Explain'
,p_alias=>'EXPLAIN'
,p_step_title=>'Explain'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pre {',
'  white-space: pre-wrap;',
'  white-space: -moz-pre-wrap;',
'  white-space: -pre-wrap;',
'  white-space: -o-pre-wrap;',
'  word-wrap: break-word;',
'  font-family: inherit;',
'  font-size: inherit;',
'}',
'.CodeMirror{',
'height : 35vh!important',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'25'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(121620012554372824)
,p_plug_name=>'Breadcrumb'
,p_region_sub_css_classes=>'u-textCenter'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(49875504558473905312)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(49874988904297905264)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(49875567090173905339)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(122170744529521896)
,p_plug_name=>'SQL'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(49875492193245905307)
,p_plug_display_sequence=>30
,p_plug_grid_column_css_classes=>'col-xxs-12 col-xs-12 col-sm-12 col-md-12'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(125202539657711870)
,p_plug_name=>'Explanation'
,p_region_template_options=>'#DEFAULT#:margin-top-none'
,p_plug_template=>wwv_flow_imp.id(49875025529997905280)
,p_plug_display_sequence=>40
,p_plug_grid_column_css_classes=>'col-xxs-12 col-xs-12 col-sm-12 col-md-12'
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_explanation clob;',
'    l_uses_vector_index number;',
'    l_return clob;',
'    l_prompt clob;',
'    l_showsql ADB_CHAT_PROMPTS.showsql%type;',
'    l_profile_names user_cloud_ai_profiles.profile_name%type := lower(APEX_UTIL.GET_PREFERENCE(       ',
'         p_preference => ''CLOUD_AI_PROFILE'',',
'            p_user       => :APP_USER));',
'    v_profile_name varchar2(100);',
'begin',
'',
'',
'    SELECT SHOWSQL INTO l_showsql FROM ADB_CHAT_PROMPTS WHERE ID = :P3_CURRENT_ID;',
'',
'    v_profile_name:= ADB_CHAT.get_profile(',
'        profile_names => JSON(l_profile_names),',
'        prompt => ''x'',',
'        is_chat => true',
'    );',
'',
'    -- You can''t get an explanation if the current model was changed to Vector Search',
'    SELECT count(*) ',
'    INTO l_uses_vector_index',
'    FROM user_cloud_ai_profile_attributes',
'    WHERE upper(profile_name) =  upper(v_profile_name)',
'      AND upper(attribute_name) = ''VECTOR_INDEX_NAME'';',
'',
'',
'    if l_uses_vector_index > 0 then',
'        l_return := ''<h3>Explanation: </h3><div><pre>',
'        Unable to generate an explanation.</pre></div>'';',
'',
'    else',
'    /*',
'        l_return := ''<h3>Explanation: </h3><div><pre>''||',
'            dbms_cloud_ai.generate(',
'                prompt => l_prompt,',
'                action => ''explainsql'',',
'                profile_name => l_profile_name)',
'        ||''</pre></div>'';',
'    */',
'        l_return := adb_chat.explain_sql (',
'            profile_name => v_profile_name,',
'            sqlquery => l_showsql',
'        );',
'    end if;',
'    ',
'    return l_return;',
'    ',
'',
'end;'))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P3_CURRENT_ID'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(121621517644377886)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(122170744529521896)
,p_button_name=>'UPDATE_SQL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--pillStart'
,p_button_template_id=>wwv_flow_imp.id(49875565454227905338)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Update SQL'
,p_button_position=>'CHANGE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(119610213736477598)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(121620012554372824)
,p_button_name=>'CLOSE_SQL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(49875564757827905338)
,p_button_image_alt=>'Close SQL'
,p_button_position=>'UP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(119610045021477596)
,p_name=>'P3_CURRENT_ID'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121620739538375970)
,p_name=>'P3_SQL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(122170744529521896)
,p_use_cache_before_default=>'NO'
,p_source=>'SELECT SHOWSQL FROM ADB_CHAT_PROMPTS WHERE ID = :P3_CURRENT_ID;'
,p_source_type=>'QUERY'
,p_display_as=>'PLUGIN_COM.APEXBYG.BLOGSPOT.CODEMIRROR'
,p_field_template=>wwv_flow_imp.id(49875562926188905337)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large:margin-bottom-sm'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'N')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(122170920011521898)
,p_validation_name=>'Check Valid SQL'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_cursor NUMBER := dbms_sql.open_cursor;',
'BEGIN',
'            DBMS_SQL.PARSE (l_cursor, :P3_SQL, DBMS_SQL.native);',
'            return null;',
'        EXCEPTION',
'            WHEN OTHERS THEN',
'                return sqlerrm;',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(122170627676521895)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'update SQL'
,p_process_sql_clob=>'update ADB_CHAT_PROMPTS set showsql = REPLACE(:P3_SQL,'';'') where id = :P3_CURRENT_ID;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'SQL Updated'
,p_internal_uid=>16742573995008546
);
wwv_flow_imp.component_end;
end;
/
