prompt --application/shared_components/navigation/lists/llm_conversations
begin
--   Manifest
--     LIST: LLM Conversations
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>8913349955741052
,p_default_application_id=>101
,p_default_id_offset=>8914865186760203
,p_default_owner=>'MOVIESTREAM'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(124153623447818788)
,p_name=>'LLM Conversations'
,p_list_type=>'SQL_QUERY'
,p_list_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1, ',
'    summary,',
'    APEX_PAGE.GET_URL(p_page => 1, p_items => ''P1_CONV_ID'', P_values => id), ',
'    case when :P1_CONV_ID = id then ''Y''else ''N'' end , ',
'    ''fa fa-comment-o'' as image from ADB_CHAT_conversations ',
'where ',
'    username = :app_user ',
'        and summary is not null order by STARTED_ON desc;'))
,p_list_status=>'PUBLIC'
,p_version_scn=>44299283788525
);
wwv_flow_imp.component_end;
end;
/
