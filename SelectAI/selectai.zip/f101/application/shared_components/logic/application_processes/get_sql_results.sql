prompt --application/shared_components/logic/application_processes/get_sql_results
begin
--   Manifest
--     APPLICATION PROCESS: GET_SQL_RESULTS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>8913349955741052
,p_default_application_id=>101
,p_default_id_offset=>8914865186760203
,p_default_owner=>'MOVIESTREAM'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(128150484157079474)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_SQL_RESULTS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_context apex_exec.t_context;',
'    l_sql VARCHAR2(4000);',
'begin',
'    SELECT showsql into l_sql from adb_chat_prompts where id = apex_application.g_x01;',
'    l_context := apex_exec.open_query_context( ',
'                     p_location   => apex_exec.c_location_local_db,',
'                     p_sql_query  => l_sql,',
'                     p_max_rows => 10,',
'                     p_total_row_count => true);',
'',
'   apex_json.open_object;',
'   apex_json.write(''id'',apex_application.g_x01 );',
'   apex_json.write(''totalRowCount'',apex_exec.get_total_row_count(l_context) );',
'   apex_json.write_context( p_name => ''results'', p_context => l_context, p_write_null=> true);',
'   apex_json.close_object;',
' end;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>44299283579003
);
wwv_flow_imp.component_end;
end;
/
