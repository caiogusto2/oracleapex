prompt --application/shared_components/web_sources/openai2
begin
--   Manifest
--     WEB SOURCE: OpenAI2
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>8913349955741052
,p_default_application_id=>101
,p_default_id_offset=>8914865186760203
,p_default_owner=>'MOVIESTREAM'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(124173074003050263)
,p_name=>'OpenAI2'
,p_static_id=>'openai2'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(124171640873050257)
,p_remote_server_id=>wwv_flow_imp.id(72224630919217958)
,p_url_path_prefix=>'v1/completions'
,p_credential_id=>wwv_flow_imp.id(72224291469217955)
,p_attribute_05=>'1'
,p_attribute_08=>'OFFSET'
,p_attribute_10=>'EQUALS'
,p_attribute_11=>'true'
,p_version_scn=>41807807648911
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(124173697825050268)
,p_web_src_module_id=>wwv_flow_imp.id(124173074003050263)
,p_name=>'Content-Type'
,p_param_type=>'HEADER'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value=>'application/json'
,p_is_static=>true
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(124173312000050265)
,p_web_src_module_id=>wwv_flow_imp.id(124173074003050263)
,p_operation=>'POST'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_request_body_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'"prompt":"#PROMPT#", "model":"text-davinci-003", "temperature":0.7,"max_tokens":2000',
'}'))
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
