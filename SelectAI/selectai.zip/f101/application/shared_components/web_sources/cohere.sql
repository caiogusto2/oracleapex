prompt --application/shared_components/web_sources/cohere
begin
--   Manifest
--     WEB SOURCE: Cohere
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>8913349955741052
,p_default_application_id=>101
,p_default_id_offset=>8914865186760203
,p_default_owner=>'MOVIESTREAM'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(49876974987932926037)
,p_name=>'Cohere'
,p_static_id=>'cohere'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(49876973877248926032)
,p_remote_server_id=>wwv_flow_imp.id(49825037123118161318)
,p_url_path_prefix=>'/v1/generate'
,p_credential_id=>wwv_flow_imp.id(50812519596113887632)
,p_attribute_05=>'1'
,p_attribute_08=>'OFFSET'
,p_attribute_10=>'EQUALS'
,p_attribute_11=>'true'
,p_version_scn=>41807807648974
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(49876975181190926037)
,p_web_src_module_id=>wwv_flow_imp.id(49876974987932926037)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(49876975557709926039)
,p_web_src_module_id=>wwv_flow_imp.id(49876974987932926037)
,p_operation=>'POST'
,p_url_pattern=>'.'
,p_request_body_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'      "model": "command",',
'      "prompt": "#PROMPT#",',
'      "max_tokens": 300,',
'      "temperature": 0.9,',
'      "k": 0,',
'      "stop_sequences": [],',
'      "return_likelihoods": "NONE"',
'    }'))
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(49878735597265931606)
,p_web_src_module_id=>wwv_flow_imp.id(49876974987932926037)
,p_web_src_operation_id=>wwv_flow_imp.id(49876975557709926039)
,p_name=>'PROMPT'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(49880274925063936399)
,p_web_src_module_id=>wwv_flow_imp.id(49876974987932926037)
,p_web_src_operation_id=>wwv_flow_imp.id(49876975557709926039)
,p_name=>'Content-Type'
,p_param_type=>'HEADER'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value=>'application/json'
,p_is_static=>true
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(49880284900547937480)
,p_web_src_module_id=>wwv_flow_imp.id(49876974987932926037)
,p_web_src_operation_id=>wwv_flow_imp.id(49876975557709926039)
,p_name=>'RESPONSE'
,p_param_type=>'BODY'
,p_is_required=>false
,p_direction=>'OUT'
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(49876976011520926040)
,p_web_src_module_id=>wwv_flow_imp.id(49876974987932926037)
,p_operation=>'PUT'
,p_database_operation=>'UPDATE'
,p_url_pattern=>'/:id'
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(49876976369724926040)
,p_web_src_module_id=>wwv_flow_imp.id(49876974987932926037)
,p_operation=>'DELETE'
,p_database_operation=>'DELETE'
,p_url_pattern=>'/:id'
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
