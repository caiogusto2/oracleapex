prompt --workspace/credentials/cohere_api_key
begin
--   Manifest
--     CREDENTIAL: Cohere API Key
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>8913349955741052
,p_default_application_id=>101
,p_default_id_offset=>8914865186760203
,p_default_owner=>'MOVIESTREAM'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(50812519596113887632)
,p_name=>'Cohere API Key'
,p_static_id=>'COHERE_API_KEY'
,p_authentication_type=>'HTTP_HEADER'
,p_prompt_on_install=>true
);
wwv_flow_imp.component_end;
end;
/
