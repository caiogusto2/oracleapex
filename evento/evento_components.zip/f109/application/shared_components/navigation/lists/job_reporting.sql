prompt --application/shared_components/navigation/lists/job_reporting
begin
--   Manifest
--     LIST: Job Reporting
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>26179492243556005
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'EVENTO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(28115096045715521)
,p_name=>'Job Reporting'
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_imp.id(28050201233715229)
,p_version_scn=>41983412698013
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(28115420583715522)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Job Reporting'
,p_list_item_link_target=>'f?p=&APP_ID.:10020:&APP_SESSION.::&DEBUG.:10020::'
,p_list_item_icon=>'fa-user-chart'
,p_list_text_01=>'View status and run details of jobs supporting this application'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
