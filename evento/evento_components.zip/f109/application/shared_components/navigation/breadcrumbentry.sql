prompt --application/shared_components/navigation/breadcrumbentry
begin
--   Manifest
--     BREADCRUMB ENTRY: 
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>26179492243556005
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'EVENTO'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(27267178704267220)
,p_menu_id=>wwv_flow_imp.id(27266932552267219)
,p_option_sequence=>10
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(27590994678359782)
,p_menu_id=>wwv_flow_imp.id(27266932552267219)
,p_option_sequence=>10
,p_short_name=>'Lista de Hands On Ativos'
,p_link=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
,p_page_id=>2
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(27620247598458452)
,p_menu_id=>wwv_flow_imp.id(27266932552267219)
,p_option_sequence=>10
,p_short_name=>'Clientes em Hands On Ativos'
,p_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
,p_page_id=>4
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(27976452152444353)
,p_menu_id=>wwv_flow_imp.id(27266932552267219)
,p_option_sequence=>10
,p_short_name=>'Landing Page'
,p_link=>'f?p=&APP_ID.:7:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>7
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(28042785800712222)
,p_menu_id=>wwv_flow_imp.id(27266932552267219)
,p_option_sequence=>10
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:10000:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(28305824131378305)
,p_menu_id=>wwv_flow_imp.id(27266932552267219)
,p_option_sequence=>10
,p_short_name=>'Lista Hands On - Completa'
,p_link=>'f?p=&APP_ID.:9:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>9
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(28312544856382081)
,p_menu_id=>wwv_flow_imp.id(27266932552267219)
,p_option_sequence=>10
,p_short_name=>'Lista Clientes - Completa'
,p_link=>'f?p=&APP_ID.:10:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10
);
wwv_flow_imp.component_end;
end;
/
