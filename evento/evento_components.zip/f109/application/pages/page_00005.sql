prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>26179492243556005
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'EVENTO'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>unistr('Inscri\00E7\00E3o')
,p_alias=>'CADASTRAR-CLIENTES'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Inscri\00E7\00E3o')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27600669603458373)
,p_plug_name=>unistr('Inscri\00E7\00E3o')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27303648107267339)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'		ID_CADASTRO,',
'    FK_HANDSON,',
'    DATACADASTRO,',
'    DATAEXPIRACAO,',
'    STATUS,',
'--    NOME,',
'--    SOBRENOME,',
'--    EMPRESA,',
'--    CARGO,',
'    TRIAL,',
'		ID_CRACHA,',
'		BRINDE',
'--	  EMAIL',
'  from CADASTRO'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27609059999458409)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27306410436267347)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(27609410880458410)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(27609059999458409)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27443898431267765)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(27610819213458416)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(27609059999458409)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger'
,p_button_template_id=>wwv_flow_imp.id(27443898431267765)
,p_button_image_alt=>'Deletar'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P5_ID_CADASTRO'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(27611266117458418)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(27609059999458409)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27443898431267765)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Salvar'
,p_button_position=>'NEXT'
,p_button_condition=>'P5_ID_CADASTRO'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(27611662356458419)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(27609059999458409)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27443898431267765)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Inscrever'
,p_button_position=>'NEXT'
,p_button_condition=>'P5_ID_CADASTRO'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24485253573541538)
,p_name=>'P5_EVENTO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(27600669603458373)
,p_prompt=>unistr('Qual \00E9 o evento que voc\00EA esta participando?')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>'SELECT DISTINCT EVENTO REQUEST, EVENTO DISPLAY FROM HANDSON WHERE STATUS = ''ATIVO'';'
,p_field_template=>wwv_flow_imp.id(27441340280267755)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24485769808541543)
,p_name=>'P5_DATAEXPIRACAO'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(27600669603458373)
,p_item_source_plug_id=>wwv_flow_imp.id(27600669603458373)
,p_format_mask=>'DD-MON-YYYY HH24:MI'
,p_source=>'DATAEXPIRACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27601086657458375)
,p_name=>'P5_ID_CADASTRO'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(27600669603458373)
,p_item_source_plug_id=>wwv_flow_imp.id(27600669603458373)
,p_source=>'ID_CADASTRO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27601412083458377)
,p_name=>'P5_FK_HANDSON'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(27600669603458373)
,p_item_source_plug_id=>wwv_flow_imp.id(27600669603458373)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'--	TITULO AS DISPLAY,',
'	ID_HANDSON AS REQUEST',
unistr('--	,''SESS\00C3O: '' || TO_CHAR(DATA, ''DD/MM HH24:MI'') || '' - '' || TITULO AS DISPLAY'),
'FROM',
'	HANDSON',
'WHERE ',
'	ID_HANDSON = :P5_ID_HANDSON',
'order by data;',
''))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>unistr('Pra qual hands on voc\00EA deseja se inscrever?')
,p_source=>'FK_HANDSON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'--	TITULO AS DISPLAY,',
unistr('    ''SESS\00C3O: '' || TO_CHAR(DATA, ''DD/MM HH24:MI'') || '' - '' || TITULO AS DISPLAY,'),
'	ID_HANDSON AS REQUEST',
'FROM',
'	HANDSON',
'WHERE ',
'	EVENTO = :P5_EVENTO',
'AND',
'	STATUS = ''ATIVO''',
'AND',
'	VAGAS = ''COM VAGAS''',
'order by data;',
''))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P5_EVENTO'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(27441340280267755)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_protection_level=>'S'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27602165418458383)
,p_name=>'P5_DATACADASTRO'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(27600669603458373)
,p_item_source_plug_id=>wwv_flow_imp.id(27600669603458373)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT TO_CHAR(CURRENT_TIMESTAMP, ''DD-MON-YYYY HH24:MI'') AS formatted_timestamp',
'FROM dual;'))
,p_item_default_type=>'SQL_QUERY'
,p_source=>'DATACADASTRO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27603633494458389)
,p_name=>'P5_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(27600669603458373)
,p_item_source_plug_id=>wwv_flow_imp.id(27600669603458373)
,p_item_default=>'ATIVO'
,p_prompt=>'Status'
,p_source=>'STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:ATIVO;ATIVO,INATIVO;INATIVO'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>'P5_ID_CADASTRO'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(27441340280267755)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27605688310458397)
,p_name=>'P5_TRIAL'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(27600669603458373)
,p_item_source_plug_id=>wwv_flow_imp.id(27600669603458373)
,p_prompt=>'Possui Ambiente de Trial Oracle?'
,p_source=>'TRIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>unistr('STATIC:SIM;SIM,N\00C3O;N\00C3O')
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(27441340280267755)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27658471187913413)
,p_name=>'P5_STATUSCREATE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(27600669603458373)
,p_item_source_plug_id=>wwv_flow_imp.id(27600669603458373)
,p_item_default=>'ATIVO'
,p_source=>'STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>'P5_ID_CADASTRO'
,p_display_when_type=>'ITEM_IS_NULL'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27661904533913448)
,p_name=>'P5_ID_CRACHA'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(27600669603458373)
,p_item_source_plug_id=>wwv_flow_imp.id(27600669603458373)
,p_prompt=>'Qual o ID da sua Credencial?'
,p_source=>'ID_CRACHA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_cMaxlength=>6
,p_field_template=>wwv_flow_imp.id(27441340280267755)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'0'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27662063612913449)
,p_name=>'P5_BRINDE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(27600669603458373)
,p_item_source_plug_id=>wwv_flow_imp.id(27600669603458373)
,p_prompt=>'Brinde'
,p_source=>'BRINDE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>unistr('STATIC:SIM;SIM,N\00C3O;N\00C3O')
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>'P5_ID_CADASTRO'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(27441340280267755)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27981234145446020)
,p_name=>'P5_IMAGEM'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(27600669603458373)
,p_prompt=>'Como descobrir o ID da minha credencial?'
,p_source=>'#APP_FILES#Presentation1.jpg'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_field_template=>wwv_flow_imp.id(27441340280267755)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--boldDisplay'
,p_attribute_01=>'URL'
,p_attribute_02=>'#APP_FILES#Presentation1.jpg'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28281298771948704)
,p_name=>'P5_ID_HANDSON'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(27600669603458373)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(28282421494948716)
,p_validation_name=>'NDECIMAL'
,p_validation_sequence=>10
,p_validation=>'P5_ID_CRACHA'
,p_validation2=>'.,,'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_NO_CHAR_IN_STRING2'
,p_error_message=>unistr('VALORES DECIMAIS N\00C3O S\00C3O ACEITOS')
,p_associated_item=>wwv_flow_imp.id(27661904533913448)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(27609509421458410)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(27609410880458410)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(27610323874458414)
,p_event_id=>wwv_flow_imp.id(27609509421458410)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(27658180750913410)
,p_name=>'STATUS'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P5_STATUS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(27658203544913411)
,p_event_id=>wwv_flow_imp.id(27658180750913410)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'INATIVO'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P5_DATAEXPIRACAO'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT TO_CHAR(CURRENT_TIMESTAMP, ''DD-MON-YYYY HH24:MI'') AS formatted_timestamp',
'FROM dual;'))
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P5_STATUS'
,p_client_condition_expression=>'INATIVO'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(27658337203913412)
,p_event_id=>wwv_flow_imp.id(27658180750913410)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'ATIVO'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P5_DATAEXPIRACAO'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P5_STATUS'
,p_client_condition_expression=>'ATIVO'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(27660160263913430)
,p_name=>'Desabilitar Status'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(27600669603458373)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_cond=>'P5_STATUS'
,p_display_when_cond2=>'INATIVO'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(27660203493913431)
,p_event_id=>wwv_flow_imp.id(27660160263913430)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P5_STATUS'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(27983969222446047)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Valida\00E7\00E3o')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_count NUMBER;',
'BEGIN',
'    -- Perform the SELECT query to count rows',
'--    SELECT COUNT(*)',
'--    INTO v_count',
'--    FROM CADASTRO c, handson h',
'--    WHERE c.id_cracha = :P5_ID_CRACHA',
'--    AND c.fk_handson = h.id_handson',
'--    AND c.status = ''ATIVO''',
'--    AND c.fk_handson = :P5_FK_HANDSON;',
'SELECT COUNT(*)',
'INTO v_count',
'FROM CADASTRO c, HANDSON h',
'WHERE c.id_cracha = :P5_ID_CRACHA',
'  AND c.fk_handson = h.id_handson',
'  AND h.titulo = (',
'      SELECT h.TITULO',
'      FROM HANDSON h ',
'	  	WHERE h.id_handson = :P5_FK_HANDSON',
'  );',
'',
'',
'',
'',
'    -- Check if any rows are returned',
'    IF v_count > 0 THEN',
'        -- Raise an error if rows are found',
'        RAISE_APPLICATION_ERROR(-20001, ''Error: Active registration found for this ID and Hands-on event.'');',
'    ELSE',
'        -- Output success message if no rows are found',
'        DBMS_OUTPUT.PUT_LINE(''OK: No active registration found.'');',
'    END IF;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>unistr('Voc\00EA j\00E1 se encontra cadastrado no handson ou j\00E1 fez essa sess\00E3o anteriormente')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>27983969222446047
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(27612454635458422)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(27600669603458373)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Cadastrar Clientes'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>27612454635458422
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(27659784777913426)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Calcular Inscritos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    -- Declare variables to hold the ID_HANDSON, QTDE_INSCRITOS, and POSICOES',
'    FOR rec IN (',
'        SELECT ',
'            H.ID_HANDSON,',
'            COUNT(C.ID_CADASTRO) AS QTDE_INSCRITOS,',
'            H.POSICOES',
'        FROM HANDSON H',
'        LEFT JOIN CADASTRO C ',
'            ON H.ID_HANDSON = C.FK_HANDSON ',
'            AND C.STATUS = ''ATIVO''',
'        WHERE H.STATUS = ''ATIVO''',
'        GROUP BY H.ID_HANDSON, H.POSICOES',
'    ) LOOP',
'        -- Update the INSCRITOS column with the count of active registrations',
'        UPDATE HANDSON',
'        SET INSCRITOS = rec.QTDE_INSCRITOS',
'        WHERE ID_HANDSON = rec.ID_HANDSON;',
'        ',
'        -- Perform the validation for POSICOES - QTDE_INSCRITOS',
'        IF (rec.POSICOES - rec.QTDE_INSCRITOS) <= 0 THEN',
'            -- If there are more registrants than available positions, set VAGAS to ''LOTADO''',
'            UPDATE HANDSON',
'            SET VAGAS = ''LOTADO''',
'            WHERE ID_HANDSON = rec.ID_HANDSON;',
'        ELSE',
'            -- Otherwise, set VAGAS to ''COM VAGAS''',
'            UPDATE HANDSON',
'            SET VAGAS = ''COM VAGAS''',
'            WHERE ID_HANDSON = rec.ID_HANDSON;',
'        END IF;',
'    END LOOP;',
'',
'    -- Commit the changes to the database',
'    COMMIT;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>unistr('Erro na Inscri\00E7\00E3o, Falar com Administrador!')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>unistr('Inscri\00E7\00E3o Efetuada com Sucesso!')
,p_internal_uid=>27659784777913426
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(27612839972458423)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>27612839972458423
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(27612090254458421)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(27600669603458373)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Cadastrar Clientes'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>27612090254458421
);
wwv_flow_imp.component_end;
end;
/
