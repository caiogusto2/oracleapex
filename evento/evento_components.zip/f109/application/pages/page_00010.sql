prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>26179492243556005
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'EVENTO'
);
wwv_flow_imp_page.create_page(
 p_id=>10
,p_name=>'Lista Clientes - Completa'
,p_alias=>'LISTA-CLIENTES-COMPLETA'
,p_step_title=>'Lista Clientes - Completa'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(27560179695268317)
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(55921077129840482)
,p_plug_name=>'Lista Clientes'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27360459694267504)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'	C.ID_CADASTRO,',
'  C.FK_HANDSON,',
'  C.DATACADASTRO,',
'--  C.DATAEXPIRACAO,',
'  C.STATUS,',
'--  C.NOME,',
'--  C.SOBRENOME,',
'--  C.EMPRESA,',
'--  C.CARGO,',
'  C.TRIAL,',
'  C.ID_CRACHA,',
'  C.BRINDE,',
'--  C.EMAIL,',
'	H.TITULO,',
'	H.EVENTO,',
'	H.DATA as sessao',
'  from ',
'  	CADASTRO C, ',
'		HANDSON H',
'  WHERE',
'  	C.FK_HANDSON = H.ID_HANDSON',
'	order by sessao desc;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Lista Clientes'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(55921150112840482)
,p_name=>'Lista Clientes'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_finder_drop_down=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:5:P5_ID_CADASTRO,P5_EVENTO,P5_FK_HANDSON:#ID_CADASTRO#,#EVENTO#,#FK_HANDSON#'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_owner=>'EVENTO'
,p_internal_uid=>55921150112840482
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55921844834840486)
,p_db_column_name=>'ID_CADASTRO'
,p_display_order=>0
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'Id Cadastro'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(52792626538923593)
,p_db_column_name=>'TITULO'
,p_display_order=>10
,p_column_identifier=>'M'
,p_column_label=>'Titulo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55925466152840499)
,p_db_column_name=>'TRIAL'
,p_display_order=>70
,p_column_identifier=>'J'
,p_column_label=>'Trial'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55922699536840489)
,p_db_column_name=>'DATACADASTRO'
,p_display_order=>80
,p_column_identifier=>'C'
,p_column_label=>'Data Cadastro'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55923439603840492)
,p_db_column_name=>'STATUS'
,p_display_order=>100
,p_column_identifier=>'E'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(52792694876923594)
,p_db_column_name=>'FK_HANDSON'
,p_display_order=>110
,p_column_identifier=>'N'
,p_column_label=>'Fk Handson'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(52792777263923595)
,p_db_column_name=>'EVENTO'
,p_display_order=>120
,p_column_identifier=>'O'
,p_column_label=>'Evento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55968971192295500)
,p_db_column_name=>'ID_CRACHA'
,p_display_order=>130
,p_column_identifier=>'P'
,p_column_label=>'Id Cracha'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55969103306295501)
,p_db_column_name=>'BRINDE'
,p_display_order=>140
,p_column_identifier=>'Q'
,p_column_label=>'Brinde'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(28284061048948732)
,p_db_column_name=>'SESSAO'
,p_display_order=>150
,p_column_identifier=>'R'
,p_column_label=>'Sessao'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(55930798155847611)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'276236'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'EVENTO:TITULO:ID_CRACHA:BRINDE:TRIAL:SESSAO:STATUS:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(55927592981840506)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27382621317267569)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(27266932552267219)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(27445492819267771)
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(28312886536382082)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(55921077129840482)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(28313335826382083)
,p_event_id=>wwv_flow_imp.id(28312886536382082)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(55921077129840482)
);
wwv_flow_imp.component_end;
end;
/
