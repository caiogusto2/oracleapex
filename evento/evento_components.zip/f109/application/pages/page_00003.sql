prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>26179492243556005
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'EVENTO'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Cadastrar Hands On'
,p_alias=>'CADASTRAR-HANDS-ON'
,p_page_mode=>'MODAL'
,p_step_title=>'Cadastrar Hands On'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27572005433359697)
,p_plug_name=>'Cadastrar Hands On'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27303648107267339)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'HANDSON'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27579726833359733)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27306410436267347)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(27580168454359734)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(27579726833359733)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27443898431267765)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(27581568669359740)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(27579726833359733)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27443898431267765)
,p_button_image_alt=>'Deletar'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P3_ID_HANDSON'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(27982864124446036)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(27579726833359733)
,p_button_name=>'CLONAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27443898431267765)
,p_button_image_alt=>'Clonar Hands On'
,p_button_position=>'NEXT'
,p_button_condition=>'P3_ID_HANDSON'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(27581943454359741)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(27579726833359733)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27443898431267765)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Alterar'
,p_button_position=>'NEXT'
,p_button_condition=>'P3_ID_HANDSON'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(27582380504359742)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(27579726833359733)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27443898431267765)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Criar'
,p_button_position=>'NEXT'
,p_button_condition=>'P3_ID_HANDSON'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27572367233359698)
,p_name=>'P3_ID_HANDSON'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(27572005433359697)
,p_item_source_plug_id=>wwv_flow_imp.id(27572005433359697)
,p_source=>'ID_HANDSON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27572758449359704)
,p_name=>'P3_TITULO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(27572005433359697)
,p_item_source_plug_id=>wwv_flow_imp.id(27572005433359697)
,p_prompt=>'Titulo'
,p_source=>'TITULO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>200
,p_field_template=>wwv_flow_imp.id(27441340280267755)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
,p_attribute_06=>'UPPER'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27573138903359706)
,p_name=>'P3_EVENTO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(27572005433359697)
,p_item_source_plug_id=>wwv_flow_imp.id(27572005433359697)
,p_prompt=>'Evento'
,p_source=>'EVENTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:TDC RGS 04/12/24;TDC RGS 04/12/24'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(27441340280267755)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27573556746359708)
,p_name=>'P3_DESCRICAO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(27572005433359697)
,p_item_source_plug_id=>wwv_flow_imp.id(27572005433359697)
,p_prompt=>'Descricao'
,p_source=>'DESCRICAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>32
,p_cMaxlength=>200
,p_cHeight=>3
,p_field_template=>wwv_flow_imp.id(27441340280267755)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27573992891359709)
,p_name=>'P3_POSICOES'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(27572005433359697)
,p_item_source_plug_id=>wwv_flow_imp.id(27572005433359697)
,p_prompt=>'Posicoes'
,p_source=>'POSICOES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(27441340280267755)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27574391842359711)
,p_name=>'P3_DATA'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(27572005433359697)
,p_item_source_plug_id=>wwv_flow_imp.id(27572005433359697)
,p_prompt=>'Data Hands On'
,p_format_mask=>'DD-MON-YYYY HH24:MI'
,p_source=>'DATA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(27441340280267755)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:TODAY-BUTTON'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27575105970359715)
,p_name=>'P3_MATERIAIS'
,p_source_data_type=>'BLOB'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(27572005433359697)
,p_item_source_plug_id=>wwv_flow_imp.id(27572005433359697)
,p_prompt=>'Materiais'
,p_source=>'MATERIAIS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>60
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(27441340280267755)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'DB_COLUMN'
,p_attribute_06=>'Y'
,p_attribute_08=>'attachment'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27575974587359718)
,p_name=>'P3_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(27572005433359697)
,p_item_source_plug_id=>wwv_flow_imp.id(27572005433359697)
,p_item_default=>'ATIVO'
,p_prompt=>'STATUS'
,p_source=>'STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:ATIVO;ATIVO,INATIVO;INATIVO'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(27441340280267755)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27576316176359719)
,p_name=>'P3_PALESTRANTES'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(27572005433359697)
,p_item_source_plug_id=>wwv_flow_imp.id(27572005433359697)
,p_prompt=>'Palestrantes'
,p_source=>'PALESTRANTES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>200
,p_field_template=>wwv_flow_imp.id(27441340280267755)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
,p_attribute_06=>'UPPER'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27661647606913445)
,p_name=>'P3_VAGAS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(27572005433359697)
,p_item_source_plug_id=>wwv_flow_imp.id(27572005433359697)
,p_item_default=>'COM VAGAS'
,p_source=>'VAGAS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27981756885446025)
,p_name=>'P3_INSCRITOS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(27572005433359697)
,p_item_source_plug_id=>wwv_flow_imp.id(27572005433359697)
,p_item_default=>'0'
,p_source=>'INSCRITOS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27982324298446031)
,p_name=>'P3_IMAGEM'
,p_source_data_type=>'BLOB'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(27572005433359697)
,p_item_source_plug_id=>wwv_flow_imp.id(27572005433359697)
,p_prompt=>'Imagem'
,p_source=>'IMAGEM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_IMAGE_UPLOAD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(27441340280267755)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'DB_COLUMN'
,p_attribute_02=>'MIME_TYPE'
,p_attribute_03=>'FILENAME'
,p_attribute_05=>'IMAGEM_LASTUPDATE'
,p_attribute_06=>'Y'
,p_attribute_12=>'DROPZONE_ICON'
,p_attribute_18=>'Y'
,p_attribute_19=>'1:1'
,p_attribute_23=>'AUTO'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(27574897397359714)
,p_validation_name=>'P3_DATA must be timestamp'
,p_validation_sequence=>50
,p_validation=>'P3_DATA'
,p_validation_type=>'ITEM_IS_TIMESTAMP'
,p_error_message=>'#LABEL# must be a valid timestamp.'
,p_associated_item=>wwv_flow_imp.id(27574391842359711)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(27580244067359734)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(27580168454359734)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(27581012557359738)
,p_event_id=>wwv_flow_imp.id(27580244067359734)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(27583145016359745)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(27572005433359697)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Cadastrar Hands On'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>27583145016359745
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(27984055602446048)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Calcular Inscritos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    -- Declare variables to hold the ID_HANDSON, QTDE_INSCRITOS, and POSICOES',
'    FOR rec IN (',
'        SELECT ',
'            H.ID_HANDSON,',
'            COUNT(C.ID_CADASTRO) AS QTDE_INSCRITOS,',
'            H.POSICOES',
'        FROM HANDSON H',
'        LEFT JOIN CADASTRO C ',
'            ON H.ID_HANDSON = C.FK_HANDSON ',
'            AND C.STATUS = ''ATIVO''',
'        WHERE H.STATUS = ''ATIVO''',
'        GROUP BY H.ID_HANDSON, H.POSICOES',
'    ) LOOP',
'        -- Update the INSCRITOS column with the count of active registrations',
'        UPDATE HANDSON',
'        SET INSCRITOS = rec.QTDE_INSCRITOS',
'        WHERE ID_HANDSON = rec.ID_HANDSON;',
'        ',
'        -- Perform the validation for POSICOES - QTDE_INSCRITOS',
'        IF (rec.POSICOES - rec.QTDE_INSCRITOS) <= 0 THEN',
'            -- If there are more registrants than available positions, set VAGAS to ''LOTADO''',
'            UPDATE HANDSON',
'            SET VAGAS = ''LOTADO''',
'            WHERE ID_HANDSON = rec.ID_HANDSON;',
'        ELSE',
'            -- Otherwise, set VAGAS to ''COM VAGAS''',
'            UPDATE HANDSON',
'            SET VAGAS = ''COM VAGAS''',
'            WHERE ID_HANDSON = rec.ID_HANDSON;',
'        END IF;',
'    END LOOP;',
'',
'    -- Commit the changes to the database',
'    COMMIT;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>27984055602446048
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(27583537979359746)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE,CLONAR'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>27583537979359746
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(27582790232359744)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(27572005433359697)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Cadastrar Hands On'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>27582790232359744
);
wwv_flow_imp.component_end;
end;
/
