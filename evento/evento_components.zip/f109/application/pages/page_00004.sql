prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>26179492243556005
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'EVENTO'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Lista Clientes'
,p_alias=>'LISTA-CLIENTES'
,p_step_title=>'Lista Clientes'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'22'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27620360841458452)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27382621317267569)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(27266932552267219)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(27445492819267771)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28281625451948708)
,p_plug_name=>'Pesquisar Clientes Cadastrados'
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(27370276013267532)
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(28281861030948710)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'N',
  'compact_numbers_threshold', '10000',
  'display_chart_for_top_n_values', '10',
  'show_charts', 'Y',
  'show_current_facets', 'N',
  'show_total_row_count', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28281861030948710)
,p_plug_name=>'Cards'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleB'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27310786183267359)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--select ',
'--	C.ID_CADASTRO,',
'--  C.FK_HANDSON,',
'--  C.DATACADASTRO,',
'--  C.STATUS,',
'--  C.TRIAL,',
'--  C.ID_CRACHA,',
'--  C.BRINDE,',
'--	H.TITULO,',
'--	H.EVENTO,',
'--	H.DATA,',
'--	TO_CHAR(H.DATA, ''DD-MM HH24:MI'') AS TESTE,',
unistr('--  ''Sess\00E3o: '' || TO_CHAR(H.DATA, ''DD-MM HH24:MI'') || '' | Handson: '' || h.titulo as sessaodata'),
'--  from ',
'--  	CADASTRO C, ',
'--		HANDSON H',
'--  WHERE',
'--  	C.FK_HANDSON = H.ID_HANDSON',
'--		AND C.STATUS = ''ATIVO''',
'--order by h.data;',
'',
'SELECT * FROM CADASTROHANDSON;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(28281907871948711)
,p_region_id=>wwv_flow_imp.id(28281861030948710)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>true
,p_title_html_expr=>'<h2><b>ID CRACHA: </b>&ID_CRACHA.</h2>'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>',
'<b>Evento:</b> &EVENTO.<br>',
'<b>Hands On:</b> &TITULO.<br>',
'<b>Brinde:</b> &BRINDE.<br>',
'<b>Trial:</b> &TRIAL.<br>',
unistr('<b>Sess\00E3o:</b> &DATA.'),
'</h3>'))
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(28282038100948712)
,p_card_id=>wwv_flow_imp.id(28281907871948711)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:5:P5_ID_CADASTRO,P5_EVENTO,P5_FK_HANDSON:&ID_CADASTRO.,&EVENTO.,&FK_HANDSON.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(27618713312458447)
,p_button_sequence=>10
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(27443898431267765)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Inscrever Novo'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:5:P5_EVENTO:TDC RGS 04/12/24'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28283199114948723)
,p_name=>'P4_CRACHA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(28281625451948708)
,p_prompt=>'ID CRACHA'
,p_source=>'ID_CRACHA'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_item_icon_css_classes=>'fa-badges'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>15
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>false
,p_fc_actions_filter=>false
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28791190335574013)
,p_name=>'P4_FK_HANDSON'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(28281625451948708)
,p_prompt=>unistr('Sess\00F5es')
,p_source=>'FK_HANDSON'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
unistr('    DISTINCT ''Sess\00E3o: '' || TO_CHAR(H.DATA, ''DD-MM HH24:MI'') || '' | Handson: '' || H.TITULO AS DISPLAY,'),
'    C.FK_HANDSON AS REQUEST',
'--	,H.DATA',
'FROM CADASTRO C',
'JOIN HANDSON H ON C.FK_HANDSON = H.ID_HANDSON',
'WHERE H.STATUS = ''ATIVO''',
'--ORDER BY H.DATA',
';',
''))
,p_item_icon_css_classes=>'fa-presentation'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>10
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>false
,p_fc_actions_filter=>false
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(27619061237458448)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(28281861030948710)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(27619526552458449)
,p_event_id=>wwv_flow_imp.id(27619061237458448)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(28281861030948710)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(28282902381948721)
,p_name=>'Edit Report - Dialog Closed V1'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(27618713312458447)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(28283057563948722)
,p_event_id=>wwv_flow_imp.id(28282902381948721)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(28281861030948710)
);
wwv_flow_imp.component_end;
end;
/
