prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>10289753147261904
,p_default_application_id=>104
,p_default_id_offset=>10290911905224747
,p_default_owner=>'PORTO'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Cadastrar Dataset'
,p_alias=>'CADASTRAR-DATASET'
,p_page_mode=>'MODAL'
,p_step_title=>'Cadastrar Dataset'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>1661186590416509825
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10390641100245416)
,p_plug_name=>'Cadastrar Dataset'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DATASET_ID,',
'       NOME_DATASET,',
'       LINK_OAC,',
'       TABELA_DB,',
'       DESCRICAO_AI,',
'       PERFIL_FK,',
'       DATA_CADASTRO,',
'       OAC_PRINTSCREEN,',
'       OAC_PRINTNOME,',
'       OAC_PRINTMIMETYPE,',
'       OAC_PRINTDATE',
'  from DATASET'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10395450385245363)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10395811997245362)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10395450385245363)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10398036471245351)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(10395450385245363)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P3_DATASET_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10391062174245413)
,p_name=>'P3_DATASET_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10390641100245416)
,p_item_source_plug_id=>wwv_flow_imp.id(10390641100245416)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Dataset Id'
,p_source=>'DATASET_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10391443577245397)
,p_name=>'P3_NOME_DATASET'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(10390641100245416)
,p_item_source_plug_id=>wwv_flow_imp.id(10390641100245416)
,p_prompt=>'Nome Dataset'
,p_source=>'NOME_DATASET'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>400
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10391813056245393)
,p_name=>'P3_LINK_OAC'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(10390641100245416)
,p_item_source_plug_id=>wwv_flow_imp.id(10390641100245416)
,p_prompt=>'URL OAC (Colocar https://)'
,p_source=>'LINK_OAC'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>2
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10392284865245391)
,p_name=>'P3_TABELA_DB'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(10390641100245416)
,p_item_source_plug_id=>wwv_flow_imp.id(10390641100245416)
,p_prompt=>'Tabela DB'
,p_source=>'TABELA_DB'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select table_name as request, table_name as display from user_tables',
'where table_name not in (''DATASET'',''PERFIL'') '))
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10392646541245390)
,p_name=>'P3_DESCRICAO_AI'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(10390641100245416)
,p_item_source_plug_id=>wwv_flow_imp.id(10390641100245416)
,p_source=>'DESCRICAO_AI'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10392931526245388)
,p_name=>'P3_PERFIL_FK'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(10390641100245416)
,p_item_source_plug_id=>wwv_flow_imp.id(10390641100245416)
,p_prompt=>'Perfil'
,p_source=>'PERFIL_FK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT NOME_PERFIL, PERFIL_ID FROM PERFIL;'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10404571496170104)
,p_name=>'P3_OUTPUTAI'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10404790143170106)
,p_name=>'P3_DATA_CADASTRO'
,p_source_data_type=>'DATE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(10390641100245416)
,p_item_source_plug_id=>wwv_flow_imp.id(10390641100245416)
,p_item_default=>'select current_date from dual;'
,p_item_default_type=>'SQL_QUERY'
,p_source=>'DATA_CADASTRO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10405543340170114)
,p_name=>'P3_OAC_PRINTSCREEN'
,p_source_data_type=>'BLOB'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(10390641100245416)
,p_item_source_plug_id=>wwv_flow_imp.id(10390641100245416)
,p_prompt=>'Imagem'
,p_source=>'OAC_PRINTSCREEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_IMAGE_UPLOAD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_cropping', 'N',
  'blob_last_updated_column', 'OAC_PRINTDATE',
  'display_as', 'DROPZONE_BLOCK',
  'display_download_link', 'N',
  'filename_column', 'OAC_PRINTNOME',
  'mime_type_column', 'OAC_PRINTMIMETYPE',
  'storage_type', 'DB_COLUMN')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10405633619170115)
,p_name=>'P3_OAC_PRINTNOME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(10390641100245416)
,p_item_source_plug_id=>wwv_flow_imp.id(10390641100245416)
,p_source=>'OAC_PRINTNOME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10405756238170116)
,p_name=>'P3_OAC_PRINTMIMETYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(10390641100245416)
,p_item_source_plug_id=>wwv_flow_imp.id(10390641100245416)
,p_source=>'OAC_PRINTMIMETYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10405831848170117)
,p_name=>'P3_OAC_PRINTDATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(10390641100245416)
,p_item_source_plug_id=>wwv_flow_imp.id(10390641100245416)
,p_source=>'OAC_PRINTDATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10395940227245362)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(10395811997245362)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10396759864245356)
,p_event_id=>wwv_flow_imp.id(10395940227245362)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10309414621900647)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Execution_Chain'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>10309414621900647
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10399204902245341)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>10399204902245341
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10398495419245345)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(10390641100245416)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Cadastrar Dataset'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>10398495419245345
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10398818428245344)
,p_process_sequence=>10
,p_region_id=>wwv_flow_imp.id(10390641100245416)
,p_parent_process_id=>wwv_flow_imp.id(10309414621900647)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Cadastrar Dataset'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_internal_uid=>10398818428245344
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10309799201900650)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(10309414621900647)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'METADADOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_table_name   VARCHAR2(128) := UPPER(:P3_TABELA_DB);',
'    v_dataset_id   NUMBER := :P3_DATASET_ID;',
'    v_json_output  CLOB := '''';',
'    v_columns_json CLOB := '''';',
'BEGIN',
'    -- Gera o JSON do array de colunas separadamente',
'    SELECT JSON_ARRAYAGG(',
'             JSON_OBJECT(',
'                ''column_name''  VALUE c.column_name,',
'                ''data_type''    VALUE c.data_type,',
'                ''num_distinct'' VALUE c.num_distinct,',
'                ''density''      VALUE CASE ',
'                                      WHEN c.data_type = ''NUMBER'' THEN ROUND(c.density, 2)',
'                                      ELSE NULL ',
'                                    END,',
'                ''low_value''    VALUE CASE ',
'                                      WHEN c.data_type = ''NUMBER'' THEN ',
'                                          TO_CHAR(ROUND(UTL_RAW.CAST_TO_NUMBER(c.low_value), 2))',
'                                      ELSE NULL ',
'                                    END,',
'                ''high_value''   VALUE CASE ',
'                                      WHEN c.data_type = ''NUMBER'' THEN ',
'                                          TO_CHAR(ROUND(UTL_RAW.CAST_TO_NUMBER(c.high_value), 2))',
'                                      ELSE NULL ',
'                                    END,',
'                ''num_nulls''    VALUE c.num_nulls',
'             ) RETURNING CLOB',
'           )',
'    INTO v_columns_json',
'    FROM user_tab_columns c',
'    WHERE c.table_name = v_table_name;',
'',
'    -- Monta o JSON principal com dados do dataset, perfil e tabela',
'    SELECT JSON_OBJECT(',
'             ''dataset_id''     VALUE d.dataset_id,',
'             ''nome_dataset''   VALUE d.nome_dataset,',
'             ''link_oac''       VALUE d.link_oac,',
'             ''perfil''         VALUE JSON_OBJECT(',
'                                    ''perfil_id''    VALUE p.perfil_id,',
'                                    ''nome_perfil''  VALUE p.nome_perfil',
'                                ),',
'             ''table_name''     VALUE t.table_name,',
'             ''num_rows''       VALUE t.num_rows,',
'             ''column_count''   VALUE column_count',
'           RETURNING CLOB)',
'    INTO v_json_output',
'    FROM dataset d',
'    LEFT JOIN perfil p ON d.perfil_fk = p.perfil_id',
'    JOIN (',
'        SELECT ',
'            t.table_name, ',
'            t.num_rows, ',
'            COUNT(c.column_name) AS column_count',
'        FROM ',
'            user_tables t',
'        JOIN ',
'            user_tab_columns c ON t.table_name = c.table_name',
'        WHERE t.table_name = v_table_name',
'        GROUP BY ',
'            t.table_name, ',
'            t.num_rows',
'    ) t ON d.tabela_db = t.table_name',
'    WHERE d.dataset_id = v_dataset_id;',
'',
'    -- Junta o array de colunas ao JSON principal',
'    v_json_output := SUBSTR(v_json_output, 1, LENGTH(v_json_output)-1) || '', "columns": '' || v_columns_json || ''}'';',
'',
'    -- Atualiza a tabela com o JSON completo',
'    UPDATE dataset ',
'       SET metadados = v_json_output ',
'     WHERE dataset_id = v_dataset_id;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>10309799201900650
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10404250459170101)
,p_process_sequence=>30
,p_parent_process_id=>wwv_flow_imp.id(10309414621900647)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'GENAI_API'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(29590749230325283)
,p_web_src_operation_id=>wwv_flow_imp.id(29591368000325311)
,p_attribute_01=>'WEB_SOURCE'
,p_internal_uid=>10404250459170101
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(10404373337170102)
,p_page_id=>3
,p_web_src_param_id=>wwv_flow_imp.id(29790456047335030)
,p_page_process_id=>wwv_flow_imp.id(10404250459170101)
,p_value_type=>'SQL_QUERY'
,p_value=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
unistr('    ''Um arquivo JSON ser\00E1 compartilhado e nele haver\00E1 os metadados de uma tabela, '),
unistr('     crie um par\00E1grafo sem formata\00E7\00E3o com no m\00E1ximo 50 palavras descrevendo o dataset, n\00E3o mencionsar a quantidade de linhas no par\00E1grafo. JSON:'' || metadados || '';'' as mensagem'),
'from dataset',
'where dataset_id = :P3_DATASET_ID'))
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(10404478615170103)
,p_page_id=>3
,p_web_src_param_id=>wwv_flow_imp.id(29790825519336163)
,p_page_process_id=>wwv_flow_imp.id(10404250459170101)
,p_value_type=>'ITEM'
,p_value=>'P3_OUTPUTAI'
,p_ignore_output=>false
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10404880774170107)
,p_process_sequence=>40
,p_parent_process_id=>wwv_flow_imp.id(10309414621900647)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'JSONParse'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_json      VARCHAR2(32767) := :P3_OUTPUTAI;',
'    l_text      VARCHAR2(4000);',
'BEGIN',
'    -- Extract the text from the JSON',
'    SELECT jt.text',
'    INTO l_text',
'    FROM dual,',
'         JSON_TABLE(',
'             l_json,',
'             ''$.chatResponse'' COLUMNS (',
'                 text VARCHAR2(4000) PATH ''$.text''',
'             )',
'         ) jt;',
'',
'    -- Set the extracted text to P3_OUTPUT',
'    update dataset set DESCRICAO_AI = l_text where DATASET_ID = :P3_DATASET_ID;',
'    commit;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>10404880774170107
);
wwv_flow_imp.component_end;
end;
/
