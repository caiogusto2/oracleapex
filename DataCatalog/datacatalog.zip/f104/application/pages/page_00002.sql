prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>10289753147261904
,p_default_application_id=>104
,p_default_id_offset=>10290911905224747
,p_default_owner=>'PORTO'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Dataset Details'
,p_alias=>'DATASET-DETAILS'
,p_step_title=>'Dataset Details'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.floatlogoff {',
'  z-index: 100;',
'  position: absolute;',
'  top: 10px;  /* Position from the top */',
'  right: 10px; /* Position from the right */',
'  width: auto; /* Adjust width as needed */',
'  height: auto; /* Adjust height as needed */',
'  padding: 10px 20px; /* Add padding for better spacing */',
'  color: #FFF;',
'  text-align: center;',
'  border-radius: 5px; /* Optional: Slightly rounded corners */',
'  /* background-color: black;  Removed */',
'  /* box-shadow: 2px 2px 3px #999;  Removed */',
'}',
'',
'.my-floatlogoff {',
'  margin-top: 0; /* Remove unnecessary margin */',
'}'))
,p_step_template=>2979075366320325194
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10306590469900618)
,p_plug_name=>unistr('Informa\00E7\00F5es Tabela')
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10406006108170119)
,p_plug_name=>'Dataset'
,p_parent_plug_id=>wwv_flow_imp.id(10306590469900618)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>5
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d.DATASET_ID,',
'       d.NOME_DATASET,',
'       d.LINK_OAC,',
'       d.DESCRICAO_AI,',
'       d.DATA_CADASTRO,',
'       d.OAC_PRINTSCREEN,',
'       d.OAC_PRINTNOME,',
'       d.OAC_PRINTMIMETYPE,',
'       d.OAC_PRINTDATE,',
'       d.TABELA_DB,',
'       d.perfil_fk,',
'       d.OAC_PRINTSCREEN as "TROCAR_IMAGEM"',
'from DATASET d',
'where d.DATASET_ID = :P2_DATASET_ID',
''))
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10306652153900619)
,p_plug_name=>'Colunas Tabela'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>30
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18349072609499264)
,p_plug_name=>'Dataset Metadata'
,p_parent_plug_id=>wwv_flow_imp.id(10306652153900619)
,p_region_template_options=>'#DEFAULT#:t-IRR-region--noBorders:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>60
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    column_name, ',
'    data_type, ',
'    num_distinct,',
'    CASE ',
'        WHEN data_type = ''NUMBER'' THEN ROUND(density, 2)',
'        ELSE NULL',
'    END AS density,',
'    ',
'    CASE ',
'        WHEN data_type = ''NUMBER'' THEN TO_CHAR(ROUND(UTL_RAW.CAST_TO_NUMBER(low_value), 2))',
'        WHEN data_type LIKE ''%CHAR%'' THEN NULL',
'        ELSE NULL',
'    END AS low_value,',
'    ',
'    CASE ',
'        WHEN data_type = ''NUMBER'' THEN TO_CHAR(ROUND(UTL_RAW.CAST_TO_NUMBER(high_value), 2))',
'        WHEN data_type LIKE ''%CHAR%'' THEN NULL',
'        ELSE NULL',
'    END AS high_value,',
'    ',
'    num_nulls',
'FROM USER_TAB_COLUMNS',
'WHERE table_name = UPPER(:P2_TABLE_NAME);',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(30191042018353052)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DEMO'
,p_internal_uid=>19900130113128305
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(30191192504353053)
,p_db_column_name=>'COLUMN_NAME'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Coluna'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10305182934900604)
,p_db_column_name=>'DATA_TYPE'
,p_display_order=>20
,p_column_identifier=>'F'
,p_column_label=>'Data Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10305238935900605)
,p_db_column_name=>'NUM_DISTINCT'
,p_display_order=>30
,p_column_identifier=>'G'
,p_column_label=>'Qtde Distintos'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10305688377900609)
,p_db_column_name=>'NUM_NULLS'
,p_display_order=>70
,p_column_identifier=>'K'
,p_column_label=>'Qtde Nulos'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10306185113900614)
,p_db_column_name=>'LOW_VALUE'
,p_display_order=>90
,p_column_identifier=>'P'
,p_column_label=>'Menor Valor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10306277897900615)
,p_db_column_name=>'HIGH_VALUE'
,p_display_order=>100
,p_column_identifier=>'Q'
,p_column_label=>'Maior Valor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10306490541900617)
,p_db_column_name=>'DENSITY'
,p_display_order=>110
,p_column_identifier=>'S'
,p_column_label=>'Densidade'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(32792268075599034)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'225014'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'COLUMN_NAME:DATA_TYPE:NUM_DISTINCT:NUM_NULLS:HIGH_VALUE:LOW_VALUE'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10407973841170138)
,p_plug_name=>unistr('Estat\00EDsticas Tabela')
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18244586053810156)
,p_plug_name=>'Dicionario'
,p_parent_plug_id=>wwv_flow_imp.id(10407973841170138)
,p_region_template_options=>'#DEFAULT#:t-IRR-region--noBorders:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>25
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    t.table_name, ',
'    t.num_rows, ',
'    t.last_analyzed,',
'    COUNT(c.column_name) AS column_count',
'FROM ',
'    user_tables t, user_tab_columns c, dataset d',
'where t.table_name = c.table_name',
'and t.table_name = d.TABELA_DB',
'and d.DATASET_ID = :P2_DATASET_ID',
'GROUP BY ',
'    t.table_name, ',
'    t.num_rows, ',
'    t.last_analyzed',
'ORDER BY ',
'    t.table_name;',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(10407383224170132)
,p_max_row_count=>'1000000'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'PORTO'
,p_internal_uid=>10407383224170132
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10407470079170133)
,p_db_column_name=>'TABLE_NAME'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Nome Tabela'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10407564973170134)
,p_db_column_name=>'NUM_ROWS'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>unistr('N\00FAmero de Linhas')
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10407660363170135)
,p_db_column_name=>'LAST_ANALYZED'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>unistr('\00DAltima coleta de estat\00EDsticas')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10407779358170136)
,p_db_column_name=>'COLUMN_COUNT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Qtde de Colunas'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(10469779191736178)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'104698'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TABLE_NAME:NUM_ROWS:LAST_ANALYZED:COLUMN_COUNT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18245179625810162)
,p_plug_name=>'Detalhes Dataset'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--featured'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(18226828428558568)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(18349124753499265)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(18245179625810162)
,p_button_name=>'Voltar'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Voltar'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(18246657888810177)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(18245179625810162)
,p_button_name=>'Deletar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Deletar'
,p_button_position=>'NEXT'
,p_security_scheme=>wwv_flow_imp.id(18232056467558719)
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10408025326170139)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(18245179625810162)
,p_button_name=>'Salvar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Salvar'
,p_button_position=>'NEXT'
,p_security_scheme=>wwv_flow_imp.id(18232056467558719)
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10408444050170143)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(18245179625810162)
,p_button_name=>'LinkOpen'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Abrir OAC'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-external-link'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(18246894294810179)
,p_branch_name=>'Return Home'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'REQUEST_NOT_EQUAL_CONDITION'
,p_branch_condition=>'Download'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10406136824170120)
,p_name=>'P2_DATASET_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10406006108170119)
,p_item_source_plug_id=>wwv_flow_imp.id(10406006108170119)
,p_source=>'DATASET_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10406202010170121)
,p_name=>'P2_NOME_DATASET'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(10406006108170119)
,p_item_source_plug_id=>wwv_flow_imp.id(10406006108170119)
,p_prompt=>'Nome Dataset'
,p_source=>'NOME_DATASET'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>400
,p_read_only_when=>'GET_APEX_APP_USER <> ''PORTO'''
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10406336099170122)
,p_name=>'P2_LINK_OAC'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(10406006108170119)
,p_item_source_plug_id=>wwv_flow_imp.id(10406006108170119)
,p_prompt=>'URL OAC (Colocar https://)'
,p_source=>'LINK_OAC'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>2
,p_read_only_when=>'GET_APEX_APP_USER <> ''PORTO'''
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10406532433170124)
,p_name=>'P2_DESCRICAO_AI'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(10406006108170119)
,p_item_source_plug_id=>wwv_flow_imp.id(10406006108170119)
,p_prompt=>unistr('Descri\00E7\00E3o Dataset')
,p_source=>'DESCRICAO_AI'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_read_only_when=>'GET_APEX_APP_USER <> ''PORTO'''
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10406800574170127)
,p_name=>'P2_DATA_CADASTRO'
,p_source_data_type=>'DATE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(10406006108170119)
,p_item_source_plug_id=>wwv_flow_imp.id(10406006108170119)
,p_prompt=>'Data Cadastro'
,p_source=>'DATA_CADASTRO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10406954746170128)
,p_name=>'P2_OAC_PRINTSCREEN'
,p_source_data_type=>'BLOB'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(10406006108170119)
,p_item_source_plug_id=>wwv_flow_imp.id(10406006108170119)
,p_source=>'OAC_PRINTSCREEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'DB_COLUMN',
  'blob_last_updated_column', 'OAC_PRINTDATE',
  'filename_column', 'OAC_PRINTNOME',
  'mime_type_column', 'OAC_PRINTMIMETYPE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10407028514170129)
,p_name=>'P2_OAC_PRINTNOME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(10406006108170119)
,p_item_source_plug_id=>wwv_flow_imp.id(10406006108170119)
,p_source=>'OAC_PRINTNOME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10407185540170130)
,p_name=>'P2_OAC_PRINTMIMETYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(10406006108170119)
,p_item_source_plug_id=>wwv_flow_imp.id(10406006108170119)
,p_source=>'OAC_PRINTMIMETYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10407287020170131)
,p_name=>'P2_OAC_PRINTDATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(10406006108170119)
,p_item_source_plug_id=>wwv_flow_imp.id(10406006108170119)
,p_source=>'OAC_PRINTDATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10407852039170137)
,p_name=>'P2_TABLE_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(10406006108170119)
,p_item_source_plug_id=>wwv_flow_imp.id(10406006108170119)
,p_source=>'TABELA_DB'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10408392689170142)
,p_name=>'P2_PERFIL_FK'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(10406006108170119)
,p_item_source_plug_id=>wwv_flow_imp.id(10406006108170119)
,p_prompt=>'Perfil'
,p_source=>'PERFIL_FK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select distinct nome_perfil, perfil_id from perfil'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when=>'GET_APEX_APP_USER <> ''PORTO'''
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10408869802170147)
,p_name=>'P2_TROCAR_IMAGEM'
,p_source_data_type=>'BLOB'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(10406006108170119)
,p_item_source_plug_id=>wwv_flow_imp.id(10406006108170119)
,p_prompt=>'Trocar Imagem'
,p_source=>'TROCAR_IMAGEM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_IMAGE_UPLOAD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_security_scheme=>wwv_flow_imp.id(18232056467558719)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_cropping', 'Y',
  'aspect_ratio', 'AUTO',
  'blob_last_updated_column', 'OAC_PRINTDATE',
  'display_as', 'INLINE',
  'display_download_link', 'N',
  'filename_column', 'OAC_PRINTNOME',
  'mime_type_column', 'OAC_PRINTMIMETYPE',
  'storage_type', 'DB_COLUMN')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10408510759170144)
,p_name=>'Click'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(10408444050170143)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10408639266170145)
,p_event_id=>wwv_flow_imp.id(10408510759170144)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var url = apex.item("P2_LINK_OAC").getValue();',
'window.open(url, ''_blank'');',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10405104996170110)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DELETE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    DELETE FROM DATASET WHERE DATASET_ID = :P2_DATASET_ID;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(18246657888810177)
,p_internal_uid=>10405104996170110
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10408187298170140)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(10406006108170119)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'DML-Salvar'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(10408025326170139)
,p_internal_uid=>10408187298170140
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(18244641666810157)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(10406006108170119)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Dataset Details'
,p_internal_uid=>7953729761585410
);
wwv_flow_imp.component_end;
end;
/
