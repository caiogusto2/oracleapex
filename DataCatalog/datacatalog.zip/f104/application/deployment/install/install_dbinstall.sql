prompt --application/deployment/install/install_dbinstall
begin
--   Manifest
--     INSTALL: INSTALL-DBInstall
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>10289753147261904
,p_default_application_id=>104
,p_default_id_offset=>10290911905224747
,p_default_owner=>'PORTO'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(10534154125256100)
,p_install_id=>wwv_flow_imp.id(41989702116777275)
,p_name=>'DBInstall'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  CREATE TABLE "DATASET" ',
'   (	"DATASET_ID" NUMBER GENERATED ALWAYS AS IDENTITY MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  NOT NULL ENABLE, ',
'	"NOME_DATASET" VARCHAR2(400), ',
'	"LINK_OAC" VARCHAR2(4000), ',
'	"TABELA_DB" VARCHAR2(255), ',
'	"DESCRICAO_AI" VARCHAR2(4000), ',
'	"PERFIL_FK" NUMBER, ',
'	"METADADOS" CLOB, ',
'	"DATA_CADASTRO" DATE DEFAULT current_date, ',
'	"OAC_PRINTSCREEN" BLOB, ',
'	"OAC_PRINTNOME" VARCHAR2(400), ',
'	"OAC_PRINTMIMETYPE" VARCHAR2(400), ',
'	"OAC_PRINTDATE" DATE, ',
'	 PRIMARY KEY ("DATASET_ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE TABLE "PERFIL" ',
'   (	"PERFIL_ID" NUMBER GENERATED ALWAYS AS IDENTITY MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  NOT NULL ENABLE, ',
'	"NOME_PERFIL" VARCHAR2(400), ',
'	 PRIMARY KEY ("PERFIL_ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  ALTER TABLE "DATASET" ADD CONSTRAINT "FK_PERFIL" FOREIGN KEY ("PERFIL_FK")',
'	  REFERENCES "PERFIL" ("PERFIL_ID") ENABLE;',
'      ',
'create or replace FUNCTION get_apex_app_user',
'RETURN VARCHAR2',
'IS',
'    v_app_user VARCHAR2(100);',
'BEGIN',
'    v_app_user := SYS_CONTEXT(''APEX$SESSION'', ''APP_USER'');',
'    RETURN v_app_user;',
'END;',
'/',
'',
'',
' '))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(10534228866256096)
,p_script_id=>wwv_flow_imp.id(10534154125256100)
,p_object_owner=>'#OWNER#'
,p_object_type=>'FUNCTION'
,p_object_name=>'GET_APEX_APP_USER'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(10534436064256095)
,p_script_id=>wwv_flow_imp.id(10534154125256100)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'DATASET'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(10534627965256095)
,p_script_id=>wwv_flow_imp.id(10534154125256100)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'PERFIL'
);
wwv_flow_imp.component_end;
end;
/
