prompt --application/shared_components/user_interface/lovs/perfil_nome_perfil
begin
--   Manifest
--     PERFIL.NOME_PERFIL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>10289753147261904
,p_default_application_id=>104
,p_default_id_offset=>10290911905224747
,p_default_owner=>'PORTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(10393015081245386)
,p_lov_name=>'PERFIL.NOME_PERFIL'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'PERFIL'
,p_return_column_name=>'PERFIL_ID'
,p_display_column_name=>'NOME_PERFIL'
,p_default_sort_column_name=>'NOME_PERFIL'
,p_default_sort_direction=>'ASC'
,p_version_scn=>44847270627645
);
wwv_flow_imp.component_end;
end;
/
