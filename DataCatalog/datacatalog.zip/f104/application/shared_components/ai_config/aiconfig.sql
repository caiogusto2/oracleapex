prompt --application/shared_components/ai_config/aiconfig
begin
--   Manifest
--     AI CONFIG: aiconfig
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>10289753147261904
,p_default_application_id=>104
,p_default_id_offset=>10290911905224747
,p_default_owner=>'PORTO'
);
wwv_flow_imp_shared.create_ai_config(
 p_id=>wwv_flow_imp.id(23190291947826065)
,p_name=>'aiconfig'
,p_static_id=>'aiconfig'
,p_remote_server_id=>wwv_flow_imp.id(23189828286822112)
,p_system_prompt=>unistr('Analisar conteudo com base nos resultados DESCRICAO_AI e recomendar dataset, sempre entregar output como um texto sem formata\00E7\00E3o')
,p_welcome_message=>'Bem vindo, como posso ajuda-lo?'
,p_temperature=>0
,p_version_scn=>44847462067769
);
wwv_flow_imp_shared.create_ai_config_rag_source(
 p_id=>wwv_flow_imp.id(23789445584862481)
,p_name=>'RAG01'
,p_rag_type=>'DATA_SOURCE'
,p_source=>'select DESCRICAO_AI from dataset;'
);
wwv_flow_imp.component_end;
end;
/
