prompt --application/shared_components/security/app_access_control/admin
begin
--   Manifest
--     ACL ROLE: ADMIN
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>10289753147261904
,p_default_application_id=>104
,p_default_id_offset=>10290911905224747
,p_default_owner=>'PORTO'
);
wwv_flow_imp_shared.create_acl_role(
 p_id=>wwv_flow_imp.id(18532507964336227)
,p_static_id=>'ADMIN'
,p_name=>'ADMIN'
,p_version_scn=>44791426945315
);
wwv_flow_imp.component_end;
end;
/
