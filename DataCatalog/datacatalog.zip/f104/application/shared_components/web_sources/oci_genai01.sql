prompt --application/shared_components/web_sources/oci_genai01
begin
--   Manifest
--     WEB SOURCE: oci-genai01
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>10289753147261904
,p_default_application_id=>104
,p_default_id_offset=>10290911905224747
,p_default_owner=>'PORTO'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(29590749230325283)
,p_name=>'oci-genai01'
,p_static_id=>'oci_genai_01'
,p_web_source_type=>'NATIVE_OCI'
,p_data_profile_id=>wwv_flow_imp.id(29589613826325265)
,p_remote_server_id=>wwv_flow_imp.id(29589461073325259)
,p_url_path_prefix=>'/20231130/actions/chat'
,p_credential_id=>wwv_flow_imp.id(18383208250453971)
,p_version_scn=>44823867340892
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(29591368000325311)
,p_web_src_module_id=>wwv_flow_imp.id(29590749230325283)
,p_operation=>'POST'
,p_url_pattern=>'.'
,p_request_body_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'	"chatRequest":{',
'		"apiFormat":"COHERE",',
'		"message":"#MESSAGE#",',
'                "maxTokens":"1800",',
'                "temperature":"0"',
'	},',
'	"compartmentId":"ocid1.compartment.oc1..aaaaaaaacqt2kvaoyjexiops224rzriooevivs63hxhpzjxzwbvadqcgsfha",',
'	"servingMode":{',
'		"servingType":"ON_DEMAND",',
'		"modelId":"cohere.command-r-plus-08-2024"',
'	}',
'}'))
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(29790019449333822)
,p_web_src_module_id=>wwv_flow_imp.id(29590749230325283)
,p_web_src_operation_id=>wwv_flow_imp.id(29591368000325311)
,p_name=>'Content-Type'
,p_param_type=>'HEADER'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value=>'application/json'
,p_is_static=>true
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(29790456047335030)
,p_web_src_module_id=>wwv_flow_imp.id(29590749230325283)
,p_web_src_operation_id=>wwv_flow_imp.id(29591368000325311)
,p_name=>'MESSAGE'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(29790825519336163)
,p_web_src_module_id=>wwv_flow_imp.id(29590749230325283)
,p_web_src_operation_id=>wwv_flow_imp.id(29591368000325311)
,p_name=>'RESPONSE'
,p_param_type=>'BODY'
,p_is_required=>false
,p_direction=>'OUT'
);
wwv_flow_imp.component_end;
end;
/
