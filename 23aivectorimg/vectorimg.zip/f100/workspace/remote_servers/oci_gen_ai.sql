prompt --workspace/remote_servers/oci_gen_ai
begin
--   Manifest
--     REMOTE SERVER: OCI_GEN_AI
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>8113765802594804
,p_default_application_id=>100
,p_default_id_offset=>8514033438600228
,p_default_owner=>'DEMO'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(16636818172184111)
,p_name=>'OCI_GEN_AI'
,p_static_id=>'oci_gen_ai'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('oci_gen_ai'),'https://inference.generativeai.sa-saopaulo-1.oci.oraclecloud.com')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('oci_gen_ai'),'')
,p_server_type=>'GENERATIVE_AI'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('oci_gen_ai'),'')
,p_credential_id=>wwv_flow_imp.id(51265194178743977)
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('oci_gen_ai'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('oci_gen_ai'),'')
,p_prompt_on_install=>true
,p_ai_provider_type=>'OCI_GENAI'
,p_ai_is_builder_service=>true
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('oci_gen_ai'),'')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('oci_gen_ai'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('oci_gen_ai'),'{"compartmentId":"ocid1.compartment.oc1..aaaaaaaacqt2kvaoyjexiops224rzriooevivs63hxhpzjxzwbvadqcgsfha","servingMode":{"modelId":"cohere.command-r-plus-08-2024","servingType":"ON_DEMAND"}}')
);
wwv_flow_imp.component_end;
end;
/
