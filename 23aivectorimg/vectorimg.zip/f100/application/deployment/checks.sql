prompt --application/deployment/checks
begin
--   Manifest
--     INSTALL CHECKS: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>8113765802594804
,p_default_application_id=>100
,p_default_id_offset=>8514033438600228
,p_default_owner=>'DEMO'
);
null;
wwv_flow_imp.component_end;
end;
/
