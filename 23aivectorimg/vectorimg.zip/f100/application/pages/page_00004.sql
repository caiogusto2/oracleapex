prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>8113765802594804
,p_default_application_id=>100
,p_default_id_offset=>8514033438600228
,p_default_owner=>'DEMO'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Consulta Vetorial'
,p_alias=>'CONSULTAVETORIAL'
,p_step_title=>'Consulta Vetorial'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.float{',
'  z-index:100;',
'  position:fixed;',
'  width:60px;',
'  height:60px;',
'  bottom:40px;',
'  right:40px;',
'  background-color: black;',
'  color:#FFF;',
'  border-radius:50px;',
'  text-align:center;',
'  box-shadow: 2px 2px 3px #999;',
'}',
'.my-float{',
'  margin-top:22px;',
'}',
''))
,p_step_template=>2979075366320325194
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10132375254122116)
,p_plug_name=>'Consulta Vetorial'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(65316645011130756)
,p_plug_name=>'FILE_LIST'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2072724515482255512
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    "DOC_ID",',
'    "DOC_NAME",',
'--    sys.dbms_lob.getlength("DATA")"DATA",',
'    DATA,',
'    "CREATED_AT",',
'    mime_type',
'    from "DOC_UPLOAD"',
'WHERE (:P4_DOCID IS NULL OR REGEXP_LIKE(TO_CHAR(DOC_ID), :P4_DOCID))',
'ORDER BY CREATED_AT'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(10130826780122101)
,p_region_id=>wwv_flow_imp.id(65316645011130756)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_media_source_type=>'BLOB'
,p_media_blob_column_name=>'DATA'
,p_media_display_position=>'BODY'
,p_media_sizing=>'COVER'
,p_pk1_column_name=>'DOC_ID'
,p_mime_type_column_name=>'MIME_TYPE'
,p_last_updated_column_name=>'CREATED_AT'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(10131413588122107)
,p_card_id=>wwv_flow_imp.id(10130826780122101)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::P5_DOC_ID:&DOC_ID.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16613336252790438)
,p_button_sequence=>30
,p_button_name=>'ADICIONAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Abrir'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
,p_button_css_classes=>'float my-float'
,p_icon_css_classes=>'fa-plus'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10133779492122130)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10132375254122116)
,p_button_name=>'Imagens'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Demo Imagens'
,p_button_position=>'CHANGE'
,p_button_redirect_url=>'https://objectstorage.sa-saopaulo-1.oraclecloud.com/p/wsofljTIBi1_P2viauCPm4196p5jmhVAj0wpwUB3DWnplsc_2_B9sdxJ7X75RcSG/n/grplsopryjgk/b/demo23ai/o/test.zip'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10133541362122128)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(10132375254122116)
,p_button_name=>'Clear'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--warning'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Limpar'
,p_button_position=>'CHANGE'
,p_button_redirect_url=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::P4_DOCID,P4_IMAGEM:,'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10132519667122118)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(10132375254122116)
,p_button_name=>'Filtrar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Filtrar'
,p_button_position=>'CHANGE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10132448419122117)
,p_name=>'P4_IMAGEM'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10132375254122116)
,p_prompt=>'Imagem a ser comparada'
,p_display_as=>'NATIVE_IMAGE_UPLOAD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_cropping', 'N',
  'allow_multiple_files', 'N',
  'capture_using', 'ENVIRONMENT',
  'display_as', 'DROPZONE_ICON',
  'preview_size', 'XL',
  'purge_files_at', 'SESSION',
  'storage_type', 'APEX_APPLICATION_TEMP_FILES')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10133081892122123)
,p_name=>'P4_DOCID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(10132375254122116)
,p_prompt=>'DOCID Imagens Encontradas'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38528556461947144)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(65316645011130756)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38528934973947149)
,p_event_id=>wwv_flow_imp.id(38528556461947144)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(65316645011130756)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10131288315122105)
,p_name=>'Close'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(16613336252790438)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10131332916122106)
,p_event_id=>wwv_flow_imp.id(10131288315122105)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(65316645011130756)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10132806705122121)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Execution_Chain'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>10132806705122121
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10132939472122122)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(10132806705122121)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Consulta Vetorial'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_doc_id     NUMBER;',
'    v_result     VARCHAR2(4000) := '''';',
'    l_embedding  CLOB;',
'    long_text    CLOB := '''';',
'    v_count      INTEGER := 0;',
'    v_total      INTEGER := 0;',
'',
'    CURSOR c1 IS ',
'    SELECT ',
'        doc_id',
'    FROM doc_upload',
'    ORDER BY VECTOR_DISTANCE(vetor, l_embedding, cosine)',
'    FETCH FIRST 5 ROWS ONLY;',
'',
'BEGIN',
'    -- Generate embedding from the uploaded image',
'    SELECT VECTOR_EMBEDDING(img_model USING BLOB_CONTENT AS DATA)',
'    INTO l_embedding',
'    FROM APEX_APPLICATION_TEMP_FILES',
'    WHERE name = :P4_IMAGEM;',
'',
'    DBMS_LOB.CREATETEMPORARY(long_text, TRUE, DBMS_LOB.SESSION);',
'',
'    -- Count total rows in the cursor',
'    FOR row_count IN (SELECT COUNT(*) AS total FROM (',
'                        SELECT doc_id ',
'                        FROM doc_upload',
'                        ORDER BY VECTOR_DISTANCE(vetor, l_embedding, cosine)',
'                        FETCH FIRST 5 ROWS ONLY)) ',
'    LOOP',
'        v_total := row_count.total;',
'    END LOOP;',
'',
'    -- Iterate and append with separator, skipping the last one',
'    FOR row_1 IN c1 LOOP',
'        v_count := v_count + 1;',
'        DBMS_LOB.APPEND(long_text, TO_CLOB(TO_CHAR(row_1.doc_id)));',
'        IF v_count < v_total THEN',
'            DBMS_LOB.APPEND(long_text, ''|'');',
'        END IF;',
'    END LOOP;',
'',
'    :P4_DOCID := long_text;',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        :P4_DOCID := ''Error: '' || SQLERRM;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>10132939472122122
);
wwv_flow_imp.component_end;
end;
/
