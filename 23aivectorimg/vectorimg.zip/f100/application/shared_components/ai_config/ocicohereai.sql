prompt --application/shared_components/ai_config/ocicohereai
begin
--   Manifest
--     AI CONFIG: ocicohereai
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>8113765802594804
,p_default_application_id=>100
,p_default_id_offset=>8514033438600228
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_ai_config(
 p_id=>wwv_flow_imp.id(16629769063054386)
,p_name=>'ocicohereai'
,p_static_id=>'ocicohereai'
,p_welcome_message=>'Bem vindo ao APEX Assistant como posso ajuda-lo?'
,p_version_scn=>44570648623316
);
wwv_flow_imp_shared.create_ai_config_rag_source(
 p_id=>wwv_flow_imp.id(16637178066204411)
,p_name=>'Dataset'
,p_rag_type=>'DATA_SOURCE'
,p_source=>'select ''A '' || local || '' de sigla '' || SIGLA || '' do estado '' || ESTADO || '' possui '' || qtde || '' '' || EMBARCACAO || '';'' from embarcacoes where ano = 2023;'
);
wwv_flow_imp.component_end;
end;
/
