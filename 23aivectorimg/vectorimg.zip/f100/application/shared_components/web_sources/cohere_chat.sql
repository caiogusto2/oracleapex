prompt --application/shared_components/web_sources/cohere_chat
begin
--   Manifest
--     WEB SOURCE: Cohere-Chat
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>8113765802594804
,p_default_application_id=>100
,p_default_id_offset=>8514033438600228
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(38391725543936701)
,p_name=>'Cohere-Chat'
,p_static_id=>'cohere_chat'
,p_web_source_type=>'NATIVE_OCI'
,p_data_profile_id=>wwv_flow_imp.id(38390900284936694)
,p_remote_server_id=>wwv_flow_imp.id(51295487266285641)
,p_url_path_prefix=>'chat'
,p_credential_id=>wwv_flow_imp.id(51265194178743977)
,p_version_scn=>44570451876074
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(38392080312936704)
,p_web_src_module_id=>wwv_flow_imp.id(38391725543936701)
,p_operation=>'POST'
,p_url_pattern=>'.'
,p_request_body_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'	"chatRequest":{',
'		"apiFormat":"COHERE",',
'		"message":"#MESSAGE#",',
'                "maxTokens":"1800",',
'                "temperature":"0"',
'	},',
'	"compartmentId":"ocid1.compartment.oc1..aaaaaaaacqt2kvaoyjexiops224rzriooevivs63hxhpzjxzwbvadqcgsfha",',
'	"servingMode":{',
'		"servingType":"ON_DEMAND",',
'		"modelId":"cohere.command-r-plus-08-2024"',
'	}',
'}'))
,p_force_error_for_http_404=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(38392468937936708)
,p_web_src_module_id=>wwv_flow_imp.id(38391725543936701)
,p_web_src_operation_id=>wwv_flow_imp.id(38392080312936704)
,p_name=>'Content-Type'
,p_param_type=>'HEADER'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value=>'application/json'
,p_is_static=>true
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(38392905322936711)
,p_web_src_module_id=>wwv_flow_imp.id(38391725543936701)
,p_web_src_operation_id=>wwv_flow_imp.id(38392080312936704)
,p_name=>'MESSAGE'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(38393406680936712)
,p_web_src_module_id=>wwv_flow_imp.id(38391725543936701)
,p_web_src_operation_id=>wwv_flow_imp.id(38392080312936704)
,p_name=>'RESPONSE'
,p_param_type=>'BODY'
,p_is_required=>false
,p_direction=>'OUT'
);
wwv_flow_imp.component_end;
end;
/
