prompt --application/shared_components/json_source/json_cidade
begin
--   Manifest
--     DOCUMENT SOURCE: JSON_CIDADE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>8113765802594804
,p_default_application_id=>100
,p_default_id_offset=>8514033438600228
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_document_source(
 p_id=>wwv_flow_imp.id(16684011923081169)
,p_name=>'JSON_CIDADE'
,p_static_id=>'json_cidade'
,p_document_source_type=>'JSON_COLLECTION'
,p_location=>'LOCAL'
,p_object_name=>'ci_cidade'
,p_data_profile_id=>wwv_flow_imp.id(16684055792081169)
,p_version_scn=>44573448403055
);
wwv_flow_imp.component_end;
end;
/
