prompt --application/shared_components/navigation/lists/create_dataset
begin
--   Manifest
--     LIST: Create Dataset
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>9464009710794554
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(14131147542949644)
,p_name=>'Create Dataset'
,p_static_id=>'create-dataset'
,p_version_scn=>'SH256:DsKyLsJBYKO0g49rEuPJXM5m5ilW4VXYNL3RvTmdnqE'
,p_created_on=>wwv_flow_imp.dz('20261010023207Z')
,p_updated_on=>wwv_flow_imp.dz('20261010132406Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp.component_end;
end;
/
