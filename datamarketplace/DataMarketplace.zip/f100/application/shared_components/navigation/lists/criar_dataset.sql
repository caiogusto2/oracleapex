prompt --application/shared_components/navigation/lists/criar_dataset
begin
--   Manifest
--     LIST: CRIAR_DATASET
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>9464009710794554
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(15877197144870123)
,p_name=>'CRIAR_DATASET'
,p_static_id=>'criar-dataset'
,p_version_scn=>'SH256:g3rTRti-W813Z43k-7-6h87Xc4xcKvqFQXlNPwUrlrc'
,p_created_on=>wwv_flow_imp.dz('20261010132532Z')
,p_updated_on=>wwv_flow_imp.dz('20261010132532Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(15885711477870186)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>unistr('Confirma\00E7\00E3o')
,p_static_id=>unistr('confirma\00E7\00E3o')
,p_list_item_link_target=>'f?p=&APP_ID.:5:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
,p_created_on=>wwv_flow_imp.dz('20261010132532Z')
,p_updated_on=>wwv_flow_imp.dz('20261010132532Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(15878692036870151)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Criar Dataset'
,p_static_id=>'criar-dataset'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
,p_created_on=>wwv_flow_imp.dz('20261010132532Z')
,p_updated_on=>wwv_flow_imp.dz('20261010132532Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(15881881552870172)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Revisar Dataset'
,p_static_id=>'revisar-dataset'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
,p_created_on=>wwv_flow_imp.dz('20261010132532Z')
,p_updated_on=>wwv_flow_imp.dz('20261010132532Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp.component_end;
end;
/
