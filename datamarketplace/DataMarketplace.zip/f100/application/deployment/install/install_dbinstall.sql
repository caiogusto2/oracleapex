prompt --application/deployment/install/install_dbinstall
begin
--   Manifest
--     INSTALL: INSTALL-DBINSTALL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>9464009710794554
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DEMO'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '  CREATE TABLE "DATASETS" '||wwv_flow.LF||
'   (	"ID" NUMBER GENERATED ALWAYS AS IDENTITY MINVALUE 1 MAXVALUE 999999';
wwv_flow_imp.g_varchar2_table(2) := '9999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  NOT N';
wwv_flow_imp.g_varchar2_table(3) := 'ULL ENABLE, '||wwv_flow.LF||
'	"DATASETS_NOME" VARCHAR2(200) NOT NULL ENABLE, '||wwv_flow.LF||
'	"DESCRICAO" VARCHAR2(3000), '||wwv_flow.LF||
'	"DAT';
wwv_flow_imp.g_varchar2_table(4) := 'ASETS_USUARIO" VARCHAR2(255) DEFAULT SYS_CONTEXT(''APEX$SESSION'', ''APP_USER''), '||wwv_flow.LF||
'	"DATASETS_DATA_CRIA';
wwv_flow_imp.g_varchar2_table(5) := 'CAO" TIMESTAMP (6) WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL ENABLE, '||wwv_flow.LF||
'	"DATASETS_SQL" CLOB,';
wwv_flow_imp.g_varchar2_table(6) := ' '||wwv_flow.LF||
'	 PRIMARY KEY ("ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'  CREATE TABLE "BASES" '||wwv_flow.LF||
'   (	"ID" NUMBER ';
wwv_flow_imp.g_varchar2_table(7) := 'GENERATED ALWAYS AS IDENTITY MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START W';
wwv_flow_imp.g_varchar2_table(8) := 'ITH 1 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  NOT NULL ENABLE, '||wwv_flow.LF||
'	"BASES_NOME" VARCHAR2(200) NOT';
wwv_flow_imp.g_varchar2_table(9) := ' NULL ENABLE, '||wwv_flow.LF||
'	 PRIMARY KEY ("ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace FUNCTION ';
wwv_flow_imp.g_varchar2_table(10) := 'decode_raw_value ('||wwv_flow.LF||
'    p_raw       IN RAW,'||wwv_flow.LF||
'    p_data_type IN VARCHAR2'||wwv_flow.LF||
')'||wwv_flow.LF||
'RETURN VARCHAR2'||wwv_flow.LF||
'IS'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(11) := '  v_number NUMBER;'||wwv_flow.LF||
'    v_string VARCHAR2(4000);'||wwv_flow.LF||
'    v_date   DATE;'||wwv_flow.LF||
'BEGIN'||wwv_flow.LF||
'    IF p_raw IS NULL TH';
wwv_flow_imp.g_varchar2_table(12) := 'EN'||wwv_flow.LF||
'        RETURN NULL;'||wwv_flow.LF||
'    END IF;'||wwv_flow.LF||
''||wwv_flow.LF||
'    CASE'||wwv_flow.LF||
'        WHEN p_data_type IN ('||wwv_flow.LF||
'            ''NUMBE';
wwv_flow_imp.g_varchar2_table(13) := 'R'','||wwv_flow.LF||
'            ''FLOAT'''||wwv_flow.LF||
'        ) THEN'||wwv_flow.LF||
'            DBMS_STATS.CONVERT_RAW_VALUE(p_raw, v_number);';
wwv_flow_imp.g_varchar2_table(14) := ''||wwv_flow.LF||
'            RETURN TO_CHAR(v_number);'||wwv_flow.LF||
''||wwv_flow.LF||
'        WHEN p_data_type IN ('||wwv_flow.LF||
'            ''VARCHAR2'','||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(15) := '           ''CHAR'','||wwv_flow.LF||
'            ''NVARCHAR2'','||wwv_flow.LF||
'            ''NCHAR'''||wwv_flow.LF||
'        ) THEN'||wwv_flow.LF||
'            DBMS_';
wwv_flow_imp.g_varchar2_table(16) := 'STATS.CONVERT_RAW_VALUE(p_raw, v_string);'||wwv_flow.LF||
'            RETURN v_string;'||wwv_flow.LF||
''||wwv_flow.LF||
'        WHEN p_data_type ';
wwv_flow_imp.g_varchar2_table(17) := '= ''DATE'' THEN'||wwv_flow.LF||
'            DBMS_STATS.CONVERT_RAW_VALUE(p_raw, v_date);'||wwv_flow.LF||
'            RETURN TO_CHAR(';
wwv_flow_imp.g_varchar2_table(18) := 'v_date, ''YYYY-MM-DD HH24:MI:SS'');'||wwv_flow.LF||
''||wwv_flow.LF||
'        ELSE'||wwv_flow.LF||
'            RETURN RAWTOHEX(p_raw);'||wwv_flow.LF||
'    END CASE';
wwv_flow_imp.g_varchar2_table(19) := ';'||wwv_flow.LF||
''||wwv_flow.LF||
'EXCEPTION'||wwv_flow.LF||
'    WHEN OTHERS THEN'||wwv_flow.LF||
'        RETURN RAWTOHEX(p_raw);'||wwv_flow.LF||
'END;'||wwv_flow.LF||
'/ ';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(17064992905344822)
,p_install_id=>wwv_flow_imp.id(17064210255329520)
,p_name=>'DBINSTALL'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
,p_created_on=>wwv_flow_imp.dz('20261010230439Z')
,p_updated_on=>wwv_flow_imp.dz('20261010230439Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(17065072266344828)
,p_script_id=>wwv_flow_imp.id(17064992905344822)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'BASES'
,p_created_on=>wwv_flow_imp.dz('20261010230439Z')
,p_last_updated_on=>wwv_flow_imp.dz('20261010230439Z')
,p_created_by=>'DEMO'
,p_last_updated_by=>'DEMO'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(17065225741344831)
,p_script_id=>wwv_flow_imp.id(17064992905344822)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'DATASETS'
,p_created_on=>wwv_flow_imp.dz('20261010230439Z')
,p_last_updated_on=>wwv_flow_imp.dz('20261010230439Z')
,p_created_by=>'DEMO'
,p_last_updated_by=>'DEMO'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(17065445121344832)
,p_script_id=>wwv_flow_imp.id(17064992905344822)
,p_object_owner=>'#OWNER#'
,p_object_type=>'FUNCTION'
,p_object_name=>'DECODE_RAW_VALUE'
,p_created_on=>wwv_flow_imp.dz('20261010230439Z')
,p_last_updated_on=>wwv_flow_imp.dz('20261010230439Z')
,p_created_by=>'DEMO'
,p_last_updated_by=>'DEMO'
);
wwv_flow_imp.component_end;
end;
/
