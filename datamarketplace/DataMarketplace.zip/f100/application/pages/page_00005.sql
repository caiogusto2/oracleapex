prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>9464009710794554
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DEMO'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>unistr('Confirma\00E7\00E3o')
,p_alias=>unistr('CONFIRMA\00C7\00C3O')
,p_step_title=>unistr('Confirma\00E7\00E3o')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-HeroRegion-icon {',
'    background-color: transparent;',
'}',
'',
'',
'.dataset-success {',
'    max-width: 750px;',
'    margin: 40px auto;',
'    padding: 40px;',
'    background: #ffffff;',
'    border-radius: 14px;',
'    text-align: center;',
'    box-shadow: 0 4px 20px rgba(0,0,0,0.08);',
'}',
'',
'.dataset-success-icon {',
'    width: 72px;',
'    height: 72px;',
'    margin: 0 auto 20px;',
'    border-radius: 50%;',
'    background: #e6f7ed;',
'    color: #16803c;',
'    font-size: 42px;',
'    font-weight: bold;',
'    display: flex;',
'    align-items: center;',
'    justify-content: center;',
'}',
'',
'.dataset-success h2 {',
'    color: #16803c;',
'    font-size: 25px;',
'    margin-bottom: 12px;',
'}',
'',
'.dataset-subtitle {',
'    color: #64748b;',
'    font-size: 15px;',
'    margin-bottom: 30px;',
'}',
'',
'.dataset-details {',
'    background: #f8fafc;',
'    border-radius: 10px;',
'    padding: 24px;',
'    text-align: left;',
'}',
'',
'.dataset-detail {',
'    display: flex;',
'    justify-content: space-between;',
'    gap: 20px;',
'    padding: 14px 0;',
'    border-bottom: 1px solid #e2e8f0;',
'}',
'',
'.dataset-detail:last-child {',
'    border-bottom: none;',
'}',
'',
'.detail-label {',
'    color: #64748b;',
'    font-weight: 500;',
'}',
'',
'.detail-value {',
'    color: #1e293b;',
'    font-weight: 600;',
'    text-align: right;',
'    overflow-wrap: anywhere;',
'}',
'',
'@media (max-width: 600px) {',
'    .dataset-detail {',
'        flex-direction: column;',
'        gap: 5px;',
'    }',
'',
'    .detail-value {',
'        text-align: left;',
'    }',
'}'))
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_created_on=>wwv_flow_imp.dz('20261010132532Z')
,p_last_updated_on=>wwv_flow_imp.dz('20261010175119Z')
,p_created_by=>'DEMO'
,p_last_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15885192403870185)
,p_plug_name=>unistr('Confirma\00E7\00E3o')
,p_static_id=>unistr('confirma\00E7\00E3o')
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>2120525352897701877
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_list_id=>wwv_flow_imp.id(15877197144870123)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>2011625478452504874
,p_created_on=>wwv_flow_imp.dz('20261010132532Z')
,p_updated_on=>wwv_flow_imp.dz('20261010132532Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15885257258870185)
,p_plug_name=>unistr('Confirma\00E7\00E3o')
,p_static_id=>unistr('confirma\00E7\00E3o-2')
,p_parent_plug_id=>wwv_flow_imp.id(15885192403870185)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="dataset-success">',
'',
'    <div class="dataset-success-icon">',
unistr('        \2713'),
'    </div>',
'',
unistr('    <h2>Parab\00E9ns! Seu dataset foi criado com sucesso!</h2>'),
'',
'    <p class="dataset-subtitle">',
'        O dataset <strong>&P5_TABELA!HTML.</strong>',
unistr('        foi criado e est\00E1 dispon\00EDvel para utiliza\00E7\00E3o.'),
'    </p>',
'',
'    <div class="dataset-details">',
'',
'        <div class="dataset-detail">',
'            <span class="detail-label">Nome do Dataset</span>',
'            <span class="detail-value">&P5_TABELA!HTML.</span>',
'        </div>',
'',
'        <div class="dataset-detail">',
unistr('            <span class="detail-label">Descri\00E7\00E3o</span>'),
'            <span class="detail-value">&P5_DESCRICAO!HTML.</span>',
'        </div>',
'',
'        <div class="dataset-detail">',
'            <span class="detail-label">Criado por</span>',
'            <span class="detail-value">&P5_USUARIO!HTML.</span>',
'        </div>',
'',
'        <div class="dataset-detail">',
unistr('            <span class="detail-label">Data de Cria\00E7\00E3o</span>'),
'            <span class="detail-value">&P5_DATA_CRIACAO!HTML.</span>',
'        </div>',
'',
'    </div>',
'',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010132532Z')
,p_updated_on=>wwv_flow_imp.dz('20261010175043Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56141084465824673)
,p_plug_name=>'Data Marketplace'
,p_static_id=>'data-marketplace'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--featured'
,p_plug_template=>2675494171183407654
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010145018Z')
,p_updated_on=>wwv_flow_imp.dz('20261010145018Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15886630513870190)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(15885192403870185)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_created_on=>wwv_flow_imp.dz('20261010132532Z')
,p_updated_on=>wwv_flow_imp.dz('20261010132532Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15886735253870190)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(15885192403870185)
,p_button_name=>'FINISH'
,p_static_id=>'finish'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Finish'
,p_button_position=>'NEXT'
,p_created_on=>wwv_flow_imp.dz('20261010132532Z')
,p_updated_on=>wwv_flow_imp.dz('20261010132532Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15886881799870190)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(15885192403870185)
,p_button_name=>'PREVIOUS'
,p_static_id=>'previous'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'Previous'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
,p_created_on=>wwv_flow_imp.dz('20261010132532Z')
,p_updated_on=>wwv_flow_imp.dz('20261010132532Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(15887684499870193)
,p_branch_action=>'f?p=&APP_ID.:4:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(15886881799870190)
,p_branch_sequence=>10
,p_created_on=>wwv_flow_imp.dz('20261010132532Z')
,p_updated_on=>wwv_flow_imp.dz('20261010132532Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(15888267563870195)
,p_branch_action=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(15886735253870190)
,p_branch_sequence=>1
,p_created_on=>wwv_flow_imp.dz('20261010132533Z')
,p_updated_on=>wwv_flow_imp.dz('20261010132533Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15674991450491141)
,p_name=>'P5_DATA_CRIACAO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(15885257258870185)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010153043Z')
,p_updated_on=>wwv_flow_imp.dz('20261010175119Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15674704463491139)
,p_name=>'P5_DESCRICAO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(15885257258870185)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010153043Z')
,p_updated_on=>wwv_flow_imp.dz('20261010175119Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15675067904491142)
,p_name=>'P5_SQL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(15885257258870185)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010153232Z')
,p_updated_on=>wwv_flow_imp.dz('20261010153412Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15674655557491138)
,p_name=>'P5_TABELA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(15885257258870185)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010152740Z')
,p_updated_on=>wwv_flow_imp.dz('20261010175119Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15674803754491140)
,p_name=>'P5_USUARIO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(15885257258870185)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010153043Z')
,p_updated_on=>wwv_flow_imp.dz('20261010175119Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(15674553829491137)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Retrieve Information'
,p_static_id=>'retrieve-information'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_sql CLOB;',
'BEGIN',
'',
'    SELECT',
'        descricao,',
'        datasets_usuario,',
'        TO_CHAR(',
'            datasets_data_criacao,',
'            ''DD/MM/YYYY HH24:MI:SS''',
'        ),',
'        datasets_sql',
'    INTO',
'        :P5_DESCRICAO,',
'        :P5_USUARIO,',
'        :P5_DATA_CRIACAO,',
'        l_sql',
'    FROM datasets',
'    WHERE datasets_nome = :P5_TABELA;',
'',
'    APEX_UTIL.SET_SESSION_STATE(',
'        p_name  => ''P5_SQL'',',
'        p_value => l_sql',
'    );',
'',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'        RAISE_APPLICATION_ERROR(',
'            -20001,',
'            ''Dataset not found.''',
'        );',
'',
'    WHEN TOO_MANY_ROWS THEN',
'        RAISE_APPLICATION_ERROR(',
'            -20002,',
'            ''Multiple datasets found for this ID.''',
'        );',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>15674553829491137
,p_created_on=>wwv_flow_imp.dz('20261010152740Z')
,p_updated_on=>wwv_flow_imp.dz('20261010153043Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp.component_end;
end;
/
