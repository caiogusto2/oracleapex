prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>9464009710794554
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DEMO'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Data Marketplace'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-HeroRegion-icon {',
'    background-color: transparent;',
'}'))
,p_step_template=>2980551703278319811
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_created_on=>wwv_flow_imp.dz('20261009235721Z')
,p_last_updated_on=>wwv_flow_imp.dz('20261010215028Z')
,p_created_by=>'DEMO'
,p_last_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10863979447755601)
,p_plug_name=>'Bases'
,p_static_id=>'bases'
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261009235924Z')
,p_updated_on=>wwv_flow_imp.dz('20261010000009Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10681583078751084)
,p_plug_name=>'Data Marketplace'
,p_static_id=>'datamarketplace'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--featured'
,p_plug_template=>2675494171183407654
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261009235721Z')
,p_updated_on=>wwv_flow_imp.dz('20261010022647Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10864019051755602)
,p_plug_name=>'Datasets'
,p_static_id=>'datasets'
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261009235924Z')
,p_updated_on=>wwv_flow_imp.dz('20261010022618Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15675158746491143)
,p_plug_name=>'Lista Datasets'
,p_static_id=>'lista-datasets'
,p_title=>'Lista Datasets'
,p_parent_plug_id=>wwv_flow_imp.id(10864019051755602)
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2102002977963900996
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       DATASETS_NOME as "Nome Dataset",',
unistr('       DESCRICAO as "Coment\00E1rios",'),
'       DATASETS_USUARIO,',
unistr('       DATASETS_DATA_CRIACAO as "Data Cria\00E7\00E3o"'),
'  from DATASETS',
' order by DATASETS_DATA_CRIACAO desc'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Lista Datasets'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_created_on=>wwv_flow_imp.dz('20261010175230Z')
,p_updated_on=>wwv_flow_imp.dz('20261010215028Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(15675271627491144)
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_actions_menu=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:CR,2:P2_BASE,P2_DATASET:#Nome Dataset#,Y'
,p_internal_uid=>15675271627491144
,p_created_on=>wwv_flow_imp.dz('20261010175230Z')
,p_updated_on=>wwv_flow_imp.dz('20261010215028Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(16274577658513602)
,p_db_column_name=>unistr('Coment\00E1rios')
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>unistr('Coment\00E1rios')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
,p_created_on=>wwv_flow_imp.dz('20261010175935Z')
,p_updated_on=>wwv_flow_imp.dz('20261010175935Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15675646719491148)
,p_db_column_name=>'DATASETS_USUARIO'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Datasets Usuario'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_available_clientside=>'N'
,p_created_on=>wwv_flow_imp.dz('20261010175231Z')
,p_updated_on=>wwv_flow_imp.dz('20261010175838Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(16274613167513603)
,p_db_column_name=>unistr('Data Cria\00E7\00E3o')
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>unistr('Data Cria\00E7\00E3o')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
,p_created_on=>wwv_flow_imp.dz('20261010175935Z')
,p_updated_on=>wwv_flow_imp.dz('20261010175935Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15675399888491145)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20261010175230Z')
,p_updated_on=>wwv_flow_imp.dz('20261010175347Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(16274422204513601)
,p_db_column_name=>'Nome Dataset'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Nome Dataset'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
,p_created_on=>wwv_flow_imp.dz('20261010175935Z')
,p_updated_on=>wwv_flow_imp.dz('20261010175935Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(16269692597472300)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'primary'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('Nome Dataset:Data Cria\00E7\00E3o:Coment\00E1rios')
,p_created_on=>wwv_flow_imp.dz('20261010175234Z')
,p_updated_on=>wwv_flow_imp.dz('20261010180037Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10864124108755603)
,p_plug_name=>'Cards'
,p_static_id=>'new'
,p_parent_plug_id=>wwv_flow_imp.id(10863979447755601)
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2074200852440250129
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    b.bases_nome as TABLE_NAME,',
'    c.comments AS description,',
'    t.num_rows',
'FROM bases b',
'',
'INNER JOIN user_tables t',
'    ON UPPER(t.table_name) = UPPER(b.bases_nome)',
'',
'LEFT JOIN user_tab_comments c',
'    ON c.table_name = t.table_name',
'   AND c.table_type = ''TABLE''',
'',
'ORDER BY b.bases_nome;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_created_on=>wwv_flow_imp.dz('20261009235925Z')
,p_updated_on=>wwv_flow_imp.dz('20261010181111Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(10864220996755604)
,p_region_id=>wwv_flow_imp.id(10864124108755603)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'TABLE_NAME'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_body_column_name=>'DESCRIPTION'
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_updated_on=>wwv_flow_imp.dz('20261010181111Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(10866549579755627)
,p_card_id=>wwv_flow_imp.id(10864220996755604)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::P2_BASE,P2_DATASET:&TABLE_NAME.,N'
,p_updated_on=>wwv_flow_imp.dz('20261010181111Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14085337102558933)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(15675158746491143)
,p_button_name=>'Criar'
,p_static_id=>'criar'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Criar'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:CR,3::'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-rocket'
,p_created_on=>wwv_flow_imp.dz('20261010023318Z')
,p_updated_on=>wwv_flow_imp.dz('20261010175653Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp.component_end;
end;
/
