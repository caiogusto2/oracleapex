prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>9464009710794554
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DEMO'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Criar Dataset'
,p_alias=>'CRIAR-DATASET'
,p_step_title=>'Criar Dataset'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// =====================================================',
'// GLOBAL VARIABLES',
'// =====================================================',
'',
'let sqlExecuted = false;',
'let lastExecutedSQL = "";',
'',
'',
'// =====================================================',
'// SHOW / HIDE RESULTS',
'// =====================================================',
'',
'function toggleResults() {',
'',
'    const sql = apex.item("P3_SQL").getValue();',
'',
'    if (!sql || !sql.trim() || !sqlExecuted) {',
'        $("#RESULTS").hide();',
'    } else {',
'        $("#RESULTS").show();',
'    }',
'}',
'',
'',
'// =====================================================',
'// SHOW / HIDE NEXT BUTTON',
'// =====================================================',
'',
'function toggleNextButton() {',
'',
'    $("#NEXT_BTN").toggle(sqlExecuted);',
'',
'}',
'',
'',
'// =====================================================',
'// RESET QUERY EXECUTION STATE',
'// =====================================================',
'',
'function resetSQLExecution() {',
'',
'    sqlExecuted = false;',
'    lastExecutedSQL = "";',
'',
'    toggleNextButton();',
'    toggleResults();',
'',
'}',
'',
'',
'// =====================================================',
'// EXECUTE SQL',
'// =====================================================',
'',
'function executeSQL() {',
'',
'    const sql = apex.item("P3_SQL").getValue();',
'',
'    const region = document.getElementById("RESULTS");',
'',
'    // Reset client-side execution state',
'    resetSQLExecution();',
'',
'    if (!region) {',
'        console.error("RESULTS region not found.");',
'        apex.message.alert("RESULTS region not found.");',
'        return;',
'    }',
'',
'    // Find or create result containers',
'    let results = document.getElementById("sql-results");',
'    let status = document.getElementById("sql-status");',
'',
'    if (!status) {',
'        status = document.createElement("div");',
'        status.id = "sql-status";',
'        region.appendChild(status);',
'    }',
'',
'    if (!results) {',
'        results = document.createElement("div");',
'        results.id = "sql-results";',
'        region.appendChild(results);',
'    }',
'',
'    // Clear previous results',
'    results.replaceChildren();',
'    status.textContent = "";',
'',
'    // Validate SQL input',
'    if (!sql || !sql.trim()) {',
'',
'        apex.message.alert(',
'            "Please enter a SELECT query."',
'        );',
'',
'        return;',
'    }',
'',
'    // Display loading status',
'    $("#RESULTS").show();',
'',
'    status.textContent = "Executing query...";',
'',
'    // Execute AJAX callback',
'    apex.server.process(',
'        "EXECUTE_SELECT",',
'        {',
'            x01: sql',
'        },',
'        {',
'            dataType: "json",',
'',
'            success: function(data) {',
'',
'                // SQL execution failed',
'                if (!data.success) {',
'',
'                    sqlExecuted = false;',
'',
'                    toggleNextButton();',
'',
'                    status.textContent =',
'                        "SQL Error: " +',
'                        (data.error || "Unknown error");',
'',
'                    $("#RESULTS").show();',
'',
'                    return;',
'                }',
'',
'                // SQL executed successfully',
'                sqlExecuted = true;',
'',
'                lastExecutedSQL = sql;',
'',
'                // Show NEXT button',
'                toggleNextButton();',
'',
'                // Show results',
'                $("#RESULTS").show();',
'',
'                // Execution information',
'                status.textContent =',
'                    "Query executed successfully | " +',
'                    "Rows: " + data.rowCount +',
'                    " | Time: " +',
'                    data.executionTime + " sec";',
'',
'                // Create results table',
'                const table =',
'                    document.createElement("table");',
'',
'                table.className =',
'                    "a-IRR-table sql-preview-table";',
'',
'                // Table header',
'                const thead =',
'                    document.createElement("thead");',
'',
'                const headerRow =',
'                    document.createElement("tr");',
'',
'                (data.columns || []).forEach(function(col) {',
'',
'                    const th =',
'                        document.createElement("th");',
'',
'                    th.textContent = col.name;',
'',
'                    headerRow.appendChild(th);',
'',
'                });',
'',
'                thead.appendChild(headerRow);',
'',
'                table.appendChild(thead);',
'',
'                // Table body',
'                const tbody =',
'                    document.createElement("tbody");',
'',
'                (data.rows || []).forEach(function(row) {',
'',
'                    const tr =',
'                        document.createElement("tr");',
'',
'                    row.forEach(function(value) {',
'',
'                        const td =',
'                            document.createElement("td");',
'',
'                        td.textContent =',
'                            value ?? "";',
'',
'                        tr.appendChild(td);',
'',
'                    });',
'',
'                    tbody.appendChild(tr);',
'',
'                });',
'',
'                table.appendChild(tbody);',
'',
'                // Display results',
'                results.appendChild(table);',
'',
'            },',
'',
'            error: function(',
'                jqXHR,',
'                textStatus,',
'                errorThrown',
'            ) {',
'',
'                sqlExecuted = false;',
'',
'                toggleNextButton();',
'',
'                $("#RESULTS").show();',
'',
'                status.textContent =',
'                    "Error executing SQL: " +',
'                    errorThrown;',
'',
'                console.error(',
'                    "AJAX Response:",',
'                    jqXHR.responseText',
'                );',
'',
'            }',
'        }',
'    );',
'}',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'function loadDatabaseExplorer() {',
'',
'    const tree = document.getElementById("db-tree");',
'',
'    if (!tree) return;',
'',
'    tree.textContent = "Loading tables...";',
'',
'    apex.server.process(',
'        "GET_DB_OBJECTS",',
'        {},',
'        {',
'            dataType: "json",',
'',
'            success: function(data) {',
'',
'                tree.replaceChildren();',
'',
'                (data.tables || []).forEach(function(table) {',
'',
'                    const details = document.createElement("details");',
'                    details.className = "db-table";',
'',
'                    const summary = document.createElement("summary");',
'                    summary.textContent = table.name;',
'',
'                    details.appendChild(summary);',
'',
'                    // Insert table name',
'                    const tableButton = document.createElement("button");',
'                    tableButton.type = "button";',
'                    tableButton.textContent = "+ Insert table";',
'                    tableButton.className = "db-insert-table";',
'',
'                    tableButton.addEventListener("click", function() {',
'                        insertIntoSQL("DEMO." + table.name);',
'                    });',
'',
'                    details.appendChild(tableButton);',
'',
'                    // Columns',
'                    table.columns.forEach(function(col) {',
'                        const row = document.createElement("div");',
'                        row.className = "db-column";',
'',
'                        const button = document.createElement("button");',
'                        button.type = "button";',
'                        button.textContent = col.name;',
'',
'                        // Insert TABLE_NAME.COLUMN_NAME',
'                        button.addEventListener("click", function() {',
'                            const columnReference =',
'                                table.name + "." + col.name;',
'                            insertIntoSQL(columnReference);',
'                        });',
'',
'                        const type = document.createElement("span");',
'                        type.className = "db-column-type";',
'                        type.textContent = col.type;',
'                        row.appendChild(button);',
'                        row.appendChild(type);',
'                        details.appendChild(row);',
'                    });',
'',
'                    tree.appendChild(details);',
'                });',
'',
'            },',
'',
'            error: function(jqXHR) {',
'                tree.textContent = "Error loading database objects.";',
'                console.error(jqXHR.responseText);',
'            }',
'        }',
'    );',
'}',
'',
'function insertIntoSQL(text) {',
'',
'    const editor = document.getElementById("P3_SQL");',
'',
'    if (!editor) return;',
'',
'    const start = editor.selectionStart;',
'    const end = editor.selectionEnd;',
'',
'    const current = editor.value;',
'',
'    editor.value =',
'        current.substring(0, start) +',
'        text +',
'        current.substring(end);',
'',
'    const newPosition = start + text.length;',
'',
'    editor.focus();',
'    editor.setSelectionRange(newPosition, newPosition);',
'',
'    editor.dispatchEvent(',
'        new Event("input", { bubbles: true })',
'    );',
'}',
'',
'function filterDatabaseExplorer() {',
'',
'    const search = document',
'        .getElementById("db-search")',
'        .value',
'        .toUpperCase();',
'',
'    document.querySelectorAll(".db-table").forEach(function(table) {',
'',
'        const name = table.querySelector("summary").textContent;',
'',
'        table.style.display =',
'            name.toUpperCase().includes(search)',
'                ? ""',
'                : "none";',
'    });',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sqlExecuted = false;',
'lastExecutedSQL = "";',
'',
'$("#RESULTS").hide();',
'$("#NEXT_BTN").hide();',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'loadDatabaseExplorer();',
'',
'document',
'    .getElementById("db-search")',
'    ?.addEventListener("input", filterDatabaseExplorer);'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Report-colHead {',
'    background-color: BLACK;',
'    color: white;',
'}',
'',
'.t-HeroRegion-icon {',
'    background-color: transparent;',
'}',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'/* Database Explorer */',
'',
'#DB_EXPLORER {',
'    border: 1px solid #e2e8f0;',
'    border-radius: 12px;',
'    overflow: hidden;',
'    background: #ffffff;',
'}',
'',
'.db-explorer {',
'    padding: 12px;',
'}',
'',
'#db-search {',
'    width: 100%;',
'    padding: 10px 12px;',
'    margin-bottom: 12px;',
'    border: 1px solid #cbd5e1;',
'    border-radius: 8px;',
'    font-size: 13px;',
'}',
'',
'#db-tree {',
'    max-height: 500px;',
'    overflow-y: auto;',
'}',
'',
'.db-table {',
'    border-bottom: 1px solid #e2e8f0;',
'    padding: 8px 4px;',
'}',
'',
'.db-table summary {',
'    cursor: pointer;',
'    font-size: 13px;',
'    font-weight: 600;',
'    color: #1e293b;',
'    padding: 6px;',
'}',
'',
'.db-table summary:hover {',
'    background: #f8fafc;',
'}',
'',
'.db-column {',
'    display: flex;',
'    align-items: center;',
'    justify-content: space-between;',
'    gap: 8px;',
'    padding: 6px 8px 6px 20px;',
'}',
'',
'.db-column button {',
'    border: none;',
'    background: transparent;',
'    color: #334155;',
'    cursor: pointer;',
'    font-size: 12px;',
'    text-align: left;',
'    overflow-wrap: anywhere;',
'}',
'',
'.db-column button:hover {',
'    color: #2563eb;',
'}',
'',
'.db-column-type {',
'    font-family: monospace;',
'    font-size: 11px;',
'    color: #64748b;',
'    white-space: nowrap;',
'}',
'',
'.db-insert-table {',
'    margin: 8px 0 8px 20px;',
'    padding: 6px 10px;',
'    border: 1px solid #cbd5e1;',
'    border-radius: 6px;',
'    background: #f8fafc;',
'    cursor: pointer;',
'    font-size: 12px;',
'}'))
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_created_on=>wwv_flow_imp.dz('20261010132532Z')
,p_last_updated_on=>wwv_flow_imp.dz('20261010195320Z')
,p_created_by=>'DEMO'
,p_last_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16275511449513612)
,p_plug_name=>'Database Explorer'
,p_static_id=>'DB_EXPLORER'
,p_region_name=>'DB_EXPLORER'
,p_parent_plug_id=>wwv_flow_imp.id(15878167149870151)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="db-explorer">',
'    <input',
'        type="search"',
'        id="db-search"',
'        placeholder="Search tables..."',
'        aria-label="Search database tables">',
'',
'    <div id="db-tree" role="tree">',
'        Loading tables...',
'    </div>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010191751Z')
,p_updated_on=>wwv_flow_imp.dz('20261010191751Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15672633848491118)
,p_plug_name=>'Results'
,p_static_id=>'RESULTS'
,p_region_name=>'RESULTS'
,p_parent_plug_id=>wwv_flow_imp.id(15878167149870151)
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="sql-status"></div>',
'',
'<div id="sql-results"',
'     style="overflow-x:auto; max-height:500px;">',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010133011Z')
,p_updated_on=>wwv_flow_imp.dz('20261010191751Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15878033021870151)
,p_plug_name=>'Criar Dataset'
,p_static_id=>'criar-dataset'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>2120525352897701877
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_list_id=>wwv_flow_imp.id(15877197144870123)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>2011625478452504874
,p_created_on=>wwv_flow_imp.dz('20261010132532Z')
,p_updated_on=>wwv_flow_imp.dz('20261010132532Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15878167149870151)
,p_plug_name=>'Criar Dataset'
,p_static_id=>'criar-dataset-2'
,p_parent_plug_id=>wwv_flow_imp.id(15878033021870151)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010132532Z')
,p_updated_on=>wwv_flow_imp.dz('20261010132532Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40234239132445891)
,p_plug_name=>'Data Marketplace'
,p_static_id=>'data-marketplace'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--featured'
,p_plug_template=>2675494171183407654
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010132616Z')
,p_updated_on=>wwv_flow_imp.dz('20261010132616Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15673071791491122)
,p_plug_name=>'Query'
,p_static_id=>'query'
,p_parent_plug_id=>wwv_flow_imp.id(15878167149870151)
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010133346Z')
,p_updated_on=>wwv_flow_imp.dz('20261010191751Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15879878175870164)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(15878033021870151)
,p_button_name=>'NEXT'
,p_static_id=>'NEXT_BTN'
,p_button_static_id=>'NEXT_BTN'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'t-Button--iconRight'
,p_button_template_id=>2084305881903810008
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-chevron-right'
,p_created_on=>wwv_flow_imp.dz('20261010132532Z')
,p_updated_on=>wwv_flow_imp.dz('20261010140147Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15879518035870164)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(15878033021870151)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_created_on=>wwv_flow_imp.dz('20261010132532Z')
,p_updated_on=>wwv_flow_imp.dz('20261010132532Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15672578287491117)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(15673071791491122)
,p_button_name=>'Submit'
,p_static_id=>'submit'
,p_show_as_disabled=>false
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'Submit'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-american-sign-language-interpreting'
,p_created_on=>wwv_flow_imp.dz('20261010132848Z')
,p_updated_on=>wwv_flow_imp.dz('20261010133346Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(15880554152870168)
,p_branch_action=>'f?p=&APP_ID.:4:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(15879878175870164)
,p_branch_sequence=>20
,p_created_on=>wwv_flow_imp.dz('20261010132532Z')
,p_updated_on=>wwv_flow_imp.dz('20261010132532Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15673263132491124)
,p_name=>'P3_EXECUTED'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(15673071791491122)
,p_item_default=>'N'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010134659Z')
,p_updated_on=>wwv_flow_imp.dz('20261010141217Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15673504310491127)
,p_name=>'P3_QUERY'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(15673071791491122)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010140127Z')
,p_updated_on=>wwv_flow_imp.dz('20261010141217Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15672421063491116)
,p_name=>'P3_SQL'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(15673071791491122)
,p_prompt=>'Digite sua Query'
,p_placeholder=>'Exemplo: SELECT SYSDATE FROM DUAL'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>10
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'N',
  'trim_spaces', 'NONE')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010132848Z')
,p_updated_on=>wwv_flow_imp.dz('20261010133605Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15672825999491120)
,p_name=>'Click'
,p_static_id=>'click'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(15672578287491117)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20261010133127Z')
,p_updated_on=>wwv_flow_imp.dz('20261010133127Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15672969161491121)
,p_event_id=>wwv_flow_imp.id(15672825999491120)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', 'executeSQL();')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010133127Z')
,p_updated_on=>wwv_flow_imp.dz('20261010133127Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(16275694947513613)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_DB_OBJECTS'
,p_static_id=>'get-db-objects'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--BEGIN',
'--    APEX_JSON.OPEN_OBJECT;',
'--    APEX_JSON.OPEN_ARRAY(''tables'');',
'--',
'--    FOR t IN (',
'--        SELECT table_name',
'--        FROM all_tables',
'--        WHERE owner = ''DEMO''',
'--          AND table_name NOT LIKE ''BIN$%''',
'--        ORDER BY table_name',
'--    )',
'--    LOOP',
'--        APEX_JSON.OPEN_OBJECT;',
'--',
'--        APEX_JSON.WRITE(''name'', t.table_name);',
'--',
'--        APEX_JSON.OPEN_ARRAY(''columns'');',
'--',
'--        FOR c IN (',
'--            SELECT',
'--                column_name,',
'--                data_type',
'--            FROM all_tab_columns',
'--            WHERE owner = ''DEMO''',
'--              AND table_name = t.table_name',
'--            ORDER BY column_id',
'--        )',
'--        LOOP',
'--            APEX_JSON.OPEN_OBJECT;',
'--            APEX_JSON.WRITE(''name'', c.column_name);',
'--            APEX_JSON.WRITE(''type'', c.data_type);',
'--            APEX_JSON.CLOSE_OBJECT;',
'--        END LOOP;',
'--',
'--        APEX_JSON.CLOSE_ARRAY;',
'--        APEX_JSON.CLOSE_OBJECT;',
'--    END LOOP;',
'--',
'--    APEX_JSON.CLOSE_ARRAY;',
'--    APEX_JSON.CLOSE_OBJECT;',
'--END;',
'',
'',
'BEGIN',
'    APEX_JSON.OPEN_OBJECT;',
'    APEX_JSON.OPEN_ARRAY(''tables'');',
'',
'    -- Get only tables registered in BASES',
'    FOR t IN (',
'        SELECT DISTINCT',
'            b.BASES_NOME AS TABLE_NAME',
'        FROM DEMO.BASES b',
'        INNER JOIN ALL_TABLES t',
'            ON t.TABLE_NAME = UPPER(TRIM(b.BASES_NOME))',
'           AND t.OWNER = ''DEMO''',
'        WHERE t.TABLE_NAME NOT LIKE ''BIN$%''',
'        ORDER BY TABLE_NAME',
'    )',
'    LOOP',
'        APEX_JSON.OPEN_OBJECT;',
'',
'        APEX_JSON.WRITE(',
'            ''name'',',
'            t.TABLE_NAME',
'        );',
'',
'        -- Get columns for each table',
'        APEX_JSON.OPEN_ARRAY(''columns'');',
'',
'        FOR c IN (',
'            SELECT',
'                COLUMN_NAME,',
'                DATA_TYPE',
'            FROM ALL_TAB_COLUMNS',
'            WHERE OWNER = ''DEMO''',
'              AND TABLE_NAME = UPPER(TRIM(t.TABLE_NAME))',
'            ORDER BY COLUMN_ID',
'        )',
'        LOOP',
'            APEX_JSON.OPEN_OBJECT;',
'',
'            APEX_JSON.WRITE(',
'                ''name'',',
'                c.COLUMN_NAME',
'            );',
'',
'            APEX_JSON.WRITE(',
'                ''type'',',
'                c.DATA_TYPE',
'            );',
'',
'            APEX_JSON.CLOSE_OBJECT;',
'        END LOOP;',
'',
'        APEX_JSON.CLOSE_ARRAY;',
'        APEX_JSON.CLOSE_OBJECT;',
'    END LOOP;',
'',
'    APEX_JSON.CLOSE_ARRAY;',
'    APEX_JSON.CLOSE_OBJECT;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>16275694947513613
,p_created_on=>wwv_flow_imp.dz('20261010191942Z')
,p_updated_on=>wwv_flow_imp.dz('20261010195040Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(15672767851491119)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'EXECUTE_SELECT'
,p_static_id=>'query'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_sql           VARCHAR2(32767);',
'    l_cursor        INTEGER;',
'    l_column_count  INTEGER;',
'    l_columns       DBMS_SQL.DESC_TAB2;',
'    l_value         VARCHAR2(4000);',
'    l_status        INTEGER;',
'    l_rows          INTEGER := 0;',
'    l_start         NUMBER;',
'    l_elapsed       NUMBER;',
'    l_error         VARCHAR2(4000);',
'    l_json          CLOB;',
'',
'BEGIN',
'    -- Reset execution status',
'    :P3_EXECUTED := ''N'';',
'    :P3_QUERY := NULL;',
'',
'    l_start := DBMS_UTILITY.GET_TIME;',
'',
'    l_sql := TRIM(APEX_APPLICATION.G_X01);',
'',
'    -- Basic SELECT validation',
'    IF l_sql IS NULL OR NOT REGEXP_LIKE(',
'        l_sql,',
'        ''^\s*SELECT\s'',',
'        ''i''',
'    ) THEN',
'        RAISE_APPLICATION_ERROR(',
'            -20001,',
'            ''Only SELECT statements are allowed.''',
'        );',
'    END IF;',
'',
'    -- Open cursor',
'    l_cursor := DBMS_SQL.OPEN_CURSOR;',
'',
'    DBMS_SQL.PARSE(',
'        l_cursor,',
'        l_sql,',
'        DBMS_SQL.NATIVE',
'    );',
'',
'    -- Get column metadata',
'    DBMS_SQL.DESCRIBE_COLUMNS2(',
'        l_cursor,',
'        l_column_count,',
'        l_columns',
'    );',
'',
'    -- Define dynamic columns',
'    FOR i IN 1 .. l_column_count LOOP',
'        DBMS_SQL.DEFINE_COLUMN(',
'            l_cursor,',
'            i,',
'            l_value,',
'            4000',
'        );',
'    END LOOP;',
'',
'    -- Execute query',
'    l_status := DBMS_SQL.EXECUTE(l_cursor);',
'',
'    -- Build JSON in memory',
'    APEX_JSON.INITIALIZE_CLOB_OUTPUT;',
'',
'    APEX_JSON.OPEN_OBJECT;',
'',
'    APEX_JSON.WRITE(''success'', TRUE);',
'',
'    -- Column metadata',
'    APEX_JSON.OPEN_ARRAY(''columns'');',
'',
'    FOR i IN 1 .. l_column_count LOOP',
'        APEX_JSON.OPEN_OBJECT;',
'',
'        APEX_JSON.WRITE(',
'            ''name'',',
'            l_columns(i).col_name',
'        );',
'',
'        APEX_JSON.CLOSE_OBJECT;',
'    END LOOP;',
'',
'    APEX_JSON.CLOSE_ARRAY;',
'',
'    -- Result rows',
'    APEX_JSON.OPEN_ARRAY(''rows'');',
'',
'    WHILE l_rows < 100',
'      AND DBMS_SQL.FETCH_ROWS(l_cursor) > 0',
'    LOOP',
'        APEX_JSON.OPEN_ARRAY;',
'',
'        FOR i IN 1 .. l_column_count LOOP',
'            DBMS_SQL.COLUMN_VALUE(',
'                l_cursor,',
'                i,',
'                l_value',
'            );',
'',
'            APEX_JSON.WRITE(l_value);',
'        END LOOP;',
'',
'        APEX_JSON.CLOSE_ARRAY;',
'',
'        l_rows := l_rows + 1;',
'    END LOOP;',
'',
'    APEX_JSON.CLOSE_ARRAY;',
'',
'    -- Close cursor',
'    DBMS_SQL.CLOSE_CURSOR(l_cursor);',
'',
'    l_cursor := NULL;',
'',
'    -- Calculate execution time',
'    l_elapsed :=',
'        (DBMS_UTILITY.GET_TIME - l_start) / 100;',
'',
'    -- Mark query as successfully executed',
'    :P3_QUERY := l_sql;',
'    :P3_EXECUTED := ''Y'';',
'',
'    -- Execution information',
'    APEX_JSON.WRITE(''rowCount'', l_rows);',
'',
'    APEX_JSON.WRITE(',
'        ''executionTime'',',
'        l_elapsed',
'    );',
'',
'    APEX_JSON.WRITE(',
'        ''executed'',',
'        :P3_EXECUTED',
'    );',
'',
'    APEX_JSON.CLOSE_OBJECT;',
'',
'    -- Get complete JSON response',
'    l_json := APEX_JSON.GET_CLOB_OUTPUT;',
'',
'    APEX_JSON.FREE_OUTPUT;',
'',
'    -- Send JSON to browser',
'    SYS.HTP.PRN(l_json);',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'',
'        l_error := SQLERRM;',
'',
'        -- Mark execution as failed',
'        :P3_EXECUTED := ''N'';',
'        :P3_QUERY := NULL;',
'',
'        -- Close cursor safely',
'        IF l_cursor IS NOT NULL THEN',
'            IF DBMS_SQL.IS_OPEN(l_cursor) THEN',
'                DBMS_SQL.CLOSE_CURSOR(l_cursor);',
'            END IF;',
'        END IF;',
'',
'        -- Clean up any incomplete JSON',
'        BEGIN',
'            APEX_JSON.FREE_OUTPUT;',
'        EXCEPTION',
'            WHEN OTHERS THEN',
'                NULL;',
'        END;',
'',
'        -- Return valid error JSON',
'        APEX_JSON.OPEN_OBJECT;',
'',
'        APEX_JSON.WRITE(''success'', FALSE);',
'',
'        APEX_JSON.WRITE(',
'            ''executed'',',
'            :P3_EXECUTED',
'        );',
'',
'        APEX_JSON.WRITE(',
'            ''error'',',
'            l_error',
'        );',
'',
'        APEX_JSON.CLOSE_OBJECT;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>15672767851491119
,p_created_on=>wwv_flow_imp.dz('20261010133011Z')
,p_updated_on=>wwv_flow_imp.dz('20261010141403Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(15673326911491125)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Query Executed'
,p_static_id=>'set-query-executed'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    IF TRIM(:P3_SQL) IS NOT NULL THEN',
'        :P3_EXECUTED := ''Y'';',
'    ELSE',
'        :P3_EXECUTED := ''N'';',
'    END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(15672578287491117)
,p_internal_uid=>15673326911491125
,p_created_on=>wwv_flow_imp.dz('20261010134743Z')
,p_updated_on=>wwv_flow_imp.dz('20261010134743Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(15673939919491131)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Value'
,p_static_id=>'set-value'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_sql          VARCHAR2(32767);',
'    l_cursor       INTEGER;',
'    l_column_count INTEGER;',
'    l_columns      DBMS_SQL.DESC_TAB2;',
'    l_column_name  VARCHAR2(32767);',
'    l_error        VARCHAR2(4000);',
'',
'    l_reserved     NUMBER;',
'',
'BEGIN',
'    -- Get SQL from Page 3',
'    l_sql := TRIM(:P3_SQL);',
'',
'    IF l_sql IS NULL THEN',
'        RAISE_APPLICATION_ERROR(',
'            -20001,',
'            ''Please execute a SELECT query before continuing.''',
'        );',
'    END IF;',
'',
'    -- Open cursor',
'    l_cursor := DBMS_SQL.OPEN_CURSOR;',
'',
'    DBMS_SQL.PARSE(',
'        l_cursor,',
'        l_sql,',
'        DBMS_SQL.NATIVE',
'    );',
'',
'    DBMS_SQL.DESCRIBE_COLUMNS2(',
'        l_cursor,',
'        l_column_count,',
'        l_columns',
'    );',
'',
'    -- Validate returned columns',
'    FOR i IN 1 .. l_column_count LOOP',
'',
'        l_column_name := UPPER(TRIM(l_columns(i).col_name));',
'',
'        -- Check invalid column names',
'        IF NOT REGEXP_LIKE(',
'            l_column_name,',
'            ''^[A-Z][A-Z0-9_$#]*$''',
'        ) THEN',
'            RAISE_APPLICATION_ERROR(',
'                -20002,',
'                ''Column "'' || l_column_name ||',
'                ''" requires an alias. Example: AS COLUMN_NAME.''',
'            );',
'        END IF;',
'',
'        -- Check common expressions without aliases',
'        IF l_column_name IN (',
'            ''SYSDATE'',',
'            ''SYSTIMESTAMP'',',
'            ''CURRENT_DATE'',',
'            ''CURRENT_TIMESTAMP'',',
'            ''LOCALTIMESTAMP'',',
'            ''USER'',',
'            ''UID'',',
'            ''ROWNUM'',',
'            ''LEVEL''',
'        ) THEN',
'            RAISE_APPLICATION_ERROR(',
'                -20003,',
'                ''Expression "'' || l_column_name ||',
'                ''" requires an alias. Example: '' ||',
'                l_column_name || '' AS COLUMN_NAME.''',
'            );',
'        END IF;',
'',
'    END LOOP;',
'',
'    DBMS_SQL.CLOSE_CURSOR(l_cursor);',
'    l_cursor := NULL;',
'',
'    -- Transfer validated SQL',
'    :P4_SQL := l_sql;',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'',
'        l_error := SQLERRM;',
'',
'        IF l_cursor IS NOT NULL THEN',
'            IF DBMS_SQL.IS_OPEN(l_cursor) THEN',
'                DBMS_SQL.CLOSE_CURSOR(l_cursor);',
'            END IF;',
'        END IF;',
'',
'        RAISE_APPLICATION_ERROR(',
'            -20004,',
'            ''SQL validation failed: '' || l_error',
'        );',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(15879878175870164)
,p_internal_uid=>15673939919491131
,p_created_on=>wwv_flow_imp.dz('20261010142316Z')
,p_updated_on=>wwv_flow_imp.dz('20261010144708Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp.component_end;
end;
/
