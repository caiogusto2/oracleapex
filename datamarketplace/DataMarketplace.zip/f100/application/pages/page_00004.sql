prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>9464009710794554
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DEMO'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Revisar Dataset'
,p_alias=>'REVISAR-DATASET'
,p_step_title=>'Revisar Dataset'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-HeroRegion-icon {',
'    background-color: transparent;',
'}'))
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_created_on=>wwv_flow_imp.dz('20261010132532Z')
,p_last_updated_on=>wwv_flow_imp.dz('20261010224832Z')
,p_created_by=>'DEMO'
,p_last_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56140796160823760)
,p_plug_name=>'Data Marketplace'
,p_static_id=>'data-marketplace'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--featured'
,p_plug_template=>2675494171183407654
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010145009Z')
,p_updated_on=>wwv_flow_imp.dz('20261010145009Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15881273344870171)
,p_plug_name=>'Revisar Dataset'
,p_static_id=>'revisar-dataset'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>2120525352897701877
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_list_id=>wwv_flow_imp.id(15877197144870123)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>2011625478452504874
,p_created_on=>wwv_flow_imp.dz('20261010132532Z')
,p_updated_on=>wwv_flow_imp.dz('20261010132532Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15881359665870171)
,p_plug_name=>'Revisar Dataset'
,p_static_id=>'revisar-dataset-2'
,p_parent_plug_id=>wwv_flow_imp.id(15881273344870171)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010132532Z')
,p_updated_on=>wwv_flow_imp.dz('20261010132532Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15882798945870179)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(15881273344870171)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_created_on=>wwv_flow_imp.dz('20261010132532Z')
,p_updated_on=>wwv_flow_imp.dz('20261010132532Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15883017762870179)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(15881273344870171)
,p_button_name=>'NEXT'
,p_static_id=>'next'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'t-Button--iconRight'
,p_button_template_id=>2084305881903810008
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-chevron-right'
,p_created_on=>wwv_flow_imp.dz('20261010132532Z')
,p_updated_on=>wwv_flow_imp.dz('20261010142935Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15882923151870179)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(15881273344870171)
,p_button_name=>'PREVIOUS'
,p_static_id=>'previous'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'Previous'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
,p_created_on=>wwv_flow_imp.dz('20261010132532Z')
,p_updated_on=>wwv_flow_imp.dz('20261010132532Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(15883771830870181)
,p_branch_action=>'f?p=&APP_ID.:3:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(15882923151870179)
,p_branch_sequence=>10
,p_created_on=>wwv_flow_imp.dz('20261010132532Z')
,p_updated_on=>wwv_flow_imp.dz('20261010132532Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(15884420138870183)
,p_branch_action=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::P5_TABELA:&P4_NOME_DATASET.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(15883017762870179)
,p_branch_sequence=>20
,p_created_on=>wwv_flow_imp.dz('20261010132532Z')
,p_updated_on=>wwv_flow_imp.dz('20261010152809Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15674103243491133)
,p_name=>'P4_COMENTARIOS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(15881359665870171)
,p_prompt=>unistr('Coment\00E1rios')
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010142607Z')
,p_updated_on=>wwv_flow_imp.dz('20261010142953Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15674076586491132)
,p_name=>'P4_NOME_DATASET'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(15881359665870171)
,p_prompt=>'Nome Dataset'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>128
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'text_case', 'UPPER',
  'trim_spaces', 'BOTH')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010142513Z')
,p_updated_on=>wwv_flow_imp.dz('20261010175000Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15673846748491130)
,p_name=>'P4_SQL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(15881359665870171)
,p_prompt=>'Query do Dataset'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010142232Z')
,p_updated_on=>wwv_flow_imp.dz('20261010142838Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(15674358243491135)
,p_validation_name=>'NameConvention'
,p_static_id=>'nameconvention'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'REGEXP_LIKE(',
'    :P4_NOME_DATASET,',
'    ''^[A-Za-z][A-Za-z0-9]*(_[A-Za-z0-9]+)+$''',
')'))
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Invalid table name. Use letters, numbers, and at least one underscore (_). The name must start with a letter. Example: TABLE_TESTE.'
,p_associated_item=>wwv_flow_imp.id(15674076586491132)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
,p_created_on=>wwv_flow_imp.dz('20261010143251Z')
,p_updated_on=>wwv_flow_imp.dz('20261010143251Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(15674412426491136)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CTAS'
,p_static_id=>'ctas'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--DECLARE',
'--    l_table_name VARCHAR2(128);',
'--    l_sql        VARCHAR2(32767);',
'--    l_ctas       VARCHAR2(32767);',
'--    l_exists     NUMBER;',
'--',
'--BEGIN',
'--    -- Get dataset name',
'--    l_table_name := UPPER(TRIM(:P4_NOME_DATASET));',
'--',
'--    -- Get SELECT query',
'--    l_sql := TRIM(:P4_SQL);',
'--',
'--    -- Validate dataset name',
'--    IF NOT REGEXP_LIKE(',
'--        l_table_name,',
'--        ''^[A-Z][A-Z0-9]*(_[A-Z0-9]+)+$''',
'--    ) THEN',
'--        RAISE_APPLICATION_ERROR(',
'--            -20001,',
'--            ''Invalid dataset name. Example: SALES_DATASET''',
'--        );',
'--    END IF;',
'--',
'--    -- Validate SQL',
'--    IF l_sql IS NULL OR NOT REGEXP_LIKE(',
'--        l_sql,',
'--        ''^SELECT[[:space:]]'',',
'--        ''i''',
'--    ) THEN',
'--        RAISE_APPLICATION_ERROR(',
'--            -20002,',
'--            ''Only SELECT statements are allowed.''',
'--        );',
'--    END IF;',
'--',
'--    -- Validate table name',
'--    l_table_name := DBMS_ASSERT.SIMPLE_SQL_NAME(l_table_name);',
'--',
'--    -- Check if object already exists',
'--    SELECT COUNT(*)',
'--      INTO l_exists',
'--      FROM USER_OBJECTS',
'--     WHERE OBJECT_NAME = l_table_name;',
'--',
'--    IF l_exists > 0 THEN',
'--        RAISE_APPLICATION_ERROR(',
'--            -20004,',
'--            ''A database object with this name already exists.''',
'--        );',
'--    END IF;',
'--',
'--    -- Build CTAS preserving original column names',
'--    l_ctas :=',
'--        ''CREATE TABLE '' ||',
'--        l_table_name ||',
'--        '' PARALLEL 4 AS '' ||',
'--        l_sql;',
'--',
'--    -- Execute CTAS',
'--    EXECUTE IMMEDIATE l_ctas;',
'--',
'--    -- Register Dataset',
'--    INSERT INTO DATASETS (',
'--        DATASETS_NOME,',
'--        DESCRICAO,',
'--        DATASETS_SQL',
'--    )',
'--    VALUES (',
'--        l_table_name,',
'--        :P4_COMENTARIOS,',
'--        l_sql',
'--    );',
'--',
'--    -- Success message',
'--    APEX_APPLICATION.G_PRINT_SUCCESS_MESSAGE :=',
'--        ''Dataset '' || l_table_name ||',
'--        '' created successfully!'';',
'--',
'--EXCEPTION',
'--    WHEN OTHERS THEN',
'--',
'--        IF SQLCODE = -998 THEN',
'--            APEX_ERROR.ADD_ERROR(',
'--                p_message =>',
'--                    ''Your SQL contains expressions without column aliases. '' ||',
'--                    ''Please add aliases using AS. '' ||',
'--                    ''Example: COUNT(*) AS TOTAL_EMPLOYEES.'',',
'--                p_display_location =>',
'--                    APEX_ERROR.C_INLINE_IN_NOTIFICATION',
'--            );',
'--        ELSE',
'--            APEX_ERROR.ADD_ERROR(',
'--                p_message => SQLERRM,',
'--                p_display_location =>',
'--                    APEX_ERROR.C_INLINE_IN_NOTIFICATION',
'--            );',
'--        END IF;',
'--',
'--END;',
'',
'',
'',
'',
'',
'DECLARE',
'    l_table_name    VARCHAR2(128);',
'    l_sql           VARCHAR2(32767);',
'    l_ctas          VARCHAR2(32767);',
'    l_exists        NUMBER;',
'',
'    l_original_service VARCHAR2(128);',
'    l_service_switched BOOLEAN := FALSE;',
'',
'    l_error_code    NUMBER;',
'    l_error_message VARCHAR2(4000);',
'',
'BEGIN',
'',
'    -- ==========================================',
'    -- 1. GET DATASET INFORMATION',
'    -- ==========================================',
'',
'    l_table_name := UPPER(TRIM(:P4_NOME_DATASET));',
'    l_sql        := TRIM(:P4_SQL);',
'',
'    -- ==========================================',
'    -- 2. VALIDATE DATASET NAME',
'    -- ==========================================',
'',
'    IF l_table_name IS NULL',
'       OR NOT REGEXP_LIKE(',
'           l_table_name,',
'           ''^[A-Z][A-Z0-9]*(_[A-Z0-9]+)+$''',
'       )',
'    THEN',
'        RAISE_APPLICATION_ERROR(',
'            -20001,',
'            ''Invalid dataset name. Example: SALES_DATASET''',
'        );',
'    END IF;',
'',
'    -- ==========================================',
'    -- 3. VALIDATE SQL',
'    -- ==========================================',
'',
'    IF l_sql IS NULL',
'       OR NOT REGEXP_LIKE(',
'           l_sql,',
'           ''^SELECT[[:space:]]'',',
'           ''i''',
'       )',
'    THEN',
'        RAISE_APPLICATION_ERROR(',
'            -20002,',
'            ''Only SELECT statements are allowed.''',
'        );',
'    END IF;',
'',
'    -- ==========================================',
'    -- 4. VALIDATE TABLE NAME',
'    -- ==========================================',
'',
'    l_table_name :=',
'        DBMS_ASSERT.SIMPLE_SQL_NAME(l_table_name);',
'',
'    -- ==========================================',
'    -- 5. CHECK IF OBJECT EXISTS',
'    -- ==========================================',
'',
'    SELECT COUNT(*)',
'      INTO l_exists',
'      FROM USER_OBJECTS',
'     WHERE OBJECT_NAME = l_table_name;',
'',
'    IF l_exists > 0 THEN',
'        RAISE_APPLICATION_ERROR(',
'            -20004,',
'            ''A database object with this name already exists.''',
'        );',
'    END IF;',
'',
'    -- ==========================================',
'    -- 6. BUILD PARALLEL CTAS',
'    -- ==========================================',
'',
'    l_ctas :=',
'        ''CREATE TABLE '' ||',
'        l_table_name ||',
'        '' PARALLEL 4 AS '' ||',
'        l_sql;',
'',
'    -- ==========================================',
'    -- 7. SAVE ORIGINAL SERVICE',
'    -- ==========================================',
'',
'    l_original_service :=',
'        SYS_CONTEXT(''USERENV'', ''SERVICE_NAME'');',
'',
'    APEX_DEBUG.MESSAGE(',
'        ''Original service: %s'',',
'        l_original_service',
'    );',
'',
'    -- ==========================================',
'    -- 8. SWITCH TO MEDIUM',
'    -- ==========================================',
'',
'    CS_SESSION.SWITCH_SERVICE(''MEDIUM'');',
'',
'    l_service_switched := TRUE;',
'',
'    APEX_DEBUG.MESSAGE(',
'        ''CTAS service: %s'',',
'        SYS_CONTEXT(''USERENV'', ''SERVICE_NAME'')',
'    );',
'',
'    -- ==========================================',
'    -- 9. ENABLE PARALLEL DDL',
'    -- ==========================================',
'',
'    EXECUTE IMMEDIATE',
'        ''ALTER SESSION ENABLE PARALLEL DDL'';',
'',
'    -- ==========================================',
'    -- 10. EXECUTE CTAS',
'    -- ==========================================',
'',
'    EXECUTE IMMEDIATE l_ctas;',
'',
'    -- ==========================================',
'    -- 11. DISABLE PARALLEL DDL',
'    -- ==========================================',
'',
'    EXECUTE IMMEDIATE',
'        ''ALTER SESSION DISABLE PARALLEL DDL'';',
'',
'    -- ==========================================',
'    -- 12. RESTORE ORIGINAL SERVICE',
'    -- ==========================================',
'',
'    CS_SESSION.SWITCH_SERVICE(''LOW'');',
'',
'    l_service_switched := FALSE;',
'',
'    -- ==========================================',
'    -- 13. REGISTER DATASET',
'    -- ==========================================',
'',
'    INSERT INTO DATASETS (',
'        DATASETS_NOME,',
'        DESCRICAO,',
'        DATASETS_SQL',
'    )',
'    VALUES (',
'        l_table_name,',
'        :P4_COMENTARIOS,',
'        l_sql',
'    );',
'',
'    -- ==========================================',
'    -- 14. SUCCESS MESSAGE',
'    -- ==========================================',
'',
'    APEX_APPLICATION.G_PRINT_SUCCESS_MESSAGE :=',
'        ''Dataset '' || l_table_name ||',
'        '' created successfully using MEDIUM service (PARALLEL 4)!'';',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'',
'        l_error_code    := SQLCODE;',
'        l_error_message := SQLERRM;',
'',
'        -- ======================================',
'        -- RESTORE SESSION SETTINGS',
'        -- ======================================',
'',
'        BEGIN',
'            EXECUTE IMMEDIATE',
'                ''ALTER SESSION DISABLE PARALLEL DDL'';',
'        EXCEPTION',
'            WHEN OTHERS THEN',
'                APEX_DEBUG.ERROR(',
'                    ''Unable to disable Parallel DDL: %s'',',
'                    SQLERRM',
'                );',
'        END;',
'',
'        IF l_service_switched THEN',
'',
'            BEGIN',
'                CS_SESSION.SWITCH_SERVICE(''LOW'');',
'            EXCEPTION',
'                WHEN OTHERS THEN',
'                    APEX_DEBUG.ERROR(',
'                        ''Unable to restore LOW service: %s'',',
'                        SQLERRM',
'                    );',
'            END;',
'',
'        END IF;',
'',
'        -- ======================================',
'        -- DISPLAY ERROR',
'        -- ======================================',
'',
'        IF l_error_code = -998 THEN',
'',
'            APEX_ERROR.ADD_ERROR(',
'                p_message =>',
'                    ''Your SQL contains expressions without column aliases. '' ||',
'                    ''Please add aliases using AS. '' ||',
'                    ''Example: COUNT(*) AS TOTAL_EMPLOYEES.'',',
'                p_display_location =>',
'                    APEX_ERROR.C_INLINE_IN_NOTIFICATION',
'            );',
'',
'        ELSE',
'',
'            APEX_ERROR.ADD_ERROR(',
'                p_message => l_error_message,',
'                p_display_location =>',
'                    APEX_ERROR.C_INLINE_IN_NOTIFICATION',
'            );',
'',
'        END IF;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(15883017762870179)
,p_internal_uid=>15674412426491136
,p_created_on=>wwv_flow_imp.dz('20261010143458Z')
,p_updated_on=>wwv_flow_imp.dz('20261010224832Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp.component_end;
end;
/
