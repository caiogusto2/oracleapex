prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>9464009710794554
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DEMO'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Detalhe Base'
,p_alias=>'DETALHE-BASE'
,p_step_title=>'Detalhe Base'
,p_reload_on_submit=>'A'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function loadDatasetPreview() {',
'',
'    const dataset = apex.item("P2_BASE").getValue();',
'',
'    const status = document.getElementById("preview-status");',
'    const results = document.getElementById("preview-results");',
'',
'    if (!status || !results) {',
'        console.error("Preview containers not found.");',
'        return;',
'    }',
'',
'    results.replaceChildren();',
'',
'    if (!dataset || !dataset.trim()) {',
'        status.textContent = "Nenhum dataset selecionado.";',
'        return;',
'    }',
'',
'    status.textContent = "Carregando dados...";',
'',
'    apex.server.process(',
'        "LOAD_DATASET_PREVIEW",',
'        {',
'            x01: dataset',
'        },',
'        {',
'            dataType: "json",',
'',
'            success: function(data) {',
'',
'                console.log("AJAX response:", data);',
'',
'                if (!data.success) {',
'                    status.textContent =',
'                        "Erro: " +',
'                        (data.error || "Erro desconhecido");',
'                    return;',
'                }',
'',
'                status.textContent =',
'                    "Dataset: " + data.dataset +',
'                    " | Linhas exibidas: " + data.rowCount +',
'                    " | Tempo: " + data.executionTime + "s";',
'',
'                const table = document.createElement("table");',
'',
'                table.className =',
'                    "a-IRR-table dataset-preview-table";',
'',
'                const thead = document.createElement("thead");',
'                const headerRow = document.createElement("tr");',
'',
'                (data.columns || []).forEach(function(col) {',
'',
'                    const th = document.createElement("th");',
'',
'                    th.textContent = col.name;',
'',
'                    headerRow.appendChild(th);',
'                });',
'',
'                thead.appendChild(headerRow);',
'                table.appendChild(thead);',
'',
'                const tbody = document.createElement("tbody");',
'',
'                (data.rows || []).forEach(function(row) {',
'',
'                    const tr = document.createElement("tr");',
'',
'                    row.forEach(function(value) {',
'',
'                        const td = document.createElement("td");',
'',
'                        td.textContent = value ?? "";',
'',
'                        tr.appendChild(td);',
'                    });',
'',
'                    tbody.appendChild(tr);',
'                });',
'',
'                table.appendChild(tbody);',
'                results.appendChild(table);',
'',
'            },',
'',
'            error: function(jqXHR, textStatus, errorThrown) {',
'',
'                console.error(',
'                    "AJAX Response:",',
'                    jqXHR.responseText',
'                );',
'',
'                status.textContent =',
'                    "Erro ao carregar dados: " +',
'                    (errorThrown || textStatus);',
'            }',
'        }',
'    );',
'}',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'function copyDatasetSQL() {',
'',
'    const sqlElement =',
'        document.getElementById("dataset-sql-code");',
'',
'    if (!sqlElement) {',
unistr('        apex.message.alert("SQL n\00E3o encontrado.");'),
'        return;',
'    }',
'',
'    const sql = sqlElement.textContent;',
'',
'    navigator.clipboard.writeText(sql)',
'        .then(function() {',
'',
'            apex.message.showPageSuccess(',
unistr('                "SQL copiado para a \00E1rea de transfer\00EAncia!"'),
'            );',
'',
'        })',
'        .catch(function(error) {',
'',
'            console.error("Erro ao copiar SQL:", error);',
'',
'            apex.message.alert(',
unistr('                "N\00E3o foi poss\00EDvel copiar o SQL."'),
'            );',
'',
'        });',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'loadDatasetPreview();',
'',
'',
'//const downloadUrl = apex.item("P2_DOWNLOAD_URL").getValue();',
'//',
'//if (downloadUrl && downloadUrl.startsWith(',
'//    "https://objectstorage.sa-vinhedo-1.oraclecloud.com/"',
'//)) {',
'//',
'//    window.open(',
'//        downloadUrl,',
'//        "_blank",',
'//        "noopener,noreferrer"',
'//    );',
'//}'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* ==========================================',
'   DATASET OVERVIEW - MAIN CONTAINER',
'   ========================================== */',
'',
'.dataset-overview {',
'    background: #ffffff;',
'    border: 1px solid #e5e7eb;',
'    border-radius: 12px;',
'    padding: 24px;',
'    margin-bottom: 20px;',
'    font-family: inherit;',
'    width: 100%;',
'    box-sizing: border-box;',
'}',
'',
'/* ==========================================',
'   DATASET HEADER',
'   ========================================== */',
'',
'.dataset-header {',
'    display: flex;',
'    align-items: flex-start;',
'    gap: 16px;',
'    margin-bottom: 24px;',
'}',
'',
'.dataset-icon {',
'    width: 48px;',
'    height: 48px;',
'    background: #eef2ff;',
'    color: #4f46e5;',
'    border-radius: 12px;',
'    display: flex;',
'    align-items: center;',
'    justify-content: center;',
'    font-size: 22px;',
'    flex-shrink: 0;',
'}',
'',
'.dataset-title {',
'    flex: 1;',
'    min-width: 0;',
'}',
'',
'.dataset-title h2 {',
'    font-size: 22px;',
'    font-weight: 700;',
'    color: #111827;',
'    margin: 0 0 6px;',
'    overflow-wrap: anywhere;',
'}',
'',
'.dataset-title p {',
'    font-size: 14px;',
'    color: #6b7280;',
'    margin: 0;',
'    line-height: 1.6;',
'    overflow-wrap: anywhere;',
'}',
'',
'/* ==========================================',
'   DATASET STATISTICS GRID',
'   ========================================== */',
'',
'.dataset-stats {',
'    display: grid;',
'    grid-template-columns: repeat(4, minmax(0, 1fr));',
'    gap: 16px;',
'    width: 100%;',
'}',
'',
'/* ==========================================',
'   STATISTIC CARDS',
'   ========================================== */',
'',
'.dataset-stat {',
'    display: flex;',
'    align-items: center;',
'    gap: 14px;',
'    padding: 18px;',
'    background: #f9fafb;',
'    border: 1px solid #f3f4f6;',
'    border-radius: 10px;',
'    transition:',
'        background-color 0.2s ease,',
'        box-shadow 0.2s ease,',
'        transform 0.2s ease;',
'    min-width: 0;',
'    box-sizing: border-box;',
'}',
'',
'.dataset-stat:hover {',
'    background: #f3f4f6;',
'    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);',
'    transform: translateY(-2px);',
'}',
'',
'/* ==========================================',
'   STATISTIC ICONS',
'   ========================================== */',
'',
'.stat-icon {',
'    width: 40px;',
'    height: 40px;',
'    background: #ffffff;',
'    color: #6366f1;',
'    border-radius: 8px;',
'    display: flex;',
'    align-items: center;',
'    justify-content: center;',
'    font-size: 18px;',
'    flex-shrink: 0;',
'}',
'',
'/* ==========================================',
'   STATISTIC CONTENT',
'   ========================================== */',
'',
'.stat-content {',
'    display: flex;',
'    flex-direction: column;',
'    min-width: 0;',
'    flex: 1;',
'}',
'',
'.stat-label {',
'    font-size: 12px;',
'    font-weight: 500;',
'    color: #6b7280;',
'    margin-bottom: 4px;',
'    line-height: 1.4;',
'    overflow-wrap: anywhere;',
'}',
'',
'.stat-value {',
'    font-size: 17px;',
'    font-weight: 700;',
'    color: #111827;',
'    line-height: 1.4;',
'    overflow-wrap: anywhere;',
'    font-variant-numeric: tabular-nums;',
'}',
'',
'/* ==========================================',
'   RESPONSIVE - TABLETS',
'   ========================================== */',
'',
'@media (max-width: 1100px) {',
'',
'    .dataset-stats {',
'        grid-template-columns: repeat(2, minmax(0, 1fr));',
'    }',
'',
'    .dataset-stat {',
'        padding: 16px;',
'    }',
'',
'}',
'',
'/* ==========================================',
'   RESPONSIVE - MOBILE',
'   ========================================== */',
'',
'@media (max-width: 768px) {',
'',
'    .dataset-overview {',
'        padding: 18px;',
'    }',
'',
'    .dataset-stats {',
'        grid-template-columns: 1fr;',
'        gap: 12px;',
'    }',
'',
'    .dataset-header {',
'        flex-direction: column;',
'        gap: 12px;',
'    }',
'',
'    .dataset-title h2 {',
'        font-size: 20px;',
'    }',
'',
'    .dataset-stat {',
'        padding: 14px;',
'    }',
'',
'    .stat-value {',
'        font-size: 16px;',
'    }',
'',
'}',
'',
'/* ==========================================',
'   ACCESSIBILITY - REDUCED MOTION',
'   ========================================== */',
'',
'@media (prefers-reduced-motion: reduce) {',
'',
'    .dataset-stat {',
'        transition: none;',
'    }',
'',
'    .dataset-stat:hover {',
'        transform: none;',
'    }',
'',
'}',
'',
'/* ==========================================',
'   ORACLE APEX - HERO REGION CUSTOMIZATION',
'   ========================================== */',
'',
'.t-HeroRegion-icon {',
'    background-color: transparent;',
'}',
'',
'',
'',
'',
'',
'',
'',
'',
'.t-Report-colHead {',
'    background-color: BLACK;',
'    color: white;',
'}',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'/* ==========================================',
'   DATASET PREVIEW',
'========================================== */',
'',
'.dataset-preview-container {',
'    margin-top: 30px;',
'    background: #ffffff;',
'    border: 1px solid #e2e8f0;',
'    border-radius: 12px;',
'    overflow: hidden;',
'}',
'',
'/* Header */',
'',
'.dataset-preview-header {',
'    display: flex;',
'    align-items: center;',
'    justify-content: space-between;',
'    gap: 15px;',
'    padding: 18px 22px;',
'    border-bottom: 1px solid #e2e8f0;',
'}',
'',
'.dataset-preview-header h3 {',
'    margin: 0;',
'    font-size: 18px;',
'    font-weight: 600;',
'}',
'',
'/* Status */',
'',
'#preview-status {',
'    padding: 12px 22px;',
'    font-size: 13px;',
'    color: #475569;',
'    background: #f8fafc;',
'}',
'',
'/* Results */',
'',
'#preview-results {',
'    overflow: auto;',
'    max-height: 550px;',
'}',
'',
'/* Table */',
'',
'.dataset-preview-table {',
'    width: 100%;',
'    border-collapse: collapse;',
'    font-size: 13px;',
'}',
'',
'.dataset-preview-table th {',
'    position: sticky;',
'    top: 0;',
'    z-index: 1;',
'    padding: 12px 14px;',
'    background: #f1f5f9;',
'    color: #334155;',
'    text-align: left;',
'    font-weight: 600;',
'    white-space: nowrap;',
'    border-bottom: 2px solid #cbd5e1;',
'}',
'',
'.dataset-preview-table td {',
'    padding: 10px 14px;',
'    border-bottom: 1px solid #e2e8f0;',
'    white-space: nowrap;',
'}',
'',
'.dataset-preview-table tbody tr:hover {',
'    background: #f8fafc;',
'}',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'/* ==========================================',
'   COLUMN STATS - CLASSIC REPORT',
'   Oracle APEX Universal Theme',
'========================================== */',
'',
'/* MAIN REGION */',
'#COLUMN_STATS {',
'    width: 100%;',
'    max-width: 100%;',
'    min-width: 0;',
'    background: #ffffff;',
'    border: 1px solid #e2e8f0;',
'    border-radius: 12px;',
'    box-sizing: border-box;',
'    overflow: hidden;',
'}',
'',
'/* REGION HEADER */',
'#COLUMN_STATS .t-Region-header {',
'    padding: 18px 22px;',
'    background: #ffffff;',
'    border-bottom: 1px solid #e2e8f0;',
'}',
'',
'#COLUMN_STATS .t-Region-title {',
'    font-size: 18px;',
'    font-weight: 600;',
'    color: #1e293b;',
'}',
'',
'/* REGION BODY */',
'#COLUMN_STATS .t-Region-body {',
'    padding: 0 !important;',
'    min-width: 0;',
'}',
'',
'/* APEX REPORT WRAPPERS */',
'#COLUMN_STATS .t-Report,',
'#COLUMN_STATS .t-Report-wrap {',
'    width: 100%;',
'    max-width: 100%;',
'    min-width: 0;',
'    box-sizing: border-box;',
'}',
'',
'/* SCROLLABLE TABLE CONTAINER */',
'#COLUMN_STATS .t-Report-tableWrap {',
'    display: block;',
'    width: 100%;',
'    max-width: 100%;',
'    min-width: 0;',
'',
'    overflow-x: auto;',
'    overflow-y: auto;',
'',
'    max-height: 550px;',
'    box-sizing: border-box;',
'}',
'',
'/* TABLE */',
'#COLUMN_STATS .t-Report-report {',
'    width: max-content;',
'    min-width: 100%;',
'    border-collapse: separate;',
'    border-spacing: 0;',
'    font-size: 13px;',
'}',
'',
'/* TABLE HEADER */',
'#COLUMN_STATS .t-Report-colHead {',
'    position: sticky;',
'    top: 0;',
'    z-index: 2;',
'',
'    background: #f1f5f9;',
'    color: #334155;',
'',
'    padding: 12px 14px;',
'    font-size: 12px;',
'    font-weight: 600;',
'',
'    text-align: left;',
'    white-space: nowrap;',
'',
'    border-bottom: 2px solid #cbd5e1;',
'}',
'',
'/* TABLE CELLS */',
'#COLUMN_STATS .t-Report-cell {',
'    padding: 10px 14px;',
'    color: #475569;',
'    font-size: 13px;',
'    vertical-align: middle;',
'    white-space: nowrap;',
'    border-bottom: 1px solid #e2e8f0;',
'}',
'',
'/* ALTERNATING ROWS */',
'#COLUMN_STATS .t-Report-report tbody tr:nth-child(even) {',
'    background: #f8fafc;',
'}',
'',
'/* ROW HOVER */',
'#COLUMN_STATS .t-Report-report tbody tr:hover {',
'    background: #eff6ff;',
'}',
'',
'/* COLUMN NAME */',
'#COLUMN_STATS .t-Report-report tbody td:first-child {',
'    font-weight: 600;',
'    color: #1e293b;',
'}',
'',
'/* DESCRIPTION COLUMN */',
'#COLUMN_STATS .t-Report-report th:nth-child(2),',
'#COLUMN_STATS .t-Report-report td:nth-child(2) {',
'    min-width: 260px;',
'    max-width: 400px;',
'    white-space: normal;',
'    line-height: 1.5;',
'}',
'',
'/* NUMERIC CELLS */',
'#COLUMN_STATS .t-Report-cell[align="right"] {',
'    text-align: right;',
'    font-variant-numeric: tabular-nums;',
'}',
'',
'/* DATA TYPE */',
'#COLUMN_STATS .t-Report-report tbody td:nth-child(3) {',
'    font-family: Consolas, Monaco, monospace;',
'    font-size: 12px;',
'    color: #64748b;',
'}',
'',
'/* PAGINATION */',
'#COLUMN_STATS .t-Report-pagination {',
'    width: 100%;',
'    background: #ffffff;',
'}',
'',
'#COLUMN_STATS .t-Report-pagination--bottom {',
'    border-top: 1px solid #e2e8f0;',
'}',
'',
'#COLUMN_STATS .t-Report-paginationText {',
'    color: #64748b;',
'    font-size: 12px;',
'}',
'',
'/* SCROLLBAR */',
'#COLUMN_STATS .t-Report-tableWrap::-webkit-scrollbar {',
'    height: 8px;',
'    width: 8px;',
'}',
'',
'#COLUMN_STATS .t-Report-tableWrap::-webkit-scrollbar-track {',
'    background: #f1f5f9;',
'}',
'',
'#COLUMN_STATS .t-Report-tableWrap::-webkit-scrollbar-thumb {',
'    background: #cbd5e1;',
'    border-radius: 8px;',
'}',
'',
'#COLUMN_STATS .t-Report-tableWrap::-webkit-scrollbar-thumb:hover {',
'    background: #94a3b8;',
'}',
'',
'/* RESPONSIVE */',
'@media (max-width: 768px) {',
'',
'    #COLUMN_STATS .t-Region-header {',
'        padding: 14px 16px;',
'    }',
'',
'    #COLUMN_STATS .t-Report-colHead,',
'    #COLUMN_STATS .t-Report-cell {',
'        padding: 9px 10px;',
'        font-size: 12px;',
'    }',
'',
'    #COLUMN_STATS .t-Report-tableWrap {',
'        max-height: 450px;',
'    }',
'}',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'/* ==========================================',
'   DATASET SQL VIEWER',
'========================================== */',
'',
'.dataset-sql-container {',
'    margin-top: 24px;',
'    background: #ffffff;',
'    border: 1px solid #e2e8f0;',
'    border-radius: 12px;',
'    overflow: hidden;',
'}',
'',
'/* Header */',
'',
'.dataset-sql-header {',
'    display: flex;',
'    align-items: center;',
'    justify-content: space-between;',
'    gap: 16px;',
'    padding: 16px 22px;',
'    border-bottom: 1px solid #e2e8f0;',
'}',
'',
'.dataset-sql-title {',
'    display: flex;',
'    align-items: center;',
'    gap: 10px;',
'}',
'',
'.dataset-sql-title h3 {',
'    margin: 0;',
'    font-size: 17px;',
'    font-weight: 600;',
'    color: #1e293b;',
'}',
'',
'.dataset-sql-title .fa {',
'    color: #64748b;',
'    font-size: 18px;',
'}',
'',
'/* SQL Editor */',
'',
'.dataset-sql-body {',
'    background: #1e293b;',
'    padding: 22px;',
'    max-height: 450px;',
'    overflow: auto;',
'}',
'',
'.dataset-sql-body pre {',
'    margin: 0;',
'    padding: 0;',
'    background: transparent;',
'    border: none;',
'}',
'',
'.dataset-sql-body code {',
'    font-family: "SFMono-Regular", Consolas, Monaco, monospace;',
'    font-size: 13px;',
'    line-height: 1.7;',
'    color: #e2e8f0;',
'    white-space: pre;',
'    tab-size: 4;',
'}',
'',
'/* Footer */',
'',
'.dataset-sql-footer {',
'    padding: 12px 22px;',
'    background: #f8fafc;',
'    border-top: 1px solid #e2e8f0;',
'    font-size: 12px;',
'    color: #64748b;',
'}',
'',
'/* Copy button */',
'',
'#copy-sql-btn {',
'    display: inline-flex;',
'    align-items: center;',
'    gap: 8px;',
'    border-radius: 6px;',
'}',
'',
'/* Responsive */',
'',
'@media (max-width: 600px) {',
'    .dataset-sql-header {',
'        flex-wrap: wrap;',
'    }',
'',
'    .dataset-sql-body {',
'        padding: 14px;',
'    }',
'}'))
,p_step_template=>2980551703278319811
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20261010000617Z')
,p_last_updated_on=>wwv_flow_imp.dz('20261010230028Z')
,p_created_by=>'DEMO'
,p_last_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(10865544004755617)
,p_name=>unistr('Estat\00EDsticas Colunas')
,p_static_id=>'COLUMN_STATS'
,p_region_name=>'COLUMN_STATS'
,p_parent_plug_id=>wwv_flow_imp.id(16275464914513611)
,p_template=>4073835273271169698
,p_display_sequence=>90
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    c.column_name as "Nome Coluna",',
unistr('    cc.comments AS "Descri\00E7\00E3o",'),
'    c.data_type as "Data Type",',
'    c.data_length as "Tamanho Campo",',
'    c.nullable "Aceita Nulo",',
'    s.num_distinct "Valores Distintos",',
'    s.num_nulls "Qtde Nulos",',
'',
'    CASE',
'        WHEN c.data_type IN (''VARCHAR2'', ''CHAR'', ''NVARCHAR2'', ''NCHAR'')',
'        THEN NULL',
'        ELSE decode_raw_value(s.low_value, c.data_type)',
'    END AS "Menor Valor",',
'',
'    CASE',
'        WHEN c.data_type IN (''VARCHAR2'', ''CHAR'', ''NVARCHAR2'', ''NCHAR'')',
'        THEN NULL',
'        ELSE decode_raw_value(s.high_value, c.data_type)',
'    END AS "Maior Valor",',
'',
'    CASE',
'        WHEN c.data_type IN (''VARCHAR2'', ''CHAR'', ''NVARCHAR2'', ''NCHAR'')',
'        THEN NULL',
'        ELSE TO_CHAR(s.density, ''FM0.0000'')',
'    END AS "Densidade"',
'',
'FROM user_tab_columns c',
'',
'LEFT JOIN user_tab_col_statistics s',
'    ON c.table_name = s.table_name',
'   AND c.column_name = s.column_name',
'',
'LEFT JOIN user_col_comments cc',
'    ON c.table_name = cc.table_name',
'   AND c.column_name = cc.column_name',
'',
'WHERE c.table_name = :P2_BASE',
'',
'ORDER BY c.column_id;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2540130677583398057
,p_query_num_rows=>10
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_created_on=>wwv_flow_imp.dz('20261010002519Z')
,p_updated_on=>wwv_flow_imp.dz('20261010191425Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14084484307558924)
,p_query_column_id=>5
,p_column_alias=>'Aceita Nulo'
,p_column_display_sequence=>160
,p_column_heading=>'Aceita Nulo'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010015906Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14084234938558922)
,p_query_column_id=>3
,p_column_alias=>'Data Type'
,p_column_display_sequence=>140
,p_column_heading=>'Data Type'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010015906Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14084900685558929)
,p_query_column_id=>10
,p_column_alias=>'Densidade'
,p_column_display_sequence=>210
,p_column_heading=>'Densidade'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010020003Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14084174802558921)
,p_query_column_id=>2
,p_column_alias=>unistr('Descri\00E7\00E3o')
,p_column_display_sequence=>130
,p_column_heading=>unistr('Descri\00E7\00E3o')
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010015906Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14084828952558928)
,p_query_column_id=>9
,p_column_alias=>'Maior Valor'
,p_column_display_sequence=>200
,p_column_heading=>'Maior Valor'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010020003Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14084707728558927)
,p_query_column_id=>8
,p_column_alias=>'Menor Valor'
,p_column_display_sequence=>190
,p_column_heading=>'Menor Valor'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010020003Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14084068227558920)
,p_query_column_id=>1
,p_column_alias=>'Nome Coluna'
,p_column_display_sequence=>120
,p_column_heading=>'Nome Coluna'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010015906Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14084612481558926)
,p_query_column_id=>7
,p_column_alias=>'Qtde Nulos'
,p_column_display_sequence=>180
,p_column_heading=>'Qtde Nulos'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010015906Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14084305285558923)
,p_query_column_id=>4
,p_column_alias=>'Tamanho Campo'
,p_column_display_sequence=>150
,p_column_heading=>'Tamanho Campo'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010015906Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14084593975558925)
,p_query_column_id=>6
,p_column_alias=>'Valores Distintos'
,p_column_display_sequence=>170
,p_column_heading=>'Valores Distintos'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010015906Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16275357494513610)
,p_plug_name=>'Dataset Preview (100 Linhas)'
,p_static_id=>'DATA_PREVIEW'
,p_region_name=>'DATA_PREVIEW'
,p_parent_plug_id=>wwv_flow_imp.id(16274827049513605)
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="dataset-preview-container">',
'',
'    <div id="preview-status"></div>',
'',
'    <div id="preview-results"',
'         style="overflow:auto; max-height:600px;">',
'    </div>',
'',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010183437Z')
,p_updated_on=>wwv_flow_imp.dz('20261010190535Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14083266355558912)
,p_plug_name=>'Base'
,p_static_id=>'base'
,p_parent_plug_id=>wwv_flow_imp.id(16274827049513605)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="dataset-overview">',
'',
'    <!-- Dataset Header -->',
'    <header class="dataset-header">',
'        <div class="dataset-icon" aria-hidden="true">',
'            <span class="fa fa-database"></span>',
'        </div>',
'',
'        <div class="dataset-title">',
'            <h2>&P2_BASE!HTML.</h2>',
'            <p>&P2_COMENTARIOS!HTML.</p>',
'        </div>',
'    </header>',
'',
'    <!-- Dataset Statistics -->',
unistr('    <section class="dataset-stats" aria-label="Estat\00EDsticas da tabela">'),
'',
'        <!-- Total Rows -->',
'        <div class="dataset-stat">',
'            <div class="stat-icon" aria-hidden="true">',
'                <span class="fa fa-list-ol"></span>',
'            </div>',
'            <div class="stat-content">',
'                <span class="stat-label">Total de Linhas</span>',
'                <span class="stat-value">&P2_LINHAS!HTML.</span>',
'            </div>',
'        </div>',
'',
'        <!-- Table Size -->',
'        <div class="dataset-stat">',
'            <div class="stat-icon" aria-hidden="true">',
'                <span class="fa fa-hdd-o"></span>',
'            </div>',
'            <div class="stat-content">',
'                <span class="stat-label">Tamanho da Tabela</span>',
'                <span class="stat-value">&P2_TAMANHO!HTML. GB</span>',
'            </div>',
'        </div>',
'',
'        <!-- Total Columns -->',
'        <div class="dataset-stat">',
'            <div class="stat-icon" aria-hidden="true">',
'                <span class="fa fa-columns"></span>',
'            </div>',
'            <div class="stat-content">',
unistr('                <span class="stat-label">N\00FAmero de Colunas</span>'),
'                <span class="stat-value">&P2_COLUNAS!HTML.</span>',
'            </div>',
'        </div>',
'',
'        <!-- Last Analyzed -->',
'        <div class="dataset-stat">',
'            <div class="stat-icon" aria-hidden="true">',
'                <span class="fa fa-calendar-check-o"></span>',
'            </div>',
'            <div class="stat-content">',
unistr('                <span class="stat-label">\00DAltima An\00E1lise Estat\00EDstica</span>'),
'                <span class="stat-value">&P2_ESTATISTICAS!HTML.</span>',
'            </div>',
'        </div>',
'',
'    </section>',
'',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010013532Z')
,p_updated_on=>wwv_flow_imp.dz('20261010185507Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(10868626205755648)
,p_name=>'Data Preview (Apenas 10 Linhas)'
,p_static_id=>'data-preview'
,p_region_name=>'DATA_PREVIEW'
,p_parent_plug_id=>wwv_flow_imp.id(16274827049513605)
,p_template=>4073835273271169698
,p_display_sequence=>120
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_table_name VARCHAR2(128);',
'    l_headers    VARCHAR2(32767);',
'    l_columns    VARCHAR2(32767);',
'    l_aliases    VARCHAR2(32767);',
'    l_sql        VARCHAR2(32767);',
'BEGIN',
'    -- Validate table name',
'    SELECT table_name',
'      INTO l_table_name',
'      FROM user_tables',
'     WHERE table_name = UPPER(:P2_BASE);',
'',
'    -- Generate column names and data expressions',
'    SELECT',
'        LISTAGG(',
'            '''''''' || REPLACE(column_name, '''''''', '''''''''''') ||',
'            '''''' AS COL'' || LPAD(rn, 2, ''0''),',
'            '', ''',
'        ) WITHIN GROUP (ORDER BY rn),',
'',
'        LISTAGG(',
'            ''CAST("'' || REPLACE(column_name, ''"'', ''""'') ||',
'            ''" AS VARCHAR2(4000)) AS COL'' || LPAD(rn, 2, ''0''),',
'            '', ''',
'        ) WITHIN GROUP (ORDER BY rn),',
'',
'        LISTAGG(',
'            ''COL'' || LPAD(rn, 2, ''0''),',
'            '', ''',
'        ) WITHIN GROUP (ORDER BY rn)',
'',
'    INTO l_headers, l_columns, l_aliases',
'',
'    FROM (',
'        SELECT',
'            column_name,',
'            ROW_NUMBER() OVER (ORDER BY column_id) AS rn',
'        FROM user_tab_columns',
'        WHERE table_name = l_table_name',
'    );',
'',
'    -- Generate SQL',
'    l_sql :=',
'        ''SELECT '' || l_aliases || '' FROM ('' ||',
'        ''SELECT 0 AS row_order, '' || l_headers || '' FROM DUAL '' ||',
'        ''UNION ALL '' ||',
'        ''SELECT 1 AS row_order, '' || l_columns ||',
'        '' FROM (SELECT * FROM "'' ||',
'        REPLACE(l_table_name, ''"'', ''""'') ||',
'        ''" FETCH FIRST 10 ROWS ONLY)'' ||',
'        '') ORDER BY row_order'';',
'',
'    RETURN l_sql;',
'',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'        RETURN ''SELECT CAST(NULL AS VARCHAR2(4000)) AS COL01 '' ||',
'               ''FROM DUAL WHERE 1 = 0'';',
'END;'))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'1 desc'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P2_BASE'
,p_lazy_loading=>false
,p_query_row_template=>2540130677583398057
,p_plug_query_max_columns=>200
,p_query_num_rows=>11
,p_query_options=>'GENERIC_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_required_patch=>wwv_flow_imp.id(10668219342750736)
,p_created_on=>wwv_flow_imp.dz('20261010004804Z')
,p_updated_on=>wwv_flow_imp.dz('20261010225746Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13879524143278502)
,p_query_column_id=>1
,p_column_alias=>'COL01'
,p_column_display_sequence=>10
,p_column_heading=>'Col01'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005946Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13879620175278503)
,p_query_column_id=>2
,p_column_alias=>'COL02'
,p_column_display_sequence=>20
,p_column_heading=>'Col02'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005946Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13879732842278504)
,p_query_column_id=>3
,p_column_alias=>'COL03'
,p_column_display_sequence=>30
,p_column_heading=>'Col03'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005946Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13879847440278505)
,p_query_column_id=>4
,p_column_alias=>'COL04'
,p_column_display_sequence=>40
,p_column_heading=>'Col04'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005946Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13879924274278506)
,p_query_column_id=>5
,p_column_alias=>'COL05'
,p_column_display_sequence=>50
,p_column_heading=>'Col05'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005946Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13880083638278507)
,p_query_column_id=>6
,p_column_alias=>'COL06'
,p_column_display_sequence=>60
,p_column_heading=>'Col06'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005946Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13880152388278508)
,p_query_column_id=>7
,p_column_alias=>'COL07'
,p_column_display_sequence=>70
,p_column_heading=>'Col07'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005946Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13880231954278509)
,p_query_column_id=>8
,p_column_alias=>'COL08'
,p_column_display_sequence=>80
,p_column_heading=>'Col08'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005946Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13880336586278510)
,p_query_column_id=>9
,p_column_alias=>'COL09'
,p_column_display_sequence=>90
,p_column_heading=>'Col09'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005946Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13880486642278511)
,p_query_column_id=>10
,p_column_alias=>'COL10'
,p_column_display_sequence=>100
,p_column_heading=>'Col10'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005946Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13891513007280601)
,p_query_column_id=>100
,p_column_alias=>'COL100'
,p_column_display_sequence=>1000
,p_column_heading=>'Col100'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13891654130280602)
,p_query_column_id=>101
,p_column_alias=>'COL101'
,p_column_display_sequence=>1010
,p_column_heading=>'Col101'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13891780230280603)
,p_query_column_id=>102
,p_column_alias=>'COL102'
,p_column_display_sequence=>1020
,p_column_heading=>'Col102'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13891814561280604)
,p_query_column_id=>103
,p_column_alias=>'COL103'
,p_column_display_sequence=>1030
,p_column_heading=>'Col103'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13891940455280605)
,p_query_column_id=>104
,p_column_alias=>'COL104'
,p_column_display_sequence=>1040
,p_column_heading=>'Col104'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13892082461280606)
,p_query_column_id=>105
,p_column_alias=>'COL105'
,p_column_display_sequence=>1050
,p_column_heading=>'Col105'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13892140515280607)
,p_query_column_id=>106
,p_column_alias=>'COL106'
,p_column_display_sequence=>1060
,p_column_heading=>'Col106'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13892200367280608)
,p_query_column_id=>107
,p_column_alias=>'COL107'
,p_column_display_sequence=>1070
,p_column_heading=>'Col107'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13892309301280609)
,p_query_column_id=>108
,p_column_alias=>'COL108'
,p_column_display_sequence=>1080
,p_column_heading=>'Col108'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13892463480280610)
,p_query_column_id=>109
,p_column_alias=>'COL109'
,p_column_display_sequence=>1090
,p_column_heading=>'Col109'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13880564474278512)
,p_query_column_id=>11
,p_column_alias=>'COL11'
,p_column_display_sequence=>110
,p_column_heading=>'Col11'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005946Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13892597427280611)
,p_query_column_id=>110
,p_column_alias=>'COL110'
,p_column_display_sequence=>1100
,p_column_heading=>'Col110'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13892655016280612)
,p_query_column_id=>111
,p_column_alias=>'COL111'
,p_column_display_sequence=>1110
,p_column_heading=>'Col111'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13892707537280613)
,p_query_column_id=>112
,p_column_alias=>'COL112'
,p_column_display_sequence=>1120
,p_column_heading=>'Col112'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13892848383280614)
,p_query_column_id=>113
,p_column_alias=>'COL113'
,p_column_display_sequence=>1130
,p_column_heading=>'Col113'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13892989928280615)
,p_query_column_id=>114
,p_column_alias=>'COL114'
,p_column_display_sequence=>1140
,p_column_heading=>'Col114'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13893088547280616)
,p_query_column_id=>115
,p_column_alias=>'COL115'
,p_column_display_sequence=>1150
,p_column_heading=>'Col115'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13893167367280617)
,p_query_column_id=>116
,p_column_alias=>'COL116'
,p_column_display_sequence=>1160
,p_column_heading=>'Col116'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13893207972280618)
,p_query_column_id=>117
,p_column_alias=>'COL117'
,p_column_display_sequence=>1170
,p_column_heading=>'Col117'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13893361330280619)
,p_query_column_id=>118
,p_column_alias=>'COL118'
,p_column_display_sequence=>1180
,p_column_heading=>'Col118'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13893458515280620)
,p_query_column_id=>119
,p_column_alias=>'COL119'
,p_column_display_sequence=>1190
,p_column_heading=>'Col119'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13880612281278513)
,p_query_column_id=>12
,p_column_alias=>'COL12'
,p_column_display_sequence=>120
,p_column_heading=>'Col12'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005946Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13893544222280621)
,p_query_column_id=>120
,p_column_alias=>'COL120'
,p_column_display_sequence=>1200
,p_column_heading=>'Col120'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13893678939280622)
,p_query_column_id=>121
,p_column_alias=>'COL121'
,p_column_display_sequence=>1210
,p_column_heading=>'Col121'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13893742671280623)
,p_query_column_id=>122
,p_column_alias=>'COL122'
,p_column_display_sequence=>1220
,p_column_heading=>'Col122'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13893810800280624)
,p_query_column_id=>123
,p_column_alias=>'COL123'
,p_column_display_sequence=>1230
,p_column_heading=>'Col123'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13893969642280625)
,p_query_column_id=>124
,p_column_alias=>'COL124'
,p_column_display_sequence=>1240
,p_column_heading=>'Col124'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13894060809280626)
,p_query_column_id=>125
,p_column_alias=>'COL125'
,p_column_display_sequence=>1250
,p_column_heading=>'Col125'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13894151914280627)
,p_query_column_id=>126
,p_column_alias=>'COL126'
,p_column_display_sequence=>1260
,p_column_heading=>'Col126'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13894292191280628)
,p_query_column_id=>127
,p_column_alias=>'COL127'
,p_column_display_sequence=>1270
,p_column_heading=>'Col127'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13894356468280629)
,p_query_column_id=>128
,p_column_alias=>'COL128'
,p_column_display_sequence=>1280
,p_column_heading=>'Col128'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13894412868280630)
,p_query_column_id=>129
,p_column_alias=>'COL129'
,p_column_display_sequence=>1290
,p_column_heading=>'Col129'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13880770906278514)
,p_query_column_id=>13
,p_column_alias=>'COL13'
,p_column_display_sequence=>130
,p_column_heading=>'Col13'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005946Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13894532080280631)
,p_query_column_id=>130
,p_column_alias=>'COL130'
,p_column_display_sequence=>1300
,p_column_heading=>'Col130'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13894616804280632)
,p_query_column_id=>131
,p_column_alias=>'COL131'
,p_column_display_sequence=>1310
,p_column_heading=>'Col131'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13894764289280633)
,p_query_column_id=>132
,p_column_alias=>'COL132'
,p_column_display_sequence=>1320
,p_column_heading=>'Col132'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13894849170280634)
,p_query_column_id=>133
,p_column_alias=>'COL133'
,p_column_display_sequence=>1330
,p_column_heading=>'Col133'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13894941340280635)
,p_query_column_id=>134
,p_column_alias=>'COL134'
,p_column_display_sequence=>1340
,p_column_heading=>'Col134'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13895095985280636)
,p_query_column_id=>135
,p_column_alias=>'COL135'
,p_column_display_sequence=>1350
,p_column_heading=>'Col135'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13895116155280637)
,p_query_column_id=>136
,p_column_alias=>'COL136'
,p_column_display_sequence=>1360
,p_column_heading=>'Col136'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13895283562280638)
,p_query_column_id=>137
,p_column_alias=>'COL137'
,p_column_display_sequence=>1370
,p_column_heading=>'Col137'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13895354255280639)
,p_query_column_id=>138
,p_column_alias=>'COL138'
,p_column_display_sequence=>1380
,p_column_heading=>'Col138'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13895440253280640)
,p_query_column_id=>139
,p_column_alias=>'COL139'
,p_column_display_sequence=>1390
,p_column_heading=>'Col139'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13880817758278515)
,p_query_column_id=>14
,p_column_alias=>'COL14'
,p_column_display_sequence=>140
,p_column_heading=>'Col14'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005946Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13895553200280641)
,p_query_column_id=>140
,p_column_alias=>'COL140'
,p_column_display_sequence=>1400
,p_column_heading=>'Col140'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13895675887280642)
,p_query_column_id=>141
,p_column_alias=>'COL141'
,p_column_display_sequence=>1410
,p_column_heading=>'Col141'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13895701259280643)
,p_query_column_id=>142
,p_column_alias=>'COL142'
,p_column_display_sequence=>1420
,p_column_heading=>'Col142'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13895826043280644)
,p_query_column_id=>143
,p_column_alias=>'COL143'
,p_column_display_sequence=>1430
,p_column_heading=>'Col143'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13895951619280645)
,p_query_column_id=>144
,p_column_alias=>'COL144'
,p_column_display_sequence=>1440
,p_column_heading=>'Col144'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13896016361280646)
,p_query_column_id=>145
,p_column_alias=>'COL145'
,p_column_display_sequence=>1450
,p_column_heading=>'Col145'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13896157482280647)
,p_query_column_id=>146
,p_column_alias=>'COL146'
,p_column_display_sequence=>1460
,p_column_heading=>'Col146'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13896272907280648)
,p_query_column_id=>147
,p_column_alias=>'COL147'
,p_column_display_sequence=>1470
,p_column_heading=>'Col147'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005950Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13896313083280649)
,p_query_column_id=>148
,p_column_alias=>'COL148'
,p_column_display_sequence=>1480
,p_column_heading=>'Col148'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13896442774280650)
,p_query_column_id=>149
,p_column_alias=>'COL149'
,p_column_display_sequence=>1490
,p_column_heading=>'Col149'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13880941862278516)
,p_query_column_id=>15
,p_column_alias=>'COL15'
,p_column_display_sequence=>150
,p_column_heading=>'Col15'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005946Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13896541424280601)
,p_query_column_id=>150
,p_column_alias=>'COL150'
,p_column_display_sequence=>1500
,p_column_heading=>'Col150'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13896637088280602)
,p_query_column_id=>151
,p_column_alias=>'COL151'
,p_column_display_sequence=>1510
,p_column_heading=>'Col151'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13896707493280603)
,p_query_column_id=>152
,p_column_alias=>'COL152'
,p_column_display_sequence=>1520
,p_column_heading=>'Col152'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13896840960280604)
,p_query_column_id=>153
,p_column_alias=>'COL153'
,p_column_display_sequence=>1530
,p_column_heading=>'Col153'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13896906481280605)
,p_query_column_id=>154
,p_column_alias=>'COL154'
,p_column_display_sequence=>1540
,p_column_heading=>'Col154'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13897000662280606)
,p_query_column_id=>155
,p_column_alias=>'COL155'
,p_column_display_sequence=>1550
,p_column_heading=>'Col155'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13897165884280607)
,p_query_column_id=>156
,p_column_alias=>'COL156'
,p_column_display_sequence=>1560
,p_column_heading=>'Col156'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13897283861280608)
,p_query_column_id=>157
,p_column_alias=>'COL157'
,p_column_display_sequence=>1570
,p_column_heading=>'Col157'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13897377282280609)
,p_query_column_id=>158
,p_column_alias=>'COL158'
,p_column_display_sequence=>1580
,p_column_heading=>'Col158'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13897493004280610)
,p_query_column_id=>159
,p_column_alias=>'COL159'
,p_column_display_sequence=>1590
,p_column_heading=>'Col159'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13881036306278517)
,p_query_column_id=>16
,p_column_alias=>'COL16'
,p_column_display_sequence=>160
,p_column_heading=>'Col16'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005946Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13897533385280611)
,p_query_column_id=>160
,p_column_alias=>'COL160'
,p_column_display_sequence=>1600
,p_column_heading=>'Col160'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13897606051280612)
,p_query_column_id=>161
,p_column_alias=>'COL161'
,p_column_display_sequence=>1610
,p_column_heading=>'Col161'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13897702960280613)
,p_query_column_id=>162
,p_column_alias=>'COL162'
,p_column_display_sequence=>1620
,p_column_heading=>'Col162'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13897822646280614)
,p_query_column_id=>163
,p_column_alias=>'COL163'
,p_column_display_sequence=>1630
,p_column_heading=>'Col163'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13897909294280615)
,p_query_column_id=>164
,p_column_alias=>'COL164'
,p_column_display_sequence=>1640
,p_column_heading=>'Col164'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13898097011280616)
,p_query_column_id=>165
,p_column_alias=>'COL165'
,p_column_display_sequence=>1650
,p_column_heading=>'Col165'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13898158946280617)
,p_query_column_id=>166
,p_column_alias=>'COL166'
,p_column_display_sequence=>1660
,p_column_heading=>'Col166'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13898256557280618)
,p_query_column_id=>167
,p_column_alias=>'COL167'
,p_column_display_sequence=>1670
,p_column_heading=>'Col167'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13898364884280619)
,p_query_column_id=>168
,p_column_alias=>'COL168'
,p_column_display_sequence=>1680
,p_column_heading=>'Col168'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13898448485280620)
,p_query_column_id=>169
,p_column_alias=>'COL169'
,p_column_display_sequence=>1690
,p_column_heading=>'Col169'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13881123593278518)
,p_query_column_id=>17
,p_column_alias=>'COL17'
,p_column_display_sequence=>170
,p_column_heading=>'Col17'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005946Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13898573574280621)
,p_query_column_id=>170
,p_column_alias=>'COL170'
,p_column_display_sequence=>1700
,p_column_heading=>'Col170'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13898687273280622)
,p_query_column_id=>171
,p_column_alias=>'COL171'
,p_column_display_sequence=>1710
,p_column_heading=>'Col171'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13898788305280623)
,p_query_column_id=>172
,p_column_alias=>'COL172'
,p_column_display_sequence=>1720
,p_column_heading=>'Col172'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13898864681280624)
,p_query_column_id=>173
,p_column_alias=>'COL173'
,p_column_display_sequence=>1730
,p_column_heading=>'Col173'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13898940791280625)
,p_query_column_id=>174
,p_column_alias=>'COL174'
,p_column_display_sequence=>1740
,p_column_heading=>'Col174'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13899056177280626)
,p_query_column_id=>175
,p_column_alias=>'COL175'
,p_column_display_sequence=>1750
,p_column_heading=>'Col175'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13899195467280627)
,p_query_column_id=>176
,p_column_alias=>'COL176'
,p_column_display_sequence=>1760
,p_column_heading=>'Col176'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13899237854280628)
,p_query_column_id=>177
,p_column_alias=>'COL177'
,p_column_display_sequence=>1770
,p_column_heading=>'Col177'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13899323276280629)
,p_query_column_id=>178
,p_column_alias=>'COL178'
,p_column_display_sequence=>1780
,p_column_heading=>'Col178'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13899486588280630)
,p_query_column_id=>179
,p_column_alias=>'COL179'
,p_column_display_sequence=>1790
,p_column_heading=>'Col179'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13881231255278519)
,p_query_column_id=>18
,p_column_alias=>'COL18'
,p_column_display_sequence=>180
,p_column_heading=>'Col18'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005946Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13899598871280631)
,p_query_column_id=>180
,p_column_alias=>'COL180'
,p_column_display_sequence=>1800
,p_column_heading=>'Col180'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005951Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13899600213280632)
,p_query_column_id=>181
,p_column_alias=>'COL181'
,p_column_display_sequence=>1810
,p_column_heading=>'Col181'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005952Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13899753563280633)
,p_query_column_id=>182
,p_column_alias=>'COL182'
,p_column_display_sequence=>1820
,p_column_heading=>'Col182'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005952Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13899871452280634)
,p_query_column_id=>183
,p_column_alias=>'COL183'
,p_column_display_sequence=>1830
,p_column_heading=>'Col183'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005952Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13899942501280635)
,p_query_column_id=>184
,p_column_alias=>'COL184'
,p_column_display_sequence=>1840
,p_column_heading=>'Col184'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005952Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13900042591280636)
,p_query_column_id=>185
,p_column_alias=>'COL185'
,p_column_display_sequence=>1850
,p_column_heading=>'Col185'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005952Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13900199234280637)
,p_query_column_id=>186
,p_column_alias=>'COL186'
,p_column_display_sequence=>1860
,p_column_heading=>'Col186'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005952Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13900208877280638)
,p_query_column_id=>187
,p_column_alias=>'COL187'
,p_column_display_sequence=>1870
,p_column_heading=>'Col187'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005952Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13900375801280639)
,p_query_column_id=>188
,p_column_alias=>'COL188'
,p_column_display_sequence=>1880
,p_column_heading=>'Col188'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005952Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13900446560280640)
,p_query_column_id=>189
,p_column_alias=>'COL189'
,p_column_display_sequence=>1890
,p_column_heading=>'Col189'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005952Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13881339774278520)
,p_query_column_id=>19
,p_column_alias=>'COL19'
,p_column_display_sequence=>190
,p_column_heading=>'Col19'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005946Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13900571789280641)
,p_query_column_id=>190
,p_column_alias=>'COL190'
,p_column_display_sequence=>1900
,p_column_heading=>'Col190'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005952Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13900669044280642)
,p_query_column_id=>191
,p_column_alias=>'COL191'
,p_column_display_sequence=>1910
,p_column_heading=>'Col191'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005952Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13900716258280643)
,p_query_column_id=>192
,p_column_alias=>'COL192'
,p_column_display_sequence=>1920
,p_column_heading=>'Col192'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005952Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13900867386280644)
,p_query_column_id=>193
,p_column_alias=>'COL193'
,p_column_display_sequence=>1930
,p_column_heading=>'Col193'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005952Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13900969805280645)
,p_query_column_id=>194
,p_column_alias=>'COL194'
,p_column_display_sequence=>1940
,p_column_heading=>'Col194'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005952Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13901040027280646)
,p_query_column_id=>195
,p_column_alias=>'COL195'
,p_column_display_sequence=>1950
,p_column_heading=>'Col195'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005952Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13901152151280647)
,p_query_column_id=>196
,p_column_alias=>'COL196'
,p_column_display_sequence=>1960
,p_column_heading=>'Col196'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005952Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13901298398280648)
,p_query_column_id=>197
,p_column_alias=>'COL197'
,p_column_display_sequence=>1970
,p_column_heading=>'Col197'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005952Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13901365614280649)
,p_query_column_id=>198
,p_column_alias=>'COL198'
,p_column_display_sequence=>1980
,p_column_heading=>'Col198'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005952Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13901422654280650)
,p_query_column_id=>199
,p_column_alias=>'COL199'
,p_column_display_sequence=>1990
,p_column_heading=>'Col199'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005952Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13881477468278521)
,p_query_column_id=>20
,p_column_alias=>'COL20'
,p_column_display_sequence=>200
,p_column_heading=>'Col20'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005946Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13901562671280601)
,p_query_column_id=>200
,p_column_alias=>'COL200'
,p_column_display_sequence=>2000
,p_column_heading=>'Col200'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005952Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13881532098278522)
,p_query_column_id=>21
,p_column_alias=>'COL21'
,p_column_display_sequence=>210
,p_column_heading=>'Col21'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005946Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13881632288278523)
,p_query_column_id=>22
,p_column_alias=>'COL22'
,p_column_display_sequence=>220
,p_column_heading=>'Col22'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005946Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13881707127278524)
,p_query_column_id=>23
,p_column_alias=>'COL23'
,p_column_display_sequence=>230
,p_column_heading=>'Col23'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005946Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13881892511278525)
,p_query_column_id=>24
,p_column_alias=>'COL24'
,p_column_display_sequence=>240
,p_column_heading=>'Col24'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005946Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13881961678278526)
,p_query_column_id=>25
,p_column_alias=>'COL25'
,p_column_display_sequence=>250
,p_column_heading=>'Col25'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13882075581278527)
,p_query_column_id=>26
,p_column_alias=>'COL26'
,p_column_display_sequence=>260
,p_column_heading=>'Col26'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13882125478278528)
,p_query_column_id=>27
,p_column_alias=>'COL27'
,p_column_display_sequence=>270
,p_column_heading=>'Col27'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13882256540278529)
,p_query_column_id=>28
,p_column_alias=>'COL28'
,p_column_display_sequence=>280
,p_column_heading=>'Col28'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13882312109278530)
,p_query_column_id=>29
,p_column_alias=>'COL29'
,p_column_display_sequence=>290
,p_column_heading=>'Col29'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13882442848278531)
,p_query_column_id=>30
,p_column_alias=>'COL30'
,p_column_display_sequence=>300
,p_column_heading=>'Col30'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13882528293278532)
,p_query_column_id=>31
,p_column_alias=>'COL31'
,p_column_display_sequence=>310
,p_column_heading=>'Col31'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13882678100278533)
,p_query_column_id=>32
,p_column_alias=>'COL32'
,p_column_display_sequence=>320
,p_column_heading=>'Col32'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13882746071278534)
,p_query_column_id=>33
,p_column_alias=>'COL33'
,p_column_display_sequence=>330
,p_column_heading=>'Col33'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13882849641278535)
,p_query_column_id=>34
,p_column_alias=>'COL34'
,p_column_display_sequence=>340
,p_column_heading=>'Col34'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13882941784278536)
,p_query_column_id=>35
,p_column_alias=>'COL35'
,p_column_display_sequence=>350
,p_column_heading=>'Col35'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13883027976278537)
,p_query_column_id=>36
,p_column_alias=>'COL36'
,p_column_display_sequence=>360
,p_column_heading=>'Col36'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13883127451278538)
,p_query_column_id=>37
,p_column_alias=>'COL37'
,p_column_display_sequence=>370
,p_column_heading=>'Col37'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13883299639278539)
,p_query_column_id=>38
,p_column_alias=>'COL38'
,p_column_display_sequence=>380
,p_column_heading=>'Col38'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13883335627278540)
,p_query_column_id=>39
,p_column_alias=>'COL39'
,p_column_display_sequence=>390
,p_column_heading=>'Col39'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13883403189278541)
,p_query_column_id=>40
,p_column_alias=>'COL40'
,p_column_display_sequence=>400
,p_column_heading=>'Col40'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13883589666278542)
,p_query_column_id=>41
,p_column_alias=>'COL41'
,p_column_display_sequence=>410
,p_column_heading=>'Col41'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13883653404278543)
,p_query_column_id=>42
,p_column_alias=>'COL42'
,p_column_display_sequence=>420
,p_column_heading=>'Col42'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13883740608278544)
,p_query_column_id=>43
,p_column_alias=>'COL43'
,p_column_display_sequence=>430
,p_column_heading=>'Col43'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13883841351278545)
,p_query_column_id=>44
,p_column_alias=>'COL44'
,p_column_display_sequence=>440
,p_column_heading=>'Col44'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13883966789278546)
,p_query_column_id=>45
,p_column_alias=>'COL45'
,p_column_display_sequence=>450
,p_column_heading=>'Col45'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13884060783278547)
,p_query_column_id=>46
,p_column_alias=>'COL46'
,p_column_display_sequence=>460
,p_column_heading=>'Col46'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13884159395278548)
,p_query_column_id=>47
,p_column_alias=>'COL47'
,p_column_display_sequence=>470
,p_column_heading=>'Col47'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13884292834278549)
,p_query_column_id=>48
,p_column_alias=>'COL48'
,p_column_display_sequence=>480
,p_column_heading=>'Col48'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13884338634278550)
,p_query_column_id=>49
,p_column_alias=>'COL49'
,p_column_display_sequence=>490
,p_column_heading=>'Col49'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13886510200280501)
,p_query_column_id=>50
,p_column_alias=>'COL50'
,p_column_display_sequence=>500
,p_column_heading=>'Col50'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13886657216280502)
,p_query_column_id=>51
,p_column_alias=>'COL51'
,p_column_display_sequence=>510
,p_column_heading=>'Col51'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13886737125280503)
,p_query_column_id=>52
,p_column_alias=>'COL52'
,p_column_display_sequence=>520
,p_column_heading=>'Col52'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13886820153280504)
,p_query_column_id=>53
,p_column_alias=>'COL53'
,p_column_display_sequence=>530
,p_column_heading=>'Col53'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005947Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13886911639280505)
,p_query_column_id=>54
,p_column_alias=>'COL54'
,p_column_display_sequence=>540
,p_column_heading=>'Col54'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13887000381280506)
,p_query_column_id=>55
,p_column_alias=>'COL55'
,p_column_display_sequence=>550
,p_column_heading=>'Col55'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13887129005280507)
,p_query_column_id=>56
,p_column_alias=>'COL56'
,p_column_display_sequence=>560
,p_column_heading=>'Col56'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13887254120280508)
,p_query_column_id=>57
,p_column_alias=>'COL57'
,p_column_display_sequence=>570
,p_column_heading=>'Col57'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13887347550280509)
,p_query_column_id=>58
,p_column_alias=>'COL58'
,p_column_display_sequence=>580
,p_column_heading=>'Col58'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13887486817280510)
,p_query_column_id=>59
,p_column_alias=>'COL59'
,p_column_display_sequence=>590
,p_column_heading=>'Col59'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13887528712280511)
,p_query_column_id=>60
,p_column_alias=>'COL60'
,p_column_display_sequence=>600
,p_column_heading=>'Col60'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13887685145280512)
,p_query_column_id=>61
,p_column_alias=>'COL61'
,p_column_display_sequence=>610
,p_column_heading=>'Col61'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13887790725280513)
,p_query_column_id=>62
,p_column_alias=>'COL62'
,p_column_display_sequence=>620
,p_column_heading=>'Col62'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13887872085280514)
,p_query_column_id=>63
,p_column_alias=>'COL63'
,p_column_display_sequence=>630
,p_column_heading=>'Col63'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13887968486280515)
,p_query_column_id=>64
,p_column_alias=>'COL64'
,p_column_display_sequence=>640
,p_column_heading=>'Col64'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13888019912280516)
,p_query_column_id=>65
,p_column_alias=>'COL65'
,p_column_display_sequence=>650
,p_column_heading=>'Col65'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13888147139280517)
,p_query_column_id=>66
,p_column_alias=>'COL66'
,p_column_display_sequence=>660
,p_column_heading=>'Col66'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13888234559280518)
,p_query_column_id=>67
,p_column_alias=>'COL67'
,p_column_display_sequence=>670
,p_column_heading=>'Col67'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13888334802280519)
,p_query_column_id=>68
,p_column_alias=>'COL68'
,p_column_display_sequence=>680
,p_column_heading=>'Col68'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13888434478280520)
,p_query_column_id=>69
,p_column_alias=>'COL69'
,p_column_display_sequence=>690
,p_column_heading=>'Col69'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13888587824280521)
,p_query_column_id=>70
,p_column_alias=>'COL70'
,p_column_display_sequence=>700
,p_column_heading=>'Col70'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13888647154280522)
,p_query_column_id=>71
,p_column_alias=>'COL71'
,p_column_display_sequence=>710
,p_column_heading=>'Col71'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13888743884280523)
,p_query_column_id=>72
,p_column_alias=>'COL72'
,p_column_display_sequence=>720
,p_column_heading=>'Col72'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13888890046280524)
,p_query_column_id=>73
,p_column_alias=>'COL73'
,p_column_display_sequence=>730
,p_column_heading=>'Col73'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13888904991280525)
,p_query_column_id=>74
,p_column_alias=>'COL74'
,p_column_display_sequence=>740
,p_column_heading=>'Col74'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13889091980280526)
,p_query_column_id=>75
,p_column_alias=>'COL75'
,p_column_display_sequence=>750
,p_column_heading=>'Col75'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13889169794280527)
,p_query_column_id=>76
,p_column_alias=>'COL76'
,p_column_display_sequence=>760
,p_column_heading=>'Col76'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13889282858280528)
,p_query_column_id=>77
,p_column_alias=>'COL77'
,p_column_display_sequence=>770
,p_column_heading=>'Col77'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13889394647280529)
,p_query_column_id=>78
,p_column_alias=>'COL78'
,p_column_display_sequence=>780
,p_column_heading=>'Col78'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13889464675280530)
,p_query_column_id=>79
,p_column_alias=>'COL79'
,p_column_display_sequence=>790
,p_column_heading=>'Col79'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13889510946280531)
,p_query_column_id=>80
,p_column_alias=>'COL80'
,p_column_display_sequence=>800
,p_column_heading=>'Col80'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13889609461280532)
,p_query_column_id=>81
,p_column_alias=>'COL81'
,p_column_display_sequence=>810
,p_column_heading=>'Col81'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13889713608280533)
,p_query_column_id=>82
,p_column_alias=>'COL82'
,p_column_display_sequence=>820
,p_column_heading=>'Col82'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13889810280280534)
,p_query_column_id=>83
,p_column_alias=>'COL83'
,p_column_display_sequence=>830
,p_column_heading=>'Col83'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005948Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13889994564280535)
,p_query_column_id=>84
,p_column_alias=>'COL84'
,p_column_display_sequence=>840
,p_column_heading=>'Col84'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13890064792280536)
,p_query_column_id=>85
,p_column_alias=>'COL85'
,p_column_display_sequence=>850
,p_column_heading=>'Col85'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13890147301280537)
,p_query_column_id=>86
,p_column_alias=>'COL86'
,p_column_display_sequence=>860
,p_column_heading=>'Col86'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13890200837280538)
,p_query_column_id=>87
,p_column_alias=>'COL87'
,p_column_display_sequence=>870
,p_column_heading=>'Col87'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13890380707280539)
,p_query_column_id=>88
,p_column_alias=>'COL88'
,p_column_display_sequence=>880
,p_column_heading=>'Col88'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13890481437280540)
,p_query_column_id=>89
,p_column_alias=>'COL89'
,p_column_display_sequence=>890
,p_column_heading=>'Col89'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13890565397280541)
,p_query_column_id=>90
,p_column_alias=>'COL90'
,p_column_display_sequence=>900
,p_column_heading=>'Col90'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13890685645280542)
,p_query_column_id=>91
,p_column_alias=>'COL91'
,p_column_display_sequence=>910
,p_column_heading=>'Col91'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13890745871280543)
,p_query_column_id=>92
,p_column_alias=>'COL92'
,p_column_display_sequence=>920
,p_column_heading=>'Col92'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13890899648280544)
,p_query_column_id=>93
,p_column_alias=>'COL93'
,p_column_display_sequence=>930
,p_column_heading=>'Col93'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13890906102280545)
,p_query_column_id=>94
,p_column_alias=>'COL94'
,p_column_display_sequence=>940
,p_column_heading=>'Col94'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13891008664280546)
,p_query_column_id=>95
,p_column_alias=>'COL95'
,p_column_display_sequence=>950
,p_column_heading=>'Col95'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13891168374280547)
,p_query_column_id=>96
,p_column_alias=>'COL96'
,p_column_display_sequence=>960
,p_column_heading=>'Col96'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13891259107280548)
,p_query_column_id=>97
,p_column_alias=>'COL97'
,p_column_display_sequence=>970
,p_column_heading=>'Col97'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13891366081280549)
,p_query_column_id=>98
,p_column_alias=>'COL98'
,p_column_display_sequence=>980
,p_column_heading=>'Col98'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13891425252280550)
,p_query_column_id=>99
,p_column_alias=>'COL99'
,p_column_display_sequence=>990
,p_column_heading=>'Col99'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20261010005949Z')
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24345558628571379)
,p_plug_name=>'Data Marketplace'
,p_static_id=>'datamarketplace'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--featured'
,p_plug_template=>2675494171183407654
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010000853Z')
,p_updated_on=>wwv_flow_imp.dz('20261010022939Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16274827049513605)
,p_plug_name=>'DIV01'
,p_static_id=>'div01'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>120
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010181612Z')
,p_updated_on=>wwv_flow_imp.dz('20261010181821Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16275464914513611)
,p_plug_name=>unistr('Estat\00EDsticas de Colunas')
,p_static_id=>unistr('estat\00EDsticas-de-colunas')
,p_parent_plug_id=>wwv_flow_imp.id(16274827049513605)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>130
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010191323Z')
,p_updated_on=>wwv_flow_imp.dz('20261010225746Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16276340809513620)
,p_plug_name=>'SQL'
,p_static_id=>'sql'
,p_parent_plug_id=>wwv_flow_imp.id(16274827049513605)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<!-- ==========================================',
'     DATASET SQL QUERY',
'========================================== -->',
'',
'<div class="dataset-sql-container">',
'',
'    <div class="dataset-sql-header">',
'',
'        <div class="dataset-sql-title">',
'            <span class="fa fa-code" aria-hidden="true"></span>',
'            <h3>SQL de Origem</h3>',
'        </div>',
'',
'        <button',
'            type="button"',
'            id="copy-sql-btn"',
'            class="t-Button t-Button--small"',
'            onclick="copyDatasetSQL()">',
'',
'            <span class="fa fa-copy" aria-hidden="true"></span>',
'            Copiar SQL',
'',
'        </button>',
'',
'    </div>',
'',
'    <div class="dataset-sql-body">',
'',
'        <pre><code id="dataset-sql-code">&P2_SQL!HTML.</code></pre>',
'',
'    </div>',
'',
'    <div class="dataset-sql-footer">',
'        <span class="fa fa-database" aria-hidden="true"></span>',
unistr('        Consulta utilizada para cria\00E7\00E3o do dataset'),
'    </div>',
'',
'</div>'))
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P2_SQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010225745Z')
,p_updated_on=>wwv_flow_imp.dz('20261010230028Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16274912932513606)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(16274827049513605)
,p_button_name=>'Delete'
,p_static_id=>'delete'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Delete'
,p_button_position=>'NEXT'
,p_button_condition=>'P2_DATASET'
,p_button_condition2=>'Y'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-times-square-o'
,p_created_on=>wwv_flow_imp.dz('20261010182103Z')
,p_updated_on=>wwv_flow_imp.dz('20261010182205Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13901682951280602)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(16274827049513605)
,p_button_name=>'Download'
,p_static_id=>'download'
,p_show_as_disabled=>false
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Download'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P2_DOWNLOAD_URL'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-download'
,p_created_on=>wwv_flow_imp.dz('20261010010748Z')
,p_updated_on=>wwv_flow_imp.dz('20261010214943Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16275923106513616)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(16274827049513605)
,p_button_name=>'Export'
,p_static_id=>'export'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Export'
,p_button_position=>'NEXT'
,p_button_condition=>'P2_DATASET'
,p_button_condition2=>'Y'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_created_on=>wwv_flow_imp.dz('20261010213844Z')
,p_updated_on=>wwv_flow_imp.dz('20261010213844Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14085238255558932)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(24345558628571379)
,p_button_name=>'Return'
,p_static_id=>'return'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'Return'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-backward'
,p_created_on=>wwv_flow_imp.dz('20261010022827Z')
,p_updated_on=>wwv_flow_imp.dz('20261010022916Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(16275140452513608)
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(16274912932513606)
,p_branch_sequence=>10
,p_created_on=>wwv_flow_imp.dz('20261010182615Z')
,p_updated_on=>wwv_flow_imp.dz('20261010182615Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10865456848755616)
,p_name=>'P2_BASE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(16274827049513605)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010002519Z')
,p_updated_on=>wwv_flow_imp.dz('20261010225746Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14085119689558931)
,p_name=>'P2_COLUNAS'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(16274827049513605)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010021219Z')
,p_updated_on=>wwv_flow_imp.dz('20261010225746Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14065378889479201)
,p_name=>'P2_COMENTARIOS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(16274827049513605)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010011452Z')
,p_updated_on=>wwv_flow_imp.dz('20261010225746Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16274785888513604)
,p_name=>'P2_DATASET'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(16274827049513605)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010181044Z')
,p_updated_on=>wwv_flow_imp.dz('20261010225746Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16276037934513617)
,p_name=>'P2_DOWNLOAD_URL'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(16274827049513605)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010214143Z')
,p_updated_on=>wwv_flow_imp.dz('20261010225746Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14083868637558918)
,p_name=>'P2_ESTATISTICAS'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(16274827049513605)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010014427Z')
,p_updated_on=>wwv_flow_imp.dz('20261010225746Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14083447415558914)
,p_name=>'P2_LINHAS'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(16274827049513605)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010013810Z')
,p_updated_on=>wwv_flow_imp.dz('20261010225746Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16276115560513618)
,p_name=>'P2_SQL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(16274827049513605)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010225615Z')
,p_updated_on=>wwv_flow_imp.dz('20261010225746Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14083758178558917)
,p_name=>'P2_TAMANHO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(16274827049513605)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010014320Z')
,p_updated_on=>wwv_flow_imp.dz('20261010225746Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(16275715164513614)
,p_name=>'Download CSV'
,p_static_id=>'download-csv'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(13901682951280602)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20261010213844Z')
,p_updated_on=>wwv_flow_imp.dz('20261010223116Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16275858376513615)
,p_event_id=>wwv_flow_imp.id(16275715164513614)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    '//const downloadUrl = apex.item("P2_DOWNLOAD_URL").getValue();',
    '//',
    '//if (downloadUrl) {',
    '//',
    '//    window.open(',
    '//        downloadUrl,',
    '//        "_blank",',
    '//        "noopener,noreferrer"',
    '//    );',
    '//',
    '//} else {',
    '//',
    '//    apex.message.alert(',
    unistr('//        "Nenhum arquivo dispon\00EDvel para download."'),
    '//    );',
    '//',
    '//}',
    '',
    'function downloadAllDatasetFiles() {',
    '',
    '    const downloadData = apex.item("P2_DOWNLOAD_URL").getValue();',
    '',
    '    if (!downloadData) {',
    unistr('        apex.message.alert("Nenhum arquivo dispon\00EDvel para download.");'),
    '        return;',
    '    }',
    '',
    '    try {',
    '        const urls = JSON.parse(downloadData);',
    '',
    '        if (!Array.isArray(urls) || urls.length === 0) {',
    '            apex.message.alert("Nenhum arquivo encontrado.");',
    '            return;',
    '        }',
    '',
    '        const allowedOrigin =',
    '            "https://objectstorage.sa-vinhedo-1.oraclecloud.com";',
    '',
    '        const validUrls = urls.filter(function(url) {',
    '            try {',
    '                const parsed = new URL(url);',
    '                return parsed.origin === allowedOrigin &&',
    '                       parsed.pathname.startsWith("/p/");',
    '            } catch (e) {',
    '                return false;',
    '            }',
    '        });',
    '',
    '        if (validUrls.length === 0) {',
    unistr('            apex.message.alert("Nenhum link v\00E1lido encontrado.");'),
    '            return;',
    '        }',
    '',
    '        let opened = 0;',
    '',
    '        validUrls.forEach(function(url) {',
    '',
    '            const tab = window.open(',
    '                url,',
    '                "_blank"',
    '            );',
    '',
    '            if (tab) {',
    '                tab.opener = null;',
    '                opened++;',
    '            }',
    '',
    '        });',
    '',
    '        if (opened < validUrls.length) {',
    '            apex.message.alert(',
    '                "O navegador pode ter bloqueado alguns downloads. " +',
    unistr('                "Permita pop-ups e m\00FAltiplos downloads para esta aplica\00E7\00E3o."'),
    '            );',
    '        }',
    '',
    '    } catch (error) {',
    '        console.error("Erro ao processar links de download:", error);',
    '        apex.message.alert("Erro ao preparar os downloads.");',
    '    }',
    '}',
    '',
    'downloadAllDatasetFiles();')))).to_clob
,p_created_on=>wwv_flow_imp.dz('20261010213844Z')
,p_updated_on=>wwv_flow_imp.dz('20261010223116Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(16275035178513607)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete_dataset'
,p_static_id=>'delete-dataset'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_table_name VARCHAR2(128);',
'    l_exists     NUMBER;',
'    l_owner      VARCHAR2(255);',
'',
'BEGIN',
'    -- ==========================================',
'    -- 1. GET DATASET NAME',
'    -- ==========================================',
'',
'    l_table_name := UPPER(TRIM(:P2_BASE));',
'',
'    IF l_table_name IS NULL THEN',
'        RAISE_APPLICATION_ERROR(',
'            -20001,',
'            ''Please select a dataset to delete.''',
'        );',
'    END IF;',
'',
'    -- ==========================================',
'    -- 2. VALIDATE TABLE NAME',
'    -- ==========================================',
'',
'    IF NOT REGEXP_LIKE(',
'        l_table_name,',
'        ''^[A-Z][A-Z0-9]*(_[A-Z0-9]+)+$''',
'    ) THEN',
'        RAISE_APPLICATION_ERROR(',
'            -20002,',
'            ''Invalid dataset name.''',
'        );',
'    END IF;',
'',
'    l_table_name := DBMS_ASSERT.SIMPLE_SQL_NAME(',
'        l_table_name',
'    );',
'',
'    -- ==========================================',
'    -- 3. CHECK DATASET REGISTRATION',
'    -- ==========================================',
'',
'    SELECT datasets_usuario',
'      INTO l_owner',
'      FROM datasets',
'     WHERE UPPER(datasets_nome) = l_table_name;',
'',
'    -- ==========================================',
'    -- 4. VERIFY DATASET OWNERSHIP',
'    -- ==========================================',
'',
'    IF UPPER(l_owner) <> UPPER(:APP_USER) THEN',
'        RAISE_APPLICATION_ERROR(',
'            -20003,',
'            ''You are not authorized to delete this dataset.''',
'        );',
'    END IF;',
'',
'    -- ==========================================',
'    -- 5. CHECK PHYSICAL TABLE EXISTS',
'    -- ==========================================',
'',
'    SELECT COUNT(*)',
'      INTO l_exists',
'      FROM user_tables',
'     WHERE table_name = l_table_name;',
'',
'    IF l_exists = 0 THEN',
'        RAISE_APPLICATION_ERROR(',
'            -20004,',
'            ''The physical dataset table does not exist.''',
'        );',
'    END IF;',
'',
'    -- ==========================================',
'    -- 6. DROP PHYSICAL TABLE',
'    -- ==========================================',
'',
'    EXECUTE IMMEDIATE',
'        ''DROP TABLE '' || l_table_name || '' PURGE'';',
'',
'    -- ==========================================',
'    -- 7. DELETE DATASET METADATA',
'    -- ==========================================',
'',
'    DELETE FROM datasets',
'     WHERE UPPER(datasets_nome) = l_table_name',
'       AND UPPER(datasets_usuario) = UPPER(:APP_USER);',
'',
'    -- ==========================================',
'    -- 8. SUCCESS MESSAGE',
'    -- ==========================================',
'',
'    APEX_APPLICATION.G_PRINT_SUCCESS_MESSAGE :=',
'        ''Dataset '' || l_table_name ||',
'        '' deleted successfully!'';',
'',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'',
'        APEX_ERROR.ADD_ERROR(',
'            p_message =>',
'                ''Dataset not found in the DATASETS control table.'',',
'            p_display_location =>',
'                APEX_ERROR.C_INLINE_IN_NOTIFICATION',
'        );',
'',
'    WHEN TOO_MANY_ROWS THEN',
'',
'        APEX_ERROR.ADD_ERROR(',
'            p_message =>',
'                ''Multiple dataset records found with this name.'',',
'            p_display_location =>',
'                APEX_ERROR.C_INLINE_IN_NOTIFICATION',
'        );',
'',
'    WHEN OTHERS THEN',
'',
'        APEX_ERROR.ADD_ERROR(',
'            p_message => SQLERRM,',
'            p_display_location =>',
'                APEX_ERROR.C_INLINE_IN_NOTIFICATION',
'        );',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(16274912932513606)
,p_internal_uid=>16275035178513607
,p_created_on=>wwv_flow_imp.dz('20261010182502Z')
,p_updated_on=>wwv_flow_imp.dz('20261010182731Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13901725068280603)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Export_CSV'
,p_static_id=>'download-csv'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--DECLARE',
'--    l_context   apex_exec.t_context;',
'--    l_export    apex_data_export.t_export;',
'--    l_table     VARCHAR2(128);',
'--    l_sql       VARCHAR2(32767);',
'--    l_file_uri  VARCHAR2(4000);',
'--    l_file_name VARCHAR2(255);',
'--BEGIN',
'--    -- Validate selected table',
'--    SELECT table_name',
'--      INTO l_table',
'--      FROM user_tables',
'--     WHERE table_name = UPPER(:P2_BASE);',
'--',
'--    -- Build dynamic SQL',
'--    l_sql := ''SELECT * FROM "'' ||',
'--             REPLACE(l_table, ''"'', ''""'') || ''"'';',
'--',
'--    -- Execute query',
'--    l_context := apex_exec.open_query_context(',
'--        p_location  => apex_exec.c_location_local_db,',
'--        p_sql_query => l_sql',
'--    );',
'--',
'--    -- Export CSV',
'--    l_export := apex_data_export.export(',
'--        p_context   => l_context,',
'--        p_format    => apex_data_export.c_format_csv,',
'--        p_file_name => l_table',
'--    );',
'--',
'--    apex_exec.close(l_context);',
'--',
'--    -- Generate file name',
'--    l_file_name :=',
'--        LOWER(l_table) || ''_'' ||',
'--        TO_CHAR(',
'--            CURRENT_TIMESTAMP,',
'--            ''YYYYMMDD_HH24MISSFF3''',
'--        ) ||',
'--        ''.csv'';',
'--',
'--    -- Object Storage URI',
'--    l_file_uri :=',
'--        ''https://objectstorage.sa-vinhedo-1.oraclecloud.com'' ||',
'--        ''/n/idi1o0a010nx'' ||',
'--        ''/b/bucket-cnpj-export/o/'' ||',
'--        l_file_name;',
'--',
'--    -- Export to OSS',
'--    DBMS_CLOUD.EXPORT_DATA(',
'--        credential_name => ''OBJ_STORE_CRED'',',
'--        file_uri_list   => l_file_uri,',
'--        query           => l_sql,',
'--        format          => JSON_OBJECT(',
'--            ''type'' VALUE ''csv'',',
'--            ''delimiter'' VALUE '','',',
'--            ''header'' VALUE TRUE',
'--        )',
'--    );',
'--',
'--    -- Download file',
'--    apex_data_export.download(',
'--        p_export => l_export',
'--    );',
'--END;',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'--DECLARE',
'--    -- Dataset information',
'--    l_table_name       VARCHAR2(128);',
'--    l_sql              VARCHAR2(32767);',
'--    l_exists           NUMBER;',
'--',
'--    -- Object Storage',
'--    l_file_prefix      VARCHAR2(255);',
'--    l_file_uri         VARCHAR2(4000);',
'--    l_actual_file_name VARCHAR2(4000);',
'--    l_file_count       NUMBER := 0;',
'--',
'--    -- PAR',
'--    l_par_url          VARCHAR2(32767);',
'--',
'--    l_details',
'--        DBMS_CLOUD_OCI_OBJECT_STORAGE_CREATE_PREAUTHENTICATED_REQUEST_DETAILS_T;',
'--',
'--    l_response',
'--        DBMS_CLOUD_OCI_OBS_OBJECT_STORAGE_CREATE_PREAUTHENTICATED_REQUEST_RESPONSE_T;',
'--',
'--    -- OCI configuration',
'--    c_bucket_url CONSTANT VARCHAR2(2000) :=',
'--        ''https://objectstorage.sa-vinhedo-1.oraclecloud.com'' ||',
'--        ''/n/idi1o0a010nx'' ||',
'--        ''/b/bucket-cnpj-export/o/'';',
'--',
'--BEGIN',
'--',
'--    -- ==========================================',
'--    -- 1. GET TABLE NAME',
'--    -- ==========================================',
'--',
'--    l_table_name := UPPER(TRIM(:P2_BASE));',
'--',
'--    -- ==========================================',
'--    -- 2. VALIDATE TABLE NAME',
'--    -- ==========================================',
'--',
'--    IF l_table_name IS NULL',
'--       OR NOT REGEXP_LIKE(',
'--           l_table_name,',
'--           ''^[A-Z][A-Z0-9_]*$''',
'--       )',
'--    THEN',
'--        RAISE_APPLICATION_ERROR(',
'--            -20001,',
'--            ''Invalid dataset name.''',
'--        );',
'--    END IF;',
'--',
'--    l_table_name :=',
'--        DBMS_ASSERT.SIMPLE_SQL_NAME(l_table_name);',
'--',
'--    -- ==========================================',
'--    -- 3. CHECK TABLE EXISTS',
'--    -- ==========================================',
'--',
'--    SELECT COUNT(*)',
'--      INTO l_exists',
'--      FROM ALL_TABLES',
'--     WHERE OWNER = ''DEMO''',
'--       AND TABLE_NAME = l_table_name;',
'--',
'--    IF l_exists = 0 THEN',
'--        RAISE_APPLICATION_ERROR(',
'--            -20002,',
'--            ''Dataset table does not exist in DEMO schema.''',
'--        );',
'--    END IF;',
'--',
'--    -- ==========================================',
'--    -- 4. BUILD SQL',
'--    -- ==========================================',
'--',
'--    l_sql :=',
'--        ''SELECT * FROM DEMO.'' || l_table_name;',
'--',
'--    -- ==========================================',
'--    -- 5. GENERATE UNIQUE FILE PREFIX',
'--    -- ==========================================',
'--',
'--    l_file_prefix :=',
'--        LOWER(l_table_name) || ''_'' ||',
'--        TO_CHAR(',
'--            SYSTIMESTAMP,',
'--            ''YYYYMMDD_HH24MISSFF3''',
'--        ) || ''_'' ||',
'--        LOWER(RAWTOHEX(SYS_GUID()));',
'--',
'--    -- ==========================================',
'--    -- 6. BUILD OBJECT STORAGE URI',
'--    -- ==========================================',
'--',
'--    l_file_uri :=',
'--        c_bucket_url || l_file_prefix;',
'--',
'--    -- ==========================================',
'--    -- 7. EXPORT DATASET TO OBJECT STORAGE',
'--    -- ==========================================',
'--',
'--    DBMS_CLOUD.EXPORT_DATA(',
'--        credential_name => ''OBJ_STORE_CRED'',',
'--        file_uri_list   => l_file_uri,',
'--        query           => l_sql,',
'--        format          => JSON_OBJECT(',
'--            ''type''      VALUE ''csv'',',
'--            ''delimiter'' VALUE '','',',
'--            ''header''    VALUE TRUE,',
'--            ''maxfilesize'' VALUE 1610612736',
'--        )',
'--    );',
'--',
'--    -- ==========================================',
'--    -- 8. FIND ACTUAL EXPORTED FILES',
'--    -- ==========================================',
'--',
'--    FOR r IN (',
'--        SELECT object_name',
'--          FROM TABLE(',
'--              DBMS_CLOUD.LIST_OBJECTS(',
'--                  credential_name => ''OBJ_STORE_CRED'',',
'--                  location_uri    => c_bucket_url',
'--              )',
'--          )',
'--         WHERE SUBSTR(',
'--                   object_name,',
'--                   1,',
'--                   LENGTH(l_file_prefix) + 1',
'--               ) = l_file_prefix || ''_''',
'--           AND LOWER(object_name) LIKE ''%.csv''',
'--         ORDER BY object_name',
'--    )',
'--    LOOP',
'--',
'--        l_file_count := l_file_count + 1;',
'--',
'--        l_actual_file_name := r.object_name;',
'--',
'--    END LOOP;',
'--',
'--    -- ==========================================',
'--    -- 9. VALIDATE EXPORTED FILES',
'--    -- ==========================================',
'--',
'--    IF l_file_count = 0 THEN',
'--',
'--        RAISE_APPLICATION_ERROR(',
'--            -20003,',
'--            ''Export completed, but no CSV file was found.''',
'--        );',
'--',
'--    ELSIF l_file_count > 1 THEN',
'--',
'--        RAISE_APPLICATION_ERROR(',
'--            -20004,',
'--            ''Export generated '' || l_file_count ||',
'--            '' CSV files. Multiple download links are required.''',
'--        );',
'--',
'--    END IF;',
'--',
'--    -- ==========================================',
'--    -- 10. CREATE PAR',
'--    -- ==========================================',
'--',
'--    l_details :=',
'--        DBMS_CLOUD_OCI_OBJECT_STORAGE_CREATE_PREAUTHENTICATED_REQUEST_DETAILS_T(',
'--            name                  =>',
'--                ''APEX_EXPORT_'' ||',
'--                TO_CHAR(',
'--                    SYSTIMESTAMP,',
'--                    ''YYYYMMDDHH24MISSFF3''',
'--                ),',
'--',
'--            bucket_listing_action => NULL,',
'--            object_name           => l_actual_file_name,',
'--            access_type           => ''ObjectRead'',',
'--            time_expires          =>',
'--                SYSTIMESTAMP + INTERVAL ''1'' HOUR',
'--        );',
'--',
'--    l_response :=',
'--        DBMS_CLOUD_OCI_OBS_OBJECT_STORAGE.CREATE_PREAUTHENTICATED_REQUEST(',
'--            namespace_name => ''idi1o0a010nx'',',
'--            bucket_name => ''bucket-cnpj-export'',',
'--            create_preauthenticated_request_details => l_details,',
'--            region => ''sa-vinhedo-1'',',
'--            credential_name => ''OBJ_STORE_CRED''',
'--        );',
'--',
'--    -- ==========================================',
'--    -- 11. VALIDATE PAR RESPONSE',
'--    -- ==========================================',
'--',
'--    IF l_response.status_code NOT BETWEEN 200 AND 299 THEN',
'--',
'--        RAISE_APPLICATION_ERROR(',
'--            -20005,',
'--            ''PAR creation failed. HTTP status: '' ||',
'--            l_response.status_code',
'--        );',
'--',
'--    END IF;',
'--',
'--    -- ==========================================',
'--    -- 12. BUILD DOWNLOAD URL',
'--    -- ==========================================',
'--',
'--    l_par_url :=',
'--        ''https://objectstorage.sa-vinhedo-1.oraclecloud.com'' ||',
'--        l_response.response_body.access_uri;',
'--',
'--    -- ==========================================',
'--    -- 13. SAVE URL IN APEX SESSION STATE',
'--    -- ==========================================',
'--',
'--    :P2_DOWNLOAD_URL := l_par_url;',
'--',
'--    -- ==========================================',
'--    -- 14. SUCCESS MESSAGE',
'--    -- ==========================================',
'--',
'--    APEX_APPLICATION.G_PRINT_SUCCESS_MESSAGE :=',
'--        ''Dataset exported successfully! '' ||',
'--        ''File: '' ||',
'--        APEX_ESCAPE.HTML(l_actual_file_name);',
'--',
'--END;',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'DECLARE',
'    -- Dataset information',
'    l_table_name       VARCHAR2(128);',
'    l_sql              VARCHAR2(32767);',
'    l_exists           NUMBER;',
'',
'    -- Object Storage',
'    l_file_prefix      VARCHAR2(255);',
'    l_file_uri         VARCHAR2(4000);',
'    l_actual_file_name VARCHAR2(4000);',
'    l_file_count       NUMBER := 0;',
'',
'    -- PAR',
'    l_par_url          VARCHAR2(4000);',
'    l_download_urls    CLOB;',
'    l_expires_at       TIMESTAMP WITH TIME ZONE;',
'',
'    l_details',
'        DBMS_CLOUD_OCI_OBJECT_STORAGE_CREATE_PREAUTHENTICATED_REQUEST_DETAILS_T;',
'',
'    l_response',
'        DBMS_CLOUD_OCI_OBS_OBJECT_STORAGE_CREATE_PREAUTHENTICATED_REQUEST_RESPONSE_T;',
'',
'    -- OCI configuration',
'    c_bucket_url CONSTANT VARCHAR2(2000) :=',
'        ''https://objectstorage.sa-vinhedo-1.oraclecloud.com'' ||',
'        ''/n/idi1o0a010nx'' ||',
'        ''/b/bucket-cnpj-export/o/'';',
'',
'BEGIN',
'',
'    -- ==========================================',
'    -- 1. CLEAR PREVIOUS DOWNLOAD',
'    -- ==========================================',
'',
'    :P2_DOWNLOAD_URL := NULL;',
'',
'    -- ==========================================',
'    -- 2. GET TABLE NAME',
'    -- ==========================================',
'',
'    l_table_name := UPPER(TRIM(:P2_BASE));',
'',
'    -- ==========================================',
'    -- 3. VALIDATE TABLE NAME',
'    -- ==========================================',
'',
'    IF l_table_name IS NULL',
'       OR NOT REGEXP_LIKE(',
'           l_table_name,',
'           ''^[A-Z][A-Z0-9_]*$''',
'       )',
'    THEN',
'        RAISE_APPLICATION_ERROR(',
'            -20001,',
'            ''Invalid dataset name.''',
'        );',
'    END IF;',
'',
'    l_table_name :=',
'        DBMS_ASSERT.SIMPLE_SQL_NAME(l_table_name);',
'',
'    -- ==========================================',
'    -- 4. CHECK TABLE EXISTS',
'    -- ==========================================',
'',
'    SELECT COUNT(*)',
'      INTO l_exists',
'      FROM ALL_TABLES',
'     WHERE OWNER = ''DEMO''',
'       AND TABLE_NAME = l_table_name;',
'',
'    IF l_exists = 0 THEN',
'        RAISE_APPLICATION_ERROR(',
'            -20002,',
'            ''Dataset table does not exist in DEMO schema.''',
'        );',
'    END IF;',
'',
'    -- ==========================================',
'    -- 5. BUILD SQL',
'    -- ==========================================',
'',
'    l_sql :=',
'        ''SELECT * FROM DEMO.'' || l_table_name;',
'',
'    -- ==========================================',
'    -- 6. GENERATE UNIQUE FILE PREFIX',
'    -- ==========================================',
'',
'    l_file_prefix :=',
'        LOWER(l_table_name) || ''_'' ||',
'        TO_CHAR(',
'            SYSTIMESTAMP,',
'            ''YYYYMMDD_HH24MISSFF3''',
'        ) || ''_'' ||',
'        LOWER(RAWTOHEX(SYS_GUID()));',
'',
'    -- ==========================================',
'    -- 7. BUILD OBJECT STORAGE URI',
'    -- ==========================================',
'',
'    l_file_uri :=',
'        c_bucket_url || l_file_prefix;',
'',
'    -- ==========================================',
'    -- 8. EXPORT DATASET TO OBJECT STORAGE',
'    -- ==========================================',
'',
'    DBMS_CLOUD.EXPORT_DATA(',
'        credential_name => ''OBJ_STORE_CRED'',',
'        file_uri_list   => l_file_uri,',
'        query           => l_sql,',
'        format          => JSON_OBJECT(',
'            ''type''        VALUE ''csv'',',
'            ''delimiter''   VALUE '','',',
'            ''header''      VALUE TRUE,',
'            ''maxfilesize'' VALUE 1610612736',
'        )',
'    );',
'',
'    -- ==========================================',
'    -- 9. INITIALIZE JSON ARRAY',
'    -- ==========================================',
'',
'    APEX_JSON.INITIALIZE_CLOB_OUTPUT;',
'',
'    APEX_JSON.OPEN_ARRAY;',
'',
'    l_expires_at := SYSTIMESTAMP + INTERVAL ''1'' HOUR;',
'',
'    -- ==========================================',
'    -- 10. FIND ALL EXPORTED FILES',
'    -- ==========================================',
'',
'    FOR r IN (',
'        SELECT object_name',
'          FROM TABLE(',
'              DBMS_CLOUD.LIST_OBJECTS(',
'                  credential_name => ''OBJ_STORE_CRED'',',
'                  location_uri    => c_bucket_url',
'              )',
'          )',
'         WHERE SUBSTR(',
'                   object_name,',
'                   1,',
'                   LENGTH(l_file_prefix) + 1',
'               ) = l_file_prefix || ''_''',
'           AND LOWER(object_name) LIKE ''%.csv''',
'         ORDER BY object_name',
'    )',
'    LOOP',
'',
'        l_file_count := l_file_count + 1;',
'',
'        l_actual_file_name := r.object_name;',
'',
'        -- ======================================',
'        -- 11. CREATE PAR FOR EACH FILE',
'        -- ======================================',
'',
'        l_details :=',
'            DBMS_CLOUD_OCI_OBJECT_STORAGE_CREATE_PREAUTHENTICATED_REQUEST_DETAILS_T(',
'                name =>',
'                    ''APEX_EXPORT_'' ||',
'                    SUBSTR(',
'                        REPLACE(l_file_prefix, ''_'', ''''),',
'                        1,',
'                        40',
'                    ) ||',
'                    ''_'' ||',
'                    l_file_count,',
'',
'                bucket_listing_action => NULL,',
'',
'                object_name => l_actual_file_name,',
'',
'                access_type => ''ObjectRead'',',
'',
'                time_expires => l_expires_at',
'            );',
'',
'        l_response :=',
'            DBMS_CLOUD_OCI_OBS_OBJECT_STORAGE.CREATE_PREAUTHENTICATED_REQUEST(',
'                namespace_name => ''idi1o0a010nx'',',
'                bucket_name    => ''bucket-cnpj-export'',',
'',
'                create_preauthenticated_request_details => l_details,',
'',
'                region          => ''sa-vinhedo-1'',',
'                credential_name => ''OBJ_STORE_CRED''',
'            );',
'',
'        -- Validate response',
'        IF l_response.status_code NOT BETWEEN 200 AND 299 THEN',
'',
'            RAISE_APPLICATION_ERROR(',
'                -20005,',
'                ''PAR creation failed for file: '' ||',
'                l_actual_file_name',
'            );',
'',
'        END IF;',
'',
'        -- ======================================',
'        -- 12. BUILD DOWNLOAD URL',
'        -- ======================================',
'',
'        l_par_url :=',
'            ''https://objectstorage.sa-vinhedo-1.oraclecloud.com'' ||',
'            l_response.response_body.access_uri;',
'',
'        -- ======================================',
'        -- 13. ADD URL TO JSON ARRAY',
'        -- ======================================',
'',
'        APEX_JSON.WRITE(l_par_url);',
'',
'    END LOOP;',
'',
'    -- ==========================================',
'    -- 14. VALIDATE FILE COUNT',
'    -- ==========================================',
'',
'    IF l_file_count = 0 THEN',
'',
'        RAISE_APPLICATION_ERROR(',
'            -20003,',
'            ''Export completed, but no CSV files were found.''',
'        );',
'',
'    END IF;',
'',
'    -- ==========================================',
'    -- 15. CLOSE JSON ARRAY',
'    -- ==========================================',
'',
'    APEX_JSON.CLOSE_ARRAY;',
'',
'    l_download_urls := APEX_JSON.GET_CLOB_OUTPUT;',
'',
'    APEX_JSON.FREE_OUTPUT;',
'',
'    -- ==========================================',
'    -- 16. SAVE URLS IN APEX SESSION STATE',
'    -- ==========================================',
'',
'    :P2_DOWNLOAD_URL := l_download_urls;',
'',
'    -- ==========================================',
'    -- 17. SUCCESS MESSAGE',
'    -- ==========================================',
'',
'    APEX_APPLICATION.G_PRINT_SUCCESS_MESSAGE :=',
'        ''Dataset exported successfully! '' ||',
'        l_file_count ||',
'        '' CSV file(s) available for download.'';',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(16275923106513616)
,p_internal_uid=>13901725068280603
,p_created_on=>wwv_flow_imp.dz('20261010010748Z')
,p_updated_on=>wwv_flow_imp.dz('20261010222724Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(16275205432513609)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LOAD_DATASET_PREVIEW'
,p_static_id=>'load-dataset-preview'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_table_name    VARCHAR2(128);',
'    l_sql           VARCHAR2(32767);',
'',
'    l_cursor        INTEGER;',
'    l_column_count  INTEGER;',
'    l_columns       DBMS_SQL.DESC_TAB2;',
'',
'    l_value         VARCHAR2(4000);',
'    l_status        INTEGER;',
'',
'    l_rows          INTEGER := 0;',
'    l_start         NUMBER;',
'    l_elapsed       NUMBER;',
'',
'    l_exists        NUMBER;',
'    l_error         VARCHAR2(4000);',
'    l_json          CLOB;',
'',
'BEGIN',
'    -- Start timer',
'    l_start := DBMS_UTILITY.GET_TIME;',
'',
'    -- Get dataset name',
'    l_table_name :=',
'        UPPER(TRIM(APEX_APPLICATION.G_X01));',
'',
'    -- Validate name',
'    IF l_table_name IS NULL',
'       OR NOT REGEXP_LIKE(',
'           l_table_name,',
'           ''^[A-Z][A-Z0-9_]*$''',
'       )',
'    THEN',
'        RAISE_APPLICATION_ERROR(',
'            -20001,',
'            ''Invalid dataset name.''',
'        );',
'    END IF;',
'',
'    l_table_name :=',
'        DBMS_ASSERT.SIMPLE_SQL_NAME(l_table_name);',
'',
'    -- Check dataset registration',
'--    SELECT COUNT(*)',
'--      INTO l_exists',
'--      FROM DEMO.DATASETS',
'--     WHERE UPPER(TRIM(DATASETS_NOME)) = l_table_name;',
'--',
'--    IF l_exists = 0 THEN',
'--        RAISE_APPLICATION_ERROR(',
'--            -20002,',
'--            ''Dataset not found in DEMO.DATASETS.''',
'--        );',
'--    END IF;',
'',
'    -- Check physical table',
'    SELECT COUNT(*)',
'      INTO l_exists',
'      FROM ALL_TABLES',
'     WHERE OWNER = ''DEMO''',
'       AND TABLE_NAME = l_table_name;',
'',
'    IF l_exists = 0 THEN',
'        RAISE_APPLICATION_ERROR(',
'            -20003,',
'            ''Physical table not found in DEMO schema.''',
'        );',
'    END IF;',
'',
'    -- Build SELECT',
'    l_sql :=',
'        ''SELECT * FROM DEMO.'' || l_table_name;',
'',
'    -- Open cursor',
'    l_cursor := DBMS_SQL.OPEN_CURSOR;',
'',
'    DBMS_SQL.PARSE(',
'        l_cursor,',
'        l_sql,',
'        DBMS_SQL.NATIVE',
'    );',
'',
'    -- Describe columns',
'    DBMS_SQL.DESCRIBE_COLUMNS2(',
'        l_cursor,',
'        l_column_count,',
'        l_columns',
'    );',
'',
'    -- Define columns',
'    FOR i IN 1 .. l_column_count LOOP',
'        DBMS_SQL.DEFINE_COLUMN(',
'            l_cursor,',
'            i,',
'            l_value,',
'            4000',
'        );',
'    END LOOP;',
'',
'    -- Execute query',
'    l_status := DBMS_SQL.EXECUTE(l_cursor);',
'',
'    -- Initialize JSON',
'    APEX_JSON.INITIALIZE_CLOB_OUTPUT;',
'',
'    APEX_JSON.OPEN_OBJECT;',
'',
'    APEX_JSON.WRITE(''success'', TRUE);',
'    APEX_JSON.WRITE(''dataset'', l_table_name);',
'',
'    -- Column headers',
'    APEX_JSON.OPEN_ARRAY(''columns'');',
'',
'    FOR i IN 1 .. l_column_count LOOP',
'        APEX_JSON.OPEN_OBJECT;',
'',
'        APEX_JSON.WRITE(',
'            ''name'',',
'            l_columns(i).col_name',
'        );',
'',
'        APEX_JSON.CLOSE_OBJECT;',
'    END LOOP;',
'',
'    APEX_JSON.CLOSE_ARRAY;',
'',
'    -- Result rows',
'APEX_JSON.OPEN_ARRAY(''rows'');',
'',
'WHILE l_rows < 100',
'',
'  AND DBMS_SQL.FETCH_ROWS(l_cursor) > 0',
'',
'LOOP',
'',
'    APEX_JSON.OPEN_ARRAY;',
'',
'    FOR i IN 1 .. l_column_count LOOP',
'',
'        l_value := NULL;',
'',
'        DBMS_SQL.COLUMN_VALUE(',
'',
'            l_cursor,',
'',
'            i,',
'',
'            l_value',
'',
'        );',
'',
'        -- Write column value, preserving NULL positions',
'',
'        APEX_JSON.WRITE(l_value);',
'',
'    END LOOP;',
'',
'    APEX_JSON.CLOSE_ARRAY;',
'',
'    l_rows := l_rows + 1;',
'',
'END LOOP;',
'',
'APEX_JSON.CLOSE_ARRAY;',
'',
'    -- Close cursor',
'    DBMS_SQL.CLOSE_CURSOR(l_cursor);',
'    l_cursor := NULL;',
'',
'    -- Execution statistics',
'    l_elapsed :=',
'        (DBMS_UTILITY.GET_TIME - l_start) / 100;',
'',
'    APEX_JSON.WRITE(''rowCount'', l_rows);',
'    APEX_JSON.WRITE(''executionTime'', l_elapsed);',
'',
'    APEX_JSON.CLOSE_OBJECT;',
'',
'    -- Return JSON',
'    l_json := APEX_JSON.GET_CLOB_OUTPUT;',
'',
'    APEX_JSON.FREE_OUTPUT;',
'',
'    SYS.HTP.PRN(l_json);',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'',
'        l_error := SQLERRM;',
'',
'        -- Close cursor safely',
'        BEGIN',
'            IF l_cursor IS NOT NULL THEN',
'                IF DBMS_SQL.IS_OPEN(l_cursor) THEN',
'                    DBMS_SQL.CLOSE_CURSOR(l_cursor);',
'                END IF;',
'            END IF;',
'        EXCEPTION',
'            WHEN OTHERS THEN',
'                NULL;',
'        END;',
'',
'        -- Release incomplete JSON',
'        BEGIN',
'            APEX_JSON.FREE_OUTPUT;',
'        EXCEPTION',
'            WHEN OTHERS THEN',
'                NULL;',
'        END;',
'',
'        -- Build error JSON',
'        APEX_JSON.INITIALIZE_CLOB_OUTPUT;',
'',
'        APEX_JSON.OPEN_OBJECT;',
'',
'        APEX_JSON.WRITE(''success'', FALSE);',
'        APEX_JSON.WRITE(''error'', l_error);',
'',
'        APEX_JSON.CLOSE_OBJECT;',
'',
'        l_json := APEX_JSON.GET_CLOB_OUTPUT;',
'',
'        APEX_JSON.FREE_OUTPUT;',
'',
'        SYS.HTP.PRN(l_json);',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>16275205432513609
,p_created_on=>wwv_flow_imp.dz('20261010183259Z')
,p_updated_on=>wwv_flow_imp.dz('20261010190434Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14085082708558930)
,p_process_sequence=>60
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SET_COLUNAS'
,p_static_id=>'set-colunas'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    -- Total number of columns',
'    SELECT COUNT(*)',
'    INTO :P2_COLUNAS',
'    FROM user_tab_columns c',
'    WHERE c.table_name = :P2_BASE;',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'        :P2_COLUNAS := NULL;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>14085082708558930
,p_created_on=>wwv_flow_imp.dz('20261010021220Z')
,p_updated_on=>wwv_flow_imp.dz('20261010225616Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14065482297479202)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SET_SQL'
,p_static_id=>'set-comment'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    SELECT DATASETS_SQL',
'    INTO :P2_SQL',
'    FROM DATASETS',
'    WHERE DATASETS_NOME = :P2_BASE;',
'',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'        :P2_SQL := NULL;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>14065482297479202
,p_created_on=>wwv_flow_imp.dz('20261010011452Z')
,p_updated_on=>wwv_flow_imp.dz('20261010225615Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(16276234213513619)
,p_process_sequence=>20
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SET_COMMENT'
,p_static_id=>'set-comment_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    SELECT comments',
'    INTO :P2_COMENTARIOS',
'    FROM user_tab_comments',
'    WHERE table_name = :P2_BASE',
'      AND table_type = ''TABLE'';',
'',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'        :P2_COMENTARIOS := NULL;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>16276234213513619
,p_created_on=>wwv_flow_imp.dz('20261010225615Z')
,p_updated_on=>wwv_flow_imp.dz('20261010225615Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14083922623558919)
,p_process_sequence=>50
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SET_ESTATISTICA'
,p_static_id=>'set-estatistica'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    SELECT',
'        TO_CHAR(t.last_analyzed, ''DD/MM/YYYY HH24:MI:SS'')',
'    INTO :P2_ESTATISTICAS',
'',
'    FROM user_tables t',
'',
'    WHERE t.table_name = :P2_BASE;',
'',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'        :P2_ESTATISTICAS := NULL;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>14083922623558919
,p_created_on=>wwv_flow_imp.dz('20261010014427Z')
,p_updated_on=>wwv_flow_imp.dz('20261010225616Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14083327637558913)
,p_process_sequence=>30
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SET_LINHAS'
,p_static_id=>'set-linhas'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    SELECT TO_CHAR(',
'        t.num_rows,',
'        ''FM999G999G999G999G990'',',
'        ''NLS_NUMERIC_CHARACTERS = '''',.''''''',
'    )',
'    INTO :P2_LINHAS',
'    FROM user_tables t',
'    WHERE t.table_name = :P2_BASE;',
'',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'        :P2_LINHAS := NULL;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>14083327637558913
,p_created_on=>wwv_flow_imp.dz('20261010013810Z')
,p_updated_on=>wwv_flow_imp.dz('20261010225615Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14083686974558916)
,p_process_sequence=>40
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SET_TAMANHO'
,p_static_id=>'set-tamanho'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    SELECT',
'        TO_CHAR(',
'            ROUND(seg.bytes / 1024 / 1024 / 1024, 2),',
'            ''FM0.00''',
'        )',
'    INTO :P2_TAMANHO',
'',
'    FROM user_tables t',
'',
'    LEFT JOIN (',
'        SELECT',
'            segment_name,',
'            SUM(bytes) AS bytes',
'        FROM user_segments',
'        WHERE segment_type IN (',
'            ''TABLE'',',
'            ''TABLE PARTITION'',',
'            ''TABLE SUBPARTITION''',
'        )',
'        GROUP BY segment_name',
'    ) seg',
'        ON t.table_name = seg.segment_name',
'',
'    WHERE t.table_name = :P2_BASE;',
'',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'        :P2_TAMANHO := NULL;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>14083686974558916
,p_created_on=>wwv_flow_imp.dz('20261010014320Z')
,p_updated_on=>wwv_flow_imp.dz('20261010225616Z')
,p_created_by=>'DEMO'
,p_updated_by=>'DEMO'
);
wwv_flow_imp.component_end;
end;
/
