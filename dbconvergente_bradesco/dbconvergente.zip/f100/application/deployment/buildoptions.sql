prompt --application/deployment/buildoptions
begin
--   Manifest
--     INSTALL BUILD OPTIONS: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7517539047701970
,p_default_application_id=>100
,p_default_id_offset=>7520676177711449
,p_default_owner=>'DEMO'
);
null;
wwv_flow_imp.component_end;
end;
/
