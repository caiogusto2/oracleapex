prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>26179492243556005
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'EVENTO'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Lista Hands On'
,p_alias=>'LISTA-HANDS-ON'
,p_step_title=>'Lista Hands On'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(28006497224711911)
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27584593660359751)
,p_plug_name=>'Lista Hands On'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27360459694267504)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'	"ID_HANDSON",',
'	"TITULO",',
'	"EVENTO",',
'	"DESCRICAO",',
'	"POSICOES",',
'	"DATA",',
'	sys.dbms_lob.getlength("MATERIAIS")"MATERIAIS",',
'	"STATUS",',
'	"PALESTRANTES",',
'	INSCRITOS,',
'	VAGAS',
'from "HANDSON"',
'WHERE STATUS = ''ATIVO''',
'order by data'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Lista Hands On'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(27584699883359751)
,p_name=>'Lista Hands On'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_finder_drop_down=>'N'
,p_show_actions_menu=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:3:&APP_SESSION.::&DEBUG.:RP:P3_ID_HANDSON:\#ID_HANDSON#\'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_owner=>'EVENTO'
,p_internal_uid=>27584699883359751
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(27585317561359759)
,p_db_column_name=>'ID_HANDSON'
,p_display_order=>0
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'Id Handson'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(27585797294359761)
,p_db_column_name=>'TITULO'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Titulo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(27586155806359762)
,p_db_column_name=>'EVENTO'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Evento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(27586511043359764)
,p_db_column_name=>'DESCRICAO'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Descricao'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(27586948106359765)
,p_db_column_name=>'POSICOES'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>unistr('Posi\00E7\00F5es')
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(27587396138359767)
,p_db_column_name=>'DATA'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Data'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MON-YYYY HH24:MI'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(27587768150359768)
,p_db_column_name=>'MATERIAIS'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Materiais'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DOWNLOAD:HANDSON:MATERIAIS:ID_HANDSON::::::attachment::'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(27588583918359771)
,p_db_column_name=>'STATUS'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(27588992072359773)
,p_db_column_name=>'PALESTRANTES'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Palestrantes'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(27658979414913418)
,p_db_column_name=>'INSCRITOS'
,p_display_order=>30
,p_column_identifier=>'L'
,p_column_label=>'Inscritos'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(27659800960913427)
,p_db_column_name=>'VAGAS'
,p_display_order=>40
,p_column_identifier=>'M'
,p_column_label=>'Vagas'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(27591505275360915)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'275916'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TITULO:EVENTO:DESCRICAO:DATA:POSICOES:INSCRITOS:PALESTRANTES:VAGAS:STATUS:MATERIAIS:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27591061466359783)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27382621317267569)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(27266932552267219)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(27445492819267771)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28283349948948725)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(27584593660359751)
,p_button_name=>'REFRESH'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--primary'
,p_button_template_id=>wwv_flow_imp.id(27443898431267765)
,p_button_image_alt=>unistr('Limpar Usu\00E1rios Inativos')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(27589481019359775)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(27584593660359751)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27443898431267765)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cadastrar Novo'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&APP_SESSION.::&DEBUG.:3::'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(27589726109359776)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(27584593660359751)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(27590237211359779)
,p_event_id=>wwv_flow_imp.id(27589726109359776)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(27584593660359751)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(28283438546948726)
,p_name=>'Refresh'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(28283349948948725)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(28283528938948727)
,p_event_id=>wwv_flow_imp.id(28283438546948726)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin ',
'	DBMS_SCHEDULER.run_job(job_name =>''EVENTO''||''.''||''SCHED_INATIVAR_HANDSON_USUARIOS'', use_current_session => FALSE);',
'end;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(28283644798948728)
,p_event_id=>wwv_flow_imp.id(28283438546948726)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Mensagem'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Job EVENTO.SCHED_INATIVAR_HANDSON_USUARIOS executado!'
);
wwv_flow_imp.component_end;
end;
/
