prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>26179492243556005
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'EVENTO'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'Landing Page'
,p_alias=>'LANDING-PAGE'
,p_step_title=>'Landing Page'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27975977173444351)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27382621317267569)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(27266932552267219)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(27445492819267771)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27979941912446007)
,p_plug_name=>'Vagas vs Inscritos'
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(27370276013267532)
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_landmark_type=>'exclude_landmark'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(27980035582446008)
,p_region_id=>wwv_flow_imp.id(27979941912446007)
,p_chart_type=>'line'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_fill_multi_series_gaps=>false
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(27980164453446009)
,p_chart_id=>wwv_flow_imp.id(27980035582446008)
,p_seq=>10
,p_name=>'Inscritos'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
unistr('	''SESS\00C3O: '' || TO_CHAR(DATA, ''DD/MM/YYYY HH24:MI'') || '' - '' || TITULO AS TITULO,'),
'	Inscritos,',
unistr('	posicoes as "N\00BA de Vagas"'),
'from',
'	handson',
'WHERE (:P7_EVENTO IS NULL OR REGEXP_LIKE(EVENTO, :P7_EVENTO))',
'ORDER BY DATA;'))
,p_items_value_column_name=>'INSCRITOS'
,p_items_label_column_name=>'TITULO'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'on'
,p_marker_shape=>'circle'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'none'
,p_items_label_font_size=>'14'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(27980464863446012)
,p_chart_id=>wwv_flow_imp.id(27980035582446008)
,p_seq=>20
,p_name=>'Posicoes'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
unistr('	''SESS\00C3O: '' || TO_CHAR(DATA, ''DD/MM/YYYY HH24:MI'') || '' - '' || TITULO AS TITULO,'),
'	Inscritos,',
unistr('	posicoes as "N\00BA de Vagas"'),
'from',
'	handson',
'WHERE (:P7_EVENTO IS NULL OR REGEXP_LIKE(EVENTO, :P7_EVENTO))',
'ORDER BY DATA;'))
,p_items_value_column_name=>unistr('N\00BA de Vagas')
,p_items_label_column_name=>'TITULO'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'on'
,p_marker_shape=>'circle'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'none'
,p_items_label_font_size=>'14'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(27980252398446010)
,p_chart_id=>wwv_flow_imp.id(27980035582446008)
,p_axis=>'x'
,p_is_rendered=>'off'
,p_format_type=>'datetime-short'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(27980382692446011)
,p_chart_id=>wwv_flow_imp.id(27980035582446008)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(27980591446446013)
,p_chart_id=>wwv_flow_imp.id(27980035582446008)
,p_axis=>'y2'
,p_is_rendered=>'off'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_split_dual_y=>'auto'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27980653767446014)
,p_plug_name=>'QTDE HANDS ON'
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT COUNT(*) AS CONTAGEM FROM HANDSON',
'WHERE (:P7_EVENTO IS NULL OR REGEXP_LIKE(EVENTO, :P7_EVENTO));'))
,p_template_component_type=>'PARTIAL'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'DESCRIPTION', '<h1>&CONTAGEM.</h1>',
  'DISPLAY_AVATAR', 'N',
  'DISPLAY_BADGE', 'N',
  'TITLE', wwv_flow_string.join(wwv_flow_t_varchar2(
    '<h3>HANDS ON <br>CADASTRADOS</h3>',
    '')))).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(27980888212446016)
,p_name=>'CONTAGEM'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CONTAGEM'
,p_data_type=>'NUMBER'
,p_display_sequence=>10
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27984134159446049)
,p_plug_name=>'Incritos'
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'	COUNT(*) AS CONTAGEM ',
'FROM ',
'	CADASTRO C, ',
'	HANDSON H ',
'WHERE ',
'	C.DATAEXPIRACAO IS NULL ',
'AND',
'	C.FK_HANDSON = H.ID_HANDSON',
'AND ',
' (:P7_EVENTO IS NULL OR REGEXP_LIKE(EVENTO, :P7_EVENTO));'))
,p_template_component_type=>'PARTIAL'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'DESCRIPTION', '<h1>&CONTAGEM.</h1>',
  'DISPLAY_AVATAR', 'N',
  'DISPLAY_BADGE', 'N',
  'TITLE', wwv_flow_string.join(wwv_flow_t_varchar2(
    '<h3>TOTAL <br>INSCRITOS</h3>',
    '')))).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(28281018544948702)
,p_name=>'CONTAGEM'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CONTAGEM'
,p_data_type=>'NUMBER'
,p_display_sequence=>10
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28284750435948739)
,p_plug_name=>'Inscritos por Tema e por Dia de Evento'
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(27370276013267532)
,p_plug_display_sequence=>50
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_landmark_type=>'region'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(28790357116574005)
,p_region_id=>wwv_flow_imp.id(28284750435948739)
,p_chart_type=>'bar'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'horizontal'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(28790417956574006)
,p_chart_id=>wwv_flow_imp.id(28790357116574005)
,p_seq=>10
,p_name=>'New'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'  h.titulo,',
'  count(h.titulo) as sessoes,',
'  SUM(h.inscritos) AS inscritos,',
'  TO_CHAR(H.DATA, ''DD/MM'') AS data',
'FROM ',
'  handson h ',
'WHERE (:P7_EVENTO IS NULL OR REGEXP_LIKE(EVENTO, :P7_EVENTO))',
'GROUP BY ',
'  h.titulo, TO_CHAR(H.DATA, ''DD/MM'')',
'ORDER BY ',
'  DATA ASC, INSCRITOS DESC;'))
,p_series_name_column_name=>'DATA'
,p_items_value_column_name=>'INSCRITOS'
,p_items_label_column_name=>'TITULO'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_font_size=>'16'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(28790502875574007)
,p_chart_id=>wwv_flow_imp.id(28790357116574005)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(28790641399574008)
,p_chart_id=>wwv_flow_imp.id(28790357116574005)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(28790748999574009)
,p_chart_id=>wwv_flow_imp.id(28790357116574005)
,p_axis=>'y2'
,p_is_rendered=>'off'
,p_title=>'sessoes'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'on'
,p_tick_label_rendered=>'on'
,p_split_dual_y=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28285431483948746)
,p_plug_name=>'Total Inscritos por Dia de Evento'
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(27370276013267532)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_landmark_type=>'region'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(28789904895574001)
,p_region_id=>wwv_flow_imp.id(28285431483948746)
,p_chart_type=>'pie'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'N'
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(28790047220574002)
,p_chart_id=>wwv_flow_imp.id(28789904895574001)
,p_seq=>10
,p_name=>'New'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'  TO_CHAR(H.DATA, ''DD/MM'') AS data,',
'  SUM(h.inscritos) AS inscritos',
'FROM ',
'  handson h ',
'WHERE (:P7_EVENTO IS NULL OR REGEXP_LIKE(EVENTO, :P7_EVENTO))',
'GROUP BY ',
'  TO_CHAR(H.DATA, ''DD/MM'')',
'ORDER BY ',
'  data asc, inscritos DESC;'))
,p_items_value_column_name=>'INSCRITOS'
,p_items_label_column_name=>'DATA'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'VALUE'
,p_items_label_font_size=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28791223905574014)
,p_plug_name=>'Sessoes'
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(27370276013267532)
,p_plug_display_sequence=>70
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT id_handson, ',
'       titulo, ',
'       data, ',
'       CASE ',
'           WHEN titulo = ''DESBLOQUEIE O POTENCIAL DA IA GENERATIVA EM POUCOS CLIQUES'' THEN ''blue'' ',
'           WHEN titulo = ''CONSULTAS INTELIGENTES COM ORACLE IA VECTOR SEARCH: A NOVA ERA'' THEN ''black'' ',
'           WHEN titulo = ''z'' THEN ''brown'' ',
'           ELSE ''default_color'' -- You can set a default color if none match',
'       END AS color',
'FROM handson',
'ORDER BY data;',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'calendar_views_and_navigation', 'list',
  'css_class', 'COLOR',
  'display_column', 'TITULO',
  'drag_and_drop', 'N',
  'end_date_column', 'DATA',
  'event_sorting', 'AUTOMATIC',
  'first_hour', '9',
  'maximum_events_day', '30',
  'multiple_line_event', 'N',
  'primary_key_column', 'ID_HANDSON',
  'show_time', 'Y',
  'show_tooltip', 'N',
  'show_weekend', 'N',
  'start_date_column', 'DATA',
  'time_format', '00')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31760065686728333)
,p_plug_name=>'Evento'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(27370276013267532)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(31760278439728335)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(31760065686728333)
,p_button_name=>'Filtrar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--success'
,p_button_template_id=>wwv_flow_imp.id(27443898431267765)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Filtrar'
,p_button_position=>'CHANGE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31760138155728334)
,p_name=>'P7_EVENTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(31760065686728333)
,p_prompt=>'Evento'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT DISTINCT EVENTO REQUEST, EVENTO DISPLAY FROM HANDSON;'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(27441340280267755)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp.component_end;
end;
/
