prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>26179492243556005
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'EVENTO'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Eventos'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(27284946905267284)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'22'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27568099368268368)
,p_plug_name=>unistr('Inscri\00E7\00E3o Hands On com Vagas Abertas')
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--featured'
,p_plug_template=>wwv_flow_imp.id(27336902184267437)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27660326747913432)
,p_plug_name=>'Cadastro Hands On'
,p_title=>'Cadastro Hands On'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleB'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27310786183267359)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'	ID_HANDSON, ',
'	TITULO, ',
'	DESCRICAO, ',
'	POSICOES, ',
'	TO_CHAR(DATA, ''DD/MM - HH24:MI'') AS DATA_FORMATADA,  ',
'	STATUS, ',
'	PALESTRANTES, ',
'	INSCRITOS, ',
'	VAGAS,',
'	EVENTO,',
'	POSICOES - INSCRITOS AS DISPONIVEIS,',
'	IMAGEM  ',
'FROM ',
'	HANDSON',
'where ',
'	status = ''ATIVO'' ',
'and ',
'	vagas = ''COM VAGAS'' ',
'order by data;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(27660476217913433)
,p_region_id=>wwv_flow_imp.id(27660326747913432)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>true
,p_title_html_expr=>'<h1><spawn>&EVENTO.</spawn></h1>'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>'<h2><spawn>&DATA_FORMATADA.</spawn></h2>'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>true
,p_second_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h4>Workshop: &TITULO.</h4>',
'<!--<br>',
unistr('<h5>Descri\00E7\00E3o: &DESCRICAO.</h5>-->'),
'<br>',
'<h2><spawn>Vagas restantes: &DISPONIVEIS.</spawn></h2>'))
,p_media_adv_formatting=>false
,p_media_source_type=>'BLOB'
,p_media_blob_column_name=>'IMAGEM'
,p_media_display_position=>'BODY'
,p_media_appearance=>'SQUARE'
,p_media_sizing=>'FIT'
,p_pk1_column_name=>'ID_HANDSON'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(27661196516913440)
,p_card_id=>wwv_flow_imp.id(27660476217913433)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>unistr('Inscri\00E7\00E3o')
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:5:P5_EVENTO,P5_ID_HANDSON:&EVENTO.,&ID_HANDSON.'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-hand-peace-o'
,p_action_css_classes=>'t-Button--success'
,p_is_hot=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27981519695446023)
,p_plug_name=>'Pesquise o Hands On'
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(27370276013267532)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(27660326747913432)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'N',
  'compact_numbers_threshold', '10000',
  'display_chart_for_top_n_values', '10',
  'show_charts', 'Y',
  'show_current_facets', 'N',
  'show_total_row_count', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27981693257446024)
,p_name=>'P1_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(27981519695446023)
,p_prompt=>'Search'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_02=>'FACET'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(28282205992948714)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(27660326747913432)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(28282335150948715)
,p_event_id=>wwv_flow_imp.id(28282205992948714)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(27660326747913432)
);
wwv_flow_imp.component_end;
end;
/
