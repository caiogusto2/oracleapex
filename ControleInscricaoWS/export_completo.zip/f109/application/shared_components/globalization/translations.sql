prompt --application/shared_components/globalization/translations
begin
--   Manifest
--     TRANSLATIONS: 109
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>26179492243556005
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'EVENTO'
);
null;
wwv_flow_imp.component_end;
end;
/
