prompt --application/deployment/install/install_modelimport
begin
--   Manifest
--     INSTALL: INSTALL-ModelImport
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7661655141381349
,p_default_application_id=>102
,p_default_id_offset=>7665633263437604
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(9648093369966336)
,p_install_id=>wwv_flow_imp.id(15328233907824776)
,p_name=>'ModelImport'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('--Cria\00E7\00E3o de credencial'),
'BEGIN',
'    DBMS_CLOUD.CREATE_CREDENTIAL(',
'        credential_name => ''OBJ_STORE_CRED'',',
'        username => ''oracleidentitycloudservice/CAIO.OLIVEIRA@ORACLE.COM'',',
'        password => ''teste''',
'    );',
'END;',
'/',
'',
'--Download de Modelo onnx do object storage para diretorio autonomous',
'begin',
'  dbms_cloud.get_object(',
'    credential_name => ''OBJ_STORE_CRED''',
'    , object_uri => ''https://objectstorage.sa-saopaulo-1.oraclecloud.com/p/nS9blF5U2ETiZT7YKZ_zrXtPOEH2Xf22TbdlpK99xZIEPmZedx4_eFBX4khYykmw/n/idi1o0a010nx/b/TDC/o/intfloatmodelsmall.onnx''',
'    , directory_name => ''DATA_PUMP_DIR''',
'    , file_name => ''intfloatmodelsmall.onnx''',
'  );',
'end;',
'/',
'',
'-- Import de modelo',
'begin ',
'    dbms_vector.load_onnx_model(''DATA_PUMP_DIR'', ''intfloatmodelsmall.onnx'', ''demo.doc_model'', JSON(''{"function" : "embedding", "embeddingOutput" : "embedding" , "input": {"input": ["DATA"]}}''));',
'end;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
