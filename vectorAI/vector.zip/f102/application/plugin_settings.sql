prompt --application/plugin_settings
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7661655141381349
,p_default_application_id=>102
,p_default_id_offset=>7665633263437604
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(25761108082134129)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'include_slider', 'Y')).to_clob
,p_version_scn=>41835898148446
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(25761292911134136)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_COLOR_PICKER'
,p_attribute_01=>'FULL'
,p_attribute_02=>'POPUP'
,p_version_scn=>41835898148447
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(25761681513134137)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_SELECT_MANY'
,p_attribute_01=>'separated'
,p_version_scn=>41835898148447
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(25761928214134137)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_MAP_REGION'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_vector_tile_layers', 'Y')).to_clob
,p_version_scn=>41835898148447
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(25762235091134138)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_STAR_RATING'
,p_attribute_01=>'fa-star'
,p_attribute_04=>'#VALUE#'
,p_version_scn=>41835898148447
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(25762493074134139)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_SINGLE_CHECKBOX'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_version_scn=>41835898148447
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(25762883772134140)
,p_plugin_type=>'WEB SOURCE TYPE'
,p_plugin=>'NATIVE_ADFBC'
,p_version_scn=>41835898148447
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(25763145455134141)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_IR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'actions_menu_structure', 'IG')).to_clob
,p_version_scn=>41835898148447
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(25763482782134142)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_YES_NO'
,p_attribute_01=>'Y'
,p_attribute_03=>'N'
,p_attribute_05=>'SWITCH_CB'
,p_version_scn=>41835898148447
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(25763750107134143)
,p_plugin_type=>'DYNAMIC ACTION'
,p_plugin=>'NATIVE_OPEN_AI_ASSISTANT'
,p_version_scn=>41835898148447
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(25764006060134144)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_DATE_PICKER_APEX'
,p_attribute_01=>'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON'
,p_attribute_02=>'VISIBLE'
,p_attribute_03=>'15'
,p_attribute_04=>'FOCUS'
,p_version_scn=>41835898148447
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(25764335595134145)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_GEOCODED_ADDRESS'
,p_attribute_01=>'RELAX_HOUSE_NUMBER'
,p_attribute_02=>'N'
,p_attribute_03=>'POPUP:ITEM'
,p_attribute_04=>'default'
,p_attribute_06=>'LIST'
,p_version_scn=>41835898148447
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(25764631554134146)
,p_plugin_type=>'PROCESS TYPE'
,p_plugin=>'NATIVE_GEOCODING'
,p_attribute_01=>'RELAX_HOUSE_NUMBER'
,p_version_scn=>41835898148447
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(47053679749890295)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'PLUGIN_GRAPHVIZ'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', '{"pageSize": 30}',
  'attribute_02', '{}')).to_clob
,p_version_scn=>42039214793897
);
wwv_flow_imp.component_end;
end;
/
