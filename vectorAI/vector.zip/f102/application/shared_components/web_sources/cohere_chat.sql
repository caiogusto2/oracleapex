prompt --application/shared_components/web_sources/cohere_chat
begin
--   Manifest
--     WEB SOURCE: Cohere-Chat
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7661655141381349
,p_default_application_id=>102
,p_default_id_offset=>7665633263437604
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(29826115091685412)
,p_name=>'Cohere-Chat'
,p_static_id=>'cohere_chat'
,p_web_source_type=>'NATIVE_OCI'
,p_data_profile_id=>wwv_flow_imp.id(29825289832685405)
,p_remote_server_id=>wwv_flow_imp.id(42729876814034352)
,p_url_path_prefix=>'chat'
,p_credential_id=>wwv_flow_imp.id(42699583726492688)
,p_version_scn=>41835912585051
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(29826469860685415)
,p_web_src_module_id=>wwv_flow_imp.id(29826115091685412)
,p_operation=>'POST'
,p_url_pattern=>'.'
,p_request_body_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'	"chatRequest":{',
'		"apiFormat":"COHERE",',
'		"message":"#MESSAGE#",',
'                "maxTokens":"1800",',
'                "temperature":"0"',
'	},',
'	"compartmentId":"ocid1.compartment.oc1..aaaaaaaacqt2kvaoyjexiops224rzriooevivs63hxhpzjxzwbvadqcgsfha",',
'	"servingMode":{',
'		"servingType":"ON_DEMAND",',
'		"modelId":"ocid1.generativeaimodel.oc1.sa-saopaulo-1.amaaaaaask7dceyau53t4ud4o4evlesk76c3vxrmpr6ny36pjyr3lz3vf4vq"',
'	}',
'}'))
,p_force_error_for_http_404=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(29826858485685419)
,p_web_src_module_id=>wwv_flow_imp.id(29826115091685412)
,p_web_src_operation_id=>wwv_flow_imp.id(29826469860685415)
,p_name=>'Content-Type'
,p_param_type=>'HEADER'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value=>'application/json'
,p_is_static=>true
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(29827294870685422)
,p_web_src_module_id=>wwv_flow_imp.id(29826115091685412)
,p_web_src_operation_id=>wwv_flow_imp.id(29826469860685415)
,p_name=>'MESSAGE'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(29827796228685423)
,p_web_src_module_id=>wwv_flow_imp.id(29826115091685412)
,p_web_src_operation_id=>wwv_flow_imp.id(29826469860685415)
,p_name=>'RESPONSE'
,p_param_type=>'BODY'
,p_is_required=>false
,p_direction=>'OUT'
);
wwv_flow_imp.component_end;
end;
/
