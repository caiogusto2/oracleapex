prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 102
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7661655141381349
,p_default_application_id=>102
,p_default_id_offset=>7665633263437604
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_theme(
 p_id=>wwv_flow_imp.id(26032752486135237)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_version_identifier=>'24.1'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>4070917134413059350
,p_is_locked=>false
,p_default_page_template=>wwv_flow_imp.id(25792164220134278)
,p_default_dialog_template=>wwv_flow_imp.id(25786966310134262)
,p_error_template=>wwv_flow_imp.id(25776932916134233)
,p_printer_friendly_template=>wwv_flow_imp.id(25792164220134278)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_imp.id(25776932916134233)
,p_default_button_template=>wwv_flow_imp.id(25942469916134745)
,p_default_region_template=>wwv_flow_imp.id(25868868219134505)
,p_default_chart_template=>wwv_flow_imp.id(25868868219134505)
,p_default_form_template=>wwv_flow_imp.id(25868868219134505)
,p_default_reportr_template=>wwv_flow_imp.id(25868868219134505)
,p_default_tabform_template=>wwv_flow_imp.id(25868868219134505)
,p_default_wizard_template=>wwv_flow_imp.id(25868868219134505)
,p_default_menur_template=>wwv_flow_imp.id(25881266302134539)
,p_default_listr_template=>wwv_flow_imp.id(25868868219134505)
,p_default_irr_template=>wwv_flow_imp.id(25858999358134478)
,p_default_report_template=>wwv_flow_imp.id(25907261205134619)
,p_default_label_template=>wwv_flow_imp.id(25939985888134730)
,p_default_menu_template=>wwv_flow_imp.id(25944022187134751)
,p_default_calendar_template=>wwv_flow_imp.id(25944143816134755)
,p_default_list_template=>wwv_flow_imp.id(25923817436134677)
,p_default_nav_list_template=>wwv_flow_imp.id(25935617578134715)
,p_default_top_nav_list_temp=>wwv_flow_imp.id(25935617578134715)
,p_default_side_nav_list_temp=>wwv_flow_imp.id(25930272885134698)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_imp.id(25805055814134326)
,p_default_dialogr_template=>wwv_flow_imp.id(25802216610134319)
,p_default_option_label=>wwv_flow_imp.id(25939985888134730)
,p_default_required_label=>wwv_flow_imp.id(25941248643134735)
,p_default_navbar_list_template=>wwv_flow_imp.id(25929883396134696)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#APEX_FILES#themes/theme_42/24.1/')
,p_files_version=>66
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_FILES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_FILES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_imp.component_end;
end;
/
