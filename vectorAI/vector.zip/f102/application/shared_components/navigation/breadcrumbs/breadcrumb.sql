prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7661655141381349
,p_default_application_id=>102
,p_default_id_offset=>7665633263437604
,p_default_owner=>'DEMO'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(25765515029134160)
,p_name=>'Breadcrumb'
);
wwv_flow_imp.component_end;
end;
/
