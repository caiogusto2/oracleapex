prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 102
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7661655141381349
,p_default_application_id=>102
,p_default_id_offset=>7665633263437604
,p_default_owner=>'DEMO'
);
null;
wwv_flow_imp.component_end;
end;
/
