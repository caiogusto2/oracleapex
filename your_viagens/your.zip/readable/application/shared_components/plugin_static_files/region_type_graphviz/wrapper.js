function initializeGVT(regionId, containerId, ajaxId, pagination, templateSettings, templateStyles, settings, styles, vertexLabel, edgeLabel, maxLabelLength, display, expand, fetchActions, persist, customHeight, updateGraphData, settingsThroughUi) {
  function paginate(start, size) {
    return new Promise((resolve, reject) => {
      apex.server.plugin(
        ajaxId, {
        x01: start,
        x02: size
      }, {
        success: (graph) => {
          if (graph.vertices == null && graph.edges == null) {
            console.error("Pagination returned no rows. Please make sure Attributes -> PaginationPresent is turned on/off as required, in the GVT plugin instance within APEX.")
          } else {
            if (graph.edges != null) {
              graph.edges.forEach((e, i) => {
                e.id = (e.id == undefined) ? i : e.id;
              });            
            } 
            resolve(graph);
          }
        },
        error: (e) => {
          console.error(e);
          reject(e);
        },
        dataType: 'json'
      }
      );
    });
  }

  function parse(attribute) {
    if (attribute) {
      try {
        return JSON.parse(attribute);
      }
      catch (e) {
        console.error(e);
      }
    }
    return {};
  }

  const target = document.getElementById(containerId);
  const numericHeight = Number(customHeight);
  if (numericHeight) {
    target.style.height = numericHeight + 'px';
  } else {
     target.style.height = '400px';
  }

  target.addEventListener('click', (e) => {
    e.preventDefault();
  });

  const flags = new Set(display.split(':'));

  const AsyncFunction = async function () { }.constructor;

  const self = new GraphVisualization({
    target, props: {
      settings: {
        ...parse(templateSettings),
        ...parse(settings),
        ...parse(settingsThroughUi)
      },
      styles: {
        ...parse(templateStyles),
        ...parse(styles),
        ...(maxLabelLength ? { '*': { label: { maxLength: maxLabelLength } } } : {}),
        ...(vertexLabel ? { vertex: { label: `\${properties.${vertexLabel}}` } } : {}),
        ...(edgeLabel ? { edge: { label: `\${properties.${edgeLabel}}` } } : {})
      },
      featureFlags: {
        exploration: flags.has('exploration'),
        modes: flags.has('modes'),
        pagination
      },
      paginate,
      expand: expand && AsyncFunction('ids', expand),
      fetchActions: AsyncFunction(fetchActions),
      persist: AsyncFunction("action", persist),
      updateGraphData: AsyncFunction('vertices', 'edges', updateGraphData)
    }
  });

  for (const type of ['graph', 'selection']) {
    self.$on(type, (e) => {
      apex.event.trigger(target, type, e.detail);
    });
  }

  apex.region.create(regionId, { self });
}