prompt --application/shared_components/security/authorizations/clientes
begin
--   Manifest
--     SECURITY SCHEME: CLIENTES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>14526457840079170
,p_default_application_id=>109
,p_default_id_offset=>14529182932118536
,p_default_owner=>'YOUR'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(18385708712631091)
,p_name=>'CLIENTES'
,p_scheme_type=>'NATIVE_IS_IN_GROUP'
,p_attribute_01=>'CLIENTES'
,p_attribute_02=>'A'
,p_version_scn=>39557054223809
,p_caching=>'BY_USER_BY_SESSION'
);
wwv_flow_imp.component_end;
end;
/
