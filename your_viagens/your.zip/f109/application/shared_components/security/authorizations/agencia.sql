prompt --application/shared_components/security/authorizations/agencia
begin
--   Manifest
--     SECURITY SCHEME: AGENCIA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>14526457840079170
,p_default_application_id=>109
,p_default_id_offset=>14529182932118536
,p_default_owner=>'YOUR'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(18385536657629835)
,p_name=>'AGENCIA'
,p_scheme_type=>'NATIVE_IS_IN_GROUP'
,p_attribute_01=>'AGENCIA'
,p_attribute_02=>'A'
,p_version_scn=>39556998019355
,p_caching=>'BY_USER_BY_SESSION'
);
wwv_flow_imp.component_end;
end;
/
