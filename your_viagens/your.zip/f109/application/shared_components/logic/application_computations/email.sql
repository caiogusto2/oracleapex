prompt --application/shared_components/logic/application_computations/email
begin
--   Manifest
--     APPLICATION COMPUTATION: EMAIL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>14526457840079170
,p_default_application_id=>109
,p_default_id_offset=>14529182932118536
,p_default_owner=>'YOUR'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(18540473402808319)
,p_computation_sequence=>10
,p_computation_item=>'EMAIL'
,p_computation_point=>'AFTER_LOGIN'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'get_apex_app_user;'
,p_version_scn=>39556997192639
);
wwv_flow_imp.component_end;
end;
/
