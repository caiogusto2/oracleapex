prompt --application/shared_components/logic/application_computations/usuario_id
begin
--   Manifest
--     APPLICATION COMPUTATION: USUARIO_ID
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>14526457840079170
,p_default_application_id=>109
,p_default_id_offset=>14529182932118536
,p_default_owner=>'YOUR'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(18543173050848497)
,p_computation_sequence=>10
,p_computation_item=>'USUARIO_ID'
,p_computation_point=>'AFTER_LOGIN'
,p_computation_type=>'QUERY'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'SELECT USUARIO_ID FROM USUARIO WHERE EMAIL = lower(get_apex_app_user);'
,p_version_scn=>39556997453506
);
wwv_flow_imp.component_end;
end;
/
