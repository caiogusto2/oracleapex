prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 109
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>14526457840079170
,p_default_application_id=>109
,p_default_id_offset=>14529182932118536
,p_default_owner=>'YOUR'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(59038459818435115)
,p_build_option_name=>'Commented Out'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>41835898148447
);
wwv_flow_imp.component_end;
end;
/
