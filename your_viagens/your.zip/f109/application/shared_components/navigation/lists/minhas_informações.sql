prompt --application/shared_components/navigation/lists/minhas_informações
begin
--   Manifest
--     LIST: Minhas Informações
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>14526457840079170
,p_default_application_id=>109
,p_default_id_offset=>14529182932118536
,p_default_owner=>'YOUR'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(18753519037720901)
,p_name=>unistr('Minhas Informa\00E7\00F5es')
,p_list_status=>'PUBLIC'
,p_version_scn=>39557030900982
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(18754901751720906)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>unistr('Quem \00E9 voc\00EA')
,p_list_item_link_target=>'f?p=&APP_ID.:8:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(18759278658720918)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Meus Documentos'
,p_list_item_link_target=>'f?p=&APP_ID.:9:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(18769232544720946)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>unistr('Revis\00E3o')
,p_list_item_link_target=>'f?p=&APP_ID.:11:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
