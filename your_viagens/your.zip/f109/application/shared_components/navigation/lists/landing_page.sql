prompt --application/shared_components/navigation/lists/landing_page
begin
--   Manifest
--     LIST: Landing Page
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>14526457840079170
,p_default_application_id=>109
,p_default_id_offset=>14529182932118536
,p_default_owner=>'YOUR'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(18950111041521059)
,p_name=>'Landing Page'
,p_list_status=>'PUBLIC'
,p_version_scn=>39557160106029
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(18950373101521062)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>unistr('Minhas Informa\00E7\00F5es')
,p_list_item_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::P8_USUARIO_ID:&USUARIO_ID.:'
,p_list_item_icon=>'fa-address-card-o'
,p_security_scheme=>'!'||wwv_flow_imp.id(18385536657629835)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(18950744038521064)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Minhas Viagens'
,p_list_item_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-plane'
,p_security_scheme=>'!'||wwv_flow_imp.id(18385536657629835)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24101059399790598)
,p_list_item_display_sequence=>25
,p_list_item_link_text=>'Viagens'
,p_list_item_link_target=>'f?p=&APP_ID.:103:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-plane'
,p_security_scheme=>'!'||wwv_flow_imp.id(18385708712631091)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(20245550472589045)
,p_list_item_display_sequence=>28
,p_list_item_link_text=>'Arquivos'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-files-o'
,p_security_scheme=>'!'||wwv_flow_imp.id(18385708712631091)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(20242033981549520)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>unistr('Usu\00E1rios')
,p_list_item_link_target=>'f?p=&APP_ID.:101:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user'
,p_security_scheme=>'!'||wwv_flow_imp.id(18385708712631091)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
