prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>14526457840079170
,p_default_application_id=>109
,p_default_id_offset=>14529182932118536
,p_default_owner=>'YOUR'
);
wwv_flow_imp_page.create_page(
 p_id=>9
,p_name=>'Meus Documentos'
,p_alias=>'MEUS-DOCUMENTOS'
,p_page_mode=>'MODAL'
,p_step_title=>'Meus Documentos'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(20246372532609907)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Button, .t-Button--icon, .t-Button--iconRight, .t-Button--hot {',
'        background-color: rgb(205, 75, 155);',
'        box-shadow: rgb(205, 75, 155);',
'}',
'',
'.t-WizardSteps-marker, .t-WizardSteps-label, .t-WizardSteps-step.is-active{',
'    color: rgb(205, 75, 155);',
'}',
'',
'.t-WizardSteps-marker {',
'    box-shadow: inset 0 0 0 1px rgb(205, 75, 155); /* Thinner pink shadow */',
'    color: rgb(205, 75, 155); /* Pink text */',
'    border: 0.5px solid rgb(205, 75, 155); /* Very thin pink border */',
'}',
'',
'.t-WizardSteps-step.is-active .t-WizardSteps-marker {',
'    background-color: rgb(205, 75, 155); /* Pink background */',
'    color: var(--rw-palette-neutral-0); /* Assuming this variable is defined */',
'}',
'',
'.t-WizardSteps-step.is-active .t-WizardSteps-label {',
'    color: rgb(205, 75, 155); /* Pink text */',
'    font-weight: var(--ut-wp-label-active-font-weight, 700);',
'}',
'',
'.t-WizardSteps-step.is-complete .t-WizardSteps-marker {',
'    background-color: rgb(205, 75, 155); /* Pink background */',
'    color: rgb(255, 255, 255); /* White text */',
'    transform: scale(1.2);',
'}',
''))
,p_step_template=>1661186590416509825
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_height=>'700'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18758710901720918)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(18753519037720901)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>2010149141494510257
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18758908991720918)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18878717284006607)
,p_plug_name=>'Form'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select USUARIO_ID,',
'       PASSAPORTE,',
'       PASSAPORTE_NAME,',
'       PASSAPORTE_TIME,',
'       PASSAPORTE_MIME,',
'       RG_CNH,',
'       RG_CNH_NAME,',
'       RG_CNH_TIME,',
'       RG_CNH_MIME,',
'       PID,',
'       PID_NAME,',
'       PID_TIME,',
'       PID_MIME,',
'       VACINACAO,',
'       VACINACAO_NAME,',
'       VACINACAO_TIME,',
'       VACINACAO_MIME,',
'       SEGURO,',
'       SEGURO_NAME,',
'       SEGURO_TIME,',
'       SEGURO_MIME',
'  from USUARIO'))
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18758898950720918)
,p_plug_name=>'Meus Documentos'
,p_parent_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(18760707359720923)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(18758908991720918)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'t-Button--iconRight'
,p_button_template_id=>2082829544945815391
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Seguir'
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-chevron-right'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(18763084648720930)
,p_branch_name=>'Go To Page 10'
,p_branch_action=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(18760707359720923)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18878914303006609)
,p_name=>'P9_USUARIO_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_item_source_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_source=>'USUARIO_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18880492539006624)
,p_name=>'P9_PASSAPORTE'
,p_source_data_type=>'BLOB'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_item_source_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_prompt=>'Passaporte'
,p_source=>'PASSAPORTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_help_text=>'Tirar foto do passaporte apenas da folha principal'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'blob_last_updated_column', 'PASSAPORTE_TIME',
  'capture_using', 'ENVIRONMENT',
  'content_disposition', 'inline',
  'display_as', 'INLINE',
  'display_download_link', 'Y',
  'filename_column', 'PASSAPORTE_NAME',
  'mime_type_column', 'PASSAPORTE_MIME',
  'storage_type', 'DB_COLUMN')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18880505353006625)
,p_name=>'P9_PASSAPORTE_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_item_source_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_source=>'PASSAPORTE_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18880600419006626)
,p_name=>'P9_PASSAPORTE_TIME'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_item_source_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_source=>'PASSAPORTE_TIME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18880701229006627)
,p_name=>'P9_PASSAPORTE_MIME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_item_source_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_source=>'PASSAPORTE_MIME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18880870599006628)
,p_name=>'P9_RG_CNH'
,p_source_data_type=>'BLOB'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_item_source_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_prompt=>'RG/CNH'
,p_source=>'RG_CNH'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'Tire uma foto do seu RG ou CNH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'blob_last_updated_column', 'RG_CNH_TIME',
  'content_disposition', 'inline',
  'display_as', 'INLINE',
  'display_download_link', 'Y',
  'filename_column', 'RG_CNH_NAME',
  'mime_type_column', 'RG_CNH_MIME',
  'storage_type', 'DB_COLUMN')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18880977338006629)
,p_name=>'P9_RG_CNH_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_item_source_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_source=>'RG_CNH_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18881076520006630)
,p_name=>'P9_RG_CNH_TIME'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_item_source_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_source=>'RG_CNH_TIME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18881126497006631)
,p_name=>'P9_RG_CNH_MIME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_item_source_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_source=>'RG_CNH_MIME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18881290769006632)
,p_name=>'P9_PID'
,p_source_data_type=>'BLOB'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_item_source_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_prompt=>'PID'
,p_source=>'PID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>unistr('Fa\00E7a o upload da sua permiss\00E3o internal para dirigir (PID)')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'blob_last_updated_column', 'PID_TIME',
  'content_disposition', 'inline',
  'display_as', 'INLINE',
  'display_download_link', 'Y',
  'filename_column', 'PID_NAME',
  'mime_type_column', 'PID_MIME',
  'storage_type', 'DB_COLUMN')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18881328918006633)
,p_name=>'P9_PID_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_item_source_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_source=>'PID_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18881448256006634)
,p_name=>'P9_PID_TIME'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_item_source_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_source=>'PID_TIME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18881509586006635)
,p_name=>'P9_PID_MIME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_item_source_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_source=>'PID_MIME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18881606681006636)
,p_name=>'P9_VACINACAO'
,p_source_data_type=>'BLOB'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_item_source_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_prompt=>unistr('Comprovante Vacina\00E7\00E3o')
,p_source=>'VACINACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>unistr('Fa\00E7a o upload do seu comprovante de vacina\00E7\00E3o COVID 19')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'blob_last_updated_column', 'VACINACAO_TIME',
  'content_disposition', 'inline',
  'display_as', 'INLINE',
  'display_download_link', 'Y',
  'filename_column', 'VACINACAO_NAME',
  'mime_type_column', 'VACINACAO_MIME',
  'storage_type', 'DB_COLUMN')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18881761925006637)
,p_name=>'P9_VACINACAO_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_item_source_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_source=>'VACINACAO_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18881805548006638)
,p_name=>'P9_VACINACAO_TIME'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>320
,p_item_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_item_source_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_source=>'VACINACAO_TIME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18881923287006639)
,p_name=>'P9_VACINACAO_MIME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>330
,p_item_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_item_source_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_source=>'VACINACAO_MIME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18882034827006640)
,p_name=>'P9_SEGURO'
,p_source_data_type=>'BLOB'
,p_item_sequence=>340
,p_item_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_item_source_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_prompt=>'Seguro Viagem'
,p_source=>'SEGURO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>unistr('Fa\00E7a o upload do seu seguro viagem')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'blob_last_updated_column', 'SEGURO_TIME',
  'content_disposition', 'inline',
  'display_as', 'INLINE',
  'display_download_link', 'Y',
  'filename_column', 'SEGURO_NAME',
  'mime_type_column', 'SEGURO_MIME',
  'storage_type', 'DB_COLUMN')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18882190211006641)
,p_name=>'P9_SEGURO_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>350
,p_item_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_item_source_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_source=>'SEGURO_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18882287767006642)
,p_name=>'P9_SEGURO_TIME'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>360
,p_item_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_item_source_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_source=>'SEGURO_TIME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18882337781006643)
,p_name=>'P9_SEGURO_MIME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>370
,p_item_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_item_source_plug_id=>wwv_flow_imp.id(18878717284006607)
,p_source=>'SEGURO_MIME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(18882600685006646)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(18878717284006607)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'UPDATEDB'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(18760707359720923)
,p_internal_uid=>18882600685006646
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(18939148931367036)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SETTIME'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    :P9_PASSAPORTE_TIME := CURRENT_TIMESTAMP;',
'    :P9_RG_CNH_TIME := CURRENT_TIMESTAMP;',
'    :P9_PID_TIME := CURRENT_TIMESTAMP;',
'    :P9_VACINACAO_TIME := CURRENT_TIMESTAMP;',
'    :P9_SEGURO_TIME := CURRENT_TIMESTAMP;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>18939148931367036
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(18878896471006608)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(18878717284006607)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Meus Documentos'
,p_internal_uid=>18878896471006608
);
wwv_flow_imp.component_end;
end;
/
