prompt --application/pages/page_00104
begin
--   Manifest
--     PAGE: 00104
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>14526457840079170
,p_default_application_id=>109
,p_default_id_offset=>14529182932118536
,p_default_owner=>'YOUR'
);
wwv_flow_imp_page.create_page(
 p_id=>104
,p_name=>'Cadastro Viagem'
,p_alias=>'CADASTRO-VIAGEM'
,p_page_mode=>'MODAL'
,p_step_title=>'Cadastro Viagem'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.botao_rosa{',
'    background-color: rgb(205, 75, 155);',
'    color: white;',
'}'))
,p_step_template=>1661186590416509825
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_chained=>'N'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(22707041740290110)
,p_plug_name=>'Cadastro Viagem'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT v.VIAGEM_ID,',
'       v.VIAGEM,',
'       v.DATAPARTIDA,',
'       v.DATACHEGADA,',
'       v.DESTINO',
'  FROM VIAGEM v',
''))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(22708811337290123)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(22709218405290125)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(22708811337290123)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancelar'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(22710611603290130)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(22708811337290123)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Deletar'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P104_VIAGEM_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(22711036299290131)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(22708811337290123)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Salvar'
,p_button_position=>'NEXT'
,p_button_condition=>'P104_VIAGEM_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_button_css_classes=>'botao_rosa'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(22711443874290132)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(22708811337290123)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Criar'
,p_button_position=>'NEXT'
,p_button_condition=>'P104_VIAGEM_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_button_css_classes=>'botao_rosa'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20225472044434633)
,p_name=>'P104_VIAGEM_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(22707041740290110)
,p_item_source_plug_id=>wwv_flow_imp.id(22707041740290110)
,p_source=>'VIAGEM_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20225544263434634)
,p_name=>'P104_VIAGEM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(22707041740290110)
,p_item_source_plug_id=>wwv_flow_imp.id(22707041740290110)
,p_prompt=>'Viagem'
,p_source=>'VIAGEM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>300
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20225611184434635)
,p_name=>'P104_DATAPARTIDA'
,p_source_data_type=>'DATE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(22707041740290110)
,p_item_source_plug_id=>wwv_flow_imp.id(22707041740290110)
,p_prompt=>unistr('Data In\00EDcio Viagem')
,p_source=>'DATAPARTIDA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20225783247434636)
,p_name=>'P104_DATACHEGADA'
,p_source_data_type=>'DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(22707041740290110)
,p_item_source_plug_id=>wwv_flow_imp.id(22707041740290110)
,p_prompt=>unistr('Data T\00E9rmino Viagem')
,p_source=>'DATACHEGADA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20225833855434637)
,p_name=>'P104_DESTINO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(22707041740290110)
,p_item_source_plug_id=>wwv_flow_imp.id(22707041740290110)
,p_prompt=>'Destino'
,p_source=>'DESTINO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20226893391434647)
,p_name=>'P104_USUARIO'
,p_item_sequence=>20
,p_prompt=>unistr('Quem ir\00E1 viajar')
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>'SELECT NOME_COMPLETO DISPLAY, USUARIO_ID REQUEST FROM USUARIO ORDER BY 1;'
,p_cHeight=>5
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>','
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(22709325386290125)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(22709218405290125)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(22710185487290129)
,p_event_id=>wwv_flow_imp.id(22709325386290125)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(22712290899290135)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(22707041740290110)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Cadastro Viagem'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>22712290899290135
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(20226096847434639)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'USUARO_VIAGEM'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_vc_arr2 sys.odcivarchar2list; -- Use Oracle''s built-in collection type',
'begin',
'    -- Convert comma-separated values into a table using REGEXP',
'    select regexp_substr(:P104_USUARIO, ''[^,]+'', 1, level)',
'    bulk collect into l_vc_arr2',
'    from dual',
'    connect by level <= length(:P104_USUARIO) - length(replace(:P104_USUARIO, '','', '''')) + 1;',
'',
'    -- Delete existing records that match VIAGEM_ID and usuario_id in the list',
'    delete from usuario_viagem',
'    where VIAGEM_ID = to_number(:P104_VIAGEM_ID)',
'--    and usuario_id in (select to_number(column_value) from table(l_vc_arr2))',
'    ;',
'',
unistr('    -- Insert users back (only if they don\2019t already exist)'),
'    for i in 1..l_vc_arr2.count loop',
'        begin',
'            insert into usuario_viagem (VIAGEM_ID, usuario_id)',
'            select to_number(:P104_VIAGEM_ID), to_number(l_vc_arr2(i))',
'            from dual',
'            where not exists (',
'                select 1 from usuario_viagem',
'                where VIAGEM_ID = to_number(:P104_VIAGEM_ID)',
'                and usuario_id = to_number(l_vc_arr2(i))',
'            );',
'        exception',
'            when others then',
'                -- Handle potential exceptions here (optional)',
'                null;',
'        end;',
'    end loop;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>20226096847434639
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(22712695673290136)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>22712695673290136
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(20226950342434648)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SETSHUTTLE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--DECLARE',
'--    -- Declare a variable to hold the result',
'--    v_nomes_completos VARCHAR2(4000);',
'--BEGIN',
'--    -- Select the result into the variable',
'--    SELECT LISTAGG(u.USUARIO_ID, '','') WITHIN GROUP (ORDER BY u.USUARIO_ID)',
'--    INTO v_nomes_completos',
'--    FROM VIAGEM v',
'--    JOIN USUARIO_VIAGEM vu ON v.VIAGEM_ID = vu.VIAGEM_ID',
'--    JOIN USUARIO u ON vu.USUARIO_ID = u.USUARIO_ID',
'--    WHERE v.VIAGEM_ID = :P104_VIAGEM_ID',
'--    GROUP BY v.VIAGEM_ID, v.VIAGEM, v.DATAPARTIDA, v.DATACHEGADA, v.DESTINO;',
'--',
'--    -- Assign the result to the bind variable',
'--    :P104_USUARIO := v_nomes_completos;',
'--END;',
'',
'DECLARE',
'    -- Declare a variable to hold the result',
'    v_nomes_completos VARCHAR2(4000);',
'BEGIN',
'    -- Initialize the variable with an empty string',
'    v_nomes_completos := '''';',
'',
'    BEGIN',
'        -- Select the result into the variable',
'        SELECT LISTAGG(u.USUARIO_ID, '','') WITHIN GROUP (ORDER BY u.USUARIO_ID)',
'        INTO v_nomes_completos',
'        FROM VIAGEM v',
'        JOIN USUARIO_VIAGEM vu ON v.VIAGEM_ID = vu.VIAGEM_ID',
'        JOIN USUARIO u ON vu.USUARIO_ID = u.USUARIO_ID',
'        WHERE v.VIAGEM_ID = :P104_VIAGEM_ID',
'        GROUP BY v.VIAGEM_ID, v.VIAGEM, v.DATAPARTIDA, v.DATACHEGADA, v.DESTINO;',
'    EXCEPTION',
'        -- If no data is found, assign an empty string',
'        WHEN NO_DATA_FOUND THEN',
'            v_nomes_completos := '''';',
'    END;',
'',
'    -- Assign the result (empty string if no data found) to the bind variable',
'    :P104_USUARIO := v_nomes_completos;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>20226950342434648
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(22711899199290134)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(22707041740290110)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Cadastro Viagem'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>22711899199290134
);
wwv_flow_imp.component_end;
end;
/
