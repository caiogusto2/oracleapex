prompt --application/pages/page_00103
begin
--   Manifest
--     PAGE: 00103
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>14526457840079170
,p_default_application_id=>109
,p_default_id_offset=>14529182932118536
,p_default_owner=>'YOUR'
);
wwv_flow_imp_page.create_page(
 p_id=>103
,p_name=>'Lista Viagens'
,p_alias=>'LISTA-VIAGENS'
,p_step_title=>'Lista Viagens'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Body-title{',
'    background-color: rgb(205, 75, 155);',
'}',
'',
'@media only screen and (-webkit-min-device-pixel-ratio: 1.25),',
'       only screen and (-webkit-min-device-pixel-ratio: 1.3),',
'       only screen and (min-resolution: 120dpi) {',
'    .rw-pillar--rose .t-Body-title:after,',
'    .rw-pillar--rose.rw-layout--fixed .t-Body-mainContent:before {',
'        background-image: none; /* or background-image: unset; */',
'    }',
'}',
'',
'.rw-pillar--rose .t-Body-title:after,',
'.rw-pillar--rose.rw-layout--fixed .t-Body-mainContent:before {',
'    background-image: none; /* or background-image: unset; */',
'}',
'',
'.t-Body-title:after {',
'    background-color: rgb(245, 130, 32);',
'}',
'',
'.botao_rosa{',
'    background-color: rgb(205, 75, 155);',
'    color: white;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(22713621010290143)
,p_plug_name=>'Lista Viagens'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select VIAGEM_ID,',
'       VIAGEM,',
'       DATAPARTIDA,',
'       DATACHEGADA,',
'       DESTINO',
'  from VIAGEM'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Lista Viagens'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(22713730865290143)
,p_name=>'Lista Viagens'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:104:&SESSION.::&DEBUG.:RP,:P104_VIAGEM_ID:#VIAGEM_ID#'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_owner=>'YOUR'
,p_internal_uid=>22713730865290143
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20224936222434628)
,p_db_column_name=>'VIAGEM_ID'
,p_display_order=>10
,p_is_primary_key=>'Y'
,p_column_identifier=>'C'
,p_column_label=>'Viagem Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20225058124434629)
,p_db_column_name=>'VIAGEM'
,p_display_order=>20
,p_column_identifier=>'D'
,p_column_label=>'Viagem'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20225165735434630)
,p_db_column_name=>'DATAPARTIDA'
,p_display_order=>30
,p_column_identifier=>'E'
,p_column_label=>'Datapartida'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20225214038434631)
,p_db_column_name=>'DATACHEGADA'
,p_display_order=>40
,p_column_identifier=>'F'
,p_column_label=>'Datachegada'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20225304804434632)
,p_db_column_name=>'DESTINO'
,p_display_order=>50
,p_column_identifier=>'G'
,p_column_label=>'Destino'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(22717419343291806)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'227175'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'VIAGEM_ID:VIAGEM:DESTINO:DATACHEGADA:DATAPARTIDA:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(22716892022290158)
,p_plug_name=>'Controle Viagens'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--featured'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(59038990052435128)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(22715336346290152)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(22713621010290143)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Adicionar Viagem'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:104:&APP_SESSION.::&DEBUG.:104::'
,p_button_css_classes=>'botao_rosa'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(22715607360290153)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(22713621010290143)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(22716018295290155)
,p_event_id=>wwv_flow_imp.id(22715607360290153)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(22713621010290143)
);
wwv_flow_imp.component_end;
end;
/
