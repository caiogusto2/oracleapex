prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>14526457840079170
,p_default_application_id=>109
,p_default_id_offset=>14529182932118536
,p_default_owner=>'YOUR'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Roteiro'
,p_alias=>'HOME'
,p_step_title=>'Home'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(20246372532609907)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.float{',
'  z-index:100;',
'  position:fixed;',
'  width:60px;',
'  height:60px;',
'  bottom:40px;',
'  right:40px;',
'  background-color: black;',
'  color:#FFF;',
'  border-radius:50px;',
'  text-align:center;',
'  box-shadow: 2px 2px 3px #999;',
'}',
'.my-float{',
'  margin-top:22px;',
'}',
'',
'.floatlogoff {',
'  z-index: 100;',
'  position: absolute;',
'  top: 10px;  /* Position from the top */',
'  right: 10px; /* Position from the right */',
'  width: auto; /* Adjust width as needed */',
'  height: auto; /* Adjust height as needed */',
'  padding: 10px 20px; /* Add padding for better spacing */',
'  color: #FFF;',
'  text-align: center;',
'  border-radius: 5px; /* Optional: Slightly rounded corners */',
'  /* background-color: black;  Removed */',
'  /* box-shadow: 2px 2px 3px #999;  Removed */',
'}',
'',
'.my-floatlogoff {',
'  margin-top: 0; /* Remove unnecessary margin */',
'}',
'',
'',
'',
'',
'',
'',
'',
'',
'.itinerary {',
'  font-family: Arial, sans-serif;',
'  max-width: 90%;',
'  margin: 20px auto;',
'}',
'',
'.day {',
'  background: #f4f4f4;',
'  padding: 15px;',
'  margin-bottom: 20px;',
'  border-radius: 10px;',
'  box-shadow: 0 3px 6px rgba(0, 0, 0, 0.1);',
'}',
'',
'h4 {',
'  margin: 0 0 10px 0;',
'  padding-bottom: 5px;',
'  color: #444;',
'  border-bottom: 2px solid #ccc;',
'}',
'',
'.activities {',
'  display: flex;',
'  flex-wrap: wrap;',
'  gap: 10px;',
'  margin-top: 10px;',
'}',
'',
'.activity-card {',
'  background: white;',
'  padding: 10px 15px;',
'  border-radius: 8px;',
'  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);',
'  flex: 1 1 250px; /* Responsive width */',
'  min-width: 200px;',
'  text-align: center;',
'  font-size: 16px;',
'}',
'',
'',
'',
'',
'',
'',
'',
'.t-Body-title{',
'    background-color: rgb(205, 75, 155);',
'}',
'',
'@media only screen and (-webkit-min-device-pixel-ratio: 1.25),',
'       only screen and (-webkit-min-device-pixel-ratio: 1.3),',
'       only screen and (min-resolution: 120dpi) {',
'    .rw-pillar--rose .t-Body-title:after,',
'    .rw-pillar--rose.rw-layout--fixed .t-Body-mainContent:before {',
'        background-image: none; /* or background-image: unset; */',
'    }',
'}',
'',
'.rw-pillar--rose .t-Body-title:after,',
'.rw-pillar--rose.rw-layout--fixed .t-Body-mainContent:before {',
'    background-image: none; /* or background-image: unset; */',
'}',
'',
'.t-Body-title:after {',
'    background-color: rgb(245, 130, 32);',
'}'))
,p_step_template=>2979075366320325194
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18172982913288861)
,p_plug_name=>'Escolha o dia'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--featured'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_region_image=>'#APP_FILES#icons/app-icon-512.png	'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18181404680577526)
,p_plug_name=>'Cards'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2072724515482255512
,p_plug_display_sequence=>50
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    TO_CHAR(TO_DATE(diario.data, ''DD/MM/YYYY''), ''DD/MM/YYYY'') AS data_formatada,',
'    diario.cidade,',
'    LISTAGG(atv.descricao, '', '') WITHIN GROUP (ORDER BY atv.descricao) AS descricao_ag',
'FROM ',
'    doc_upload23,',
'    JSON_TABLE(',
'        TO_CLOB(doc_upload23.data), ',
'        ''$.viagem.roteiro.diario[*]'' ',
'        COLUMNS (',
'            data VARCHAR2(20) PATH ''$.data'',',
'            cidade VARCHAR2(100) PATH ''$.cidade'',',
'            NESTED PATH ''$.atividades[*]'' ',
'            COLUMNS (',
'                descricao VARCHAR2(200) PATH ''$''',
'            )',
'        )',
'    ) diario,',
'    LATERAL (SELECT diario.descricao FROM DUAL) atv',
'    WHERE doc_upload23.doc_id = :DOC_ID',
'    AND doc_upload23.VIAGEM_FK = :VIAGEM_ID',
'GROUP BY ',
'    diario.data, ',
'    diario.cidade',
'ORDER BY TO_DATE(diario.data, ''DD/MM/YYYY'');',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'(select count (*) from doc_upload23 where doc_name like ''%.json'') > 0;'
,p_plug_display_when_cond2=>'SQL'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(18181533390577527)
,p_region_id=>wwv_flow_imp.id(18181404680577526)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'CIDADE'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'DATA_FORMATADA'
,p_body_adv_formatting=>false
,p_body_column_name=>'DESCRICAO_AG'
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'INITIALS'
,p_icon_class_column_name=>'CIDADE'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'DATA_FORMATADA'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(18181672083577528)
,p_card_id=>wwv_flow_imp.id(18181533390577527)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:2:P2_INPUT:O QUE FAREMOS NO DIA &DATA_FORMATADA.'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18182126933577533)
,p_plug_name=>unistr('Dicas e Informa\00E7\00F5es')
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:is-collapsed:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'(select count (*) from doc_upload23 where doc_name like ''%.json'') > 0;'
,p_plug_display_when_cond2=>'SQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18181835942577530)
,p_plug_name=>unistr('Informa\00E7\00F5es Viagem')
,p_parent_plug_id=>wwv_flow_imp.id(18182126933577533)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
' cursor info is',
'    SELECT ',
'        diario.destino,',
'        diario.periodo,',
'        LISTAGG(diario.cidades, '', '') WITHIN GROUP (ORDER BY diario.cidades) AS cidades,',
'        LISTAGG(diario.participantes, '', '') WITHIN GROUP (ORDER BY diario.participantes) AS participantes',
'    FROM doc_upload23,',
'        JSON_TABLE(',
'            TO_CLOB(doc_upload23.data),',
'            ''$.viagem'' ',
'            COLUMNS (',
'                destino VARCHAR2(20) PATH ''$.destino'',',
'                periodo VARCHAR2(20) PATH ''$.periodo'',',
'                NESTED PATH ''$.cidades[*]'' ',
'                COLUMNS (',
'                    cidades VARCHAR2(200) PATH ''$''',
'                ),',
'                NESTED PATH ''$.participantes[*]'' ',
'                COLUMNS (',
'                    participantes VARCHAR2(200) PATH ''$''',
'                )',
'            )',
'        ) diario',
'        WHERE doc_upload23.doc_id = :DOC_ID',
'        AND doc_upload23.VIAGEM_FK = :VIAGEM_ID',
'    GROUP BY ',
'        diario.destino, ',
'        diario.periodo',
'    ORDER BY ',
'        diario.destino, ',
'        diario.periodo;',
'',
' ',
'begin',
'  sys.htp.p('''');',
'  for a in info',
'  loop',
'    sys.htp.p(''Destino: ''   || apex_escape.html(a.destino) || '' <br>'' ||',
unistr('              ''Per\00EDodo: ''   || apex_escape.html(a.periodo) || '' <br>'' ||'),
'              ''Cidades: ''   || apex_escape.html(a.cidades) || '' <br>'' ||',
'              ''Participantes: ''   || apex_escape.html(a.participantes) ',
'                 );',
'  end loop;',
'  sys.htp.p('''');',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18181964999577531)
,p_plug_name=>unistr('Dicas e Recomenda\00E7\00F5es')
,p_parent_plug_id=>wwv_flow_imp.id(18182126933577533)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
' cursor info is',
'    SELECT ',
'        LISTAGG(diario.documentos, '', '') WITHIN GROUP (ORDER BY diario.documentos) AS documentos,',
'        LISTAGG(diario.eletronicos, '', '') WITHIN GROUP (ORDER BY diario.eletronicos) AS eletronicos,',
'        LISTAGG(diario.apps, '', '') WITHIN GROUP (ORDER BY diario.apps) AS apps        ',
'    FROM doc_upload23,',
'        JSON_TABLE(',
'            TO_CLOB(doc_upload23.data),',
'            ''$.viagem.roteiro.pre_viagem'' ',
'            COLUMNS (',
'                NESTED PATH ''$.documentos[*]'' ',
'                COLUMNS (',
'                    documentos VARCHAR2(200) PATH ''$''',
'                ),',
'                NESTED PATH ''$.eletronicos[*]'' ',
'                COLUMNS (',
'                    eletronicos VARCHAR2(200) PATH ''$''',
'                ),',
'                NESTED PATH ''$.apps[*]'' ',
'                COLUMNS (',
'                    apps VARCHAR2(200) PATH ''$''',
'                )',
'            )',
'        ) diario',
'        WHERE doc_upload23.doc_id = :DOC_ID',
'        AND doc_upload23.VIAGEM_FK = :VIAGEM_ID;',
' ',
'begin',
'  sys.htp.p('''');',
'  for a in info',
'  loop',
'    sys.htp.p(''Documentos: '' || apex_escape.html(a.documentos) || '' <br>'' ||',
unistr('              ''Eletr\00F4nicos: ''   || apex_escape.html(a.eletronicos) || '' <br>'' ||'),
'              ''Apps: ''   || apex_escape.html(a.apps)',
'                 );',
'  end loop;',
'  sys.htp.p('''');',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19710452376148673)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(18172982913288861)
,p_button_name=>'Logoff'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Logoff'
,p_button_redirect_url=>'&LOGOUT_URL.'
,p_button_css_classes=>'floatlogoff my-floatlogoff'
,p_icon_css_classes=>'fa-sign-out'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14939769619850847)
,p_button_sequence=>100
,p_button_name=>'AIAssistant'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Ai Assistant'
,p_button_redirect_url=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:2:P2_GENAIOUTPUT,P2_INPUT,P2_OUTPUT,P2_VECTOROUTPUT:,,,'
,p_button_css_classes=>'float my-float'
,p_icon_css_classes=>'fa-plus'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(19109025473284224)
,p_branch_action=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_COMPUTATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19108880742284222)
,p_name=>'Click'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(18172982913288861)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19108997322284223)
,p_event_id=>wwv_flow_imp.id(19108880742284222)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp.component_end;
end;
/
