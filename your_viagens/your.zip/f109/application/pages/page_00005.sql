prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>14526457840079170
,p_default_application_id=>109
,p_default_id_offset=>14529182932118536
,p_default_owner=>'YOUR'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'Carregar Arquivos'
,p_alias=>'UPLOADER-ARQUIVOS'
,p_page_mode=>'MODAL'
,p_step_title=>'Carregar Arquivos'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(20246401281610631)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.botao_rosa{',
'    background-color: rgb(205, 75, 155);',
'    color: white;',
'}'))
,p_step_template=>1661186590416509825
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(90416272406230239)
,p_plug_name=>'PDF Uploader'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DOC_NAME,',
'       DATA,',
'       CREATED_AT,',
'       DOC_ID,',
'       MIME_TYPE,',
'       CHUNKS_DIVISION,',
'       MODELO,',
'       BASEDADOS,',
'       VIAGEM_FK',
'  from DOC_UPLOAD23'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(90420598179230240)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(63641496881046630)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(90420598179230240)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancelar'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(63641871925046632)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(90420598179230240)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Deletar'
,p_button_position=>'CLOSE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P5_DOC_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_button_css_classes=>'botao_rosa'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(20223116968434610)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(90420598179230240)
,p_button_name=>'SALVAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--primary'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Salvar'
,p_button_position=>'NEXT'
,p_button_execute_validations=>'N'
,p_button_condition=>'P5_DOC_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_button_css_classes=>'botao_rosa'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(63642672246046634)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(90420598179230240)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Carregar'
,p_button_position=>'NEXT'
,p_button_condition=>'P5_DOC_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_button_css_classes=>'botao_rosa'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18182436837577536)
,p_name=>'P5_BASEDADOS'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(90416272406230239)
,p_item_source_plug_id=>wwv_flow_imp.id(90416272406230239)
,p_item_default=>'N'
,p_prompt=>'Arquivo p/ uso de AI?'
,p_source=>'BASEDADOS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_display_when=>'P5_DOC_ID'
,p_display_when_type=>'ITEM_IS_NULL'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>unistr('N\00E3o coloque documentos pessoais para serem processados por AI, exemplo documentos com informa\00E7\00F5es sens\00EDveis e sob regras da LGPD')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20222814696434607)
,p_name=>'P5_CHUNKS_DIVISION'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(90416272406230239)
,p_item_source_plug_id=>wwv_flow_imp.id(90416272406230239)
,p_source=>'CHUNKS_DIVISION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20227063593434649)
,p_name=>'P5_VIAGEM_FK'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(90416272406230239)
,p_item_source_plug_id=>wwv_flow_imp.id(90416272406230239)
,p_prompt=>'Viagem'
,p_source=>'VIAGEM_FK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select viagem display, viagem_id request from viagem order by 1;'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(22938624359289347)
,p_name=>'P5_MODELO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(90416272406230239)
,p_item_source_plug_id=>wwv_flow_imp.id(90416272406230239)
,p_item_default=>'cohere_embedmultilingualv30'
,p_source=>'MODELO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>'P5_DOC_ID'
,p_display_when_type=>'ITEM_IS_NULL'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85761077178950321)
,p_name=>'P5_JSONCONF'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(90416272406230239)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'    "by" : "words",',
'    "max" : "200",',
'    "overlap" : "0",',
'    "split": "sentence",',
'    "language" : "ptb",',
'    "normalize": "all"',
'}'))
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>'P5_DOC_ID'
,p_display_when_type=>'ITEM_IS_NULL'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<!DOCTYPE html>',
'<html>',
'<body>',
'    <div>',
unistr('        <h3>Colocar em formato JSON as configura\00E7\00F5es dos chunks.</h3>'),
'',
unistr('        <p>Documenta\00E7\00F5es:</p>'),
'        <ul>',
'            <li><a href="https://docs.oracle.com/en/database/oracle/oracle-database/23/arpls/dbms_vector_chain1.html#GUID-4E145629-7098-4C7C-804F-FC85D1F24240" target="_blank">Oracle DBMS_VECTOR_CHAIN Package Documentation</a></li>',
'            <li><a href="https://docs.oracle.com/en/database/oracle/oracle-database/23/sqlrf/vector_chunks.html#SQLRF-GUID-5927E2FA-6419-4744-A7CB-3E62DBB027AD" target="_blank">Oracle Vector Chunks Documentation</a></li>',
'        </ul>',
'',
'        <p>Exemplo:</p>',
'        <pre>',
'{',
'    "by" : "words",',
'    "max" : "200",',
'    "overlap" : "0",',
'    "split": "sentence",',
'    "language" : "ptb",',
'    "normalize": "none"',
'}',
'        </pre>',
'    </div>',
'</body>',
'</html>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(90417230510230300)
,p_name=>'P5_DOC_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(90416272406230239)
,p_item_source_plug_id=>wwv_flow_imp.id(90416272406230239)
,p_source=>'DOC_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(90417677120230300)
,p_name=>'P5_DOC_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(90416272406230239)
,p_item_source_plug_id=>wwv_flow_imp.id(90416272406230239)
,p_prompt=>'Nome Arquivo'
,p_source=>'DOC_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when=>'P5_DOC_ID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_read_only_when=>'P5_DOC_ID'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(90418048980230300)
,p_name=>'P5_DATA'
,p_source_data_type=>'BLOB'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(90416272406230239)
,p_item_source_plug_id=>wwv_flow_imp.id(90416272406230239)
,p_prompt=>'Arquivo'
,p_source=>'DATA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>60
,p_cMaxlength=>255
,p_display_when=>'P5_DOC_ID'
,p_display_when_type=>'ITEM_IS_NULL'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'blob_last_updated_column', 'CREATED_AT',
  'content_disposition', 'attachment',
  'display_as', 'DROPZONE_INLINE',
  'display_download_link', 'Y',
  'file_types', '.pdf,.json',
  'filename_column', 'DOC_NAME',
  'mime_type_column', 'MIME_TYPE',
  'storage_type', 'DB_COLUMN')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(90418432058230300)
,p_name=>'P5_CREATED_AT'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(90416272406230239)
,p_item_source_plug_id=>wwv_flow_imp.id(90416272406230239)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--SELECT TO_CHAR(SYSTIMESTAMP,''DD-MON-YYYY HH24:MI:SS'') FROM DUAL;',
'SELECT SYSTIMESTAMP FROM DUAL;'))
,p_item_default_type=>'SQL_QUERY'
,p_source=>'CREATED_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(90419276663230301)
,p_name=>'P5_MIME_TYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(90416272406230239)
,p_item_source_plug_id=>wwv_flow_imp.id(90416272406230239)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'application/pdf',
''))
,p_source=>'MIME_TYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(63643415519046655)
,p_validation_name=>'P5_CREATED_AT must be timestamp'
,p_validation_sequence=>30
,p_validation=>'P5_CREATED_AT'
,p_validation_type=>'ITEM_IS_TIMESTAMP'
,p_error_message=>'#LABEL# must be a valid timestamp.'
,p_associated_item=>wwv_flow_imp.id(90418432058230300)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(29716290639230493)
,p_validation_name=>'VALIDARNOME'
,p_validation_sequence=>40
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'NOT EXISTS (',
'    SELECT 1',
'    FROM doc_upload23',
'    where doc_name = trim(:P5_DOC_NAME)',
')'))
,p_validation2=>'SQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('J\00E1 existe um documento com esse nome')
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(63642672246046634)
,p_associated_item=>wwv_flow_imp.id(90417677120230300)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(63645877157046665)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(63641496881046630)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(63646444556046672)
,p_event_id=>wwv_flow_imp.id(63645877157046665)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(63644500575046659)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Upload_File_Chain'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>15081735802873737
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(63643714359046657)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>15080949586873735
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(63636902615046602)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(90416272406230239)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form PDF_UPLOADER'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>15074137842873680
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(63644125607046658)
,p_process_sequence=>20
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DeleteChunks'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DELETE FROM DOC_CHUNKS23',
'WHERE doc_id = :P5_DOC_ID;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(63641871925046632)
,p_required_patch=>wwv_flow_imp.id(59038459818435115)
,p_internal_uid=>15081360834873736
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(63637356846046605)
,p_process_sequence=>20
,p_region_id=>wwv_flow_imp.id(90416272406230239)
,p_parent_process_id=>wwv_flow_imp.id(63644500575046659)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form PDF_UPLOADER'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_internal_uid=>15074592073873683
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(29716009677230490)
,p_process_sequence=>30
,p_parent_process_id=>wwv_flow_imp.id(63644500575046659)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create_Chunks'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_chunks_division JSON := JSON(',
'        :P5_JSONCONF',
'    );',
'BEGIN',
'    -- Insert into DOC_CHUNKS',
'    INSERT INTO DOC_CHUNKS23 (',
'        doc_id,',
'        embed_id,',
'        embed_data',
'    )',
'    SELECT ',
'        dt.doc_id,',
'        et.embed_id,',
'        et.embed_data',
'    FROM',
'        doc_upload23 dt,',
'            dbms_vector_chain.utl_to_chunks(',
'                dbms_vector_chain.utl_to_text(dt.data), ',
'                v_chunks_division',
'            ) t,',
'        JSON_TABLE(',
'            t.column_value, ',
'            ''$[*]'' COLUMNS (',
'                embed_id NUMBER PATH ''$.chunk_id'', ',
'                embed_data VARCHAR2(4000) PATH ''$.chunk_data''',
'            )',
'        ) et',
'--    WHERE dt.doc_id = (SELECT MAX(doc_id) FROM doc_upload);',
'      WHERE dt.doc_id = :P5_DOC_ID;',
'',
'    -- Update DOC_UPLOAD with CHUNKS_DIVISION',
'    UPDATE doc_upload23',
'    SET CHUNKS_DIVISION = v_chunks_division',
'--    WHERE doc_id = (SELECT MAX(doc_id) FROM doc_upload);',
'    WHERE doc_id = :P5_DOC_ID;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_button_id=>wwv_flow_imp.id(63642672246046634)
,p_process_when=>'P5_BASEDADOS'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'Y'
,p_internal_uid=>5667329781156003
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(29716234552230492)
,p_process_sequence=>40
,p_parent_process_id=>wwv_flow_imp.id(63644500575046659)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create_Embedding'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    UPDATE doc_chunks23',
'    SET embed_vector = apex_ai.get_vector_embeddings(',
'                           p_value             => embed_data, ',
'                           p_service_static_id => :P5_MODELO',
'                       )',
'    WHERE doc_id = :P5_DOC_ID;',
'',
'    COMMIT;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_button_id=>wwv_flow_imp.id(63642672246046634)
,p_process_when=>'P5_BASEDADOS'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'Y'
,p_internal_uid=>5667554656156005
);
wwv_flow_imp.component_end;
end;
/
