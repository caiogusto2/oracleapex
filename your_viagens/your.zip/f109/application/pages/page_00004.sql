prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>14526457840079170
,p_default_application_id=>109
,p_default_id_offset=>14529182932118536
,p_default_owner=>'YOUR'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Arquivos'
,p_alias=>'ARQUIVOS'
,p_step_title=>'Arquivos e Normas'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(20246401281610631)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Body-title{',
'    background-color: rgb(205, 75, 155);',
'}',
'',
'@media only screen and (-webkit-min-device-pixel-ratio: 1.25),',
'       only screen and (-webkit-min-device-pixel-ratio: 1.3),',
'       only screen and (min-resolution: 120dpi) {',
'    .rw-pillar--rose .t-Body-title:after,',
'    .rw-pillar--rose.rw-layout--fixed .t-Body-mainContent:before {',
'        background-image: none; /* or background-image: unset; */',
'    }',
'}',
'',
'.rw-pillar--rose .t-Body-title:after,',
'.rw-pillar--rose.rw-layout--fixed .t-Body-mainContent:before {',
'    background-image: none; /* or background-image: unset; */',
'}',
'',
'.t-Body-title:after {',
'    background-color: rgb(245, 130, 32);',
'}',
'',
'.botao_rosa{',
'    background-color: rgb(205, 75, 155);',
'    color: white;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(60062032627105849)
,p_plug_name=>'Controle Arquivos e Viagens'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--featured'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(59038990052435128)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
,p_region_image=>'#APP_FILES#icons/app-icon-512.png	'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(90024509582180435)
,p_plug_name=>'FILE_LIST'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    d."DOC_ID",',
'    d."DOC_NAME",',
'    sys.dbms_lob.getlength(d.DATA)"DATA",',
'    d."CREATED_AT","MIME_TYPE", ',
'    d.CHUNKS_DIVISION,',
'    d.MODELO,',
'    d.basedados,',
'    g.viagem ',
'from "DOC_UPLOAD23" d, viagem g',
'where d.viagem_fk = g.viagem_id'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'FILE_LIST'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(90024588889180435)
,p_name=>'PDF_LIST'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_actions_menu=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:RP,:P5_DOC_ID:\#DOC_ID#\'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_owner=>'DOCUSER'
,p_internal_uid=>41461824117007513
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(90024950851180436)
,p_db_column_name=>'DOC_ID'
,p_display_order=>0
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'Doc ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(90025414957180436)
,p_db_column_name=>'DOC_NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Nome Documento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(90025748514180436)
,p_db_column_name=>'DATA'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Arquivo'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DOWNLOAD:DOC_UPLOAD23:DATA:DOC_ID::MIME_TYPE:DOC_NAME:CREATED_AT::attachment::'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(90026203084180436)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Upload feito em'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(90026625881180436)
,p_db_column_name=>'MIME_TYPE'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Mime Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(90696096236901474)
,p_db_column_name=>'CHUNKS_DIVISION'
,p_display_order=>15
,p_column_identifier=>'F'
,p_column_label=>unistr('Configura\00E7\00E3o de Chunks')
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_heading_alignment=>'LEFT'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(29715921094230489)
,p_db_column_name=>'MODELO'
,p_display_order=>25
,p_column_identifier=>'G'
,p_column_label=>'Modelo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(18183644992577548)
,p_db_column_name=>'BASEDADOS'
,p_display_order=>35
,p_column_identifier=>'H'
,p_column_label=>'Arquivo usado com AI'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20222605814434605)
,p_db_column_name=>'VIAGEM'
,p_display_order=>55
,p_column_identifier=>'J'
,p_column_label=>'Viagem'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(90029013886188691)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'46845'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOC_NAME:CREATED_AT:BASEDADOS:VIAGEM:DATA'
,p_sort_column_1=>'CREATED_AT'
,p_sort_direction_1=>'ASC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(63235817930996792)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(90024509582180435)
,p_button_name=>'UPLOAD'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Carregar Arquivo'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:5:P5_DOC_ID:'
,p_button_css_classes=>'botao_rosa'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(63236421032996823)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(90024509582180435)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(63236799544996828)
,p_event_id=>wwv_flow_imp.id(63236421032996823)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(90024509582180435)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
