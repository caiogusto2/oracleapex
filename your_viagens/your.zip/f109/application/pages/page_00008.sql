prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>14526457840079170
,p_default_application_id=>109
,p_default_id_offset=>14529182932118536
,p_default_owner=>'YOUR'
);
wwv_flow_imp_page.create_page(
 p_id=>8
,p_name=>unistr('Quem \00E9 voc\00EA')
,p_alias=>unistr('QUEM-\00C9-VOC\00CA')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Quem \00E9 voc\00EA')
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(20246372532609907)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.foto {',
'    max-height: 200px;',
'    width: auto;',
'    height: auto; ',
'}',
'',
'.t-Button, .t-Button--icon, .t-Button--iconRight, .t-Button--hot {',
'        background-color: rgb(205, 75, 155);',
'        box-shadow: rgb(205, 75, 155);',
'}',
'',
'.t-WizardSteps-marker, .t-WizardSteps-label, .t-WizardSteps-step.is-active{',
'    color: rgb(205, 75, 155);',
'}',
'',
'.t-WizardSteps-marker {',
'    box-shadow: inset 0 0 0 1px rgb(205, 75, 155); /* Thinner pink shadow */',
'    color: rgb(205, 75, 155); /* Pink text */',
'    border: 0.5px solid rgb(205, 75, 155); /* Very thin pink border */',
'}',
'',
'.t-WizardSteps-step.is-active .t-WizardSteps-marker {',
'    background-color: rgb(205, 75, 155); /* Pink background */',
'    color: var(--rw-palette-neutral-0); /* Assuming this variable is defined */',
'}',
'',
'.t-WizardSteps-step.is-active .t-WizardSteps-label {',
'    color: rgb(205, 75, 155); /* Pink text */',
'    font-weight: var(--ut-wp-label-active-font-weight, 700);',
'}',
''))
,p_step_template=>1661186590416509825
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_height=>'700'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18754438255720905)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(18753519037720901)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>2010149141494510257
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18754610332720905)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18840261314760303)
,p_plug_name=>'FORM'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select USUARIO_ID,',
'       NOME_COMPLETO,',
'       ENDERECO,',
'       TELEFONE,',
'       NOME_COMPLETO_EMERG,',
'       TELEFONE_EMERG,',
'       EMAIL,',
'       SELFIE,',
'       SELFIE_NAME,',
'       SELFIE_TIME,',
'       SELFIE_MIME,',
'       CPF',
'  from USUARIO'))
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18706286365533127)
,p_plug_name=>unistr('Contato de Emerg\00EAncia')
,p_parent_plug_id=>wwv_flow_imp.id(18840261314760303)
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18754576606720905)
,p_plug_name=>unistr('Quem \00E9 voc\00EA')
,p_parent_plug_id=>wwv_flow_imp.id(18840261314760303)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(18756443683720911)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(18754610332720905)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'t-Button--iconRight'
,p_button_template_id=>2082829544945815391
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Seguir'
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-chevron-right'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(18758089131720916)
,p_branch_name=>'Go To Page 9'
,p_branch_action=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::P9_USUARIO_ID:&USUARIO_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(18756443683720911)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18704783340533112)
,p_name=>'P8_UPLOAD'
,p_source_data_type=>'BLOB'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(18754576606720905)
,p_item_source_plug_id=>wwv_flow_imp.id(18840261314760303)
,p_prompt=>'Trocar Foto'
,p_source=>'SELFIE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_IMAGE_UPLOAD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_cropping', 'Y',
  'aspect_ratio', '1:1',
  'blob_last_updated_column', 'SELFIE_TIME',
  'capture_using', 'USER',
  'display_as', 'INLINE',
  'display_download_link', 'N',
  'dropzone_title', 'Trocar Foto',
  'filename_column', 'SELFIE_NAME',
  'max_file_size', '100',
  'mime_type_column', 'SELFIE_MIME',
  'storage_type', 'DB_COLUMN')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18840001687760301)
,p_name=>'P8_SELFIE'
,p_source_data_type=>'BLOB'
,p_is_query_only=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(18754576606720905)
,p_item_source_plug_id=>wwv_flow_imp.id(18840261314760303)
,p_prompt=>'Foto Atual'
,p_source=>'SELFIE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_tag_css_classes=>'foto'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    1',
'FROM USUARIO ',
'WHERE SELFIE is not null;'))
,p_display_when_type=>'EXISTS'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'DB_COLUMN',
  'blob_last_updated_column', 'SELFIE_TIME',
  'filename_column', 'SELFIE_NAME',
  'mime_type_column', 'SELFIE_MIME')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18843953280760340)
,p_name=>'P8_USUARIO_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(18840261314760303)
,p_item_source_plug_id=>wwv_flow_imp.id(18840261314760303)
,p_source=>'USUARIO_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18844026200760341)
,p_name=>'P8_NOME_COMPLETO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(18754576606720905)
,p_item_source_plug_id=>wwv_flow_imp.id(18840261314760303)
,p_prompt=>'Nome Completo'
,p_source=>'NOME_COMPLETO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>300
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18844164505760342)
,p_name=>'P8_ENDERECO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(18754576606720905)
,p_item_source_plug_id=>wwv_flow_imp.id(18840261314760303)
,p_prompt=>unistr('Endere\00E7o')
,p_source=>'ENDERECO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>500
,p_cHeight=>2
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18844241264760343)
,p_name=>'P8_TELEFONE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(18754576606720905)
,p_item_source_plug_id=>wwv_flow_imp.id(18840261314760303)
,p_prompt=>'Telefone'
,p_source=>'TELEFONE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'min_value', '0',
  'number_alignment', 'left',
  'virtual_keyboard', 'numeric')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18844551454760346)
,p_name=>'P8_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(18754576606720905)
,p_item_source_plug_id=>wwv_flow_imp.id(18840261314760303)
,p_prompt=>'Email'
,p_source=>'EMAIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>100
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'EMAIL',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18878215084006602)
,p_name=>'P8_NOMEEMERG'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(18706286365533127)
,p_item_source_plug_id=>wwv_flow_imp.id(18840261314760303)
,p_prompt=>'Nome Completo'
,p_source=>'NOME_COMPLETO_EMERG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>300
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18878326629006603)
,p_name=>'P8_TELEFONEEMERG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(18706286365533127)
,p_item_source_plug_id=>wwv_flow_imp.id(18840261314760303)
,p_prompt=>'Telefone'
,p_source=>'TELEFONE_EMERG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'min_value', '0',
  'number_alignment', 'left',
  'virtual_keyboard', 'numeric')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18878434932006604)
,p_name=>'P8_SELFIE_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(18754576606720905)
,p_item_source_plug_id=>wwv_flow_imp.id(18840261314760303)
,p_source=>'SELFIE_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18878546811006605)
,p_name=>'P8_SELFIE_TIME'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(18754576606720905)
,p_item_source_plug_id=>wwv_flow_imp.id(18840261314760303)
,p_source=>'SELFIE_TIME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18878614383006606)
,p_name=>'P8_SELFIE_MIME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(18754576606720905)
,p_item_source_plug_id=>wwv_flow_imp.id(18840261314760303)
,p_source=>'SELFIE_MIME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19109757042284231)
,p_name=>'P8_CPF'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(18754576606720905)
,p_item_source_plug_id=>wwv_flow_imp.id(18840261314760303)
,p_prompt=>'CPF'
,p_source=>'CPF'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'min_value', '0',
  'number_alignment', 'left',
  'virtual_keyboard', 'numeric')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(18882557553006645)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(18840261314760303)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'UPDATEDB'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(18756443683720911)
,p_internal_uid=>18882557553006645
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(18939070649367035)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SETIME'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    :P8_SELFIE_TIME := CURRENT_TIMESTAMP;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>18939070649367035
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(18840370342760304)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(18840261314760303)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize form Quem \00E9 voc\00EA')
,p_internal_uid=>18840370342760304
);
wwv_flow_imp.component_end;
end;
/
