prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>14526457840079170
,p_default_application_id=>109
,p_default_id_offset=>14529182932118536
,p_default_owner=>'YOUR'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'Landing Page'
,p_alias=>'LANDING-PAGE'
,p_step_title=>'Landing Page'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(20246540061611741)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.float {',
'  z-index: 100;',
'  position: absolute;',
'  top: 10px;  /* Position from the top */',
'  right: 10px; /* Position from the right */',
'  width: auto; /* Adjust width as needed */',
'  height: auto; /* Adjust height as needed */',
'  padding: 10px 20px; /* Add padding for better spacing */',
'  color: #FFF;',
'  text-align: center;',
'  border-radius: 5px; /* Optional: Slightly rounded corners */',
'  /* background-color: black;  Removed */',
'  /* box-shadow: 2px 2px 3px #999;  Removed */',
'}',
'',
'.my-float {',
'  margin-top: 0; /* Remove unnecessary margin */',
'}',
'',
'.t-Body-title{',
'    background-color: rgb(205, 75, 155);',
'}',
'',
'.fa-address-card-o, .fa-plane, .fa-user, .fa-files-o{',
'    background-color: rgb(245, 130, 32);',
'}',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'@media only screen and (-webkit-min-device-pixel-ratio: 1.25),',
'       only screen and (-webkit-min-device-pixel-ratio: 1.3),',
'       only screen and (min-resolution: 120dpi) {',
'    .rw-pillar--rose .t-Body-title:after,',
'    .rw-pillar--rose.rw-layout--fixed .t-Body-mainContent:before {',
'        background-image: none; /* or background-image: unset; */',
'    }',
'}',
'',
'.rw-pillar--rose .t-Body-title:after,',
'.rw-pillar--rose.rw-layout--fixed .t-Body-mainContent:before {',
'    background-image: none; /* or background-image: unset; */',
'}',
'',
'.t-Body-title:after {',
'    background-color: rgb(245, 130, 32);',
'}'))
,p_step_template=>2979075366320325194
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18701518743502896)
,p_plug_name=>'Bem Vindo'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--featured'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_region_image=>'#APP_FILES#icons/app-icon-512.png	'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18939472633367039)
,p_plug_name=>unistr('Navega\00E7\00E3o')
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--featured force-fa-lg:t-Cards--displayIcons:t-Cards--4cols:t-Cards--hideBody:t-Cards--animColorFill'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>20
,p_location=>null
,p_list_id=>wwv_flow_imp.id(18950111041521059)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>2886769488667748277
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19109515061284229)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(18701518743502896)
,p_button_name=>'Logoff'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Logoff'
,p_button_redirect_url=>'&LOGOUT_URL.'
,p_button_css_classes=>'float my-float'
,p_icon_css_classes=>'fa-sign-out'
);
wwv_flow_imp.component_end;
end;
/
