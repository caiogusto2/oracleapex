prompt --application/pages/page_00101
begin
--   Manifest
--     PAGE: 00101
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>14526457840079170
,p_default_application_id=>109
,p_default_id_offset=>14529182932118536
,p_default_owner=>'YOUR'
);
wwv_flow_imp_page.create_page(
 p_id=>101
,p_name=>unistr('Lista Usu\00E1rio')
,p_alias=>unistr('LISTA-USU\00C1RIO')
,p_step_title=>unistr('Lista Usu\00E1rio')
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(20246401281610631)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Body-title{',
'    background-color: rgb(205, 75, 155);',
'}',
'',
'@media only screen and (-webkit-min-device-pixel-ratio: 1.25),',
'       only screen and (-webkit-min-device-pixel-ratio: 1.3),',
'       only screen and (min-resolution: 120dpi) {',
'    .rw-pillar--rose .t-Body-title:after,',
'    .rw-pillar--rose.rw-layout--fixed .t-Body-mainContent:before {',
'        background-image: none; /* or background-image: unset; */',
'    }',
'}',
'',
'.rw-pillar--rose .t-Body-title:after,',
'.rw-pillar--rose.rw-layout--fixed .t-Body-mainContent:before {',
'    background-image: none; /* or background-image: unset; */',
'}',
'',
'.t-Body-title:after {',
'    background-color: rgb(245, 130, 32);',
'}',
'',
'',
'.botao_rosa{',
'    background-color: rgb(205, 75, 155);',
'    color: white;',
'}'))
,p_step_template=>2526643373347724467
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'22'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(20151178771303239)
,p_plug_name=>unistr('Controle Usu\00E1rios')
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--featured'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(59038990052435128)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(20151811435303243)
,p_plug_name=>'Search Results'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2072724515482255512
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    u."USUARIO_ID",',
'    u."NOME_COMPLETO",',
'    u."EMAIL"',
'    from usuario u',
'--    ,',
'--    v.viagem as viagem',
'--from viagem v',
'--JOIN USUARIO_VIAGEM vu ON v.VIAGEM_ID = vu.VIAGEM_ID',
'--JOIN USUARIO u ON vu.USUARIO_ID = u.USUARIO_ID'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(19110711878284241)
,p_region_id=>wwv_flow_imp.id(20151811435303243)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'NOME_COMPLETO'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'EMAIL'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'INITIALS'
,p_icon_class_column_name=>'NOME_COMPLETO'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(19110980606284243)
,p_card_id=>wwv_flow_imp.id(19110711878284241)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.::P102_USUARIO_ID:&USUARIO_ID.'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(20151960017303243)
,p_plug_name=>'Search'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>4
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(20151811435303243)
,p_landmark_label=>'Filters'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'N',
  'compact_numbers_threshold', '10000',
  'current_facets_selector', '#active_facets',
  'display_chart_for_top_n_values', '10',
  'show_charts', 'Y',
  'show_current_facets', 'E',
  'show_total_row_count', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(20153573769303251)
,p_plug_name=>'Button Bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>'<div id="active_facets"></div>'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19110840635284242)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(20153573769303251)
,p_button_name=>'Adicionar'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>unistr('Adicionar Usu\00E1rio')
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.:::'
,p_button_css_classes=>'botao_rosa'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(20154030125303254)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(20153573769303251)
,p_button_name=>'RESET'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Reset'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:101:&APP_SESSION.::&DEBUG.:RR,101::'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20152447106303246)
,p_name=>'P101_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(20151960017303243)
,p_prompt=>'Search'
,p_source=>'NOME_COMPLETO,ENDERECO,NOME_COMPLETO_EMERG,EMAIL,SENHAPROV'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'collapsed_search_field', 'N',
  'input_field', 'FACET',
  'search_type', 'ROW')).to_clob
,p_fc_collapsible=>false
,p_fc_initial_collapsed=>false
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19111555286284249)
,p_name=>'Close'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(20151811435303243)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19111696773284250)
,p_event_id=>wwv_flow_imp.id(19111555286284249)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(20222379633434602)
,p_name=>'CloseButton'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(19110840635284242)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20222444604434603)
,p_event_id=>wwv_flow_imp.id(20222379633434602)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp.component_end;
end;
/
