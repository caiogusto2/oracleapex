prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>14526457840079170
,p_default_application_id=>109
,p_default_id_offset=>14529182932118536
,p_default_owner=>'YOUR'
);
wwv_flow_imp_page.create_page(
 p_id=>12
,p_name=>'Escolha sua Viagem'
,p_alias=>'CARREGAR-ARQUIVO'
,p_page_mode=>'MODAL'
,p_step_title=>'Escolha sua Viagem'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(20246372532609907)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Button, .t-Button--icon, .t-Button--iconLeft, .t-Button--hot{',
'    background-color: rgb(205, 75, 155);',
'}'))
,p_step_template=>1661186590416509825
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_resizable=>'Y'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18976622426849016)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(18939822884367043)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(18976622426849016)
,p_button_name=>'Carregar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Carregar Di\00E1rio')
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19107353343284207)
,p_button_sequence=>30
,p_button_name=>'Roteiro'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Download Roteiro PDF'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-file-pdf-o'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(18939983063367044)
,p_branch_name=>'Go To Page 1'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(18939822884367043)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18939736171367042)
,p_name=>'P12_CONFIGURACAO'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19107112572284205)
,p_name=>'P12_VIAGEM'
,p_is_required=>true
,p_item_sequence=>10
,p_prompt=>'Escolha sua Viagem'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'       v.VIAGEM DISPLAY,',
'       v.viagem_id request',
'  FROM VIAGEM v',
'  JOIN USUARIO_VIAGEM vu ON v.VIAGEM_ID = vu.VIAGEM_ID',
'  JOIN USUARIO u ON vu.USUARIO_ID = u.USUARIO_ID',
'  where u.usuario_id = :USUARIO_ID;'))
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19107433228284208)
,p_name=>'Click'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(19107353343284207)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20227155221434650)
,p_event_id=>wwv_flow_imp.id(19107433228284208)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19107517001284209)
,p_event_id=>wwv_flow_imp.id(19107433228284208)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DOWNLOAD'
,p_attribute_01=>'N'
,p_attribute_03=>'ATTACHMENT'
,p_attribute_05=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    data,',
'    doc_name,',
'    MIME_TYPE',
'from doc_upload23',
'where doc_name like ''Roteiro%.pdf''',
'and VIAGEM_FK = :P12_VIAGEM;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(19107654953284210)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SETVARIAVEL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    ID NUMBER;',
'BEGIN',
'    BEGIN',
'        SELECT DOC_ID ',
'        INTO ID',
'        FROM DOC_UPLOAD23',
'        WHERE VIAGEM_FK = :P12_VIAGEM',
'          AND DOC_NAME LIKE ''%.json'';',
'        ',
'        :DOC_ID := ID;',
'        :VIAGEM_ID := :P12_VIAGEM;',
'    EXCEPTION',
'        WHEN NO_DATA_FOUND THEN',
'            :P12_CONFIGURACAO := NULL; -- Or handle as needed',
'        WHEN TOO_MANY_ROWS THEN',
'            :P12_CONFIGURACAO := NULL; -- Or handle differently',
'    END;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>19107654953284210
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(18980455391849029)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>18980455391849029
);
wwv_flow_imp.component_end;
end;
/
