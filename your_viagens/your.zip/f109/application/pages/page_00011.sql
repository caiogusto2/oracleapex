prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>14526457840079170
,p_default_application_id=>109
,p_default_id_offset=>14529182932118536
,p_default_owner=>'YOUR'
);
wwv_flow_imp_page.create_page(
 p_id=>11
,p_name=>unistr('Revis\00E3o')
,p_alias=>unistr('REVIS\00C3O')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Revis\00E3o')
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(20246372532609907)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Button, .t-Button--icon, .t-Button--iconRight, .t-Button--hot {',
'        background-color: rgb(205, 75, 155);',
'        box-shadow: rgb(205, 75, 155);',
'}',
'',
'.t-WizardSteps-marker, .t-WizardSteps-label, .t-WizardSteps-step.is-active{',
'    color: rgb(205, 75, 155);',
'}',
'',
'.t-WizardSteps-marker {',
'    box-shadow: inset 0 0 0 1px rgb(205, 75, 155); /* Thinner pink shadow */',
'    color: rgb(205, 75, 155); /* Pink text */',
'    border: 0.5px solid rgb(205, 75, 155); /* Very thin pink border */',
'}',
'',
'.t-WizardSteps-step.is-active .t-WizardSteps-marker {',
'    background-color: rgb(205, 75, 155); /* Pink background */',
'    color: var(--rw-palette-neutral-0); /* Assuming this variable is defined */',
'}',
'',
'.t-WizardSteps-step.is-active .t-WizardSteps-label {',
'    color: rgb(205, 75, 155); /* Pink text */',
'    font-weight: var(--ut-wp-label-active-font-weight, 700);',
'}',
'',
'.t-WizardSteps-step.is-complete .t-WizardSteps-marker {',
'    background-color: rgb(205, 75, 155); /* Pink background */',
'    color: rgb(255, 255, 255); /* White text */',
'    transform: scale(1.2);',
'}',
''))
,p_step_template=>1661186590416509825
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_height=>'400'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'27'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18706590953533130)
,p_plug_name=>unistr('Informa\00E7\00F5es Pessoais')
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    VARIAVEL, ',
'    VALOR, ',
'    STATUS ',
'FROM (',
'    SELECT ',
'        ''Selfie '' AS VARIAVEL, ',
'        CASE ',
'            WHEN SELFIE IS NOT NULL THEN ''Fornecido''',
unistr('            ELSE ''N\00E3o Fornecido'''),
'        END AS VALOR,',
'        CASE ',
'            WHEN SELFIE IS NOT NULL THEN ''fa-check-circle u-success-text''',
'            ELSE ''fa-minus-circle u-danger-text''',
'        END AS STATUS',
'    FROM USUARIO',
'    WHERE USUARIO_ID = :USUARIO_ID',
'',
'    UNION ALL',
'    SELECT ',
'        ''Nome Completo '' AS VARIAVEL, ',
'        CASE ',
'            WHEN NOME_COMPLETO IS NOT NULL THEN ''Fornecido''',
unistr('            ELSE ''N\00E3o Fornecido'''),
'        END AS VALOR,',
'        CASE ',
'            WHEN NOME_COMPLETO IS NOT NULL THEN ''fa-check-circle u-success-text''',
'            ELSE ''fa-minus-circle u-danger-text''',
'        END AS STATUS',
'    FROM USUARIO',
'    WHERE USUARIO_ID = :USUARIO_ID',
'    UNION ALL',
'    SELECT ',
'        ''CPF '' AS VARIAVEL, ',
'        CASE ',
'            WHEN CPF IS NOT NULL THEN ''Fornecido''',
unistr('            ELSE ''N\00E3o Fornecido'''),
'        END AS VALOR,',
'        CASE ',
'            WHEN CPF IS NOT NULL THEN ''fa-check-circle u-success-text''',
'            ELSE ''fa-minus-circle u-danger-text''',
'        END AS STATUS',
'    FROM USUARIO',
'    WHERE USUARIO_ID = :USUARIO_ID',
'    UNION ALL',
'    SELECT ',
'        ''Telefone '', ',
'        CASE ',
'            WHEN TO_CHAR(TELEFONE) IS NOT NULL THEN ''Fornecido''',
unistr('            ELSE ''N\00E3o Fornecido'''),
'        END AS VALOR,        ',
'        CASE ',
'            WHEN TELEFONE IS NOT NULL THEN ''fa-check-circle u-success-text''',
'            ELSE ''fa-minus-circle u-danger-text''',
'        END',
'    FROM USUARIO',
'    WHERE USUARIO_ID = :USUARIO_ID',
'    UNION ALL',
'    SELECT ',
unistr('        ''Endere\00E7o '', '),
'        CASE ',
'            WHEN ENDERECO IS NOT NULL THEN ''Fornecido''',
unistr('            ELSE ''N\00E3o Fornecido'''),
'        END AS VALOR,        ',
'        CASE ',
'            WHEN ENDERECO IS NOT NULL THEN ''fa-check-circle u-success-text''',
'            ELSE ''fa-minus-circle u-danger-text''',
'        END',
'    FROM USUARIO',
'    WHERE USUARIO_ID = :USUARIO_ID',
');',
''))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_CSS_CLASSES', '&STATUS.',
  'AVATAR_ICON', 'fa-assistive-listening-systems',
  'AVATAR_SHAPE', 't-Avatar--noShape',
  'AVATAR_SIZE', 't-Avatar--sm',
  'AVATAR_TYPE', 'icon',
  'BADGE_ALIGNMENT', 't-ContentRow-badge--alignEnd',
  'BADGE_COL_WIDTH', 't-ContentRow-badge--auto',
  'BADGE_LABEL', '&VARIAVEL.',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_POS', 't-ContentRow-badge--posEnd',
  'BADGE_SHAPE', 't-Avatar--noShape',
  'BADGE_SIZE', 't-Badge--md',
  'BADGE_STATE', 'STATUS',
  'BADGE_STYLE', 't-Badge--outline',
  'BADGE_VALUE', 'VARIAVEL',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'Y',
  'HIDE_BORDERS', 'N',
  'REMOVE_PADDING', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(18707188392533136)
,p_name=>'VARIAVEL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VARIAVEL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(18707386393533138)
,p_name=>'STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19107075190284204)
,p_name=>'VALOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VALOR'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18707451330533139)
,p_plug_name=>unistr('Contato de Emerg\00EAncia')
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT VARIAVEL, VALOR, STATUS ',
'FROM (',
'    SELECT ',
'        ''Nome Completo '' AS VARIAVEL, ',
'        NOME_COMPLETO_EMERG AS VALOR,  ',
'        CASE ',
'            WHEN NOME_COMPLETO_EMERG IS NOT NULL THEN ''fa-check-circle u-success-text''',
'            ELSE ''fa-minus-circle u-danger-text''',
'        END AS STATUS',
'    FROM USUARIO',
'    WHERE USUARIO_ID = :USUARIO_ID',
'    UNION ALL',
'    SELECT ',
'        ''Telefone '', ',
'        TO_CHAR(TELEFONE_EMERG),  ',
'        CASE ',
'            WHEN TELEFONE_EMERG IS NOT NULL THEN ''fa-check-circle u-success-text''',
'            ELSE ''fa-minus-circle u-danger-text''',
'        END',
'    FROM USUARIO',
'    WHERE USUARIO_ID = :USUARIO_ID',
');'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_CSS_CLASSES', '&STATUS.',
  'AVATAR_ICON', 'fa-asl-interpreting',
  'AVATAR_SHAPE', 't-Avatar--noShape',
  'AVATAR_SIZE', 't-Avatar--sm',
  'AVATAR_TYPE', 'icon',
  'BADGE_ALIGNMENT', 't-ContentRow-badge--alignEnd',
  'BADGE_COL_WIDTH', 't-ContentRow-badge--auto',
  'BADGE_LABEL', '&VARIAVEL.',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_POS', 't-ContentRow-badge--posEnd',
  'BADGE_SHAPE', 't-Avatar--noShape',
  'BADGE_STATE', 'STATUS',
  'BADGE_STYLE', 't-Badge--outline',
  'BADGE_VALUE', 'VARIAVEL',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'Y',
  'HIDE_BORDERS', 'N',
  'REMOVE_PADDING', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(18707591152533140)
,p_name=>'VARIAVEL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VARIAVEL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(18707650295533141)
,p_name=>'VALOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VALOR'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(18707766022533142)
,p_name=>'STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18707848248533143)
,p_plug_name=>'Documentos Pessoais'
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT STATUS, VARIAVEL, VALOR',
'FROM (',
'',
'    SELECT ',
'        ''Passaporte '' AS VARIAVEL, ',
'        CASE ',
'            WHEN PASSAPORTE IS NOT NULL THEN ''Fornecido''',
unistr('            ELSE ''N\00E3o Fornecido'''),
'        END AS VALOR,',
'        CASE ',
'            WHEN PASSAPORTE IS NOT NULL THEN ''fa-check-circle u-success-text''',
'            ELSE ''fa-minus-circle u-danger-text''',
'        END AS STATUS',
'    FROM USUARIO',
'    WHERE USUARIO_ID = :USUARIO_ID',
'',
'    UNION ALL',
'    SELECT ',
'        ''Foto RG ou CNH '' AS VARIAVEL, ',
'        CASE',
'            WHEN RG_CNH IS NOT NULL THEN ''Fornecido''',
unistr('            ELSE ''N\00E3o Fornecido'''),
'        END AS VALOR,',
'        CASE ',
'            WHEN RG_CNH IS NOT NULL THEN ''fa-check-circle u-success-text''',
'            ELSE ''fa-minus-circle u-danger-text''',
'        END AS STATUS',
'    FROM USUARIO',
'    WHERE USUARIO_ID = :USUARIO_ID',
'',
'    UNION ALL',
'    SELECT ',
'        ''Foto PID '' AS VARIAVEL, ',
'        CASE',
'            WHEN PID IS NOT NULL THEN ''Fornecido''',
unistr('            ELSE ''N\00E3o Fornecido'''),
'        END AS VALOR,',
'        CASE ',
'            WHEN PID IS NOT NULL THEN ''fa-check-circle u-success-text''',
'            ELSE ''fa-minus-circle u-danger-text''',
'        END AS STATUS',
'    FROM USUARIO',
'    WHERE USUARIO_ID = :USUARIO_ID',
'',
'    UNION ALL',
'    SELECT ',
unistr('        ''Comprovante Vacina\00E7\00E3o '' AS VARIAVEL, '),
'        CASE',
'            WHEN VACINACAO IS NOT NULL THEN ''Fornecido''',
unistr('            ELSE ''N\00E3o Fornecido'''),
'        END AS VALOR,',
'        CASE ',
'            WHEN PID IS NOT NULL THEN ''fa-check-circle u-success-text''',
'            ELSE ''fa-minus-circle u-danger-text''',
'        END AS STATUS',
'    FROM USUARIO',
'    WHERE USUARIO_ID = :USUARIO_ID',
'',
'    UNION ALL',
'     SELECT ',
'        ''Seguro Viagem '' AS VARIAVEL, ',
'        CASE',
'            WHEN SEGURO IS NOT NULL THEN ''Fornecido''',
unistr('            ELSE ''N\00E3o Fornecido'''),
'        END AS VALOR,',
'        CASE ',
'            WHEN SEGURO IS NOT NULL THEN ''fa-check-circle u-success-text''',
'            ELSE ''fa-minus-circle u-danger-text''',
'        END AS STATUS',
'    FROM USUARIO',
'    WHERE USUARIO_ID = :USUARIO_ID',
');',
''))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_CSS_CLASSES', '&STATUS.',
  'AVATAR_ICON', 'fa-assistive-listening-systems',
  'AVATAR_SHAPE', 't-Avatar--noShape',
  'AVATAR_SIZE', 't-Avatar--sm',
  'AVATAR_TYPE', 'icon',
  'BADGE_ALIGNMENT', 't-ContentRow-badge--alignEnd',
  'BADGE_COL_WIDTH', 't-ContentRow-badge--auto',
  'BADGE_LABEL', '&VARIAVEL.',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_POS', 't-ContentRow-badge--posEnd',
  'BADGE_SHAPE', 't-Avatar--noShape',
  'BADGE_STATE', 'STATUS',
  'BADGE_STYLE', 't-Badge--outline',
  'BADGE_VALUE', 'VARIAVEL',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'Y',
  'HIDE_BORDERS', 'N',
  'REMOVE_PADDING', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(18707944207533144)
,p_name=>'VARIAVEL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VARIAVEL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(18708012771533145)
,p_name=>'VALOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VALOR'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(18708182116533146)
,p_name=>'STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18768747975720946)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(18753519037720901)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>2010149141494510257
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18768879089720946)
,p_plug_name=>unistr('Revis\00E3o')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18768960856720946)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(18770595314720951)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(18768960856720946)
,p_button_name=>'FINISH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Finalizar'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(18773029116720958)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>18773029116720958
);
wwv_flow_imp.component_end;
end;
/
